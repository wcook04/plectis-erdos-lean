import Definitions.Def_ErdosProblems_Erdos243_ReciprocalTailRigidity
import Definitions.Def_ErdosProblems_Erdos243_GlobalLcmHeight
import Definitions.Def_ErdosProblems_Erdos243_CumulativeLcmTransfer
import Definitions.Def_ErdosProblems_Erdos243_LcmCriticalBoundary
import Definitions.Def_ErdosProblems_Erdos243_LcmRecordCrossing
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR7_Limits
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR7_RealTail
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR7_CanonicalState
import Definitions.Def_ErdosProblems_Erdos243_PrimitiveRecordBarrier
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_RecordDivisibility
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR7_ProductDefect
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR7_LcmDefect
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_GrowthRecordEquivalence
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_CanonicalGrowthBounds
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_CoprimeCores
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_LogLogNormaliser
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_OrbitBlockArithmetic
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_PresievedCRT
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_RecordGcdReduction
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_InclusiveRecordAssembly
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_InclusiveLimsup
import Theorems.Thm_ErdosProblems_Erdos243_PaperCompleteR11_runningMax_shift_at_record
import Theorems.Thm_ErdosProblems_Erdos243_PaperCompleteR11_exists_late_attained_record
import Theorems.Thm_ErdosProblems_Erdos243_PaperCompleteR11_binaryTower_mono
import Theorems.Thm_ErdosProblems_Erdos243_PaperCompleteR11_binaryTower_pos
import Theorems.Thm_ErdosProblems_Erdos243_PaperCompleteR11_binaryTower_succ
import Theorems.Thm_ErdosProblems_Erdos243_PaperCompleteR11_RecordGrowthOrbit_cofinal_inclusive_record
import Theorems.Thm_ErdosProblems_Erdos243_PaperCompleteR11_ereal_limsup_gt_one_of_cofinal
import Theorems.Thm_ErdosProblems_Erdos243_PaperCompleteR11_one_le_recordLogLog
import Theorems.Thm_ErdosProblems_Erdos243_PaperCompleteR11_runningMax_true_increment
import Theorems.Thm_ErdosProblems_Erdos243_PaperCompleteR21_exactOrbit_unbounded_of_error_not_eventually_zero
import Theorems.Thm_ErdosProblems_Erdos243_PaperCompleteR21_exists_multiplier_ge_four
import Theorems.Thm_ErdosProblems_Erdos243_PaperCompleteR21_tail_multiplier_quadratic_lower
import Theorems.Thm_ErdosProblems_Erdos243_PaperCompleteR21_tail_binaryTower_lower
import Mathlib
import Mathlib.Algebra.Order.BigOperators.GroupWithZero.Finset
import Mathlib.Algebra.Ring.Basic
import Mathlib.Analysis.SpecialFunctions.Log.Basic
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Analysis.SumIntegralComparisons
import Mathlib.Data.EReal.Basic
import Mathlib.Data.Fin.Pigeonhole
import Mathlib.Data.Fintype.BigOperators
import Mathlib.Data.Fintype.EquivFin
import Mathlib.Data.Nat.ChineseRemainder
import Mathlib.Data.Nat.Factorization.Basic
import Mathlib.Data.Nat.Find
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.Nat.Totient
import Mathlib.Data.Rat.Defs
import Mathlib.Data.ZMod.Basic
import Mathlib.Order.Filter.AtTopBot.Basic
import Mathlib.Order.LiminfLimsup
import Mathlib.Tactic
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.InfiniteSum.NatInt

namespace ErdosProblems.Erdos243.PaperCompleteR21
end ErdosProblems.Erdos243.PaperCompleteR21

noncomputable section

namespace ErdosProblems.Erdos243.PaperCompleteR21
open Filter
open ErdosProblems.Erdos243
open ErdosProblems.Erdos243.PaperCompleteR11
section
variable (a C D : ℕ → ℕ) (E : ℕ → ℤ)
/-- `D n ≥ 2ⁿ` on an exact orbit with `a n > 1` and `D 0 ≥ 1`. -/
theorem den_ge_two_pow (ha : ∀ n, 1 < a n) (hD0 : 1 ≤ D 0)
    (hD : ∀ n, D (n + 1) = a n * D n) : ∀ n, 2 ^ n ≤ D n := by
  intro n
  induction n with
  | zero => simpa using hD0
  | succ n ih =>
      have h2 : 2 ≤ a n := ha n
      calc (2 : ℕ) ^ (n + 1) = 2 * 2 ^ n := by ring
      _ ≤ a n * D n := Nat.mul_le_mul h2 ih
      _ = D (n + 1) := (hD n).symm
end
section
variable (a C D : ℕ → ℕ) (E : ℕ → ℤ)
/-- `4 |E n| < C n` gives `4 C (n+1) ≤ 5 C n`. -/
theorem tail_four_five (hC : ∀ n, C (n + 1) + D n = a n * C n)
    (hE : ∀ n, E n = centeredState (a n : ℤ) (D n : ℤ) (C n : ℤ))
    (n : ℕ) (hsmall : 4 * Int.natAbs (E n) < C n) :
    4 * C (n + 1) ≤ 5 * C n := by
  have hTail : (C (n + 1) : ℤ) = (C n : ℤ) - E n :=
    natTail_eq_sub_centeredState a C D E hC hE n
  omega
end
section
variable (a C D : ℕ → ℕ) (E : ℕ → ℤ)
/-- `2 |E n| < C n` gives `C (n+1) ≤ 2 C n`. -/
theorem tail_two (hC : ∀ n, C (n + 1) + D n = a n * C n)
    (hE : ∀ n, E n = centeredState (a n : ℤ) (D n : ℤ) (C n : ℤ))
    (n : ℕ) (hsmall : 2 * Int.natAbs (E n) < C n) :
    C (n + 1) ≤ 2 * C n := by
  have hTail : (C (n + 1) : ℤ) = (C n : ℤ) - E n :=
    natTail_eq_sub_centeredState a C D E hC hE n
  omega
end
section
variable (a C D : ℕ → ℕ) (E : ℕ → ℤ)
/-- `a n ≤ 1 + D n`: the multiplier is controlled by the denominator. -/
theorem multiplier_le_den (hCpos : ∀ n, 0 < C n)
    (hC : ∀ n, C (n + 1) + D n = a n * C n)
    (hE : ∀ n, E n = centeredState (a n : ℤ) (D n : ℤ) (C n : ℤ))
    (n : ℕ) (hsmall : 4 * Int.natAbs (E n) < C n) :
    a n ≤ 1 + D n := by
  have h1 : 4 * C (n + 1) ≤ 5 * C n := tail_four_five a C D E hC hE n hsmall
  have h2 : C (n + 1) + D n = a n * C n := hC n
  have h3 : 4 * (a n * C n) ≤ 5 * C n + 4 * D n := by omega
  have h4 : 1 ≤ C n := hCpos n
  nlinarith [h3, h4]
end
section
variable (a C D : ℕ → ℕ) (E : ℕ → ℤ)
/-- `a n ≥ 4` forces `a n ² ≤ 2 a (n+1)`, hence a strict rise. -/
theorem tail_square_step
    (ha : ∀ n, 1 < a n) (hCpos : ∀ n, 0 < C n)
    (hC : ∀ n, C (n + 1) + D n = a n * C n)
    (hD : ∀ n, D (n + 1) = a n * D n)
    (hE : ∀ n, E n = centeredState (a n : ℤ) (D n : ℤ) (C n : ℤ))
    (n : ℕ) (hsmall : 4 * Int.natAbs (E n) < C n) (h4 : 4 ≤ a n) :
    a n ^ 2 ≤ 2 * a (n + 1) := by
  have hkey := tail_multiplier_quadratic_lower a C D E ha hCpos hC hD hE n hsmall
  nlinarith [hkey, h4]
end
/-- A pointwise monotone envelope bounds the running maximum. -/
theorem runningMax_le_of_mono_bound (U B : ℕ → ℕ) (hBmono : Monotone B)
    (h : ∀ j, U j ≤ B j) : ∀ n, runningMax U n ≤ B n := by
  intro n
  induction n with
  | zero => exact h 0
  | succ n ih =>
      show max (runningMax U n) (U (n + 1)) ≤ B (n + 1)
      exact max_le (le_trans ih (hBmono (Nat.le_succ n))) (h (n + 1))
end ErdosProblems.Erdos243.PaperCompleteR21

open ErdosProblems
open ErdosProblems.Erdos243
open ErdosProblems.Erdos243.PaperCompleteR21
open Filter
open ErdosProblems.Erdos243
open ErdosProblems.Erdos243.PaperCompleteR11
open ErdosProblems in
open ErdosProblems.Erdos243 in
open ErdosProblems.Erdos243.PaperCompleteR21 in
theorem solution
    (a C D : ℕ → ℕ) (E : ℕ → ℤ)
    (ha : ∀ n, 1 < a n) (hCpos : ∀ n, 0 < C n) (hD0 : 1 ≤ D 0)
    (hC : ∀ n, C (n + 1) + D n = a n * C n)
    (hD : ∀ n, D (n + 1) = a n * D n)
    (hE : ∀ n, E n = centeredState (a n : ℤ) (D n : ℤ) (C n : ℤ))
    (hvanish : ∀ K, ∃ N, ∀ n, N ≤ n → K * Int.natAbs (E n) < C n)
    (hnot : ¬ ∃ N, ∀ n, N ≤ n → E n = 0) :
    (1 : EReal) < recordTheta C := by
  classical
  have hDpos : ∀ n, 0 < D n := fun n ↦
    lt_of_lt_of_le (pow_pos (by norm_num : (0 : ℕ) < 2) n) (den_ge_two_pow a D ha hD0 hD n)
  have hunb := exactOrbit_unbounded_of_error_not_eventually_zero a C D E hC hD hE hvanish hnot
  obtain ⟨N4, hN4⟩ := hvanish 4
  obtain ⟨N2, hN2⟩ := hvanish 2
  obtain ⟨t, htM, htN, ht4⟩ :=
    exists_multiplier_ge_four a C D E ha hCpos hD0 hC hD hE N4 hN4 (max N4 N2)
  have htower : ∀ k, 2 * binaryTower k ≤ a (t + k) :=
    tail_binaryTower_lower a C D E ha hCpos hC hD hE t (fun n hn ↦ hN4 n (by omega)) ht4
  -- from `t` on, `a` is at least `4` and strictly increasing
  have h4t : ∀ k, 4 ≤ a (t + k) := by
    intro k
    have h := htower k
    have hbt : 1 ≤ binaryTower k := binaryTower_pos k
    have hbt2 : 2 ≤ binaryTower k := by
      have := binaryTower_mono (Nat.zero_le k)
      simpa [binaryTower] using this
    omega
  have hrise : ∀ k, a (t + k) < a (t + k + 1) := by
    intro k
    have hsq := tail_square_step a C D E ha hCpos hC hD hE (t + k)
      (hN4 (t + k) (by omega)) (h4t k)
    have h4 := h4t k
    nlinarith [hsq, h4]
  -- choose a late index attaining a global record of `C`
  obtain ⟨s, hst, hsrec⟩ := exists_late_attained_record C hunb t
  -- the shifted orbit
  set a' : ℕ → ℕ := fun n ↦ a (s + n) with ha'
  set C' : ℕ → ℕ := fun n ↦ C (s + n) with hC'
  set D' : ℕ → ℕ := fun n ↦ D (s + n) with hD'
  have hshift : ∀ m : ℕ, s + (m + 1) = (s + m) + 1 := fun m ↦ by omega
  have hC1 : ∀ n, C' (n + 1) + D' n = a' n * C' n := by
    intro n
    simp only [ha', hC', hD', hshift]
    exact hC (s + n)
  have hD1 : ∀ n, D' (n + 1) = a' n * D' n := by
    intro n
    simp only [ha', hD', hshift]
    exact hD (s + n)
  -- `increasing`
  have hinc : StrictMono a' := by
    apply strictMono_nat_of_lt_succ
    intro n
    have hk : s + n = t + ((s - t) + n) := by omega
    have h := hrise ((s - t) + n)
    simp only [ha']
    rw [hk, hshift n, hk]
    exact h
  -- `lower`
  have hlower : ∃ N : ℕ, ∀ k, 2 * binaryTower k ≤ a' (N + k) := by
    refine ⟨0, fun k ↦ ?_⟩
    have hk : s + (0 + k) = t + ((s - t) + k) := by omega
    have h := htower ((s - t) + k)
    have hmono : binaryTower k ≤ binaryTower ((s - t) + k) := binaryTower_mono (by omega)
    simp only [ha']
    rw [hk]
    omega
  -- `record_bound`
  have hrecb : ∃ K : ℕ, ∀ n, runningMax C' n ≤ 2 ^ (K + n) := by
    obtain ⟨K, hK⟩ : ∃ K : ℕ, C' 0 ≤ 2 ^ K := ⟨C' 0, Nat.le_of_lt Nat.lt_two_pow_self⟩
    refine ⟨K, ?_⟩
    have hpt : ∀ j, C' j ≤ 2 ^ (K + j) := by
      intro j
      induction j with
      | zero => simpa using hK
      | succ j ih =>
          have hstep : C' (j + 1) ≤ 2 * C' j := by
            simp only [hC', hshift]
            exact tail_two a C D E hC hE (s + j) (hN2 (s + j) (by omega))
          have : 2 * C' j ≤ 2 * 2 ^ (K + j) := Nat.mul_le_mul (le_refl _) ih
          have he : (2 : ℕ) * 2 ^ (K + j) = 2 ^ (K + (j + 1)) := by
            rw [show K + (j + 1) = (K + j) + 1 by omega, pow_succ]; ring
          omega
    exact runningMax_le_of_mono_bound C' (fun n ↦ 2 ^ (K + n))
      (fun i j hij ↦ Nat.pow_le_pow_right (by norm_num) (by omega)) hpt
  -- `den_bound`
  have hdenb : ∃ L : ℕ, ∀ n, D' n ≤ binaryTower (n + L) := by
    obtain ⟨L, hL⟩ : ∃ L : ℕ, 2 * D' 0 ≤ binaryTower L := by
      refine ⟨2 * D' 0, ?_⟩
      calc 2 * D' 0 ≤ 2 ^ (2 * D' 0) := Nat.le_of_lt Nat.lt_two_pow_self
      _ ≤ 2 ^ (2 ^ (2 * D' 0)) :=
          Nat.pow_le_pow_right (by norm_num) (Nat.le_of_lt Nat.lt_two_pow_self)
    refine ⟨L, fun n ↦ ?_⟩
    have hstrong : ∀ m, 2 * D' m ≤ binaryTower (m + L) := by
      intro m
      induction m with
      | zero => simpa using hL
      | succ m ih =>
          have hale : a' m ≤ 1 + D' m := by
            simp only [ha', hD']
            exact multiplier_le_den a C D E hCpos hC hE (s + m) (hN4 (s + m) (by omega))
          have hDp : 0 < D' m := hDpos (s + m)
          have hnext : 2 * D' (m + 1) ≤ (2 * D' m) ^ 2 := by
            rw [hD1 m]
            nlinarith [hale, hDp]
          have hsq : (2 * D' m) ^ 2 ≤ (binaryTower (m + L)) ^ 2 :=
            Nat.pow_le_pow_left ih 2
          have hbt : (binaryTower (m + L)) ^ 2 = binaryTower ((m + 1) + L) := by
            rw [show (m + 1) + L = (m + L) + 1 by omega, binaryTower_succ]
          omega
    have := hstrong n
    omega
  -- `unbounded`
  have hunb' : ∀ H : ℕ, ∃ n, H ≤ C' n := by
    intro H
    obtain ⟨m, hm⟩ := hunb (H + runningMax C s + 1)
    have hms : s < m := by
      by_contra hcon
      have := le_runningMax C (show m ≤ s by omega)
      omega
    refine ⟨m - s, ?_⟩
    simp only [hC', show s + (m - s) = m by omega]
    omega
  -- the orbit object
  let O : RecordGrowthOrbit :=
    { a := a', U := C', D := D'
      increasing := fun i j hij ↦ hinc hij
      a_pos := fun n ↦ lt_trans Nat.zero_lt_one (ha (s + n))
      U_pos := fun n ↦ hCpos (s + n)
      D_pos := fun n ↦ hDpos (s + n)
      U_step := hC1
      D_step := hD1
      lower := hlower
      record_bound := hrecb
      den_bound := hdenb
      unbounded := hunb' }
  have hOfun : O.U = C' := rfl
  have hrm : ∀ m, runningMax C' m = runningMax C (s + m) := by
    intro m
    simp only [hC']
    exact runningMax_shift_at_record C s hsrec m
  obtain ⟨c, hc, hcof⟩ := O.cofinal_inclusive_record
  apply ereal_limsup_gt_one_of_cofinal
  refine ⟨c, hc, fun T ↦ ?_⟩
  obtain ⟨n, hn, hnew, hgap⟩ := hcof T
  refine ⟨s + n, by omega, ?_⟩
  have hgap' : c * recordLogLog (runningMax C (s + n))
      < ((C (s + n + 1) - runningMax C (s + n) : ℕ) : ℝ) := by
    have h := hgap
    rw [hOfun, hrm n] at h
    simpa [hC'] using h
  have hden : 0 < recordLogLog (runningMax C (s + n)) :=
    lt_of_lt_of_le (by norm_num) (one_le_recordLogLog _)
  unfold recordLogLogCharge
  rw [runningMax_true_increment]
  exact (lt_div_iff₀ hden).2 hgap'
