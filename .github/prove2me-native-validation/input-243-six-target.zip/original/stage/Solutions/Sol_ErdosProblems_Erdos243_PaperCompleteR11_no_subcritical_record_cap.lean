import Definitions.Def_ErdosProblems_Erdos243_ReciprocalTailRigidity
import Definitions.Def_ErdosProblems_Erdos243_GlobalLcmHeight
import Definitions.Def_ErdosProblems_Erdos243_CumulativeLcmTransfer
import Definitions.Def_ErdosProblems_Erdos243_LcmCriticalBoundary
import Definitions.Def_ErdosProblems_Erdos243_LcmRecordCrossing
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR7_Limits
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR7_RealTail
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR7_CanonicalState
import Definitions.Def_ErdosProblems_Erdos243_PrimitiveRecordBarrier
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_RecordDivisibility
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR7_ProductDefect
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR7_LcmDefect
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_GrowthRecordEquivalence
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_CanonicalGrowthBounds
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_CoprimeCores
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_LogLogNormaliser
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_OrbitBlockArithmetic
import Theorems.Thm_ErdosProblems_Erdos243_PaperCompleteR11_eventual_quadratic_budget
import Theorems.Thm_ErdosProblems_Erdos243_PaperCompleteR11_multiplier_block_old
import Theorems.Thm_ErdosProblems_Erdos243_PaperCompleteR11_recordLogLog_nat_mul_mono
import Theorems.Thm_ErdosProblems_Erdos243_PaperCompleteR11_scaled_crt_height_logLog
import Theorems.Thm_ErdosProblems_Erdos243_PaperCompleteR11_coprime_core_record_fence
import Theorems.Thm_ErdosProblems_Erdos243_PaperCompleteR11_index_le_binaryTower
import Theorems.Thm_ErdosProblems_Erdos243_PaperCompleteR11_multiplier_block_product_le_denominator
import Theorems.Thm_ErdosProblems_Erdos243_PaperCompleteR11_multiplier_gcd_le_terminal_record
import Theorems.Thm_ErdosProblems_Erdos243_PaperCompleteR11_square_block_core_size
import Mathlib
import Mathlib.Algebra.Order.BigOperators.GroupWithZero.Finset
import Mathlib.Algebra.Ring.Basic
import Mathlib.Analysis.SpecialFunctions.Log.Basic
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Analysis.SumIntegralComparisons
import Mathlib.Data.Fin.Pigeonhole
import Mathlib.Data.Fintype.BigOperators
import Mathlib.Data.Nat.ChineseRemainder
import Mathlib.Data.Nat.Factorization.Basic
import Mathlib.Data.Nat.Find
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.Rat.Defs
import Mathlib.Data.ZMod.Basic
import Mathlib.Order.Filter.AtTopBot.Basic
import Mathlib.Tactic
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.InfiniteSum.NatInt

namespace PaperCompleteR7
end PaperCompleteR7

/-!
# The nonprimitive coefficient-one lower boundary


This module performs the growing-block selection and the logarithmic
composition, rather than taking the needed block as a hypothesis. The
canonical corollary derives all growth budgets from the original series.
It proves the subcritical part, not the strict primitive amplification
which is needed for the inclusive coefficient-one endpoint.
-/

namespace ErdosProblems.Erdos243.PaperCompleteR11
open Filter PaperCompleteR7
open scoped BigOperators Topology
end ErdosProblems.Erdos243.PaperCompleteR11

open Filter PaperCompleteR7
open scoped BigOperators Topology
open ErdosProblems in
open ErdosProblems.Erdos243 in
open ErdosProblems.Erdos243.PaperCompleteR11 in
open ErdosProblems.Erdos243.PaperCompleteR7 in
theorem solution
    (a U D : ℕ → ℕ) (ha : StrictMono a)
    (hapos : ∀ n, 0 < a n) (hUpos : ∀ n, 0 < U n) (hDpos : ∀ n, 0 < D n)
    (hU : ∀ n, U (n + 1) + D n = a n * U n)
    (hD : ∀ n, D (n + 1) = a n * D n)
    (hlower : ∃ N : ℕ, ∀ k, 2 * binaryTower k ≤ a (N + k))
    (hrecord : ∃ K : ℕ, ∀ n, runningMax U n ≤ 2 ^ (K + n))
    (hden : ∃ L : ℕ, ∀ n, D n ≤ binaryTower (n + L))
    (hunbounded : ∀ H : ℕ, ∃ n, H ≤ U n)
    (g : ℕ) (c : ℝ) (hc0 : 0 ≤ c) (hc1 : c < 1) :
    ¬ ∃ T : ℕ, ∀ n, T ≤ n → runningMax U n < U (n + 1) →
      ((U (n + 1) - runningMax U n : ℕ) : ℝ) ≤
        c * recordLogLog (g * runningMax U n : ℕ) := by
  rintro ⟨T, hcap⟩
  obtain ⟨N, hN⟩ := hlower
  obtain ⟨K, hK⟩ := hrecord
  obtain ⟨L, hL⟩ := hden
  obtain ⟨k₀, hk₀⟩ := eventual_quadratic_budget c 1 1 (N + L + g + 2) hc0
    (by simpa only [Nat.cast_one, mul_one] using hc1)
  let t := max 5 (max (K + N) (T + k₀))
  let k := 2 ^ t
  let B := k ^ 2
  let J := N + k
  let M := J + B
  let A : Fin B → ℕ := fun i ↦ a (J + i)
  have ht5 : 5 ≤ t := le_max_left _ _
  have htK : K + N ≤ t := (le_max_left _ _).trans (le_max_right _ _)
  have htT : T + k₀ ≤ t := (le_max_right _ _).trans (le_max_right _ _)
  have htk : t ≤ k := by have := index_succ_le_two_pow t; dsimp [k]; omega
  have hKN : K + N ≤ k := htK.trans htk
  have hk₀k : k₀ ≤ k := by omega
  have hTM : T ≤ M := by dsimp [M, J, B]; omega
  have hB : 0 < B := by dsimp [B, k]; positivity
  have hApos : ∀ i, 0 < A i := fun i ↦ hapos _
  have hAlower : ∀ i, 2 * binaryTower k ≤ A i := by
    intro i
    exact (hN k).trans (ha.monotone (by dsimp [J]; omega))
  have hpair : ∀ i j : Fin B, i ≠ j → Nat.gcd (A i) (A j) ≤ runningMax U M := by
    intro i j hij
    apply multiplier_gcd_le_terminal_record a U D hU hD hUpos
    · intro heq
      apply hij
      apply Fin.ext
      dsimp [A, J] at heq
      omega
    · dsimp [M]; have := i.isLt; omega
    · dsimp [M]; have := j.isLt; omega
  have hlarge : ∀ i, max B (runningMax U M) * (runningMax U M) ^ (B - 1) < A i :=
    square_block_core_size U K N t ht5 hKN (hK M) A hAlower
  have hUI : ∀ n, (U (n + 1) : ℤ) = (a n : ℤ) * U n - (1 : ℤ) * D n := by
    intro n
    have hh : (U (n + 1) : ℤ) + D n = (a n : ℤ) * U n := by exact_mod_cast hU n
    linarith
  have hDI : ∀ n, (D (n + 1) : ℤ) = (a n : ℤ) * D n := by
    intro n
    exact_mod_cast hD n
  obtain ⟨x, P, hPx, hxP, hPA, hRx, hfence⟩ :=
    coprime_core_record_fence U (fun n ↦ (D n : ℤ)) (fun n ↦ (a n : ℤ))
      (fun _ ↦ 1) M B (runningMax U M) hB A hApos hUI hDI hpair hlarge
      (fun i n hn ↦ Int.natCast_dvd_natCast.mpr (multiplier_block_old a D hD J B i n hn))
  have hPD : P ≤ D M := hPA.trans (multiplier_block_product_le_denominator a D hD hDpos J B)
  have hPtower : P ≤ binaryTower (M + L) := hPD.trans (hL M)
  have hBtower : B ≤ binaryTower (M + L) :=
    (show B ≤ M + L by dsimp [M]; omega).trans (index_le_binaryTower (M + L))
  have hheight := scaled_crt_height_logLog g P B (M + L) hPtower hBtower
  have hbudget : c * (M + L + g + 2 : ℕ) ≤ (B : ℝ) := by
    have hh := hk₀ k hk₀k
    dsimp [M, J, B]
    push_cast
    push_cast at hh
    nlinarith
  have hbounded : ∀ n, U n < x + B := by
    apply hfence
    intro n hn hR hnew
    have hfirst := hcap n (hTM.trans hn) hnew
    have hRheight : recordLogLog (g * runningMax U n : ℕ) ≤
        recordLogLog (g * (2 * P + B) : ℕ) :=
      recordLogLog_nat_mul_mono g (by omega)
    have hfinal : ((U (n + 1) - runningMax U n : ℕ) : ℝ) ≤ (B : ℝ) :=
      hfirst.trans ((mul_le_mul_of_nonneg_left (hRheight.trans hheight) hc0).trans hbudget)
    exact_mod_cast hfinal
  obtain ⟨n, hn⟩ := hunbounded (x + B)
  exact (not_lt_of_ge hn) (hbounded n)
