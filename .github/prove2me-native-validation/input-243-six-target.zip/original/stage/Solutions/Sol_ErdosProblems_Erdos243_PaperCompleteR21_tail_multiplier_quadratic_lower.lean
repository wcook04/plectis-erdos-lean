import Definitions.Def_ErdosProblems_Erdos243_ReciprocalTailRigidity
import Definitions.Def_ErdosProblems_Erdos243_GlobalLcmHeight
import Definitions.Def_ErdosProblems_Erdos243_CumulativeLcmTransfer
import Definitions.Def_ErdosProblems_Erdos243_LcmCriticalBoundary
import Definitions.Def_ErdosProblems_Erdos243_LcmRecordCrossing
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR7_Limits
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR7_RealTail
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR7_CanonicalState
import Definitions.Def_ErdosProblems_Erdos243_PrimitiveRecordBarrier
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_RecordDivisibility
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR7_ProductDefect
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR7_LcmDefect
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_GrowthRecordEquivalence
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_CanonicalGrowthBounds
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_CoprimeCores
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_LogLogNormaliser
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_OrbitBlockArithmetic
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_PresievedCRT
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_RecordGcdReduction
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_InclusiveRecordAssembly
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_InclusiveLimsup
import Mathlib
import Mathlib.Algebra.Order.BigOperators.GroupWithZero.Finset
import Mathlib.Algebra.Ring.Basic
import Mathlib.Analysis.SpecialFunctions.Log.Basic
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Analysis.SumIntegralComparisons
import Mathlib.Data.EReal.Basic
import Mathlib.Data.Fin.Pigeonhole
import Mathlib.Data.Fintype.BigOperators
import Mathlib.Data.Fintype.EquivFin
import Mathlib.Data.Nat.ChineseRemainder
import Mathlib.Data.Nat.Factorization.Basic
import Mathlib.Data.Nat.Find
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.Nat.Totient
import Mathlib.Data.Rat.Defs
import Mathlib.Data.ZMod.Basic
import Mathlib.Order.Filter.AtTopBot.Basic
import Mathlib.Order.LiminfLimsup
import Mathlib.Tactic
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.InfiniteSum.NatInt

namespace ErdosProblems.Erdos243.PaperCompleteR21
end ErdosProblems.Erdos243.PaperCompleteR21

noncomputable section

namespace ErdosProblems.Erdos243.PaperCompleteR21
open Filter
open ErdosProblems.Erdos243
open ErdosProblems.Erdos243.PaperCompleteR11
variable (a C D : ℕ → ℕ) (E : ℕ → ℤ)
end ErdosProblems.Erdos243.PaperCompleteR21

open ErdosProblems
open ErdosProblems.Erdos243
open ErdosProblems.Erdos243.PaperCompleteR21
open Filter
open ErdosProblems.Erdos243
open ErdosProblems.Erdos243.PaperCompleteR11
variable (a C D : ℕ → ℕ) (E : ℕ → ℤ)
open ErdosProblems in
open ErdosProblems.Erdos243 in
open ErdosProblems.Erdos243.PaperCompleteR21 in
theorem solution
    (ha : ∀ n, 1 < a n) (hCpos : ∀ n, 0 < C n)
    (hC : ∀ n, C (n + 1) + D n = a n * C n)
    (hD : ∀ n, D (n + 1) = a n * D n)
    (hE : ∀ n, E n = centeredState (a n : ℤ) (D n : ℤ) (C n : ℤ))
    (n : ℕ) (hsmall : 4 * Int.natAbs (E n) < C n) :
    4 * a n ^ 2 ≤ 5 * a (n + 1) + 5 * a n := by
  have hTail : (C (n + 1) : ℤ) = (C n : ℤ) - E n :=
    natTail_eq_sub_centeredState a C D E hC hE n
  have hEdef : E n = (D n : ℤ) - ((a n : ℤ) - 1) * (C n : ℤ) := by
    rw [hE n, centeredState]
  have hEbound : -((C n : ℤ)) < 4 * E n ∧ 4 * E n < (C n : ℤ) := by omega
  have hCn : (0 : ℤ) < (C n : ℤ) := by exact_mod_cast hCpos n
  have hCn1 : (0 : ℤ) < (C (n + 1) : ℤ) := by exact_mod_cast hCpos (n + 1)
  have hCn2 : (0 : ℤ) ≤ (C (n + 2) : ℤ) := Int.natCast_nonneg _
  have hAnn : (0 : ℤ) ≤ (a (n + 1) : ℤ) := Int.natCast_nonneg _
  have hAn : (2 : ℤ) ≤ (a n : ℤ) := by exact_mod_cast ha n
  -- `4 C (n+1) ≤ 5 C n`
  have h1 : (4 : ℤ) * (C (n + 1) : ℤ) ≤ 5 * (C n : ℤ) := by omega
  -- `(4 a n - 5) C n ≤ 4 D n`
  have h2 : (4 * (a n : ℤ) - 5) * (C n : ℤ) ≤ 4 * (D n : ℤ) := by
    have := hEbound.1
    nlinarith [hEdef]
  -- `a (n+1) C (n+1) = C (n+2) + a n D n`
  have h3 : (a (n + 1) : ℤ) * (C (n + 1) : ℤ)
      = (C (n + 2) : ℤ) + (a n : ℤ) * (D n : ℤ) := by
    have e1 : ((C (n + 2) + D (n + 1) : ℕ) : ℤ) = ((a (n + 1) * C (n + 1) : ℕ) : ℤ) := by
      exact_mod_cast congrArg (fun t : ℕ ↦ (t : ℤ)) (hC (n + 1))
    have e2 : ((D (n + 1) : ℕ) : ℤ) = ((a n * D n : ℕ) : ℤ) := by
      exact_mod_cast congrArg (fun t : ℕ ↦ (t : ℤ)) (hD n)
    push_cast at e1 e2
    linarith
  -- assemble
  have hbig : (4 * (a n : ℤ) ^ 2 - 5 * (a n : ℤ)) * (C n : ℤ)
      ≤ (5 * (a (n + 1) : ℤ)) * (C n : ℤ) := by
    nlinarith [mul_le_mul_of_nonneg_left h1 hAnn, mul_le_mul_of_nonneg_left h2
      (le_trans (by norm_num : (0:ℤ) ≤ 2) hAn), h3, hCn2]
  have hdiv := le_of_mul_le_mul_right hbig hCn
  have hfinal : (4 : ℤ) * (a n : ℤ) ^ 2 ≤ 5 * (a (n + 1) : ℤ) + 5 * (a n : ℤ) := by
    linarith
  exact_mod_cast hfinal
