import Definitions.Def_ErdosProblems_Erdos243_ReciprocalTailRigidity
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR7_Limits
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR7_RealTail
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR7_CanonicalState
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR7_ProductDefect
import Theorems.Thm_ErdosProblems_Erdos243_PaperCompleteR7_prefix_over_square_tendsto_zero
import Mathlib.Algebra.Order.BigOperators.GroupWithZero.Finset
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Data.Fin.Pigeonhole
import Mathlib.Data.Nat.ChineseRemainder
import Mathlib.Data.Nat.Find
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.ZMod.Basic
import Mathlib.Order.Filter.AtTopBot.Basic
import Mathlib.Tactic
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.InfiniteSum.NatInt

/-!
# The original-coordinate bounded-product-defect corollary

Compiled candidates.  This module supplies the analytic error dictionary
rather than assuming bounded centred error.  Finite upper limsup is stated
as eventual boundedness above by a real constant; the finite initial
segment is irrelevant.  Rationality is given by p/q and HasSum.

The proof avoids assuming a pre-existing double-exponential estimate:
P_n/a_n^2 tends to zero by its successive-ratio identity.  This suffices
for the exact two-term error dictionary.
-/

namespace ErdosProblems.Erdos243.PaperCompleteR7
open Filter
open scoped BigOperators







/-- Exact two-term algebra behind E_n + q Q_n, before limiting. -/
theorem two_term_defect_identity
    (a aNext P q x x2 : ℝ) (ha : a ≠ 0) (haNext : aNext ≠ 0)
    (hx : x = 1 / a + 1 / aNext + x2) :
    q * P - (a - 1) * (q * P * x) + q * (P / a * (a ^ 2 / aNext - 1)) =
      q * (P / aNext - P * (a - 1) * x2) := by
  rw [hx]
  field_simp [ha, haNext]
  <;> ring
end ErdosProblems.Erdos243.PaperCompleteR7

open Filter
open scoped BigOperators
open ErdosProblems in
open ErdosProblems.Erdos243 in
open ErdosProblems.Erdos243.PaperCompleteR7 in
theorem solution
    (a : ℕ → ℕ) (ha : StrictMono a) (hpos : ∀ n, 0 < a n)
    (p : ℤ) (q : ℕ) (hqpos : 0 < q)
    (hs : HasSum (fun n ↦ 1 / (a n : ℝ)) ((p : ℝ) / (q : ℝ)))
    (hgrowth : Tendsto (fun n ↦ (a (n + 1) : ℝ) / (a n : ℝ) ^ 2)
      atTop (nhds 1)) :
    let C := canonicalNaturalNumerator a p q
    let D := canonicalDenominator a q
    let E := fun n ↦ centeredState (a n : ℤ) (D n : ℤ) (C n : ℤ)
    Tendsto (fun n ↦ (E n : ℝ) + (q : ℝ) * productDefect a n)
      atTop (nhds 0) := by
  let t : ℕ → ℝ := fun n ↦ 1 / (a n : ℝ)
  let C := canonicalNaturalNumerator a p q
  let D := canonicalDenominator a q
  let E := fun n ↦ centeredState (a n : ℤ) (D n : ℤ) (C n : ℤ)
  obtain ⟨hcpos, hdpos, hc, hd, hrep⟩ := canonical_integer_tail a hpos p q hqpos hs
  have hinv : Tendsto (fun n ↦ (a n : ℝ)⁻¹) atTop (nhds 0) :=
    tendsto_inv_atTop_zero.comp (strictMono_nat_cast_tendsto_atTop a ha hpos)
  have hq : Tendsto (fun n ↦ (a n : ℝ) ^ 2 / (a (n + 1) : ℝ))
      atTop (nhds 1) := by
    simpa only [inv_div, inv_one] using hgrowth.inv₀ (by norm_num : (1 : ℝ) ≠ 0)
  have hqnext := hq.comp (shift_tendsto_atTop 1)
  have hscale := prefix_over_square_tendsto_zero a ha hpos hgrowth
  have hsmall := reciprocal_successive_ratio_tendsto_zero a ha hpos hgrowth
  have hfirst : Tendsto (fun n ↦ (prefixProduct a n : ℝ) / (a (n + 1) : ℝ))
      atTop (nhds 0) := by
    have hz := hscale.mul hq
    have hz' : Tendsto (fun n ↦
        ((prefixProduct a n : ℝ) / (a n : ℝ) ^ 2) *
          ((a n : ℝ) ^ 2 / (a (n + 1) : ℝ))) atTop (nhds 0) := by
      simpa only [zero_mul] using hz
    apply hz'.congr'
    exact Filter.Eventually.of_forall fun n ↦ by
      have h0 : (a n : ℝ) ≠ 0 := by exact_mod_cast (hpos n).ne'
      have h1 : (a (n + 1) : ℝ) ≠ 0 := by exact_mod_cast (hpos (n + 1)).ne'
      field_simp [h0, h1]
      <;> ring
  have hprod : Tendsto (fun n ↦
      (prefixProduct a n : ℝ) * (a n : ℝ) / (a (n + 2) : ℝ))
      atTop (nhds 0) := by
    have hz := ((hscale.mul hq).mul hqnext).mul hsmall
    have hz' : Tendsto (fun n ↦
        (((prefixProduct a n : ℝ) / (a n : ℝ) ^ 2) *
          ((a n : ℝ) ^ 2 / (a (n + 1) : ℝ))) *
          ((a (n + 1) : ℝ) ^ 2 / (a (n + 2) : ℝ)) *
          ((1 / (a (n + 1) : ℝ)) / (1 / (a n : ℝ))))
        atTop (nhds 0) := by
      simpa only [zero_mul, Function.comp_apply, Nat.add_assoc] using hz
    apply hz'.congr'
    exact Filter.Eventually.of_forall fun n ↦ by
      have h0 : (a n : ℝ) ≠ 0 := by exact_mod_cast (hpos n).ne'
      have h1 : (a (n + 1) : ℝ) ≠ 0 := by exact_mod_cast (hpos (n + 1)).ne'
      have h2 : (a (n + 2) : ℝ) ≠ 0 := by exact_mod_cast (hpos (n + 2)).ne'
      field_simp [h0, h1, h2]
      <;> ring
  have hrel : Tendsto (fun n ↦ (a n : ℝ) * realTail t n) atTop (nhds 1) := by
    have hh := realTail_div_term_tendsto_one t hs.summable
      (fun n ↦ one_div_pos.mpr (by exact_mod_cast hpos n)) hsmall
    simpa only [t, one_div, div_inv_eq_mul, mul_comm] using hh
  have hsecond : Tendsto (fun n ↦
      (prefixProduct a n : ℝ) * ((a n : ℝ) - 1) * realTail t (n + 2))
      atTop (nhds 0) := by
    have hfactor : Tendsto (fun n ↦ 1 - (a n : ℝ)⁻¹) atTop (nhds 1) := by
      simpa only [sub_zero] using
        (tendsto_const_nhds (x := (1 : ℝ))).sub hinv
    have hz := (hprod.mul hfactor).mul (hrel.comp (shift_tendsto_atTop 2))
    have hz' : Tendsto (fun n ↦
        ((prefixProduct a n : ℝ) * (a n : ℝ) / (a (n + 2) : ℝ)) *
          (1 - (a n : ℝ)⁻¹) * ((a (n + 2) : ℝ) * realTail t (n + 2)))
        atTop (nhds 0) := by
      simpa only [zero_mul, Function.comp_apply] using hz
    apply hz'.congr'
    exact Filter.Eventually.of_forall fun n ↦ by
      have h0 : (a n : ℝ) ≠ 0 := by exact_mod_cast (hpos n).ne'
      have h2 : (a (n + 2) : ℝ) ≠ 0 := by exact_mod_cast (hpos (n + 2)).ne'
      field_simp [h0, h2]
      <;> ring
  have hdict : ∀ n, (E n : ℝ) + (q : ℝ) * productDefect a n =
      (q : ℝ) * ((prefixProduct a n : ℝ) / (a (n + 1) : ℝ) -
        (prefixProduct a n : ℝ) * ((a n : ℝ) - 1) * realTail t (n + 2)) := by
    intro n
    have h0 : (a n : ℝ) ≠ 0 := by exact_mod_cast (hpos n).ne'
    have h1 : (a (n + 1) : ℝ) ≠ 0 := by exact_mod_cast (hpos (n + 1)).ne'
    have htail : realTail t n = 1 / (a n : ℝ) + 1 / (a (n + 1) : ℝ) +
        realTail t (n + 2) := by
      rw [realTail_step t hs.summable n, realTail_step t hs.summable (n + 1)]
      simp only [t, Nat.add_assoc]
      ring
    have hecast : (E n : ℝ) = (D n : ℝ) - ((a n : ℝ) - 1) * (C n : ℝ) := by
      simp [E, centeredState]
    rw [hecast, hrep n]
    simp only [D, canonicalDenominator, Nat.cast_mul]
    exact two_term_defect_identity (a n : ℝ) (a (n + 1) : ℝ)
      (prefixProduct a n : ℝ) (q : ℝ) (realTail t n) (realTail t (n + 2))
      h0 h1 htail
  have hz := (tendsto_const_nhds (x := (q : ℝ))).mul (hfirst.sub hsecond)
  have hz' : Tendsto (fun n ↦ (q : ℝ) *
      ((prefixProduct a n : ℝ) / (a (n + 1) : ℝ) -
       (prefixProduct a n : ℝ) * ((a n : ℝ) - 1) * realTail t (n + 2)))
      atTop (nhds 0) := by simpa only [sub_self, mul_zero] using hz
  apply hz'.congr'
  exact Filter.Eventually.of_forall fun n ↦ (hdict n).symm
