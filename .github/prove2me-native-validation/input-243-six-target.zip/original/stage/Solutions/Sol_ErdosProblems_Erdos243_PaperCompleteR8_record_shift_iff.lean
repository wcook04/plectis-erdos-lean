import Definitions.Def_ErdosProblems_Erdos243_ReciprocalTailRigidity
import Definitions.Def_ErdosProblems_Erdos243_LcmRecordCrossing
import Definitions.Def_ErdosProblems_Erdos243_LcmRecordDivergence
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR7_Limits
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR7_RealTail
import Definitions.Def_ErdosProblems_Erdos243_PrimitiveRecordBarrier
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR8_WeightAnalysis
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR8_WeightedRecords
import Mathlib
import Mathlib.Algebra.Order.BigOperators.GroupWithZero.Finset
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Analysis.SumIntegralComparisons
import Mathlib.Data.Fin.Pigeonhole
import Mathlib.Data.Nat.ChineseRemainder
import Mathlib.Data.Nat.Factorization.Basic
import Mathlib.Data.Nat.Find
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.ZMod.Basic
import Mathlib.Order.Filter.AtTopBot.Basic
import Mathlib.Tactic
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.InfiniteSum.NatInt
import Mathlib.Topology.Algebra.InfiniteSum.Real

namespace ErdosProblems.Erdos243.PaperCompleteR8
open Filter Classical
open scoped BigOperators
end ErdosProblems.Erdos243.PaperCompleteR8

open ErdosProblems
open ErdosProblems.Erdos243
open ErdosProblems.Erdos243.PaperCompleteR8
open Filter Classical
open scoped BigOperators
open ErdosProblems in
open ErdosProblems.Erdos243 in
open ErdosProblems.Erdos243.PaperCompleteR8 in
theorem solution
    (U : ℕ → ℕ) (T n : ℕ) (hT : ∀ j, j ≤ T → U j ≤ U T) :
    Record (fun k => U (T + k)) n ↔ Record U (T + n) := by
  constructor
  · intro hr j hj
    by_cases hbefore : j ≤ T
    · have h0 := hr 0 (Nat.zero_le n)
      simp only [Nat.add_zero] at h0
      exact (hT j hbefore).trans_lt (by simpa only [Nat.add_assoc] using h0)
    · have hTj : T ≤ j := by omega
      have hidx : j - T ≤ n := by omega
      have hh := hr (j - T) hidx
      dsimp only at hh
      rw [Nat.add_sub_of_le hTj] at hh
      simpa only [Nat.add_assoc] using hh
  · intro hr k hk
    have hh := hr (T + k) (by omega)
    simpa only [Nat.add_assoc] using hh
