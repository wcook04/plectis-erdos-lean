import Definitions.Def_ErdosProblems_Erdos243_ReciprocalTailRigidity
import Definitions.Def_ErdosProblems_Erdos243_GlobalLcmHeight
import Definitions.Def_ErdosProblems_Erdos243_CumulativeLcmTransfer
import Definitions.Def_ErdosProblems_Erdos243_LcmCriticalBoundary
import Definitions.Def_ErdosProblems_Erdos243_LcmRecordCrossing
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR7_Limits
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR7_RealTail
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR7_CanonicalState
import Definitions.Def_ErdosProblems_Erdos243_PrimitiveRecordBarrier
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_RecordDivisibility
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR7_ProductDefect
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR7_LcmDefect
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_GrowthRecordEquivalence
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_CanonicalGrowthBounds
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_CoprimeCores
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_LogLogNormaliser
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_OrbitBlockArithmetic
import Mathlib
import Mathlib.Algebra.Order.BigOperators.GroupWithZero.Finset
import Mathlib.Algebra.Ring.Basic
import Mathlib.Analysis.SpecialFunctions.Log.Basic
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Analysis.SumIntegralComparisons
import Mathlib.Data.Fin.Pigeonhole
import Mathlib.Data.Fintype.BigOperators
import Mathlib.Data.Nat.ChineseRemainder
import Mathlib.Data.Nat.Factorization.Basic
import Mathlib.Data.Nat.Find
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.Rat.Defs
import Mathlib.Data.ZMod.Basic
import Mathlib.Order.Filter.AtTopBot.Basic
import Mathlib.Tactic
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.InfiniteSum.NatInt

/-!
# Explicit square-sized blocks for the inclusive boundary

These bounds apply simultaneously
throughout a block whose width grows with the selection parameter. They
replace the previously missing uniform `ceil(log B)` estimates with exact
natural arithmetic on the cofinal choices `k = 2^t`, `B = k^2`.
-/

namespace ErdosProblems.Erdos243.PaperCompleteR11
open scoped BigOperators

/-- The exponential dominates the precise linear exponent used below. -/
theorem four_mul_add_one_le_two_pow {t : ℕ} (ht : 5 ≤ t) :
    4 * t + 1 ≤ 2 ^ t := by
  induction t, ht using Nat.le_induction with
  | base => norm_num
  | succ t ht ih =>
      rw [pow_succ]
      omega

/-- Exact domination of the fourth power; no floating-point evaluation is
used for the growing parameter. -/
theorem twice_fourth_power_le_two_pow_two_pow {t : ℕ} (ht : 5 ≤ t) :
    2 * (2 ^ t) ^ 4 ≤ 2 ^ (2 ^ t) := by
  calc
    2 * (2 ^ t) ^ 4 = 2 ^ (4 * t + 1) := by
      rw [← pow_mul, show t * 4 = 4 * t by omega, pow_succ]
      ring
    _ ≤ 2 ^ (2 ^ t) := two_pow_mono (four_mul_add_one_le_two_pow ht)
end ErdosProblems.Erdos243.PaperCompleteR11

open scoped BigOperators
open ErdosProblems in
open ErdosProblems.Erdos243 in
open ErdosProblems.Erdos243.PaperCompleteR11 in
theorem solution (K N t : ℕ) (ht : 5 ≤ t)
    (hKN : K + N ≤ 2 ^ t) :
    (K + (N + 2 ^ t + (2 ^ t) ^ 2)) * (2 ^ t) ^ 2 ≤ 2 ^ (2 ^ t) := by
  let k := 2 ^ t
  have hk : 2 ≤ k := by
    have hh := index_succ_le_two_pow t
    dsimp [k]
    omega
  have hlin : 2 * k ≤ k ^ 2 := by
    have hh := Nat.mul_le_mul_left k hk
    nlinarith
  have hsum : K + (N + k + k ^ 2) ≤ 2 * k ^ 2 := by
    dsimp [k] at *
    omega
  calc
    (K + (N + k + k ^ 2)) * k ^ 2 ≤ (2 * k ^ 2) * k ^ 2 :=
      Nat.mul_le_mul_right _ hsum
    _ = 2 * k ^ 4 := by ring
    _ ≤ 2 ^ k := twice_fourth_power_le_two_pow_two_pow ht
