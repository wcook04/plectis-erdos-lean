import Definitions.Def_ErdosProblems_Erdos243_ReciprocalTailRigidity
import Definitions.Def_ErdosProblems_Erdos243_GlobalLcmHeight
import Definitions.Def_ErdosProblems_Erdos243_CumulativeLcmTransfer
import Definitions.Def_ErdosProblems_Erdos243_LcmCriticalBoundary
import Definitions.Def_ErdosProblems_Erdos243_LcmRecordCrossing
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR7_Limits
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR7_RealTail
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR7_CanonicalState
import Definitions.Def_ErdosProblems_Erdos243_PrimitiveRecordBarrier
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_RecordDivisibility
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR7_ProductDefect
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR7_LcmDefect
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_GrowthRecordEquivalence
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_CanonicalGrowthBounds
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_CoprimeCores
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_LogLogNormaliser
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_OrbitBlockArithmetic
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_PresievedCRT
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_RecordGcdReduction
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_InclusiveRecordAssembly
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_InclusiveLimsup
import Theorems.Thm_ErdosProblems_Erdos243_PaperCompleteR21_exists_five_eight_gap
import Theorems.Thm_ErdosProblems_Erdos243_PaperCompleteR21_tail_geometric_bound
import Mathlib
import Mathlib.Algebra.Order.BigOperators.GroupWithZero.Finset
import Mathlib.Algebra.Ring.Basic
import Mathlib.Analysis.SpecialFunctions.Log.Basic
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Analysis.SumIntegralComparisons
import Mathlib.Data.EReal.Basic
import Mathlib.Data.Fin.Pigeonhole
import Mathlib.Data.Fintype.BigOperators
import Mathlib.Data.Fintype.EquivFin
import Mathlib.Data.Nat.ChineseRemainder
import Mathlib.Data.Nat.Factorization.Basic
import Mathlib.Data.Nat.Find
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.Nat.Totient
import Mathlib.Data.Rat.Defs
import Mathlib.Data.ZMod.Basic
import Mathlib.Order.Filter.AtTopBot.Basic
import Mathlib.Order.LiminfLimsup
import Mathlib.Tactic
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.InfiniteSum.NatInt

namespace ErdosProblems.Erdos243.PaperCompleteR21
end ErdosProblems.Erdos243.PaperCompleteR21

noncomputable section

namespace ErdosProblems.Erdos243.PaperCompleteR21
open Filter
open ErdosProblems.Erdos243
open ErdosProblems.Erdos243.PaperCompleteR11
variable (a C D : ℕ → ℕ) (E : ℕ → ℤ)
/-- `D n ≥ 2ⁿ` on an exact orbit with `a n > 1` and `D 0 ≥ 1`. -/
theorem den_ge_two_pow (ha : ∀ n, 1 < a n) (hD0 : 1 ≤ D 0)
    (hD : ∀ n, D (n + 1) = a n * D n) : ∀ n, 2 ^ n ≤ D n := by
  intro n
  induction n with
  | zero => simpa using hD0
  | succ n ih =>
      have h2 : 2 ≤ a n := ha n
      calc (2 : ℕ) ^ (n + 1) = 2 * 2 ^ n := by ring
      _ ≤ a n * D n := Nat.mul_le_mul h2 ih
      _ = D (n + 1) := (hD n).symm
/-- `4 |E n| < C n` gives `4 C (n+1) ≤ 5 C n`. -/
theorem tail_four_five (hC : ∀ n, C (n + 1) + D n = a n * C n)
    (hE : ∀ n, E n = centeredState (a n : ℤ) (D n : ℤ) (C n : ℤ))
    (n : ℕ) (hsmall : 4 * Int.natAbs (E n) < C n) :
    4 * C (n + 1) ≤ 5 * C n := by
  have hTail : (C (n + 1) : ℤ) = (C n : ℤ) - E n :=
    natTail_eq_sub_centeredState a C D E hC hE n
  omega
end ErdosProblems.Erdos243.PaperCompleteR21

open ErdosProblems
open ErdosProblems.Erdos243
open ErdosProblems.Erdos243.PaperCompleteR21
open Filter
open ErdosProblems.Erdos243
open ErdosProblems.Erdos243.PaperCompleteR11
variable (a C D : ℕ → ℕ) (E : ℕ → ℤ)
open ErdosProblems in
open ErdosProblems.Erdos243 in
open ErdosProblems.Erdos243.PaperCompleteR21 in
theorem solution
    (ha : ∀ n, 1 < a n) (hCpos : ∀ n, 0 < C n) (hD0 : 1 ≤ D 0)
    (hC : ∀ n, C (n + 1) + D n = a n * C n)
    (hD : ∀ n, D (n + 1) = a n * D n)
    (hE : ∀ n, E n = centeredState (a n : ℤ) (D n : ℤ) (C n : ℤ))
    (N : ℕ) (hN : ∀ n, N ≤ n → 4 * Int.natAbs (E n) < C n) (M : ℕ) :
    ∃ t, M ≤ t ∧ N ≤ t ∧ 4 ≤ a t := by
  classical
  set S := max M N with hS
  have hSN : N ≤ S := le_max_right _ _
  have hSM : M ≤ S := le_max_left _ _
  have hgeo : ∀ m, 4 ^ m * C (S + m) ≤ 5 ^ m * C S :=
    tail_geometric_bound C S (fun n hn ↦ tail_four_five a C D E hC hE n (hN n (by omega)))
  obtain ⟨m, hm0⟩ := exists_five_eight_gap (4 * C S)
  have hm : 4 * (5 ^ m * C S) < 8 ^ m := by
    calc 4 * (5 ^ m * C S) = 4 * C S * 5 ^ m := by ring
    _ < 8 ^ m := hm0
  refine ⟨S + m, by omega, by omega, ?_⟩
  by_contra hcon
  have hle : a (S + m) ≤ 4 := by omega
  -- `4 ^ m * D (S+m) ≤ a (S+m) * (4 ^ m * C (S+m)) ≤ 4 * 5 ^ m * C S`
  have hDle : D (S + m) ≤ a (S + m) * C (S + m) := by
    have := hC (S + m); omega
  have hchain : 8 ^ m ≤ 4 * (5 ^ m * C S) := by
    calc (8 : ℕ) ^ m = 4 ^ m * 2 ^ m := by rw [← Nat.mul_pow]
    _ ≤ 4 ^ m * D (S + m) := by
        refine Nat.mul_le_mul (le_refl _) (le_trans ?_ (den_ge_two_pow a D ha hD0 hD (S + m)))
        exact Nat.pow_le_pow_right (by norm_num) (by omega)
    _ ≤ 4 ^ m * (a (S + m) * C (S + m)) := Nat.mul_le_mul (le_refl _) hDle
    _ = a (S + m) * (4 ^ m * C (S + m)) := by ring
    _ ≤ 4 * (4 ^ m * C (S + m)) := Nat.mul_le_mul hle (le_refl _)
    _ ≤ 4 * (5 ^ m * C S) := Nat.mul_le_mul (le_refl _) (hgeo m)
  omega
