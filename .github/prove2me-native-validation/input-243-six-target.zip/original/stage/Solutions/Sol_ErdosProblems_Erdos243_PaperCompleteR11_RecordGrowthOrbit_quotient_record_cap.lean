import Definitions.Def_ErdosProblems_Erdos243_ReciprocalTailRigidity
import Definitions.Def_ErdosProblems_Erdos243_GlobalLcmHeight
import Definitions.Def_ErdosProblems_Erdos243_CumulativeLcmTransfer
import Definitions.Def_ErdosProblems_Erdos243_LcmCriticalBoundary
import Definitions.Def_ErdosProblems_Erdos243_LcmRecordCrossing
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR7_Limits
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR7_RealTail
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR7_CanonicalState
import Definitions.Def_ErdosProblems_Erdos243_PrimitiveRecordBarrier
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_RecordDivisibility
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR7_ProductDefect
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR7_LcmDefect
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_GrowthRecordEquivalence
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_CanonicalGrowthBounds
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_CoprimeCores
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_LogLogNormaliser
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_OrbitBlockArithmetic
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_PresievedCRT
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_RecordGcdReduction
import Theorems.Thm_ErdosProblems_Erdos243_PaperCompleteR11_runningMax_mul
import Theorems.Thm_ErdosProblems_Erdos243_PaperCompleteR11_runningMax_shift_at_record
import Mathlib
import Mathlib.Algebra.Order.BigOperators.GroupWithZero.Finset
import Mathlib.Algebra.Ring.Basic
import Mathlib.Analysis.SpecialFunctions.Log.Basic
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Analysis.SumIntegralComparisons
import Mathlib.Data.Fin.Pigeonhole
import Mathlib.Data.Fintype.BigOperators
import Mathlib.Data.Fintype.EquivFin
import Mathlib.Data.Nat.ChineseRemainder
import Mathlib.Data.Nat.Factorization.Basic
import Mathlib.Data.Nat.Find
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.Nat.Totient
import Mathlib.Data.Rat.Defs
import Mathlib.Data.ZMod.Basic
import Mathlib.Order.Filter.AtTopBot.Basic
import Mathlib.Tactic
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.InfiniteSum.NatInt

/-!
# Exact record-preserving quotient tails


The growth record below packages already derived orbit properties, not
any assertion about record gaps. Quotients are constructed from a genuine
common divisor. A global attained record is used as the starting index,
so the original running maximum is preserved exactly, including its prefix.
-/

namespace ErdosProblems.Erdos243.PaperCompleteR11
/-- Exact equality of the global record with the scaled quotient record. -/
theorem RecordGrowthOrbit.quotient_record_exact (O : RecordGrowthOrbit)
    (s g : ℕ) (hg : 0 < g) (hUg : g ∣ O.U s) (hDg : g ∣ O.D s)
    (hs : O.U s = runningMax O.U s) (n : ℕ) :
    runningMax O.U (s + n) =
      g * runningMax (O.quotientAt s g hg hUg hDg).U n := by
  rw [← runningMax_shift_at_record O.U s hs n, ← runningMax_mul]
  congr 1
  funext j
  exact (Nat.mul_div_cancel' (O.common_divisor_tail s g hUg hDg j).1).symm
end ErdosProblems.Erdos243.PaperCompleteR11

open ErdosProblems in
open ErdosProblems.Erdos243 in
open ErdosProblems.Erdos243.PaperCompleteR11 in
theorem solution (O : RecordGrowthOrbit)
    (s g : ℕ) (hg : 0 < g) (hUg : g ∣ O.U s) (hDg : g ∣ O.D s)
    (hs : O.U s = runningMax O.U s) (c : ℝ) (T : ℕ)
    (hcap : ∀ n, T ≤ n → runningMax O.U n < O.U (n + 1) →
      ((O.U (n + 1) - runningMax O.U n : ℕ) : ℝ) ≤ c * recordLogLog (runningMax O.U n)) :
    let V := O.quotientAt s g hg hUg hDg
    ∀ n : ℕ, T ≤ n → runningMax V.U n < V.U (n + 1) →
      ((V.U (n + 1) - runningMax V.U n : ℕ) : ℝ) ≤
        (c / g) * recordLogLog (g * runningMax V.U n : ℕ) := by
  dsimp only
  let V := O.quotientAt s g hg hUg hDg
  intro n hn hnew
  have hmax := O.quotient_record_exact s g hg hUg hDg hs n
  have hnext : O.U (s + n + 1) = g * V.U (n + 1) := by
    simpa only [V, RecordGrowthOrbit.quotientAt, Nat.add_assoc] using
      (Nat.mul_div_cancel' (O.common_divisor_tail s g hUg hDg (n + 1)).1).symm
  have hnew' : runningMax O.U (s + n) < O.U (s + n + 1) := by
    rw [hmax, hnext]
    exact Nat.mul_lt_mul_of_pos_left hnew hg
  have hh := hcap (s + n) (by omega) hnew'
  rw [hmax, hnext, ← Nat.mul_sub_left_distrib, Nat.cast_mul] at hh
  have hgR : (0 : ℝ) < g := by exact_mod_cast hg
  calc
    ((V.U (n + 1) - runningMax V.U n : ℕ) : ℝ) ≤
        (c * recordLogLog (g * runningMax V.U n : ℕ)) / g :=
      (le_div_iff₀ hgR).2 (by nlinarith)
    _ = (c / g) * recordLogLog (g * runningMax V.U n : ℕ) := by ring
