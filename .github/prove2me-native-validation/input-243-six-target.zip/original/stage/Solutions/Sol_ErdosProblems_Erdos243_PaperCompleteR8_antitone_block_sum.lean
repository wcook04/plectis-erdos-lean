import Definitions.Def_ErdosProblems_Erdos243_ReciprocalTailRigidity
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR7_Limits
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR7_RealTail
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR8_WeightAnalysis
import Mathlib
import Mathlib.Algebra.Order.BigOperators.GroupWithZero.Finset
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Analysis.SumIntegralComparisons
import Mathlib.Data.Fin.Pigeonhole
import Mathlib.Data.Nat.ChineseRemainder
import Mathlib.Data.Nat.Find
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.ZMod.Basic
import Mathlib.Order.Filter.AtTopBot.Basic
import Mathlib.Tactic
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.InfiniteSum.NatInt
import Mathlib.Topology.Algebra.InfiniteSum.Real

/-!
# The analytic part of the weighted-record assembly

Compiled round-8 candidates. No assumed divergence of sampled weights is
left in the paper-facing theorem. Its source is the displayed improper
integral and antitonicity on `[1, infinity)`.

Pinned source checks:
* Analysis/SumIntegralComparisons.lean: AntitoneOn.integral_le_sum.
* Topology/Algebra/InfiniteSum/Real.lean: summable_of_sum_range_le.
* Topology/Algebra/InfiniteSum/NatInt.lean: summable_nat_add_iff.
* Algebra/BigOperators/Group/Finset/Basic.lean: sum_range_add, sum_range_succ.
* Topology/Algebra/InfiniteSum/Order.lean: Summable.sum_le_tsum.
* Algebra/Order/BigOperators/Group/Finset.lean: sum_le_sum,
  sum_le_sum_of_subset_of_nonneg.
-/

namespace ErdosProblems.Erdos243.PaperCompleteR8
open Filter MeasureTheory
open scoped BigOperators
end ErdosProblems.Erdos243.PaperCompleteR8

open Filter MeasureTheory
open scoped BigOperators
open ErdosProblems in
open ErdosProblems.Erdos243 in
open ErdosProblems.Erdos243.PaperCompleteR8 in
theorem solution
    (f : ℕ → ℝ) (hf : Antitone f) (x P K : ℕ) :
    (∑ i ∈ Finset.range (P * K), f (x + i)) ≤
      (P : ℝ) * ∑ k ∈ Finset.range K, f (x + k * P) := by
  induction K with
  | zero => simp only [Nat.mul_zero, Finset.range_zero, Finset.sum_empty, mul_zero, le_refl]
  | succ K ih =>
      have hblock : (∑ i ∈ Finset.range P, f (x + (P * K + i))) ≤
          (P : ℝ) * f (x + K * P) := by
        calc
          (∑ i ∈ Finset.range P, f (x + (P * K + i))) ≤
              ∑ _i ∈ Finset.range P, f (x + K * P) := by
            apply Finset.sum_le_sum
            intro i _
            apply hf
            rw [Nat.mul_comm K P]
            omega
          _ = _ := by simp only [Finset.sum_const, Finset.card_range, nsmul_eq_mul]
      rw [Nat.mul_succ, Finset.sum_range_add, Finset.sum_range_succ]
      calc
        (∑ i ∈ Finset.range (P * K), f (x + i)) +
            (∑ i ∈ Finset.range P, f (x + (P * K + i))) ≤
            (P : ℝ) * (∑ k ∈ Finset.range K, f (x + k * P)) +
              (P : ℝ) * f (x + K * P) := add_le_add ih hblock
        _ = _ := by ring
