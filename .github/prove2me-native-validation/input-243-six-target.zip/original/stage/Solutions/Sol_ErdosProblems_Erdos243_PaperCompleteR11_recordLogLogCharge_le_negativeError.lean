import Definitions.Def_ErdosProblems_Erdos243_ReciprocalTailRigidity
import Definitions.Def_ErdosProblems_Erdos243_GlobalLcmHeight
import Definitions.Def_ErdosProblems_Erdos243_CumulativeLcmTransfer
import Definitions.Def_ErdosProblems_Erdos243_LcmCriticalBoundary
import Definitions.Def_ErdosProblems_Erdos243_LcmRecordCrossing
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR7_Limits
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR7_RealTail
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR7_CanonicalState
import Definitions.Def_ErdosProblems_Erdos243_PrimitiveRecordBarrier
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_RecordDivisibility
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR7_ProductDefect
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR7_LcmDefect
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_GrowthRecordEquivalence
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_CanonicalGrowthBounds
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_CoprimeCores
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_LogLogNormaliser
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_OrbitBlockArithmetic
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_PresievedCRT
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_RecordGcdReduction
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_InclusiveRecordAssembly
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_InclusiveLimsup
import Theorems.Thm_ErdosProblems_Erdos243_PaperCompleteR11_recordLogLog_mono
import Theorems.Thm_ErdosProblems_Erdos243_PaperCompleteR11_one_le_recordLogLog
import Theorems.Thm_ErdosProblems_Erdos243_PaperCompleteR11_record_increment_le_negative_part
import Theorems.Thm_ErdosProblems_Erdos243_PaperCompleteR11_runningMax_true_increment
import Mathlib
import Mathlib.Algebra.Order.BigOperators.GroupWithZero.Finset
import Mathlib.Algebra.Ring.Basic
import Mathlib.Analysis.SpecialFunctions.Log.Basic
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Analysis.SumIntegralComparisons
import Mathlib.Data.EReal.Basic
import Mathlib.Data.Fin.Pigeonhole
import Mathlib.Data.Fintype.BigOperators
import Mathlib.Data.Fintype.EquivFin
import Mathlib.Data.Nat.ChineseRemainder
import Mathlib.Data.Nat.Factorization.Basic
import Mathlib.Data.Nat.Find
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.Nat.Totient
import Mathlib.Data.Rat.Defs
import Mathlib.Data.ZMod.Basic
import Mathlib.Order.Filter.AtTopBot.Basic
import Mathlib.Order.LiminfLimsup
import Mathlib.Tactic
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.InfiniteSum.NatInt

namespace PaperCompleteR7
end PaperCompleteR7

/-!
# Extended-real inclusive log-log endpoint


The limsup is taken in EReal, so an unbounded quotient is not silently
replaced by a real conditionally-complete-lattice default. The normaliser
is the paper's exact log_2(log_2(max(4,x))). All-index true running-maximum
increments are used, exactly as in the definition of Theta in the paper.
-/

namespace ErdosProblems.Erdos243.PaperCompleteR11
open Filter PaperCompleteR7
open scoped Topology
end ErdosProblems.Erdos243.PaperCompleteR11

open Filter PaperCompleteR7
open scoped Topology
open ErdosProblems in
open ErdosProblems.Erdos243 in
open ErdosProblems.Erdos243.PaperCompleteR11 in
open ErdosProblems.Erdos243.PaperCompleteR7 in
theorem solution
    (U : ℕ → ℕ) (E : ℕ → ℤ)
    (hstep : ∀ n, (U (n + 1) : ℤ) = (U n : ℤ) - E n) (n : ℕ) :
    recordLogLogCharge U n ≤ negativeErrorLogLogCharge U E n := by
  have hgap : ((U (n + 1) - runningMax U n : ℕ) : ℝ) ≤ ((max (-E n) 0 : ℤ) : ℝ) := by
    exact_mod_cast record_increment_le_negative_part U E hstep n
  have hnum : (0 : ℝ) ≤ ((max (-E n) 0 : ℤ) : ℝ) := by
    exact_mod_cast (le_max_right (-E n) (0 : ℤ))
  have hCpos : 0 < recordLogLog (U n) :=
    lt_of_lt_of_le (by norm_num) (one_le_recordLogLog _)
  have hHpos : 0 < recordLogLog (runningMax U n) :=
    lt_of_lt_of_le (by norm_num) (one_le_recordLogLog _)
  have hden : recordLogLog (U n) ≤ recordLogLog (runningMax U n) :=
    recordLogLog_mono (by exact_mod_cast le_runningMax U (le_refl n))
  unfold recordLogLogCharge negativeErrorLogLogCharge
  rw [runningMax_true_increment]
  exact (div_le_div_of_nonneg_right hgap hHpos.le).trans
    (div_le_div_of_nonneg_left hnum hCpos hden)
