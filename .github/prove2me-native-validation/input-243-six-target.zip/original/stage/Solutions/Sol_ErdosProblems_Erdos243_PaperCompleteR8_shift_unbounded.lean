import Definitions.Def_ErdosProblems_Erdos243_ReciprocalTailRigidity
import Definitions.Def_ErdosProblems_Erdos243_LcmRecordCrossing
import Definitions.Def_ErdosProblems_Erdos243_LcmRecordDivergence
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR7_Limits
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR7_RealTail
import Definitions.Def_ErdosProblems_Erdos243_PrimitiveRecordBarrier
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR8_WeightAnalysis
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR8_WeightedRecords
import Mathlib
import Mathlib.Algebra.Order.BigOperators.GroupWithZero.Finset
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Analysis.SumIntegralComparisons
import Mathlib.Data.Fin.Pigeonhole
import Mathlib.Data.Nat.ChineseRemainder
import Mathlib.Data.Nat.Factorization.Basic
import Mathlib.Data.Nat.Find
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.ZMod.Basic
import Mathlib.Order.Filter.AtTopBot.Basic
import Mathlib.Tactic
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.InfiniteSum.NatInt
import Mathlib.Topology.Algebra.InfiniteSum.Real

namespace ErdosProblems.Erdos243.PaperCompleteR8
open Filter Classical
open scoped BigOperators
end ErdosProblems.Erdos243.PaperCompleteR8

open ErdosProblems
open ErdosProblems.Erdos243
open ErdosProblems.Erdos243.PaperCompleteR8
open Filter Classical
open scoped BigOperators
open ErdosProblems in
open ErdosProblems.Erdos243 in
open ErdosProblems.Erdos243.PaperCompleteR8 in
theorem solution
    (U : ℕ → ℕ) (hu : HeightUnbounded U) (T : ℕ) :
    HeightUnbounded (fun k => U (T + k)) := by
  intro H
  obtain ⟨n, hn⟩ := hu (max H (runningMax U T))
  have hTn : T ≤ n := by
    by_contra hnot
    have hle := le_runningMax U (show n ≤ T by omega)
    have hhi := le_max_right H (runningMax U T)
    omega
  refine ⟨n - T, ?_⟩
  dsimp only
  rw [Nat.add_sub_of_le hTn]
  exact (le_max_left _ _).trans_lt hn
