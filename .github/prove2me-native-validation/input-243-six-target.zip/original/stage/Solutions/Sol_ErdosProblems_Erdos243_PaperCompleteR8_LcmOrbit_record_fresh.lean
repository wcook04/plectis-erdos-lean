import Definitions.Def_ErdosProblems_Erdos243_ReciprocalTailRigidity
import Definitions.Def_ErdosProblems_Erdos243_LcmRecordCrossing
import Definitions.Def_ErdosProblems_Erdos243_LcmRecordDivergence
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR7_Limits
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR7_RealTail
import Definitions.Def_ErdosProblems_Erdos243_PrimitiveRecordBarrier
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR8_WeightAnalysis
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR8_WeightedRecords
import Theorems.Thm_ErdosProblems_Erdos243_LcmRecordExcess_rise_is_fresh
import Mathlib
import Mathlib.Algebra.Order.BigOperators.GroupWithZero.Finset
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Analysis.SumIntegralComparisons
import Mathlib.Data.Fin.Pigeonhole
import Mathlib.Data.Nat.ChineseRemainder
import Mathlib.Data.Nat.Factorization.Basic
import Mathlib.Data.Nat.Find
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.ZMod.Basic
import Mathlib.Order.Filter.AtTopBot.Basic
import Mathlib.Tactic
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.InfiniteSum.NatInt
import Mathlib.Topology.Algebra.InfiniteSum.Real

namespace ErdosProblems.Erdos243.PaperCompleteR8.LcmOrbit
open Filter Classical
open scoped BigOperators
end ErdosProblems.Erdos243.PaperCompleteR8.LcmOrbit

open ErdosProblems
open ErdosProblems.Erdos243
open ErdosProblems.Erdos243.PaperCompleteR8
open ErdosProblems.Erdos243.PaperCompleteR8.LcmOrbit
open Filter Classical
open scoped BigOperators
open ErdosProblems in
open ErdosProblems.Erdos243 in
open ErdosProblems.Erdos243.PaperCompleteR8 in
open ErdosProblems.Erdos243.PaperCompleteR8.LcmOrbit in
theorem solution (o : LcmOrbit)
    (hc : ∀ n, -(o.U n : ℤ) ≤ 2 * o.V n)
    {n : ℕ} (hn : Record o.U n) : Nat.gcd (o.L n) (o.a n) = 1 := by
  have hrho : 1 ≤ (Nat.gcd (o.L n) (o.a n) : ℤ) := by
    have hnat : (1 : ℕ) ≤ Nat.gcd (o.L n) (o.a n) :=
      Nat.succ_le_iff.mpr (Nat.gcd_pos_of_pos_left (o.a n) (o.Lpos n))
    exact_mod_cast hnat
  have hs := LcmRecordExcess.rise_is_fresh
    (by exact_mod_cast o.Upos n) hrho (hc n) (o.step n)
    (by exact_mod_cast hn n le_rfl)
  exact_mod_cast hs.1
