import Definitions.Def_ErdosProblems_Erdos243_ReciprocalTailRigidity
import Definitions.Def_ErdosProblems_Erdos243_LcmRecordCrossing
import Definitions.Def_ErdosProblems_Erdos243_LcmRecordDivergence
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR7_Limits
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR7_RealTail
import Definitions.Def_ErdosProblems_Erdos243_PrimitiveRecordBarrier
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR8_WeightAnalysis
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR8_WeightedRecords
import Theorems.Thm_ErdosProblems_Erdos243_PaperCompleteR8_LcmOrbit_old_digit_dvd
import Theorems.Thm_ErdosProblems_Erdos243_PaperCompleteR8_LcmOrbit_record_fresh
import Mathlib
import Mathlib.Algebra.Order.BigOperators.GroupWithZero.Finset
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Analysis.SumIntegralComparisons
import Mathlib.Data.Fin.Pigeonhole
import Mathlib.Data.Nat.ChineseRemainder
import Mathlib.Data.Nat.Factorization.Basic
import Mathlib.Data.Nat.Find
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.ZMod.Basic
import Mathlib.Order.Filter.AtTopBot.Basic
import Mathlib.Tactic
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.InfiniteSum.NatInt
import Mathlib.Topology.Algebra.InfiniteSum.Real

namespace ErdosProblems.Erdos243.PaperCompleteR8.LcmOrbit
open Filter Classical
open scoped BigOperators
end ErdosProblems.Erdos243.PaperCompleteR8.LcmOrbit

open ErdosProblems
open ErdosProblems.Erdos243
open ErdosProblems.Erdos243.PaperCompleteR8
open ErdosProblems.Erdos243.PaperCompleteR8.LcmOrbit
open Filter Classical
open scoped BigOperators
open ErdosProblems in
open ErdosProblems.Erdos243 in
open ErdosProblems.Erdos243.PaperCompleteR8 in
open ErdosProblems.Erdos243.PaperCompleteR8.LcmOrbit in
theorem solution (o : LcmOrbit)
    (hc : ∀ n, -(o.U n : ℤ) ≤ 2 * o.V n)
    {s t : ℕ} (hs : Record o.U s) (ht : Record o.U t) (hst : s < t) :
    Nat.Coprime (o.a s) (o.a t) := by
  have hcop : Nat.Coprime (o.L t) (o.a t) := o.record_fresh hc ht
  -- Mathlib/Data/Nat/GCD/Basic.lean.
  exact hcop.of_dvd_left (o.old_digit_dvd hst)
