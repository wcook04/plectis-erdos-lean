import Definitions.Def_ErdosProblems_Erdos243_ReciprocalTailRigidity
import Definitions.Def_ErdosProblems_Erdos243_GlobalLcmHeight
import Definitions.Def_ErdosProblems_Erdos243_CumulativeLcmTransfer
import Definitions.Def_ErdosProblems_Erdos243_LcmCriticalBoundary
import Definitions.Def_ErdosProblems_Erdos243_LcmRecordCrossing
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR7_Limits
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR7_RealTail
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR7_CanonicalState
import Definitions.Def_ErdosProblems_Erdos243_PrimitiveRecordBarrier
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_RecordDivisibility
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR7_ProductDefect
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR7_LcmDefect
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_GrowthRecordEquivalence
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_CanonicalGrowthBounds
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_CoprimeCores
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_LogLogNormaliser
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_OrbitBlockArithmetic
import Mathlib
import Mathlib.Algebra.Order.BigOperators.GroupWithZero.Finset
import Mathlib.Algebra.Ring.Basic
import Mathlib.Analysis.SpecialFunctions.Log.Basic
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Analysis.SumIntegralComparisons
import Mathlib.Data.Fin.Pigeonhole
import Mathlib.Data.Fintype.BigOperators
import Mathlib.Data.Nat.ChineseRemainder
import Mathlib.Data.Nat.Factorization.Basic
import Mathlib.Data.Nat.Find
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.Rat.Defs
import Mathlib.Data.ZMod.Basic
import Mathlib.Order.Filter.AtTopBot.Basic
import Mathlib.Tactic
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.InfiniteSum.NatInt

namespace PaperCompleteR7
end PaperCompleteR7

/-!
# Orbit-supplied gcd and product budgets

Every gcd bound and every old-divisor
statement is derived from the exact two-coordinate orbit. In particular,
no pairwise-coprimality assumption is made on the original multipliers.
-/


open PaperCompleteR7 Filter
open scoped BigOperators Topology

open ErdosProblems.Erdos243.PaperCompleteR11

open ErdosProblems.Erdos243.PaperCompleteR7

theorem ErdosProblems.Erdos243.PaperCompleteR11.multiplier_gcd_le_terminal_record (a U D : ℕ → ℕ)
    (hU : ∀ n, U (n + 1) + D n = a n * U n)
    (hD : ∀ n, D (n + 1) = a n * D n) (hUpos : ∀ n, 0 < U n)
    {i j M : ℕ} (hij : i ≠ j) (hi : i < M) (hj : j < M) :
    Nat.gcd (a i) (a j) ≤ runningMax U M := by sorry
