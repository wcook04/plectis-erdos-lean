import Definitions.Def_ErdosProblems_Erdos243_ReciprocalTailRigidity
import Definitions.Def_ErdosProblems_Erdos243_LcmCriticalBoundary
import Mathlib.Algebra.Order.BigOperators.GroupWithZero.Finset
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.Data.Fin.Pigeonhole
import Mathlib.Data.Nat.ChineseRemainder
import Mathlib.Data.Nat.Find
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.ZMod.Basic
import Mathlib.Order.Filter.AtTopBot.Basic
import Mathlib.Tactic.Ring

open scoped BigOperators

/-!
# Erdős 243: the LCM critical boundary

This module formalizes the strict-rise CRT consumer and weighted block
telescope arising from the LCM-cleared tail state.
-/

open ErdosProblems.Erdos243

theorem ErdosProblems.Erdos243.eventually_zero_of_bounded_lcmState
    (u : ℕ → ℕ) (V : ℕ → ℤ) (M : ℕ)
    (hbound : ∀ n, u n ≤ M)
    (hvanish : ∀ K, ∃ N, ∀ n, N ≤ n →
      K * (V n).natAbs < u n) :
    ∃ N, ∀ n, N ≤ n → V n = 0 := by sorry
