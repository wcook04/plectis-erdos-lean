import Mathlib

namespace ErdosProblems.Erdos243.LcmRecordExcess
end ErdosProblems.Erdos243.LcmRecordExcess

/-!
# Finite arithmetic and weighted charging for LCM record crossings

These lemmas verify the local arithmetic and charging steps of
`LcmRecordExcess.md`. They do not formalise its analytic divergence theorem,
its canonical-orbit transfer, or unrestricted Erdős 243.
-/

open ErdosProblems.Erdos243.LcmRecordExcess

theorem ErdosProblems.Erdos243.LcmRecordExcess.rise_is_fresh {U U' V rho : ℤ}
    (hU : 0 < U) (hrho : 1 ≤ rho)
    (hcenter : -U ≤ 2 * V) (hstep : rho * U' = U - V)
    (hrise : U < U') : rho = 1 ∧ U' - U = -V := by sorry
