import Mathlib

namespace ErdosProblems.Erdos243.LcmRecordExcess
end ErdosProblems.Erdos243.LcmRecordExcess

/-!
# Finite arithmetic and weighted charging for LCM record crossings

These lemmas verify the local arithmetic and charging steps of
`LcmRecordExcess.md`. They do not formalise its analytic divergence theorem,
its canonical-orbit transfer, or unrestricted Erdős 243.
-/

open ErdosProblems.Erdos243.LcmRecordExcess

theorem ErdosProblems.Erdos243.LcmRecordExcess.covered_wall_forces_excess {U d L a tau B : ℤ}
    (hd : 0 < d) (hsource : U < tau) (hcross : tau ≤ U + d)
    (hfeedback : d = (a - 1) * U - L)
    (hcover : ∀ z : ℤ, tau - B ≤ z → z < tau →
      ∃ m : ℤ, B < m ∧ m ∣ L ∧ m ∣ z) : B < d := by sorry
