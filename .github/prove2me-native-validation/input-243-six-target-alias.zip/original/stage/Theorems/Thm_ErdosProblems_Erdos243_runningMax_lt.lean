import Definitions.Def_ErdosProblems_Erdos243_ReciprocalTailRigidity
import Definitions.Def_ErdosProblems_Erdos243_PrimitiveRecordBarrier
import Mathlib.Algebra.Order.BigOperators.GroupWithZero.Finset
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.Data.Fin.Pigeonhole
import Mathlib.Data.Nat.ChineseRemainder
import Mathlib.Data.Nat.Factorization.Basic
import Mathlib.Data.Nat.Find
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.ZMod.Basic
import Mathlib.Order.Filter.AtTopBot.Basic
import Mathlib.Tactic.Ring

/-!
# Erdős 243: prime-power barriers for record numerator jumps

This module formalises the finite arithmetic of the record-jump barrier for a
*dynamically reduced* reciprocal tail, i.e. one in which an arbitrary
cancellation factor `hc n` is removed at every step.  Writing the reduced tail
as `u n / v n` in lowest terms, the step is the division-free cocycle

* `w n + v n = a n * u n`      (raw next numerator),
* `w n = hc n * u (n + 1)`     (reduced next numerator),
* `a n * v n = hc n * v (n + 1)` (reduced next denominator).

`DynamicCancellation` already supplies the primitive identities
`Nat.gcd (w n) (a n * v n) = Nat.gcd (w n) (a n ^ 2)` and
`Nat.Coprime (u n) (w n)`; the second gives `Nat.Coprime (u n) (u (n + 1))`
because `u (n + 1) ∣ w n`.

The chain proved here is:

1. `primitive_valuation_no_drop` — a prime power `p ^ l ∣ v n` cannot leave the
   reduced denominator while the *raw* numerator stays below `p ^ (l + 1)`.
   This is the only place where arbitrary cancellation is controlled: no bound
   on `hc n` is used anywhere.
2. `protectedPrimePower_persists` — the persistence of that prime power up to
   and including the first index at which `u` reaches a height `H` with
   `3 * H < 2 * p ^ (l + 1)`.
3. `odd_record_cut` — if `H` is an *odd* multiple of `p` above the running
   numerator maximum, the orbit can never reach `H` at all, provided every
   record-setting step rises by at most `2`.  The first crossing would have to
   be a record; `p ∣ v` kills the landing `u = H`, and the only other option
   `(H - 1, H + 1)` has both endpoints even, contradicting adjacent-numerator
   coprimality.
4. `recordRiseTwo_sylvesterNext_eventually` — the composed consumer.  The
   analytic *supply* of fresh odd large prime powers is an explicit hypothesis;
   see the module note at the end for exactly which bridges remain open.

Nothing in this module is conditional on a bound for the cancellation factors,
and no hypothesis is imposed at non-record steps.
-/


/-! ## 1. The valuation-loss threshold

r07 Lemma 1 / r08 Lemma 2.  Stated with `p ^ l ∣ v` rather than `p ^ l ‖ v`:
the divisibility form is strictly stronger, because `w < p ^ (l + 1)` is then
also below `p ^ (ν_p v + 1)`. -/



/-! ## 2. Persistence up to a first height crossing (r07 Lemma 2) -/



/-! ## 3. The running numerator maximum -/

open ErdosProblems.Erdos243

theorem ErdosProblems.Erdos243.runningMax_lt (u : ℕ → ℕ) {n H : ℕ} (h : ∀ k, k ≤ n → u k < H) :
    runningMax u n < H := by sorry
