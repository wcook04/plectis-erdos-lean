import Mathlib

namespace ErdosProblems.Erdos243.LcmRecordExcess
end ErdosProblems.Erdos243.LcmRecordExcess

/-!
# Finite arithmetic and weighted charging for LCM record crossings

These lemmas verify the local arithmetic and charging steps of
`LcmRecordExcess.md`. They do not formalise its analytic divergence theorem,
its canonical-orbit transfer, or unrestricted Erdős 243.
-/

open ErdosProblems.Erdos243.LcmRecordExcess

theorem ErdosProblems.Erdos243.LcmRecordExcess.wall_count_le_excess {h P d B : ℕ}
    (hP : B < P) (hd : B < d)
    (hspacing : (h - 1) * P < d) : h ≤ d - B := by sorry
