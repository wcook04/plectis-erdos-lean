import Mathlib.Tactic

namespace ErdosProblems.Erdos243.CoefficientDivisorFence
end ErdosProblems.Erdos243.CoefficientDivisorFence

/-!
# Coefficient-independent divisor fences (r5)

Finite transition algebra only.  This module does not claim the global CRT
supply theorem, the analytic positive-numerator transfer, or the Erdős #243
endpoint.  The covering hypothesis is explicit: producing such a cover is a
separate CRT argument, and producing the required old divisors is a separate
record argument.

Not imported into `ErdosProblems/Root.lean`.  Erdős #243 remains open.
-/

open ErdosProblems.Erdos243.CoefficientDivisorFence

theorem ErdosProblems.Erdos243.CoefficientDivisorFence.no_jump_through_fence (a b L u v rho B z : ℤ)
    (hv : 0 < v) (hrho : 1 ≤ rho) (_hB : 0 ≤ B)
    (hcap : rho * v ≤ u + B)
    (hstep : rho * v = a * u - b * L)
    (hz : B < z) (hbefore : u < z + B)
    (hcover : ∀ x : ℤ, z ≤ x → x < z + B →
      ∃ m : ℤ, B < m ∧ m ∣ x ∧ m ∣ L) :
    v < z + B := by sorry
