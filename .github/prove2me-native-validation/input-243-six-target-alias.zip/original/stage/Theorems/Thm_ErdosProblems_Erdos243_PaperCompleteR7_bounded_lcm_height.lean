import Definitions.Def_ErdosProblems_Erdos243_ReciprocalTailRigidity
import Definitions.Def_ErdosProblems_Erdos243_GlobalLcmHeight
import Definitions.Def_ErdosProblems_Erdos243_CumulativeLcmTransfer
import Definitions.Def_ErdosProblems_Erdos243_LcmCriticalBoundary
import Definitions.Def_ErdosProblems_Erdos243_LcmRecordCrossing
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR7_Limits
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR7_RealTail_v243UnionFbf41fb8
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR7_CanonicalState_v243UnionFbf41fb8
import Definitions.Def_ErdosProblems_Erdos243_PrimitiveRecordBarrier
import Mathlib
import Mathlib.Algebra.Order.BigOperators.GroupWithZero.Finset
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Data.Fin.Pigeonhole
import Mathlib.Data.Nat.ChineseRemainder
import Mathlib.Data.Nat.Factorization.Basic
import Mathlib.Data.Nat.Find
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.ZMod.Basic
import Mathlib.Order.Filter.AtTopBot.Basic
import Mathlib.Tactic
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.InfiniteSum.NatInt

/-!
# Global boundedness and stationarity of the actual LCM state

Compiled candidates.  Unlike the existing finite CRT consumers, the
principal theorem constructs its old fresh multipliers from the unbounded
orbit.  No old-prime supply, global avoidance hypothesis, or preconstructed
cover is a premise.  Strict increase of the given denominators supplies
multipliers larger than the fixed bound.
-/


open Filter
open scoped BigOperators

open ErdosProblems.Erdos243.PaperCompleteR7

theorem ErdosProblems.Erdos243.PaperCompleteR7.bounded_lcm_height
    (q : ℕ) (a U : ℕ → ℕ) (V : ℕ → ℤ)
    (hq : 0 < q) (ha : StrictMono a) (hapos : ∀ n, 0 < a n)
    (hUpos : ∀ n, 0 < U n)
    (hstep : ∀ n, (lcmOverlap q a n : ℤ) * (U (n + 1) : ℤ) = (U n : ℤ) - V n)
    (hcenter : ∀ n, V n = (cumulativeDigitLcm q a n : ℤ) -
      ((a n : ℤ) - 1) * (U n : ℤ))
    (hbound : ∃ N B : ℕ, ∀ n, N ≤ n → -(B : ℤ) ≤ V n) :
    ∃ H : ℕ, ∀ n, U n ≤ H := by sorry
