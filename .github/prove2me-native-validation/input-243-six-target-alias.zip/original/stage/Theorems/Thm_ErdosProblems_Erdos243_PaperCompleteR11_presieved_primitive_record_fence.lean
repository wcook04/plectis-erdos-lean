import Definitions.Def_ErdosProblems_Erdos243_ReciprocalTailRigidity
import Definitions.Def_ErdosProblems_Erdos243_GlobalLcmHeight
import Definitions.Def_ErdosProblems_Erdos243_CumulativeLcmTransfer
import Definitions.Def_ErdosProblems_Erdos243_LcmCriticalBoundary
import Definitions.Def_ErdosProblems_Erdos243_LcmRecordCrossing
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR7_Limits
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR7_RealTail_v243UnionFbf41fb8
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR7_CanonicalState_v243UnionFbf41fb8
import Definitions.Def_ErdosProblems_Erdos243_PrimitiveRecordBarrier
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_RecordDivisibility_v243UnionFbf41fb8
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_PresievedCRT_v243UnionFbf41fb8
import Mathlib
import Mathlib.Algebra.Order.BigOperators.GroupWithZero.Finset
import Mathlib.Algebra.Ring.Basic
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Data.Fin.Pigeonhole
import Mathlib.Data.Nat.ChineseRemainder
import Mathlib.Data.Nat.Factorization.Basic
import Mathlib.Data.Nat.Find
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.Nat.Totient
import Mathlib.Data.Rat.Defs
import Mathlib.Data.ZMod.Basic
import Mathlib.Order.Filter.AtTopBot.Basic
import Mathlib.Tactic
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.InfiniteSum.NatInt

/-!
# Exact finite pre-sieving and the primitive record fence


The modulus W is part of the CRT construction, not merely mentioned in
an offset-counting hypothesis.  Thus x is a multiple of W, and only the
phi(W)/W proportion of offsets coprime to W need individual old moduli.
The exact count, its asymptotic proportion, the bounded CRT phase and the
primitive first-crossing contradiction are all supplied here.  Selection
of the canonical moduli and the final log-log limit remain separate.
-/


open Filter
open scoped BigOperators Topology

open ErdosProblems.Erdos243.PaperCompleteR11

theorem ErdosProblems.Erdos243.PaperCompleteR11.presieved_primitive_record_fence
    (U D : ℕ → ℕ) (W B T x : ℕ)
    (m : {r // r ∈ presievedOffsets W B} → ℕ)
    (hm : ∀ i, 1 < m i)
    (hprimitive : ∀ n, T ≤ n → Nat.Coprime (U n) (D n))
    (hWold : ∀ n, T ≤ n → W ∣ D n)
    (hmOld : ∀ i n, T ≤ n → m i ∣ D n)
    (hWx : W ∣ x) (hphase : ∀ i, m i ∣ x + i.val)
    (hprefix : runningMax U T < x)
    (hcap : ∀ n, T ≤ n → runningMax U n < x + B →
      runningMax U n < U (n + 1) → U (n + 1) - runningMax U n ≤ B) :
    ∀ n, U n < x + B := by sorry
