import Definitions.Def_ErdosProblems_Erdos243_ReciprocalTailRigidity
import Definitions.Def_ErdosProblems_Erdos243_GlobalLcmHeight
import Definitions.Def_ErdosProblems_Erdos243_CumulativeLcmTransfer
import Definitions.Def_ErdosProblems_Erdos243_LcmCriticalBoundary
import Definitions.Def_ErdosProblems_Erdos243_LcmRecordCrossing
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR7_Limits
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR7_RealTail_v243UnionFbf41fb8
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR7_CanonicalState_v243UnionFbf41fb8
import Definitions.Def_ErdosProblems_Erdos243_PrimitiveRecordBarrier
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_RecordDivisibility_v243UnionFbf41fb8
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_CoprimeCores_v243UnionFbf41fb8
import Mathlib
import Mathlib.Algebra.Order.BigOperators.GroupWithZero.Finset
import Mathlib.Algebra.Ring.Basic
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Data.Fin.Pigeonhole
import Mathlib.Data.Nat.ChineseRemainder
import Mathlib.Data.Nat.Factorization.Basic
import Mathlib.Data.Nat.Find
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.Rat.Defs
import Mathlib.Data.ZMod.Basic
import Mathlib.Order.Filter.AtTopBot.Basic
import Mathlib.Tactic
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.InfiniteSum.NatInt

/-!
# Coprime cores of a finite non-coprime family

Removing gcd(A_i, product of all other A_j) yields pairwise-coprime
cores. The loss is bounded by the product of the pairwise gcds. This avoids
an unproved supply of pairwise-coprime original multipliers in the
non-stabilised-gcd branch of the inclusive argument.
-/


open scoped BigOperators

open ErdosProblems.Erdos243.PaperCompleteR11

theorem ErdosProblems.Erdos243.PaperCompleteR11.coprime_core_record_fence
    (U : ℕ → ℕ) (D a b : ℕ → ℤ) (T B H : ℕ) (hB : 0 < B)
    (A : Fin B → ℕ) (hA : ∀ i, 0 < A i)
    (hC : ∀ n, (U (n + 1) : ℤ) = a n * U n - b n * D n)
    (hD : ∀ n, D (n + 1) = a n * D n)
    (hpair : ∀ i j, i ≠ j → Nat.gcd (A i) (A j) ≤ H)
    (hlarge : ∀ i, (max B (runningMax U T)) * H ^ (B - 1) < A i)
    (hOld : ∀ i n, T ≤ n → (A i : ℤ) ∣ D n) :
    ∃ x P : ℕ, P ≤ x ∧ x < 2 * P ∧ P ≤ (∏ i, A i) ∧
      runningMax U T < x ∧
      ((∀ n, T ≤ n → runningMax U n < x + B →
          runningMax U n < U (n + 1) →
          U (n + 1) - runningMax U n ≤ B) →
        ∀ n, U n < x + B) := by sorry
