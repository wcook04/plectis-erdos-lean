import Definitions.Def_ErdosProblems_Erdos243_ReciprocalTailRigidity
import Mathlib.Algebra.Order.BigOperators.GroupWithZero.Finset
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.Data.Fin.Pigeonhole
import Mathlib.Data.Nat.ChineseRemainder
import Mathlib.Data.Nat.Find
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.ZMod.Basic
import Mathlib.Order.Filter.AtTopBot.Basic
import Mathlib.Tactic.Ring

/-!
# Erdős #243: the slow-rise barrier by common-divisor persistence

`ReciprocalTailRigidity.lean` excludes a *bounded* negative part by stabilising
the tail gcd, reducing the orbit, and running a CRT block against the
pairwise-coprime reduced multipliers.  Gcd stabilisation needs bounded negative
magnitudes, so that route stops exactly at the bounded regime.

This module replaces gcd stabilisation by *persistence*: a common divisor of
one tail state `Cₙ` and denominator state `Dₙ` divides every later `Cₜ`, `Dₜ`,
and therefore every later centred error `Eₜ = Dₜ - (aₜ - 1) Cₜ`.  A landing on a
CRT block therefore locks a whole block modulus into every later error, and the
next negative error is at least that modulus.  The CRT block is placed in
`[P, 2P)` for `P` the block product, so the rise bound is only needed below `2P`.

Consequences kernel-checked here:

* `exists_consecutiveMultiples_between`: the bounded CRT block.
* `commonDivisor_persists`, `multiplierOverlap_persists`,
  `multiplierOverlap_dvd_laterCenteredState`: persistence, and the unconditional
  fact that `gcd(aₙ, Dₙ)` divides every later centred error.
* `slowRise_landing`: a tail state starting below the block product that rises
  by at most `B` while below `2P` lands on a block modulus, which then divides
  every later state.
* `no_slowNegative_of_coprimeBlock`: with cofinal negativity and every negative
  error below `2P + B` smaller than every block modulus, contradiction.
* `no_slowRise_reducedTail`: the reduced-tail form, generalising
  `no_boundedRise_reducedTail` from a uniform rise bound to a rise bound that is
  only required below twice the product of `B` consecutive multipliers.

No hypothesis of periodicity, bounded negative part, or stable gcd appears.
The analytic transfer (which moduli to choose on the canonical orbit, and that
`(1 - δ) log₂ log₂ Cₙ` is an admissible rise bound) is an ordinary proof in
`SlowNegativePartRigidity.md`; it is not formalised.  Nothing here settles
Erdős #243.
-/


/-! ## The bounded CRT block -/



/-! ## Persistence of common divisors -/

open ErdosProblems.Erdos243

theorem ErdosProblems.Erdos243.dvd_denState_of_le
    (a D : ℕ → ℕ) (N d T : ℕ)
    (hD : ∀ k, N ≤ k → D (k + 1) = a k * D k)
    (hNT : N ≤ T) (hdT : d ∣ D T) :
    ∀ t, T ≤ t → d ∣ D t := by sorry
