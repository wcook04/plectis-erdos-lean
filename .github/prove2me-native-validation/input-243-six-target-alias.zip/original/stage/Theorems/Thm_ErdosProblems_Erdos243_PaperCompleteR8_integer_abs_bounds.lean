import Mathlib

namespace ErdosProblems.Erdos243.PaperCompleteR8
end ErdosProblems.Erdos243.PaperCompleteR8

/-!
# Elementary signed bounds used by the round-8 candidates

These constructor proofs avoid depending on the explicit/implicit argument
conventions of the core integer absolute-value lemmas. Compiled.
-/

open ErdosProblems.Erdos243.PaperCompleteR8

theorem ErdosProblems.Erdos243.PaperCompleteR8.integer_abs_bounds (z : ℤ) :
    -(z.natAbs : ℤ) ≤ z ∧ z ≤ (z.natAbs : ℤ) := by sorry
