import Mathlib.Tactic

namespace ErdosProblems.Erdos243.CoefficientDivisorFence
end ErdosProblems.Erdos243.CoefficientDivisorFence

/-!
# Coefficient-independent divisor fences (r5)

Finite transition algebra only.  This module does not claim the global CRT
supply theorem, the analytic positive-numerator transfer, or the Erdős #243
endpoint.  The covering hypothesis is explicit: producing such a cover is a
separate CRT argument, and producing the required old divisors is a separate
record argument.

Not imported into `ErdosProblems/Root.lean`.  Erdős #243 remains open.
-/

open ErdosProblems.Erdos243.CoefficientDivisorFence

theorem ErdosProblems.Erdos243.CoefficientDivisorFence.stays_below_fence
    (a b L U rho : ℕ → ℤ) (B z : ℤ)
    (hU : ∀ n, 0 < U n)
    (hrho : ∀ n, 1 ≤ rho n)
    (hB : 0 ≤ B) (hz : B < z)
    (hcap : ∀ n, rho n * U (n + 1) ≤ U n + B)
    (hstep : ∀ n, rho n * U (n + 1) = a n * U n - b n * L n)
    (hstart : U 0 < z + B)
    (hcover : ∀ n, ∀ x : ℤ, z ≤ x → x < z + B →
      ∃ m : ℤ, B < m ∧ m ∣ x ∧ m ∣ L n) :
    ∀ n, U n < z + B := by sorry
