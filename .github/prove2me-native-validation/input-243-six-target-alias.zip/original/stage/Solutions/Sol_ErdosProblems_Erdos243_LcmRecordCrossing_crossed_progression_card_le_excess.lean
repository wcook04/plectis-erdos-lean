import Definitions.Def_ErdosProblems_Erdos243_ReciprocalTailRigidity
import Definitions.Def_ErdosProblems_Erdos243_LcmRecordCrossing
import Theorems.Thm_ErdosProblems_Erdos243_LcmRecordCrossing_crossed_progression_spacing
import Theorems.Thm_ErdosProblems_Erdos243_LcmRecordExcess_covered_wall_forces_excess
import Theorems.Thm_ErdosProblems_Erdos243_LcmRecordExcess_wall_count_le_excess
import Mathlib
import Mathlib.Algebra.Order.BigOperators.GroupWithZero.Finset
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.Data.Fin.Pigeonhole
import Mathlib.Data.Nat.ChineseRemainder
import Mathlib.Data.Nat.Find
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.ZMod.Basic
import Mathlib.Order.Filter.AtTopBot.Basic
import Mathlib.Tactic.Ring

namespace LcmRecordExcess
end LcmRecordExcess

/-!
# Counting the CRT heights crossed by one arithmetic step

The heights are the actual arithmetic progression `x + k * P`, not an
assumed cardinality bound. This supplies the finite local charging step in
the weighted-record argument of `LcmRecordExcess.md`. First-crossing existence,
uniqueness, and the finite partition across time require no monotonicity of
the numerator sequence. The existing CRT construction supplies the covering
from any finite family of sufficiently large pairwise-coprime old divisors.
Producing that family from an infinite canonical orbit and the analytic
divergence argument are not asserted by this module.
-/

namespace ErdosProblems.Erdos243.LcmRecordCrossing
open LcmRecordExcess
end ErdosProblems.Erdos243.LcmRecordCrossing

open LcmRecordExcess
open ErdosProblems in
open ErdosProblems.Erdos243 in
open ErdosProblems.Erdos243.LcmRecordCrossing in
open ErdosProblems.Erdos243.LcmRecordExcess in
theorem solution (s : Finset ℕ)
    (x P U d B : ℕ) (a L : ℤ) (hP : B < P)
    (hlo : ∀ k ∈ s, U < x + k * P)
    (hhi : ∀ k ∈ s, x + k * P ≤ U + d)
    (hfeedback : (d : ℤ) = (a - 1) * U - L)
    (hcover : ∀ k ∈ s, ∀ z : ℤ,
      (x + k * P : ℕ) - (B : ℤ) ≤ z → z < (x + k * P : ℕ) →
      ∃ m : ℤ, (B : ℤ) < m ∧ m ∣ L ∧ m ∣ z) :
    s.card ≤ d - B := by
  by_cases hs : s.Nonempty
  · obtain ⟨k, hk⟩ := hs
    have hd : 0 < d := by have := hlo k hk; have := hhi k hk; omega
    have hexcess : (B : ℤ) < d :=
      covered_wall_forces_excess (U := U) (d := d) (L := L) (a := a)
        (tau := (x + k * P : ℕ)) (B := B)
        (by exact_mod_cast hd) (by exact_mod_cast hlo k hk)
        (by exact_mod_cast hhi k hk) hfeedback (hcover k hk)
    apply wall_count_le_excess hP (by exact_mod_cast hexcess)
    exact crossed_progression_spacing s ⟨k, hk⟩ x P U d hlo hhi
  · have hempty : s = ∅ := Finset.not_nonempty_iff_eq_empty.mp hs
    simp [hempty]
