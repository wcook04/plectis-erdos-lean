import Definitions.Def_ErdosProblems_Erdos243_ReciprocalTailRigidity
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR7_Limits
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR7_RealTail_v243UnionFbf41fb8
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR8_WeightAnalysis_v243UnionFbf41fb8
import Theorems.Thm_ErdosProblems_Erdos243_PaperCompleteR8_heightWeight_eq
import Theorems.Thm_ErdosProblems_Erdos243_PaperCompleteR8_heightWeight_nonneg
import Mathlib
import Mathlib.Algebra.Order.BigOperators.GroupWithZero.Finset
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Analysis.SumIntegralComparisons
import Mathlib.Data.Fin.Pigeonhole
import Mathlib.Data.Nat.ChineseRemainder
import Mathlib.Data.Nat.Find
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.ZMod.Basic
import Mathlib.Order.Filter.AtTopBot.Basic
import Mathlib.Tactic
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.InfiniteSum.NatInt
import Mathlib.Topology.Algebra.InfiniteSum.Real

/-!
# The analytic part of the weighted-record assembly

Compiled round-8 candidates. No assumed divergence of sampled weights is
left in the paper-facing theorem. Its source is the displayed improper
integral and antitonicity on `[1, infinity)`.

Pinned source checks:
* Analysis/SumIntegralComparisons.lean: AntitoneOn.integral_le_sum.
* Topology/Algebra/InfiniteSum/Real.lean: summable_of_sum_range_le.
* Topology/Algebra/InfiniteSum/NatInt.lean: summable_nat_add_iff.
* Algebra/BigOperators/Group/Finset/Basic.lean: sum_range_add, sum_range_succ.
* Topology/Algebra/InfiniteSum/Order.lean: Summable.sum_le_tsum.
* Algebra/Order/BigOperators/Group/Finset.lean: sum_le_sum,
  sum_le_sum_of_subset_of_nonneg.
-/

namespace ErdosProblems.Erdos243.PaperCompleteR8
open Filter MeasureTheory
open scoped BigOperators
end ErdosProblems.Erdos243.PaperCompleteR8

open Filter MeasureTheory
open scoped BigOperators
open ErdosProblems in
open ErdosProblems.Erdos243 in
open ErdosProblems.Erdos243.PaperCompleteR8 in
theorem solution
    (f : ℝ → ℝ) (hf : AntitoneOn f (Set.Ici 1))
    (hpos : ∀ x : ℝ, 1 ≤ x → 0 ≤ f x)
    (hdiv : DivergentIntegral f) :
    ¬ Summable (heightWeight f) := by
  intro hs
  let M : ℝ := ∑' n, heightWeight f (n + 1)
  -- Topology/Algebra/InfiniteSum/Group.lean: Summable.comp_injective.
  have ht : Summable (fun n : ℕ => heightWeight f (n + 1)) :=
    hs.comp_injective (fun i j hij => by omega)
  have hupper : ∀ N : ℕ, (∫ x in (1 : ℝ)..(1 + (N : ℝ)), f x) ≤ M := by
    intro N
    have hmono : AntitoneOn f (Set.Icc 1 (1 + (N : ℝ))) := by
      intro x hx y hy hxy
      exact hf hx.1 hy.1 hxy
    -- Analysis/SumIntegralComparisons.lean.
    have hcomp := hmono.integral_le_sum
    have hsum : (∑ i ∈ Finset.range N, f (1 + (i : ℝ))) =
        ∑ i ∈ Finset.range N, heightWeight f (i + 1) := by
      apply Finset.sum_congr rfl
      intro i _
      rw [heightWeight_eq f (i + 1) (by omega)]
      congr 1
      push_cast
      ring
    rw [hsum] at hcomp
    exact hcomp.trans (ht.sum_le_tsum (Finset.range N)
      (fun i _ => heightWeight_nonneg f hpos (i + 1)))
  have hnat : Tendsto (fun N : ℕ => 1 + (N : ℝ)) atTop atTop := by
    have hc := PaperCompleteR7.strictMono_nat_cast_tendsto_atTop
      (fun n : ℕ => n + 1) (fun i j hij => by dsimp only at *; omega)
      (fun n => by change 0 < n + 1; omega)
    simpa only [Nat.cast_add, Nat.cast_one, add_comm] using hc
  have hnatdiv := hdiv.comp hnat
  have hev : ∀ᶠ N : ℕ in atTop,
      M + 1 ≤ ∫ x in (1 : ℝ)..(1 + (N : ℝ)), f x :=
    (tendsto_atTop.mp hnatdiv) (M + 1)
  obtain ⟨N, hN⟩ := hev.exists
  have hu := hupper N
  linarith
