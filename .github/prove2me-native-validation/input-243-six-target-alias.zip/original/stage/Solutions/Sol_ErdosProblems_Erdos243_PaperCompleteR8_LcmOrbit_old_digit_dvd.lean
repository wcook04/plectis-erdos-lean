import Definitions.Def_ErdosProblems_Erdos243_ReciprocalTailRigidity
import Definitions.Def_ErdosProblems_Erdos243_LcmRecordCrossing
import Definitions.Def_ErdosProblems_Erdos243_LcmRecordDivergence
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR7_Limits
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR7_RealTail_v243UnionFbf41fb8
import Definitions.Def_ErdosProblems_Erdos243_PrimitiveRecordBarrier
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR8_WeightAnalysis_v243UnionFbf41fb8
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR8_WeightedRecords_v243UnionFbf41fb8
import Theorems.Thm_ErdosProblems_Erdos243_PaperCompleteR8_LcmOrbit_L_dvd_of_le
import Mathlib
import Mathlib.Algebra.Order.BigOperators.GroupWithZero.Finset
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Analysis.SumIntegralComparisons
import Mathlib.Data.Fin.Pigeonhole
import Mathlib.Data.Nat.ChineseRemainder
import Mathlib.Data.Nat.Factorization.Basic
import Mathlib.Data.Nat.Find
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.ZMod.Basic
import Mathlib.Order.Filter.AtTopBot.Basic
import Mathlib.Tactic
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.InfiniteSum.NatInt
import Mathlib.Topology.Algebra.InfiniteSum.Real

namespace ErdosProblems.Erdos243.PaperCompleteR8.LcmOrbit
open Filter Classical
open scoped BigOperators
end ErdosProblems.Erdos243.PaperCompleteR8.LcmOrbit

open ErdosProblems
open ErdosProblems.Erdos243
open ErdosProblems.Erdos243.PaperCompleteR8
open ErdosProblems.Erdos243.PaperCompleteR8.LcmOrbit
open Filter Classical
open scoped BigOperators
open ErdosProblems in
open ErdosProblems.Erdos243 in
open ErdosProblems.Erdos243.PaperCompleteR8 in
open ErdosProblems.Erdos243.PaperCompleteR8.LcmOrbit in
theorem solution (o : LcmOrbit) {s t : ℕ} (hst : s < t) : o.a s ∣ o.L t := by
  have hd : o.a s ∣ o.L (s + 1) := by
    rw [o.nextL s]
    exact Nat.dvd_lcm_right _ _
  exact hd.trans (o.L_dvd_of_le (by omega))
