import Definitions.Def_ErdosProblems_Erdos243_ReciprocalTailRigidity
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR7_Limits
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR7_RealTail_v243UnionFbf41fb8
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR8_WeightAnalysis_v243UnionFbf41fb8
import Theorems.Thm_ErdosProblems_Erdos243_PaperCompleteR8_antitone_block_sum
import Mathlib
import Mathlib.Algebra.Order.BigOperators.GroupWithZero.Finset
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Analysis.SumIntegralComparisons
import Mathlib.Data.Fin.Pigeonhole
import Mathlib.Data.Nat.ChineseRemainder
import Mathlib.Data.Nat.Find
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.ZMod.Basic
import Mathlib.Order.Filter.AtTopBot.Basic
import Mathlib.Tactic
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.InfiniteSum.NatInt
import Mathlib.Topology.Algebra.InfiniteSum.Real

/-!
# The analytic part of the weighted-record assembly

Compiled round-8 candidates. No assumed divergence of sampled weights is
left in the paper-facing theorem. Its source is the displayed improper
integral and antitonicity on `[1, infinity)`.

Pinned source checks:
* Analysis/SumIntegralComparisons.lean: AntitoneOn.integral_le_sum.
* Topology/Algebra/InfiniteSum/Real.lean: summable_of_sum_range_le.
* Topology/Algebra/InfiniteSum/NatInt.lean: summable_nat_add_iff.
* Algebra/BigOperators/Group/Finset/Basic.lean: sum_range_add, sum_range_succ.
* Topology/Algebra/InfiniteSum/Order.lean: Summable.sum_le_tsum.
* Algebra/Order/BigOperators/Group/Finset.lean: sum_le_sum,
  sum_le_sum_of_subset_of_nonneg.
-/

namespace ErdosProblems.Erdos243.PaperCompleteR8
open Filter MeasureTheory
open scoped BigOperators
end ErdosProblems.Erdos243.PaperCompleteR8

open Filter MeasureTheory
open scoped BigOperators
open ErdosProblems in
open ErdosProblems.Erdos243 in
open ErdosProblems.Erdos243.PaperCompleteR8 in
theorem solution
    (f : ℕ → ℝ) (hf : Antitone f) (hpos : ∀ n, 0 ≤ f n)
    (hdiv : ¬ Summable f) (x P : ℕ) (hP : 0 < P) :
    ¬ Summable (fun k : ℕ => f (x + k * P)) := by
  intro hs
  apply hdiv
  -- Topology/Algebra/InfiniteSum/Real.lean.
  apply summable_of_sum_range_le hpos
    (c := (∑ i ∈ Finset.range x, f i) +
      (P : ℝ) * ∑' k : ℕ, f (x + k * P))
  intro N
  have hNP : N ≤ x + P * N := by nlinarith
  have hextend : (∑ i ∈ Finset.range N, f i) ≤
      ∑ i ∈ Finset.range (x + P * N), f i :=
    Finset.sum_le_sum_of_subset_of_nonneg (Finset.range_mono hNP)
      (fun i _ _ => hpos i)
  have hblock := antitone_block_sum f hf x P N
  have hbound := hs.sum_le_tsum (Finset.range N) (fun k _ => hpos (x + k * P))
  have hmul := mul_le_mul_of_nonneg_left hbound (Nat.cast_nonneg P)
  rw [Finset.sum_range_add] at hextend
  exact hextend.trans (add_le_add_right (hblock.trans hmul) _)
