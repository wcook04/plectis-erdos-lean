import Definitions.Def_ErdosProblems_Erdos243_ReciprocalTailRigidity
import Definitions.Def_ErdosProblems_Erdos243_SparseResetRecovery
import Theorems.Thm_ErdosProblems_Erdos243_tail_growth_le_one_add_negativeRelativeMass
import Mathlib.Algebra.Order.BigOperators.GroupWithZero.Finset
import Mathlib.Analysis.SpecialFunctions.Log.Summable
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.Data.Fin.Pigeonhole
import Mathlib.Data.Nat.ChineseRemainder
import Mathlib.Data.Nat.Find
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.ZMod.Basic
import Mathlib.Order.Filter.AtTopBot.Basic
import Mathlib.Tactic.Ring

/-!
# Erdős #243: sparse reset recovery

This module isolates the order-theoretic recovery forest behind dynamically
reduced reciprocal-tail orbits.  It also gives a division-free finite-product
bound for the full reset payment on a recovery interval.

The declarations do not exclude the unrestricted divergent-negative-mass
branch and therefore do not prove Erdős #243.
-/

namespace ErdosProblems.Erdos243
open scoped BigOperators

/-! ## Recovery intervals -/



















/-! ## Division-free payment bounds -/











/-! ## A checked endpoint consumer -/













/-! ## Scalar finite mass, without normalised vanishing

Type B r2 (file 05, Proposition J) observed that the product bound already
caps `C_n`, so a strict integer rise costs a definite relative mass `≥ 1/K`
and only finitely many rises can occur.  After the last rise the tail is
nonincreasing, hence eventually constant by
`antitone_nat_eventually_constant`.  Normalised vanishing is not used. -/
end ErdosProblems.Erdos243

open scoped BigOperators
open ErdosProblems in
open ErdosProblems.Erdos243 in
theorem solution
    (C : ℕ → ℕ) (E : ℕ → ℤ)
    (hCpos : ∀ n, 0 < C n)
    (hstep :
      ∀ n, (C (n + 1) : ℤ) = (C n : ℤ) - E n)
    (hsum : Summable (negativeRelativeMass C E)) :
    ∃ M : ℕ, ∀ n, C n ≤ M := by
  have hδ : ∀ n, 0 ≤ negativeRelativeMass C E n := fun n =>
    div_nonneg (by positivity) (by positivity)
  have hgrowth :=
    tail_growth_le_one_add_negativeRelativeMass C E hCpos hstep
  have hCprod : ∀ N,
      (C N : ℝ) ≤
        C 0 * (∏ i ∈ Finset.range N, (1 + negativeRelativeMass C E i)) := by
    intro N
    induction N with
    | zero => simp
    | succ N ih =>
        calc
          (C (N + 1) : ℝ) ≤ C N * (1 + negativeRelativeMass C E N) :=
            hgrowth N
          _ ≤ (C 0 *
                (∏ i ∈ Finset.range N, (1 + negativeRelativeMass C E i))) *
              (1 + negativeRelativeMass C E N) :=
                mul_le_mul_of_nonneg_right ih (by linarith [hδ N])
          _ = C 0 *
              (∏ i ∈ Finset.range (N + 1), (1 + negativeRelativeMass C E i)) := by
                rw [Finset.prod_range_succ]
                ring
  have hmulti : Multipliable (fun n ↦ 1 + negativeRelativeMass C E n) :=
    Real.multipliable_one_add_of_summable hsum
  obtain ⟨R, hRpos, s, hs⟩ :=
    hmulti.eventually_bounded_finset_prod
  obtain ⟨N₀, hsRange⟩ := Finset.exists_nat_subset_range s
  obtain ⟨Mtail, hMtail⟩ :=
    exists_nat_gt ((C 0 : ℝ) * R)
  let Mprefix := (Finset.range (N₀ + 1)).sup C
  refine ⟨max Mprefix Mtail, fun n => ?_⟩
  by_cases hn : n ≤ N₀
  · have hmem : n ∈ Finset.range (N₀ + 1) :=
      Finset.mem_range.mpr (Nat.lt_succ_of_le hn)
    exact (Finset.le_sup hmem).trans (le_max_left _ _)
  · have hn₀ : N₀ ≤ n := Nat.le_of_not_ge hn
    have hprod :
        (∏ i ∈ Finset.range n, (1 + negativeRelativeMass C E i)) ≤ R := by
      apply hs
      exact hsRange.trans (Finset.range_mono hn₀)
    have hCnReal : (C n : ℝ) < Mtail := by
      calc
        (C n : ℝ) ≤
            C 0 * (∏ i ∈ Finset.range n, (1 + negativeRelativeMass C E i)) :=
              hCprod n
        _ ≤ C 0 * R :=
              mul_le_mul_of_nonneg_left hprod (by positivity)
        _ < Mtail := hMtail
    have hCn : C n ≤ Mtail := by
      exact_mod_cast (le_of_lt hCnReal)
    exact hCn.trans (le_max_right _ _)
