import Definitions.Def_ErdosProblems_Erdos243_ReciprocalTailRigidity
import Definitions.Def_ErdosProblems_Erdos243_SparseResetRecovery
import Mathlib.Algebra.Order.BigOperators.GroupWithZero.Finset
import Mathlib.Analysis.SpecialFunctions.Log.Summable
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.Data.Fin.Pigeonhole
import Mathlib.Data.Nat.ChineseRemainder
import Mathlib.Data.Nat.Find
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.ZMod.Basic
import Mathlib.Order.Filter.AtTopBot.Basic
import Mathlib.Tactic.Ring

/-!
# Erdős #243: sparse reset recovery

This module isolates the order-theoretic recovery forest behind dynamically
reduced reciprocal-tail orbits.  It also gives a division-free finite-product
bound for the full reset payment on a recovery interval.

The declarations do not exclude the unrestricted divergent-negative-mass
branch and therefore do not prove Erdős #243.
-/

namespace ErdosProblems.Erdos243
open scoped BigOperators

/-! ## Recovery intervals -/



















/-! ## Division-free payment bounds -/











/-! ## A checked endpoint consumer -/
end ErdosProblems.Erdos243

open scoped BigOperators
open ErdosProblems in
open ErdosProblems.Erdos243 in
theorem solution
    (C : ℕ → ℕ) (E : ℕ → ℤ)
    (hCpos : ∀ n, 0 < C n)
    (hstep :
      ∀ n, (C (n + 1) : ℤ) = (C n : ℤ) - E n) :
    ∀ n,
      (C (n + 1) : ℝ) ≤
        C n * (1 + negativeRelativeMass C E n) := by
  intro n
  have hCne : (C n : ℝ) ≠ 0 := by
    exact_mod_cast (ne_of_gt (hCpos n))
  by_cases he : E n ≤ 0
  · have hmin : min (E n) 0 = E n := min_eq_left he
    have habscast :
        (Int.natAbs (E n) : ℤ) = -E n :=
      Int.ofNat_natAbs_of_nonpos he
    have hstepR :
        (C (n + 1) : ℝ) =
          (C n : ℝ) - (E n : ℝ) := by
      exact_mod_cast hstep n
    rw [negativeRelativeMass, hmin]
    have habsR :
        (Int.natAbs (E n) : ℝ) = -(E n : ℝ) := by
      calc
        (Int.natAbs (E n) : ℝ) =
            (((Int.natAbs (E n) : ℕ) : ℤ) : ℝ) := by norm_num
        _ = ((-E n : ℤ) : ℝ) := by rw [habscast]
        _ = -(E n : ℝ) := by norm_num
    rw [habsR, hstepR]
    apply le_of_eq
    field_simp [hCne]
    ring
  · have hepos : 0 ≤ E n := by omega
    have hmin : min (E n) 0 = 0 := min_eq_right hepos
    have hstepR :
        (C (n + 1) : ℝ) =
          (C n : ℝ) - (E n : ℝ) := by
      exact_mod_cast hstep n
    rw [negativeRelativeMass, hmin]
    simp only [Int.natAbs_zero, Nat.cast_zero, zero_div, add_zero, mul_one]
    rw [hstepR]
    exact sub_le_self _ (by exact_mod_cast hepos)
