import Definitions.Def_ErdosProblems_Erdos243_ReciprocalTailRigidity
import Theorems.Thm_ErdosProblems_Erdos243_reducedStep_coprime_currentFactor
import Theorems.Thm_ErdosProblems_Erdos243_reducedTail_pairwiseCoprime
import Theorems.Thm_ErdosProblems_Erdos243_reducedTail_wholeModulusAvoidance
import Mathlib.Algebra.Order.BigOperators.GroupWithZero.Finset
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.Data.Fin.Pigeonhole
import Mathlib.Data.Nat.ChineseRemainder
import Mathlib.Data.Nat.Find
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.ZMod.Basic
import Mathlib.Order.Filter.AtTopBot.Basic
import Mathlib.Tactic
import Mathlib.Tactic.Ring

namespace ErdosProblems.Erdos243.PaperCompleteR7
end ErdosProblems.Erdos243.PaperCompleteR7

/-!
# Full paper assemblies for reduced tails and gcd stabilisation

The stable gcd is carried explicitly: the positivity, reducedness, and both
exact quotient recurrences are concluded.
No extra positivity assumption is imposed in the cofinal-negative version;
it is derived from the supplied signed-error hypotheses.
-/

open ErdosProblems in
open ErdosProblems.Erdos243 in
open ErdosProblems.Erdos243.PaperCompleteR7 in
theorem solution
    (a u v : ℕ → ℕ)
    (hred : ∀ n, Nat.Coprime (u n) (v n))
    (hu : ∀ n, u (n + 1) + v n = a n * u n)
    (hv : ∀ n, v (n + 1) = a n * v n) :
    (∀ n, Nat.Coprime (a n) (v n)) ∧
    (∀ i j, i ≠ j → Nat.Coprime (a i) (a j)) ∧
    (∀ i t, i < t → Nat.Coprime (a i) (u t)) := by
  refine ⟨?_, ?_, ?_⟩
  · intro n
    exact reducedStep_coprime_currentFactor (hred (n + 1)) (hu n) (hv n)
  · intro i j hij
    rcases lt_or_gt_of_ne hij with hlt | hgt
    · exact reducedTail_pairwiseCoprime a u v hred hu hv hlt
    · exact (reducedTail_pairwiseCoprime a u v hred hu hv hgt).symm
  · intro i t hit
    exact reducedTail_wholeModulusAvoidance a u v hred hv hit
