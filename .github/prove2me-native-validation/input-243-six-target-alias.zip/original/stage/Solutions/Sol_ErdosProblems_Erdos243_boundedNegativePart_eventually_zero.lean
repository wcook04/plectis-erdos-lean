import Definitions.Def_ErdosProblems_Erdos243_ReciprocalTailRigidity
import Theorems.Thm_ErdosProblems_Erdos243_centeredState_zero_absorbing
import Theorems.Thm_ErdosProblems_Erdos243_eventually_nonzero_of_zero_absorbing
import Theorems.Thm_ErdosProblems_Erdos243_tailState_tendsto_atTop_of_nonzero_normalizedVanishes
import Theorems.Thm_ErdosProblems_Erdos243_antitone_nat_eventually_constant
import Theorems.Thm_ErdosProblems_Erdos243_no_cofinallyBoundedNegative_of_tailTendsto
import Mathlib.Algebra.Order.BigOperators.GroupWithZero.Finset
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.Data.Fin.Pigeonhole
import Mathlib.Data.Nat.ChineseRemainder
import Mathlib.Data.Nat.Find
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.ZMod.Basic
import Mathlib.Order.Filter.AtTopBot.Basic
import Mathlib.Tactic.Ring

/-!
# Erdős #243: reciprocal-tail rigidity

This module owns the exact centered integer dynamics behind the rational case.
It proves the algebraic defect identity and the well-founded stabilization step:
if the centered errors are eventually nonnegative, the natural tail state is
nonincreasing and the errors eventually vanish.  It excludes both constant
negative centered states and, in the natural tail regime, every positive
eventually periodic negative-state magnitude.  It also proves the arithmetic
core of the stronger bounded-aperiodic route: an exact reduced tail tending to
infinity cannot have bounded upward increments.  That proof combines exact
coprimality, whole-modulus avoidance, a shifted CRT barrier, and first crossing.

It does not settle the unrestricted problem, whose live obstruction is an
integer centered state with cofinally unbounded negative excursions.  The full
bounded-negative-part regime is closed below without a periodicity hypothesis.
For the remaining branch, dynamic gcd reduction is also made exact: every gcd
growth factor is paid for by old-prime overlap.  Normalized centered-state
vanishing now yields local near-unit tail growth, explicit subexponential tail
growth, and hence sublinear strict gcd growth through the finite `2^r` budget.
The residual is to turn sparse old-prime reuse into a contradiction.
-/

namespace ErdosProblems.Erdos243
/-! The entire integer-state system is equivariant under a common scale.  This
removes a large family of duplicate constant-negative-state searches. -/







/-! ## Excluding the normalized constant-negative orbit

If `Eₙ = -1` and `C₀ = 1`, then `Cₙ = n + 1` and the centered-state
identity becomes

`Dₙ + 1 = (n + 1) (aₙ - 1)`.

On the other hand, `Dₙ₊₁ = aₙ Dₙ` makes every `Dₙ` with `n ≥ 1`
divisible by `a₀`.  Evaluating the displayed identity at `n = a₀ - 1`
would make both `Dₙ` and `Dₙ + 1` divisible by `a₀`, impossible for
`a₀ ≥ 2`.  This consumes the exact multiplicative denominator update above
and closes the normalized branch explored by `FiniteHorizonResidue`.
-/









/-! ## Excluding phase-primitive periodic negative magnitudes

The constant-negative argument has a periodic analogue.  Write `eₙ = -Eₙ`
for a positive negative-state magnitude, so that `Cₙ₊₁ = Cₙ + eₙ` and

`Dₙ + eₙ = (aₙ - 1) Cₙ`.

If a divisor `p` occurs in two distinct multiplier states `aⱼ` and `aₖ`, then
the first occurrence puts `p` into `Dₖ`, while the second occurrence forces
`p ∣ Cₖ₊₁`.  From there `p` divides every later `D`, `C`, and `e`.
When `e` is periodic and `C` has a fixed positive drift over one period, any
prime divisor of that drift propagates back to all phases.  A finite-prime
pigeonhole argument therefore excludes a phase-primitive periodic orbit.
-/



















/-! ## The bounded aperiodic route: a CRT barrier

Periodicity is not needed once the reduced exact tail supplies infinitely many
pairwise-coprime moduli which every later numerator must avoid.  The finite
producer below places a consecutive forbidden block past any prescribed
height. -/















/-! The remaining bounded-negative wrapper needs the tail gcd to stabilise.
The next lemmas kernel-check that exact arithmetic reduction. -/

/-! ## Dynamic cancellation and the gcd-growth budget

Before the tail gcd stabilises, reduction at consecutive indices introduces a
growth factor `h`.  The exact normalized step below shows that `h` is paid for
by overlap between the current multiplier and the reduced denominator.  The
finite counting lemmas then quantify how expensive strict gcd growth is.
-/





















































/-- Division-free normalized vanishing closes the cofinally bounded negative
branch by supplying the tail divergence needed above. -/
theorem no_cofinallyBoundedNegative_of_normalizedVanishes
    (a C D magnitude : ℕ → ℕ) (B : ℕ)
    (hB : 0 < B)
    (ha : ∀ n, 1 < a n)
    (hCpos : ∀ n, 0 < C n)
    (hC : ∀ n, C (n + 1) + D n = a n * C n)
    (hD : ∀ n, D (n + 1) = a n * D n)
    (hRise : ∀ n, C (n + 1) ≤ C n + B)
    (hmagnitude : ∀ n, 0 < magnitude n)
    (hvanish : ∀ K, ∃ N, ∀ n, N ≤ n →
      K * magnitude n < C n)
    (hnegative : ∀ n, ∃ t e, n ≤ t ∧ 0 < e ∧ e ≤ B ∧
      D t + e = (a t - 1) * C t) :
    False := by
  exact no_cofinallyBoundedNegative_of_tailTendsto a C D B hB ha hCpos
    hC hD hRise hnegative
    (tailState_tendsto_atTop_of_nonzero_normalizedVanishes
      C magnitude hmagnitude hvanish)









/-- The positive-integer stabilization step used by every one-sided #243
criterion.  If `Cₙ₊₁ + Eₙ = Cₙ`, then the nonnegative errors vanish
eventually. -/
theorem centeredState_eventually_zero
    (C E : ℕ → ℕ) (hrec : ∀ n, C (n + 1) + E n = C n) :
    ∃ N, ∀ n, N ≤ n → E n = 0 := by
  have hstep : ∀ n, C (n + 1) ≤ C n := fun n => by
    have := hrec n
    omega
  obtain ⟨N, hconst⟩ := antitone_nat_eventually_constant C hstep
  refine ⟨N, fun n hn => ?_⟩
  have hn1 : N ≤ n + 1 := hn.trans (Nat.le_succ n)
  have hsame : C (n + 1) = C n :=
    (hconst (n + 1) hn1).trans (hconst n hn).symm
  have := hrec n
  omega

/-! ## Bounded negative part: the signed wrapper

The preceding CRT theorem excludes cofinally many bounded negative errors once
their nonzero magnitudes vanish relative to the tail.  The final wrapper has
two additional ingredients.  First, the exact defect identity makes zero
absorbing as soon as the centered representative satisfies `|Eₙ| < Cₙ`.
Second, failure of cofinal negativity leaves an eventually nonnegative natural
tail, so `centeredState_eventually_zero` applies.
-/
end ErdosProblems.Erdos243

open ErdosProblems in
open ErdosProblems.Erdos243 in
theorem solution
    (a C D : ℕ → ℕ) (E : ℕ → ℤ) (B : ℕ)
    (ha : ∀ n, 1 < a n)
    (hCpos : ∀ n, 0 < C n)
    (hC : ∀ n, C (n + 1) + D n = a n * C n)
    (hD : ∀ n, D (n + 1) = a n * D n)
    (hE : ∀ n, E n = centeredState (a n : ℤ) (D n : ℤ) (C n : ℤ))
    (hcentered : ∀ n, Int.natAbs (E n) < C n)
    (hbound : ∀ n, -(B : ℤ) ≤ E n)
    (hvanish : ∀ K, ∃ N, ∀ n, N ≤ n →
      K * Int.natAbs (E n) < C n) :
    ∃ N, ∀ n, N ≤ n → E n = 0 := by
  by_contra hnot
  have habsorbing : ∀ n, E n = 0 → E (n + 1) = 0 := by
    intro n
    exact centeredState_zero_absorbing a C D E hC hD hE hcentered n
  have hnonzero : ∀ n, E n ≠ 0 :=
    fun n ↦ eventually_nonzero_of_zero_absorbing E 0
      (fun m _ ↦ habsorbing m) hnot n (Nat.zero_le n)
  by_cases hnegative : ∀ n, ∃ t, n ≤ t ∧ E t < 0
  · have hBpos : 0 < B := by
      obtain ⟨t, _, htneg⟩ := hnegative 0
      have htbound := hbound t
      omega
    have hRise : ∀ n, C (n + 1) ≤ C n + B := by
      intro n
      have htail := natTail_eq_sub_centeredState a C D E hC hE n
      have hboundn := hbound n
      exact_mod_cast (show (C (n + 1) : ℤ) ≤ (C n : ℤ) + (B : ℤ) by omega)
    have hmagnitude : ∀ n, 0 < Int.natAbs (E n) := by
      intro n
      exact Int.natAbs_pos.mpr (hnonzero n)
    have hnegativeShape : ∀ n, ∃ t e, n ≤ t ∧ 0 < e ∧ e ≤ B ∧
        D t + e = (a t - 1) * C t := by
      intro n
      obtain ⟨t, hnt, htneg⟩ := hnegative n
      let e := Int.natAbs (E t)
      have hepos : 0 < e := Int.natAbs_pos.mpr (hnonzero t)
      have hecast : (e : ℤ) = -E t := by
        dsimp [e]
        exact Int.ofNat_natAbs_of_nonpos (le_of_lt htneg)
      have heB : e ≤ B := by
        have htbound := hbound t
        exact_mod_cast (show (e : ℤ) ≤ (B : ℤ) by omega)
      have haone : 1 ≤ a t := by have := ha t; omega
      have hshapeCast :
          (D t : ℤ) + (e : ℤ) = ((a t - 1 : ℕ) : ℤ) * (C t : ℤ) := by
        rw [Nat.cast_sub haone]
        rw [hE t] at hecast
        simp only [centeredState] at hecast
        norm_num at hecast ⊢
        omega
      refine ⟨t, e, hnt, hepos, heB, ?_⟩
      exact_mod_cast hshapeCast
    exact no_cofinallyBoundedNegative_of_normalizedVanishes
      a C D (fun n ↦ Int.natAbs (E n)) B hBpos ha hCpos hC hD hRise
      hmagnitude hvanish hnegativeShape
  · push Not at hnegative
    obtain ⟨N, hnonnegative⟩ := hnegative
    let Eplus : ℕ → ℕ := fun n ↦ Int.toNat (E (N + n))
    have hrec : ∀ n, C (N + (n + 1)) + Eplus n = C (N + n) := by
      intro n
      have hnnonneg : 0 ≤ E (N + n) := hnonnegative (N + n) (by omega)
      apply Nat.cast_injective (R := ℤ)
      simp only [Nat.cast_add]
      rw [Int.toNat_of_nonneg hnnonneg]
      have htail := natTail_eq_sub_centeredState a C D E hC hE (N + n)
      have htail' :
          (C ((N + n) + 1) : ℤ) + E (N + n) = (C (N + n) : ℤ) := by
        omega
      simpa only [Nat.add_assoc] using htail'
    obtain ⟨K, hK⟩ := centeredState_eventually_zero
      (fun n ↦ C (N + n)) Eplus hrec
    refine hnot ⟨N + K, fun n hn ↦ ?_⟩
    have hNn : N ≤ n := by omega
    let k := n - N
    have hNk : N + k = n := Nat.add_sub_of_le hNn
    have hKk : K ≤ k := by omega
    have htoNat : Int.toNat (E n) = 0 := by
      simpa [Eplus, hNk] using hK k hKk
    have hnnonneg : 0 ≤ E n := hnonnegative n hNn
    have hcast := Int.toNat_of_nonneg hnnonneg
    rw [htoNat] at hcast
    exact hcast.symm
