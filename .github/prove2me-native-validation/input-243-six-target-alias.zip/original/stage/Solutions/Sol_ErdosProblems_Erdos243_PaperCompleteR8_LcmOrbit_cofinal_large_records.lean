import Definitions.Def_ErdosProblems_Erdos243_ReciprocalTailRigidity
import Definitions.Def_ErdosProblems_Erdos243_LcmRecordCrossing
import Definitions.Def_ErdosProblems_Erdos243_LcmRecordDivergence
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR7_Limits
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR7_RealTail_v243UnionFbf41fb8
import Definitions.Def_ErdosProblems_Erdos243_PrimitiveRecordBarrier
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR8_WeightAnalysis_v243UnionFbf41fb8
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR8_WeightedRecords_v243UnionFbf41fb8
import Theorems.Thm_ErdosProblems_Erdos243_PaperCompleteR8_LcmOrbit_old_digit_dvd
import Theorems.Thm_ErdosProblems_Erdos243_PaperCompleteR8_LcmOrbit_record_fresh
import Theorems.Thm_ErdosProblems_Erdos243_PaperCompleteR8_cofinal_records
import Mathlib
import Mathlib.Algebra.Order.BigOperators.GroupWithZero.Finset
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Analysis.SumIntegralComparisons
import Mathlib.Data.Fin.Pigeonhole
import Mathlib.Data.Nat.ChineseRemainder
import Mathlib.Data.Nat.Factorization.Basic
import Mathlib.Data.Nat.Find
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.ZMod.Basic
import Mathlib.Order.Filter.AtTopBot.Basic
import Mathlib.Tactic
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.InfiniteSum.NatInt
import Mathlib.Topology.Algebra.InfiniteSum.Real

namespace ErdosProblems.Erdos243.PaperCompleteR8.LcmOrbit
open Filter Classical
open scoped BigOperators
theorem record_digit_gt_one (o : LcmOrbit)
    (hc : ∀ n, -(o.U n : ℤ) ≤ 2 * o.V n)
    {n : ℕ} (hn : Record o.U n) : 1 < o.a n := by
  have hs := o.step n
  rw [o.record_fresh hc hn, Nat.cast_one, one_mul, o.digit n] at hs
  have hr : (o.U n : ℤ) < o.U (n + 1) := by exact_mod_cast hn n le_rfl
  have hL : (0 : ℤ) < o.L n := by exact_mod_cast o.Lpos n
  by_contra ha
  have hsmall : (o.a n : ℤ) ≤ 1 := by exact_mod_cast (show o.a n ≤ 1 by omega)
  have hU : (0 : ℤ) ≤ o.U n := by positivity
  have hm := mul_le_mul_of_nonneg_right hsmall hU
  nlinarith [hs]
end ErdosProblems.Erdos243.PaperCompleteR8.LcmOrbit

open ErdosProblems
open ErdosProblems.Erdos243
open ErdosProblems.Erdos243.PaperCompleteR8
open ErdosProblems.Erdos243.PaperCompleteR8.LcmOrbit
open Filter Classical
open scoped BigOperators
open ErdosProblems in
open ErdosProblems.Erdos243 in
open ErdosProblems.Erdos243.PaperCompleteR8 in
open ErdosProblems.Erdos243.PaperCompleteR8.LcmOrbit in
theorem solution (o : LcmOrbit)
    (hc : ∀ n, -(o.U n : ℤ) ≤ 2 * o.V n)
    (hu : HeightUnbounded o.U) (B T : ℕ) :
    ∃ n, T ≤ n ∧ Record o.U n ∧ B < o.a n := by
  classical
  let old : Fin (B + 1) → ℕ := fun i =>
    if hi : ∃ n, Record o.U n ∧ o.a n = i.val then Nat.find hi else 0
  let cutoff := T + (∑ i : Fin (B + 1), old i) + 1
  obtain ⟨n, hcut, hn⟩ := cofinal_records o.U hu cutoff
  refine ⟨n, by dsimp [cutoff] at hcut; omega, hn, ?_⟩
  by_contra hlarge
  have han : o.a n ≤ B := by omega
  let i : Fin (B + 1) := ⟨o.a n, by omega⟩
  have hex : ∃ k, Record o.U k ∧ o.a k = i.val := ⟨n, hn, rfl⟩
  have hold : old i = Nat.find hex := by simp only [old, dif_pos hex]
  have hspec : Record o.U (old i) ∧ o.a (old i) = o.a n := by
    rw [hold]
    exact Nat.find_spec hex
  have hsum : old i ≤ ∑ j : Fin (B + 1), old j :=
    Finset.single_le_sum (fun _ _ => Nat.zero_le _) (Finset.mem_univ i)
  have hbefore : old i < n := by dsimp [cutoff] at hcut; omega
  have hd : o.a n ∣ o.L n := by
    rw [← hspec.2]
    exact o.old_digit_dvd hbefore
  have hdone : o.a n ∣ 1 := by
    have hgg := Nat.dvd_gcd hd (dvd_refl (o.a n))
    rwa [o.record_fresh hc hn] at hgg
  have hsmall := Nat.le_of_dvd Nat.one_pos hdone
  have hgt := o.record_digit_gt_one hc hn
  omega
