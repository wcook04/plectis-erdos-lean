import Definitions.Def_ErdosProblems_Erdos243_ReciprocalTailRigidity
import Definitions.Def_ErdosProblems_Erdos243_LcmRecordCrossing
import Definitions.Def_ErdosProblems_Erdos243_LcmRecordDivergence
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR7_Limits
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR7_RealTail_v243UnionFbf41fb8
import Definitions.Def_ErdosProblems_Erdos243_PrimitiveRecordBarrier
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR8_WeightAnalysis_v243UnionFbf41fb8
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR8_WeightedRecords_v243UnionFbf41fb8
import Theorems.Thm_ErdosProblems_Erdos243_LcmRecordCrossing_exists_unique_firstCrossing
import Mathlib
import Mathlib.Algebra.Order.BigOperators.GroupWithZero.Finset
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Analysis.SumIntegralComparisons
import Mathlib.Data.Fin.Pigeonhole
import Mathlib.Data.Nat.ChineseRemainder
import Mathlib.Data.Nat.Factorization.Basic
import Mathlib.Data.Nat.Find
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.ZMod.Basic
import Mathlib.Order.Filter.AtTopBot.Basic
import Mathlib.Tactic
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.InfiniteSum.NatInt
import Mathlib.Topology.Algebra.InfiniteSum.Real

namespace ErdosProblems.Erdos243.PaperCompleteR8
open Filter Classical
open scoped BigOperators
end ErdosProblems.Erdos243.PaperCompleteR8

open ErdosProblems
open ErdosProblems.Erdos243
open ErdosProblems.Erdos243.PaperCompleteR8
open Filter Classical
open scoped BigOperators
open ErdosProblems in
open ErdosProblems.Erdos243 in
open ErdosProblems.Erdos243.PaperCompleteR8 in
theorem solution (U : ℕ → ℕ) (hu : HeightUnbounded U) (T : ℕ) :
    ∃ n, T ≤ n ∧ Record U n := by
  let z := runningMax U T + 1
  obtain ⟨K, hK⟩ := hu z
  have hzero : U 0 < z := by
    have h := le_runningMax U (Nat.zero_le T)
    dsimp [z]
    omega
  obtain ⟨n, hn, _⟩ := LcmRecordCrossing.exists_unique_firstCrossing
    U z K hzero ⟨K, le_rfl, hK.le⟩
  have hfirst := hn.2
  have hTn : T ≤ n := by
    by_contra hh
    have hle := le_runningMax U (show n + 1 ≤ T by omega)
    have hz := hfirst.2
    dsimp [z] at hz
    omega
  refine ⟨n, hTn, ?_⟩
  intro j hj
  exact (hfirst.1 j hj).trans_le hfirst.2
