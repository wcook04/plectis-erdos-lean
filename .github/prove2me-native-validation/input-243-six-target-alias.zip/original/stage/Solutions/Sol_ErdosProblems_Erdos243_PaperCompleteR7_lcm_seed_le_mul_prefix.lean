import Definitions.Def_ErdosProblems_Erdos243_ReciprocalTailRigidity
import Definitions.Def_ErdosProblems_Erdos243_GlobalLcmHeight
import Definitions.Def_ErdosProblems_Erdos243_CumulativeLcmTransfer
import Definitions.Def_ErdosProblems_Erdos243_LcmCriticalBoundary
import Definitions.Def_ErdosProblems_Erdos243_LcmRecordCrossing
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR7_Limits
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR7_RealTail_v243UnionFbf41fb8
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR7_CanonicalState_v243UnionFbf41fb8
import Definitions.Def_ErdosProblems_Erdos243_PrimitiveRecordBarrier
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR7_ProductDefect_v243UnionFbf41fb8
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR7_LcmDefect_v243UnionFbf41fb8
import Mathlib
import Mathlib.Algebra.Order.BigOperators.GroupWithZero.Finset
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Data.Fin.Pigeonhole
import Mathlib.Data.Nat.ChineseRemainder
import Mathlib.Data.Nat.Factorization.Basic
import Mathlib.Data.Nat.Find
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.ZMod.Basic
import Mathlib.Order.Filter.AtTopBot.Basic
import Mathlib.Tactic
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.InfiniteSum.NatInt

/-!
# Original-coordinate LCM-prefactor corollary

Compiled end-to-end candidate for short-note `res:lcmbounded`.
The rational denominator q is NOT assumed to divide the prefix LCM.
The proof constructs the lifted integer state, derives its small-error
hypothesis, supplies its one-sided bound from the printed LCM-weighted
expression, and invokes the global CRT argument, not a supply hypothesis.
-/

namespace ErdosProblems.Erdos243.PaperCompleteR7
open Filter
end ErdosProblems.Erdos243.PaperCompleteR7

open Filter
open ErdosProblems in
open ErdosProblems.Erdos243 in
open ErdosProblems.Erdos243.PaperCompleteR7 in
theorem solution (q : ℕ) (a : ℕ → ℕ)
    (hq : 0 < q) (ha : ∀ n, 0 < a n) (n : ℕ) :
    cumulativeDigitLcm q a n ≤ q * cumulativeDigitLcm 1 a n := by
  have hid : ∀ k, cumulativeDigitLcm q a k = Nat.lcm q (cumulativeDigitLcm 1 a k) := by
    intro k
    induction k with
    | zero => simp [cumulativeDigitLcm]
    | succ k ih => simp only [cumulativeDigitLcm, ih, Nat.lcm_assoc]
  rw [hid n]
  have hd : Nat.lcm q (cumulativeDigitLcm 1 a n) ∣ q * cumulativeDigitLcm 1 a n := by
    apply Nat.lcm_dvd
    · exact dvd_mul_right _ _
    · exact dvd_mul_left _ _
  exact Nat.le_of_dvd (Nat.mul_pos hq (cumulativeDigitLcm_pos (by norm_num) ha n)) hd
