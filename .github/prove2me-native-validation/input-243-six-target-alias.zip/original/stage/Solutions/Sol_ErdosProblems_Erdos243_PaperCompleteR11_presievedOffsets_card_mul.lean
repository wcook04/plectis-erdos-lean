import Definitions.Def_ErdosProblems_Erdos243_ReciprocalTailRigidity
import Definitions.Def_ErdosProblems_Erdos243_GlobalLcmHeight
import Definitions.Def_ErdosProblems_Erdos243_CumulativeLcmTransfer
import Definitions.Def_ErdosProblems_Erdos243_LcmCriticalBoundary
import Definitions.Def_ErdosProblems_Erdos243_LcmRecordCrossing
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR7_Limits
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR7_RealTail_v243UnionFbf41fb8
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR7_CanonicalState_v243UnionFbf41fb8
import Definitions.Def_ErdosProblems_Erdos243_PrimitiveRecordBarrier
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_RecordDivisibility_v243UnionFbf41fb8
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_PresievedCRT_v243UnionFbf41fb8
import Mathlib
import Mathlib.Algebra.Order.BigOperators.GroupWithZero.Finset
import Mathlib.Algebra.Ring.Basic
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Data.Fin.Pigeonhole
import Mathlib.Data.Nat.ChineseRemainder
import Mathlib.Data.Nat.Factorization.Basic
import Mathlib.Data.Nat.Find
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.Nat.Totient
import Mathlib.Data.Rat.Defs
import Mathlib.Data.ZMod.Basic
import Mathlib.Order.Filter.AtTopBot.Basic
import Mathlib.Tactic
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.InfiniteSum.NatInt

/-!
# Exact finite pre-sieving and the primitive record fence


The modulus W is part of the CRT construction, not merely mentioned in
an offset-counting hypothesis.  Thus x is a multiple of W, and only the
phi(W)/W proportion of offsets coprime to W need individual old moduli.
The exact count, its asymptotic proportion, the bounded CRT phase and the
primitive first-crossing contradiction are all supplied here.  Selection
of the canonical moduli and the final log-log limit remain separate.
-/

namespace ErdosProblems.Erdos243.PaperCompleteR11
open Filter
open scoped BigOperators Topology
end ErdosProblems.Erdos243.PaperCompleteR11

open Filter
open scoped BigOperators Topology
open ErdosProblems in
open ErdosProblems.Erdos243 in
open ErdosProblems.Erdos243.PaperCompleteR11 in
theorem solution (W k : ℕ) :
    (presievedOffsets W (k * W)).card = k * Nat.totient W := by
  classical
  induction k with
  | zero => simp [presievedOffsets]
  | succ k ih =>
      have hunion : presievedOffsets W ((k + 1) * W) =
          presievedOffsets W (k * W) ∪
            ((Finset.Ico (k * W) (k * W + W)).filter (fun r ↦ Nat.Coprime W r)) := by
        rw [Nat.add_mul, Nat.one_mul]
        ext r
        simp only [presievedOffsets, Finset.mem_filter, Finset.mem_range,
          Finset.mem_union, Finset.mem_Ico]
        omega
      have hdisj : Disjoint (presievedOffsets W (k * W))
          ((Finset.Ico (k * W) (k * W + W)).filter (fun r ↦ Nat.Coprime W r)) := by
        apply Finset.disjoint_left.mpr
        intro r hr hs
        have hlt := (Finset.mem_filter.mp hr).1
        have hge := (Finset.mem_Ico.mp (Finset.mem_filter.mp hs).1).1
        have hlt' := Finset.mem_range.mp hlt
        omega
      rw [hunion, Finset.card_union_of_disjoint hdisj, ih,
        Nat.filter_coprime_Ico_eq_totient]
      ring
