import Definitions.Def_ErdosProblems_Erdos243_ReciprocalTailRigidity
import Mathlib.Algebra.Order.BigOperators.GroupWithZero.Finset
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.Data.Fin.Pigeonhole
import Mathlib.Data.Nat.ChineseRemainder
import Mathlib.Data.Nat.Find
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.ZMod.Basic
import Mathlib.Order.Filter.AtTopBot.Basic
import Mathlib.Tactic.Ring

/-!
# Erdős #243: reciprocal-tail rigidity

This module owns the exact centered integer dynamics behind the rational case.
It proves the algebraic defect identity and the well-founded stabilization step:
if the centered errors are eventually nonnegative, the natural tail state is
nonincreasing and the errors eventually vanish.  It excludes both constant
negative centered states and, in the natural tail regime, every positive
eventually periodic negative-state magnitude.  It also proves the arithmetic
core of the stronger bounded-aperiodic route: an exact reduced tail tending to
infinity cannot have bounded upward increments.  That proof combines exact
coprimality, whole-modulus avoidance, a shifted CRT barrier, and first crossing.

It does not settle the unrestricted problem, whose live obstruction is an
integer centered state with cofinally unbounded negative excursions.  The full
bounded-negative-part regime is closed below without a periodicity hypothesis.
For the remaining branch, dynamic gcd reduction is also made exact: every gcd
growth factor is paid for by old-prime overlap.  Normalized centered-state
vanishing now yields local near-unit tail growth, explicit subexponential tail
growth, and hence sublinear strict gcd growth through the finite `2^r` budget.
The residual is to turn sparse old-prime reuse into a contradiction.
-/

namespace ErdosProblems.Erdos243
/-! The entire integer-state system is equivariant under a common scale.  This
removes a large family of duplicate constant-negative-state searches. -/







/-! ## Excluding the normalized constant-negative orbit

If `Eₙ = -1` and `C₀ = 1`, then `Cₙ = n + 1` and the centered-state
identity becomes

`Dₙ + 1 = (n + 1) (aₙ - 1)`.

On the other hand, `Dₙ₊₁ = aₙ Dₙ` makes every `Dₙ` with `n ≥ 1`
divisible by `a₀`.  Evaluating the displayed identity at `n = a₀ - 1`
would make both `Dₙ` and `Dₙ + 1` divisible by `a₀`, impossible for
`a₀ ≥ 2`.  This consumes the exact multiplicative denominator update above
and closes the normalized branch explored by `FiniteHorizonResidue`.
-/









/-! ## Excluding phase-primitive periodic negative magnitudes

The constant-negative argument has a periodic analogue.  Write `eₙ = -Eₙ`
for a positive negative-state magnitude, so that `Cₙ₊₁ = Cₙ + eₙ` and

`Dₙ + eₙ = (aₙ - 1) Cₙ`.

If a divisor `p` occurs in two distinct multiplier states `aⱼ` and `aₖ`, then
the first occurrence puts `p` into `Dₖ`, while the second occurrence forces
`p ∣ Cₖ₊₁`.  From there `p` divides every later `D`, `C`, and `e`.
When `e` is periodic and `C` has a fixed positive drift over one period, any
prime divisor of that drift propagates back to all phases.  A finite-prime
pigeonhole argument therefore excludes a phase-primitive periodic orbit.
-/



















/-! ## The bounded aperiodic route: a CRT barrier

Periodicity is not needed once the reduced exact tail supplies infinitely many
pairwise-coprime moduli which every later numerator must avoid.  The finite
producer below places a consecutive forbidden block past any prescribed
height. -/
end ErdosProblems.Erdos243

open ErdosProblems in
open ErdosProblems.Erdos243 in
theorem solution
    {k : ℕ}
    (m : Fin k → ℕ)
    (hm : ∀ i, 1 < m i)
    (hpair : ∀ i j, i ≠ j → Nat.Coprime (m i) (m j))
    (L : ℕ) :
    ∃ x, L < x ∧ ∀ i : Fin k, m i ∣ x + i.1 := by
  classical
  let residue : Fin k → ℕ := fun i ↦ m i - i.1 % m i
  have hm0 : ∀ i ∈ (Finset.univ : Finset (Fin k)), m i ≠ 0 := by
    intro i _
    have := hm i
    omega
  have hpairSet : Set.Pairwise
      (↑(Finset.univ : Finset (Fin k)) : Set (Fin k))
      (fun i j ↦ Nat.Coprime (m i) (m j)) := by
    intro i _ j _ hij
    exact hpair i j hij
  let y := Nat.chineseRemainderOfFinset residue m Finset.univ hm0 hpairSet
  let P := ∏ i : Fin k, m i
  have hPpos : 0 < P := by
    dsimp [P]
    exact Finset.prod_pos fun i _ ↦ by have := hm i; omega
  let x := (y : ℕ) + (L + 1) * P
  have hLx : L < x := by
    have hmul : L + 1 ≤ (L + 1) * P :=
      Nat.le_mul_of_pos_right (L + 1) hPpos
    dsimp [x]
    omega
  refine ⟨x, hLx, fun i ↦ ?_⟩
  have hy : (y : ℕ) ≡ residue i [MOD m i] :=
    y.property i (Finset.mem_univ i)
  have hremLt : i.1 % m i < m i := Nat.mod_lt _ (by have := hm i; omega)
  have hresidueDvd : m i ∣ residue i + i.1 := by
    refine ⟨i.1 / m i + 1, ?_⟩
    dsimp [residue]
    calc
      m i - i.1 % m i + i.1 =
          m i - i.1 % m i + (i.1 % m i + m i * (i.1 / m i)) := by
            rw [Nat.mod_add_div]
      _ = m i + m i * (i.1 / m i) := by omega
      _ = m i * (i.1 / m i + 1) := by ring
  have hyDvd : m i ∣ (y : ℕ) + i.1 := by
    apply Nat.modEq_zero_iff_dvd.mp
    exact (hy.add_right i.1).trans
      (Nat.modEq_zero_iff_dvd.mpr hresidueDvd)
  have hmP : m i ∣ P := by
    dsimp [P]
    simpa using Finset.dvd_prod_of_mem m (Finset.mem_univ i)
  have hmShift : m i ∣ (L + 1) * P :=
    dvd_mul_of_dvd_right hmP (L + 1)
  obtain ⟨q, hq⟩ := hyDvd
  obtain ⟨r, hr⟩ := hmShift
  refine ⟨q + r, ?_⟩
  dsimp [x]
  calc
    (y : ℕ) + (L + 1) * P + i.1 =
        ((y : ℕ) + i.1) + (L + 1) * P := by omega
    _ = m i * q + m i * r := by rw [hq, hr]
    _ = m i * (q + r) := by ring
