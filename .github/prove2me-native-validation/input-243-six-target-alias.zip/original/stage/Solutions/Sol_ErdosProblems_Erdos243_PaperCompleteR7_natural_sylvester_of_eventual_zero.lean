import Definitions.Def_ErdosProblems_Erdos243_ReciprocalTailRigidity
import Mathlib.Algebra.Order.BigOperators.GroupWithZero.Finset
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.Data.Fin.Pigeonhole
import Mathlib.Data.Nat.ChineseRemainder
import Mathlib.Data.Nat.Find
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.ZMod.Basic
import Mathlib.Order.Filter.AtTopBot.Basic
import Mathlib.Tactic
import Mathlib.Tactic.Ring

namespace ErdosProblems.Erdos243.PaperCompleteR7
end ErdosProblems.Erdos243.PaperCompleteR7

/-!
# Paper-complete campaign, round 7: exact algebra and signed descent

Source candidates for the supplied 7 September 2026 paper snapshot.
These files have NOT been compiled in the return environment.  No result
is represented as a new kernel-checked theorem in theorem_coverage.json.

The original declarations are reused.  New statements below assemble the
combined paper environments, extend the natural second-order identity to
the displayed integer domain, and prove signed eventual descent.
-/

open ErdosProblems in
open ErdosProblems.Erdos243 in
open ErdosProblems.Erdos243.PaperCompleteR7 in
theorem solution
    (a C D : ℕ → ℕ) (E : ℕ → ℤ)
    (hCpos : ∀ n, 0 < C n)
    (hC : ∀ n, C (n + 1) + D n = a n * C n)
    (hD : ∀ n, D (n + 1) = a n * D n)
    (hE : ∀ n, E n = centeredState (a n : ℤ) (D n : ℤ) (C n : ℤ))
    (hzero : ∃ N, ∀ n, N ≤ n → E n = 0) :
    ∃ N, ∀ n, N ≤ n → (a (n + 1) : ℤ) = sylvesterNext (a n : ℤ) := by
  obtain ⟨N, hN⟩ := hzero
  refine ⟨N, fun n hn ↦ ?_⟩
  apply sylvesterNext_eq_of_centered_zero (a n : ℤ) (a (n + 1) : ℤ)
    (D n : ℤ) (C n : ℤ)
  · rw [← natTail_eq_nextTailState a C D hC n]
    exact_mod_cast (hCpos (n + 1)).ne'
  · rw [← hE n]
    exact hN n hn
  · rw [← natDen_eq_nextDenState a D hD n,
      ← natTail_eq_nextTailState a C D hC n, ← hE (n + 1)]
    exact hN (n + 1) (by omega)
