import Definitions.Def_ErdosProblems_Erdos243_ReciprocalTailRigidity
import Definitions.Def_ErdosProblems_Erdos243_GlobalLcmHeight
import Definitions.Def_ErdosProblems_Erdos243_CumulativeLcmTransfer
import Definitions.Def_ErdosProblems_Erdos243_LcmCriticalBoundary
import Definitions.Def_ErdosProblems_Erdos243_LcmRecordCrossing
import Definitions.Def_ErdosProblems_Erdos243_LcmRecordDivergence
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR7_Limits
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR7_RealTail_v243UnionFbf41fb8
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR7_CanonicalState_v243UnionFbf41fb8
import Definitions.Def_ErdosProblems_Erdos243_PrimitiveRecordBarrier
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR7_ProductDefect_v243UnionFbf41fb8
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR7_LcmDefect_v243UnionFbf41fb8
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR8_WeightAnalysis_v243UnionFbf41fb8
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR8_WeightedRecords_v243UnionFbf41fb8
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR8_CanonicalWeightedRecords_v243UnionFbf41fb8
import Theorems.Thm_ErdosProblems_Erdos243_PaperCompleteR7_natural_sylvester_of_eventual_zero
import Theorems.Thm_ErdosProblems_Erdos243_PaperCompleteR7_zero_digit_of_bounded_height
import Theorems.Thm_ErdosProblems_Erdos243_PaperCompleteR8_rawRecordWeight_nonneg
import Theorems.Thm_ErdosProblems_Erdos243_PaperCompleteR8_summable_of_eventually_zero_nonneg
import Theorems.Thm_ErdosProblems_Erdos243_PaperCompleteR8_arithmetic_weighted_record_eventually_centred
import Theorems.Thm_ErdosProblems_Erdos243_PaperCompleteR8_canonicalLcmOrbit_normalized
import Theorems.Thm_ErdosProblems_Erdos243_PaperCompleteR8_eventual_zero_of_sylvester_and_normalized
import Theorems.Thm_ErdosProblems_Erdos243_PaperCompleteR8_integer_abs_bounds
import Mathlib
import Mathlib.Algebra.Order.BigOperators.GroupWithZero.Finset
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Analysis.SumIntegralComparisons
import Mathlib.Data.Fin.Pigeonhole
import Mathlib.Data.Nat.ChineseRemainder
import Mathlib.Data.Nat.Factorization.Basic
import Mathlib.Data.Nat.Find
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.ZMod.Basic
import Mathlib.Order.Filter.AtTopBot.Basic
import Mathlib.Tactic
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.InfiniteSum.NatInt
import Mathlib.Topology.Algebra.InfiniteSum.Real

/-!
# The canonical weighted-record equivalence

Complete compiled candidates for both occurrences of `res:weightedrecord`.
The rational value is supplied as `HasSum ... (p/q)`, exactly as in the
repaired r7 canonical-state theorem. All tail integrality and small-error
facts come from that theorem; none are additional hypotheses here.

The eventual-centred arithmetic theorem is obtained by shifting at a genuine
running maximum. Shifting at an arbitrary index would change the record set.
The converse implication uses the exact squared-error transport on a
Sylvester tail, rather than presuming zero error from the recurrence.

Mathlib facts used for casts and products also occur in the repaired r7
`LcmDefect.lean`: Int.natAbs_mul, Int.natAbs_natCast,
Nat.mul_lt_mul_left. All substantial arithmetic imports are supplied sources.
-/

namespace ErdosProblems.Erdos243.PaperCompleteR8
open Filter Classical
open scoped BigOperators
end ErdosProblems.Erdos243.PaperCompleteR8

open Filter Classical
open scoped BigOperators
open ErdosProblems in
open ErdosProblems.Erdos243 in
open ErdosProblems.Erdos243.PaperCompleteR8 in
theorem solution
    (a : ℕ → ℕ) (ha : StrictMono a) (hapos : ∀ n, 0 < a n)
    (p : ℤ) (q : ℕ) (hq : 0 < q)
    (hs : HasSum (fun n => 1 / (a n : ℝ)) ((p : ℝ) / (q : ℝ)))
    (hg : Tendsto (fun n => (a (n + 1) : ℝ) / (a n : ℝ) ^ 2) atTop (nhds 1))
    (f : ℕ → ℝ) (hf : Antitone f) (hpos : ∀ n, 0 ≤ f n) (hdiv : ¬ Summable f) :
    let o := canonicalLcmOrbit a ha hapos p q hq hs hg
    (∃ N, ∀ n, N ≤ n → (a (n + 1) : ℤ) = sylvesterNext (a n : ℤ)) ↔
      ∃ B : ℕ, Summable (rawRecordWeight o.U o.V B f) := by
  let o := canonicalLcmOrbit a ha hapos p q hq hs hg
  let C := PaperCompleteR7.canonicalNaturalNumerator a p q
  let D := PaperCompleteR7.canonicalDenominator a q
  let E := fun n => centeredState (a n : ℤ) (D n : ℤ) (C n : ℤ)
  obtain ⟨hCp, _hDp, hC, hD, _hrep, hv, _hc⟩ :=
    PaperCompleteR7.canonical_integer_tail_normalized a ha hapos p q hq hs hg
  have hscale : ∀ n, D n = digitProductScale q a n :=
    fun n => (PaperCompleteR7.productScale_eq_canonicalDenominator q a n).symm
  have hVeq : ∀ n, (cumulativeOverlapDebt q a n : ℤ) * o.V n = E n :=
    lcmLiftedDigit_mul_overlapDebt q a C D hscale hC
  have hVo := canonicalLcmOrbit_normalized a ha hapos p q hq hs hg
  have hcent : ∃ N, ∀ n, N ≤ n → -(o.U n : ℤ) ≤ 2 * o.V n := by
    obtain ⟨N, hN⟩ := hVo 2
    refine ⟨N, ?_⟩
    intro n hn
    have hb : (2 : ℤ) * Int.natAbs (o.V n) < o.U n := by
      exact_mod_cast hN n hn
    have hl := (integer_abs_bounds (o.V n)).1
    omega
  constructor
  · intro hS
    have hz := eventual_zero_of_sylvester_and_normalized a C D E hapos hC hD
      (fun _ => rfl) hv hS
    obtain ⟨N, hN⟩ := hz
    refine ⟨0, summable_of_eventually_zero_nonneg _
      (rawRecordWeight_nonneg _ _ _ _ hpos) ⟨N, ?_⟩⟩
    intro n hn
    have hM : (cumulativeOverlapDebt q a n : ℤ) ≠ 0 := by
      exact_mod_cast (cumulativeOverlapDebt_pos hq hapos n).ne'
    have hzero : o.V n = 0 := by
      have hh := hVeq n
      rw [hN n hn] at hh
      exact (mul_eq_zero.mp hh).resolve_left hM
    unfold rawRecordWeight
    rw [hzero]
    simp only [neg_zero, Nat.cast_zero, sub_zero, Int.toNat_zero,
      Nat.cast_zero, zero_mul, ite_self]
  · rintro ⟨B, hB⟩
    have hbound := (arithmetic_weighted_record_eventually_centred o hcent B f hf hpos hdiv).mpr hB
    obtain ⟨N, hN⟩ := PaperCompleteR7.zero_digit_of_bounded_height o.U o.V hbound hVo
    have hzero : ∃ N, ∀ n, N ≤ n → E n = 0 := by
      refine ⟨N, fun n hn => ?_⟩
      rw [← hVeq n, hN n hn, mul_zero]
    exact PaperCompleteR7.natural_sylvester_of_eventual_zero a C D E hCp hC hD
      (fun _ => rfl) hzero
