import Mathlib

namespace ErdosProblems.Erdos243.LcmRecordExcess
end ErdosProblems.Erdos243.LcmRecordExcess

/-!
# Finite arithmetic and weighted charging for LCM record crossings

These lemmas verify the local arithmetic and charging steps of
`LcmRecordExcess.md`. They do not formalise its analytic divergence theorem,
its canonical-orbit transfer, or unrestricted Erdős 243.
-/

open ErdosProblems in
open ErdosProblems.Erdos243 in
open ErdosProblems.Erdos243.LcmRecordExcess in
theorem solution {h P d B : ℕ}
    (hP : B < P) (hd : B < d)
    (hspacing : (h - 1) * P < d) : h ≤ d - B := by
  by_contra hh
  have hge : d - B ≤ h - 1 := by omega
  have hmul : (d - B) * P ≤ (h - 1) * P := Nat.mul_le_mul_right P hge
  have hrem : 1 ≤ d - B := by omega
  have hBP : B + 1 ≤ P := by omega
  have hbound : d ≤ (d - B) * P := by
    have hmul2 := Nat.mul_le_mul_left (d - B) hBP
    have hmul3 := Nat.mul_le_mul_right B hrem
    have hsplit : d - B + B = d := Nat.sub_add_cancel (by omega)
    nlinarith
  omega
