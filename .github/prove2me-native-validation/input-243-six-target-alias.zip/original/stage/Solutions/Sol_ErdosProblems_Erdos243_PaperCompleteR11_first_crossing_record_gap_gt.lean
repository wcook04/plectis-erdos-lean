import Definitions.Def_ErdosProblems_Erdos243_ReciprocalTailRigidity
import Definitions.Def_ErdosProblems_Erdos243_GlobalLcmHeight
import Definitions.Def_ErdosProblems_Erdos243_CumulativeLcmTransfer
import Definitions.Def_ErdosProblems_Erdos243_LcmCriticalBoundary
import Definitions.Def_ErdosProblems_Erdos243_LcmRecordCrossing
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR7_Limits
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR7_RealTail_v243UnionFbf41fb8
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR7_CanonicalState_v243UnionFbf41fb8
import Definitions.Def_ErdosProblems_Erdos243_PrimitiveRecordBarrier
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_RecordDivisibility_v243UnionFbf41fb8
import Theorems.Thm_ErdosProblems_Erdos243_runningMax_lt
import Mathlib
import Mathlib.Algebra.Order.BigOperators.GroupWithZero.Finset
import Mathlib.Algebra.Ring.Basic
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Data.Fin.Pigeonhole
import Mathlib.Data.Nat.ChineseRemainder
import Mathlib.Data.Nat.Factorization.Basic
import Mathlib.Data.Nat.Find
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.Rat.Defs
import Mathlib.Data.ZMod.Basic
import Mathlib.Order.Filter.AtTopBot.Basic
import Mathlib.Tactic
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.InfiniteSum.NatInt

/-!
# Record fences without primitivity


Unlike a source-jump fence, the result below charges the *record increment*.
It allows arbitrarily deep intervening drawdowns and does not assume that
numerator and denominator are coprime. It is a finite ingredient of the
inclusive log-log argument, not a declaration of that analytic endpoint.
-/

namespace ErdosProblems.Erdos243.PaperCompleteR11
open scoped BigOperators



/-- A common divisor of an exact state survives every subsequent step.
The coefficient may be any integer; no positivity is needed. -/
theorem common_divisor_persists
    (C D a b : ℕ → ℤ)
    (hC : ∀ n, C (n + 1) = a n * C n - b n * D n)
    (hD : ∀ n, D (n + 1) = a n * D n)
    (m : ℤ) {s t : ℕ} (hst : s ≤ t)
    (hmC : m ∣ C s) (hmD : m ∣ D s) :
    m ∣ C t ∧ m ∣ D t := by
  obtain ⟨k, rfl⟩ := Nat.exists_eq_add_of_le hst
  induction k with
  | zero => simpa using And.intro hmC hmD
  | succ k ih =>
      have ih' := ih (by omega : s ≤ s + k)
      constructor
      · rw [show s + (k + 1) = (s + k) + 1 by omega, hC]
        exact dvd_sub (dvd_mul_of_dvd_right ih'.1 _) (dvd_mul_of_dvd_right ih'.2 _)
      · rw [show s + (k + 1) = (s + k) + 1 by omega, hD]
        exact dvd_mul_of_dvd_right ih'.2 _



/-- An old divisor found at an *attained previous record* divides the new
record gap, even if the source of the new record is far below that record. -/
theorem old_divisor_dvd_record_gap
    (U : ℕ → ℕ) (D a b : ℕ → ℤ)
    (hC : ∀ n, (U (n + 1) : ℤ) = a n * U n - b n * D n)
    (hD : ∀ n, D (n + 1) = a n * D n)
    (m : ℤ) {j n : ℕ} (hjn : j ≤ n)
    (hrecord : U j = runningMax U n)
    (hmU : m ∣ (U j : ℤ)) (hmD : m ∣ D j) :
    m ∣ (U (n + 1) : ℤ) - runningMax U n := by
  have hfuture := common_divisor_persists
    (fun k ↦ (U k : ℤ)) D a b hC hD m
    (show j ≤ n + 1 by omega) hmU hmD
  rw [← hrecord]
  exact dvd_sub hfuture.1 hmU
end ErdosProblems.Erdos243.PaperCompleteR11

open scoped BigOperators
open ErdosProblems in
open ErdosProblems.Erdos243 in
open ErdosProblems.Erdos243.PaperCompleteR11 in
theorem solution
    (U : ℕ → ℕ) (D a b : ℕ → ℤ) (T x B n : ℕ)
    (hC : ∀ k, (U (k + 1) : ℤ) = a k * U k - b k * D k)
    (hD : ∀ k, D (k + 1) = a k * D k)
    (hprefix : runningMax U T < x)
    (hfirst : LcmRecordCrossing.FirstCrossing U (x + B) n)
    (hcover : ∀ j, T ≤ j → ∀ z : ℕ, x ≤ z → z < x + B →
      ∃ m : ℤ, (B : ℤ) < m ∧ m ∣ (z : ℤ) ∧ m ∣ D j) :
    B < U (n + 1) - runningMax U n := by
  by_contra hnot
  have hgap : U (n + 1) - runningMax U n ≤ B := by omega
  have hRlt : runningMax U n < x + B := runningMax_lt U hfirst.1
  have hreach : x + B ≤ U (n + 1) := hfirst.2
  have hRnew : runningMax U n < U (n + 1) := hRlt.trans_le hreach
  have hgap_eq : U (n + 1) - runningMax U n + runningMax U n = U (n + 1) :=
    Nat.sub_add_cancel hRnew.le
  have hRx : x ≤ runningMax U n := by omega
  obtain ⟨j, hjn, hj⟩ := runningMax_attained U n
  have hTj : T ≤ j := by
    by_contra hbad
    have hu := le_runningMax U (show j ≤ T by omega)
    omega
  obtain ⟨m, hm, hmU, hmD⟩ := hcover j hTj (U j) (by omega) (by omega)
  have hdiv := old_divisor_dvd_record_gap U D a b hC hD m hjn hj hmU hmD
  have hpos : 0 < (U (n + 1) : ℤ) - runningMax U n := by
    apply sub_pos.mpr
    exact_mod_cast hRnew
  have hle := Int.le_of_dvd hpos hdiv
  have hgapZ : (U (n + 1) : ℤ) - runningMax U n ≤ (B : ℤ) := by omega
  omega
