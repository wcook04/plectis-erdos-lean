import Mathlib

namespace ErdosProblems.Erdos243.LcmRecordExcess
end ErdosProblems.Erdos243.LcmRecordExcess

/-!
# Finite arithmetic and weighted charging for LCM record crossings

These lemmas verify the local arithmetic and charging steps of
`LcmRecordExcess.md`. They do not formalise its analytic divergence theorem,
its canonical-orbit transfer, or unrestricted Erdős 243.
-/

open ErdosProblems in
open ErdosProblems.Erdos243 in
open ErdosProblems.Erdos243.LcmRecordExcess in
theorem solution {U U' V rho : ℤ}
    (hU : 0 < U) (hrho : 1 ≤ rho)
    (hcenter : -U ≤ 2 * V) (hstep : rho * U' = U - V)
    (hrise : U < U') : rho = 1 ∧ U' - U = -V := by
  have hsmall : rho < 2 := by
    by_contra h
    have hlarge : 2 ≤ rho := by omega
    have hprod : 2 * U' ≤ rho * U' := by nlinarith
    nlinarith
  have hone : rho = 1 := by omega
  constructor
  · exact hone
  · rw [hone] at hstep
    linarith
