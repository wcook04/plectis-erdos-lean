import Definitions.Def_ErdosProblems_Erdos243_ReciprocalTailRigidity
import Theorems.Thm_ErdosProblems_Erdos243_exists_shifted_consecutiveMultiples
import Mathlib.Algebra.Order.BigOperators.GroupWithZero.Finset
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.Data.Fin.Pigeonhole
import Mathlib.Data.Nat.ChineseRemainder
import Mathlib.Data.Nat.Find
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.ZMod.Basic
import Mathlib.Order.Filter.AtTopBot.Basic
import Mathlib.Tactic.Ring

/-!
# Erdős #243: reciprocal-tail rigidity

This module owns the exact centered integer dynamics behind the rational case.
It proves the algebraic defect identity and the well-founded stabilization step:
if the centered errors are eventually nonnegative, the natural tail state is
nonincreasing and the errors eventually vanish.  It excludes both constant
negative centered states and, in the natural tail regime, every positive
eventually periodic negative-state magnitude.  It also proves the arithmetic
core of the stronger bounded-aperiodic route: an exact reduced tail tending to
infinity cannot have bounded upward increments.  That proof combines exact
coprimality, whole-modulus avoidance, a shifted CRT barrier, and first crossing.

It does not settle the unrestricted problem, whose live obstruction is an
integer centered state with cofinally unbounded negative excursions.  The full
bounded-negative-part regime is closed below without a periodicity hypothesis.
For the remaining branch, dynamic gcd reduction is also made exact: every gcd
growth factor is paid for by old-prime overlap.  Normalized centered-state
vanishing now yields local near-unit tail growth, explicit subexponential tail
growth, and hence sublinear strict gcd growth through the finite `2^r` budget.
The residual is to turn sparse old-prime reuse into a contradiction.
-/

namespace ErdosProblems.Erdos243
/-! The entire integer-state system is equivariant under a common scale.  This
removes a large family of duplicate constant-negative-state searches. -/







/-! ## Excluding the normalized constant-negative orbit

If `Eₙ = -1` and `C₀ = 1`, then `Cₙ = n + 1` and the centered-state
identity becomes

`Dₙ + 1 = (n + 1) (aₙ - 1)`.

On the other hand, `Dₙ₊₁ = aₙ Dₙ` makes every `Dₙ` with `n ≥ 1`
divisible by `a₀`.  Evaluating the displayed identity at `n = a₀ - 1`
would make both `Dₙ` and `Dₙ + 1` divisible by `a₀`, impossible for
`a₀ ≥ 2`.  This consumes the exact multiplicative denominator update above
and closes the normalized branch explored by `FiniteHorizonResidue`.
-/









/-! ## Excluding phase-primitive periodic negative magnitudes

The constant-negative argument has a periodic analogue.  Write `eₙ = -Eₙ`
for a positive negative-state magnitude, so that `Cₙ₊₁ = Cₙ + eₙ` and

`Dₙ + eₙ = (aₙ - 1) Cₙ`.

If a divisor `p` occurs in two distinct multiplier states `aⱼ` and `aₖ`, then
the first occurrence puts `p` into `Dₖ`, while the second occurrence forces
`p ∣ Cₖ₊₁`.  From there `p` divides every later `D`, `C`, and `e`.
When `e` is periodic and `C` has a fixed positive drift over one period, any
prime divisor of that drift propagates back to all phases.  A finite-prime
pigeonhole argument therefore excludes a phase-primitive periodic orbit.
-/



















/-! ## The bounded aperiodic route: a CRT barrier

Periodicity is not needed once the reduced exact tail supplies infinitely many
pairwise-coprime moduli which every later numerator must avoid.  The finite
producer below places a consecutive forbidden block past any prescribed
height. -/
end ErdosProblems.Erdos243

open ErdosProblems in
open ErdosProblems.Erdos243 in
theorem solution
    (u m : ℕ → ℕ) (N B : ℕ)
    (hB : 0 < B)
    (hm : ∀ n, N ≤ n → 1 < m n)
    (hpair : ∀ {i j : ℕ}, N ≤ i → N ≤ j → i ≠ j →
      Nat.Coprime (m i) (m j))
    (havoid : ∀ {i t : ℕ}, N ≤ i → i < t →
      Nat.Coprime (m i) (u t))
    (hrise : ∀ n, N ≤ n → u (n + 1) ≤ u n + B)
    (huTop : Filter.Tendsto u Filter.atTop Filter.atTop) :
    False := by
  let selected : Fin B → ℕ := fun i ↦ m (N + i.1)
  have hselected : ∀ i, 1 < selected i := by
    intro i
    exact hm (N + i.1) (by omega)
  have hselectedPair : ∀ i j, i ≠ j →
      Nat.Coprime (selected i) (selected j) := by
    intro i j hij
    apply hpair (by omega) (by omega)
    intro hindex
    apply hij
    apply Fin.ext
    omega
  let T := N + B
  obtain ⟨x, hxT, hxDiv⟩ :=
    exists_shifted_consecutiveMultiples selected hselected hselectedPair (u T)
  have hforbidden : ∀ t, T ≤ t →
      ¬ (x ≤ u t ∧ u t < x + B) := by
    intro t ht ⟨hxu, huTopBlock⟩
    let rNat := u t - x
    have hrLt : rNat < B := by
      dsimp [rNat]
      omega
    let r : Fin B := ⟨rNat, hrLt⟩
    have hxr : x + r.1 = u t := by
      dsimp [r, rNat]
      omega
    have hmodDvd : m (N + r.1) ∣ u t := by
      rw [← hxr]
      exact hxDiv r
    have hindexLt : N + r.1 < t := by
      dsimp [T] at ht
      have hr := r.2
      omega
    have hcop : Nat.Coprime (m (N + r.1)) (u t) :=
      havoid (by omega) hindexLt
    have hone : m (N + r.1) = 1 :=
      Nat.eq_one_of_dvd_coprimes hcop dvd_rfl hmodDvd
    have hmgt := hm (N + r.1) (by omega)
    omega
  obtain ⟨K, hK⟩ := (Filter.tendsto_atTop_atTop.mp huTop) (x + B)
  let t0 := max K (T + 1)
  have ht0T : T < t0 := by
    dsimp [t0]
    exact lt_of_lt_of_le (Nat.lt_succ_self T) (le_max_right K (T + 1))
  have hu0 : x + B ≤ u t0 := hK t0 (le_max_left K (T + 1))
  let P : ℕ → Prop := fun t ↦ T < t ∧ x + B ≤ u t
  have hP : ∃ t, P t := ⟨t0, ht0T, hu0⟩
  let t := Nat.find hP
  have htP : P t := Nat.find_spec hP
  have htPrev : T ≤ t - 1 := by
    dsimp [P] at htP
    omega
  have htSucc : t - 1 + 1 = t := by
    dsimp [P] at htP
    omega
  have huPrevTop : u (t - 1) < x + B := by
    by_contra hnot
    have hge : x + B ≤ u (t - 1) := by omega
    by_cases heq : t - 1 = T
    · rw [heq] at hge
      omega
    · have hTlt : T < t - 1 := by omega
      have hmin : t ≤ t - 1 := Nat.find_min' hP ⟨hTlt, hge⟩
      omega
  have huPrevBelow : u (t - 1) < x := by
    by_contra hnot
    have hxle : x ≤ u (t - 1) := by omega
    exact hforbidden (t - 1) htPrev ⟨hxle, huPrevTop⟩
  have hRise := hrise (t - 1) (le_trans (by omega) htPrev)
  rw [htSucc] at hRise
  dsimp [P] at htP
  omega
