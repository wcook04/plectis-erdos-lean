import Definitions.Def_ErdosProblems_Erdos243_ReciprocalTailRigidity
import Definitions.Def_ErdosProblems_Erdos243_GlobalLcmHeight
import Definitions.Def_ErdosProblems_Erdos243_CumulativeLcmTransfer
import Definitions.Def_ErdosProblems_Erdos243_LcmCriticalBoundary
import Definitions.Def_ErdosProblems_Erdos243_LcmRecordCrossing
import Definitions.Def_ErdosProblems_Erdos243_LcmRecordDivergence
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR7_Limits
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR7_RealTail_v243UnionFbf41fb8
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR7_CanonicalState_v243UnionFbf41fb8
import Definitions.Def_ErdosProblems_Erdos243_PrimitiveRecordBarrier
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR7_ProductDefect_v243UnionFbf41fb8
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR7_LcmDefect_v243UnionFbf41fb8
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR8_WeightAnalysis_v243UnionFbf41fb8
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR8_WeightedRecords_v243UnionFbf41fb8
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR8_CanonicalWeightedRecords_v243UnionFbf41fb8
import Mathlib
import Mathlib.Algebra.Order.BigOperators.GroupWithZero.Finset
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Analysis.SumIntegralComparisons
import Mathlib.Data.Fin.Pigeonhole
import Mathlib.Data.Nat.ChineseRemainder
import Mathlib.Data.Nat.Factorization.Basic
import Mathlib.Data.Nat.Find
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.ZMod.Basic
import Mathlib.Order.Filter.AtTopBot.Basic
import Mathlib.Tactic
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.InfiniteSum.NatInt
import Mathlib.Topology.Algebra.InfiniteSum.Real

/-!
# The canonical weighted-record equivalence

Complete compiled candidates for both occurrences of `res:weightedrecord`.
The rational value is supplied as `HasSum ... (p/q)`, exactly as in the
repaired r7 canonical-state theorem. All tail integrality and small-error
facts come from that theorem; none are additional hypotheses here.

The eventual-centred arithmetic theorem is obtained by shifting at a genuine
running maximum. Shifting at an arbitrary index would change the record set.
The converse implication uses the exact squared-error transport on a
Sylvester tail, rather than presuming zero error from the recurrence.

Mathlib facts used for casts and products also occur in the repaired r7
`LcmDefect.lean`: Int.natAbs_mul, Int.natAbs_natCast,
Nat.mul_lt_mul_left. All substantial arithmetic imports are supplied sources.
-/

namespace ErdosProblems.Erdos243.PaperCompleteR8
open Filter Classical
open scoped BigOperators



/-- On an exact Sylvester tail the error is multiplied by a squared digit.
This is the missing converse transport in a state-level equivalence. -/
theorem error_square_transport_of_sylvester
    (a C D : ℕ → ℕ) (E : ℕ → ℤ)
    (hC : ∀ n, C (n + 1) + D n = a n * C n)
    (hD : ∀ n, D (n + 1) = a n * D n)
    (hE : ∀ n, E n = centeredState (a n : ℤ) (D n : ℤ) (C n : ℤ))
    (n : ℕ) (hS : (a (n + 1) : ℤ) = sylvesterNext (a n : ℤ)) :
    E (n + 1) = (a n : ℤ) ^ 2 * E n := by
  have hh := sylvesterDefect_mul_nextTailState
    (a n : ℤ) (a (n + 1) : ℤ) (D n : ℤ) (C n : ℤ)
  rw [← natTail_eq_nextTailState a C D hC n,
    ← natDen_eq_nextDenState a D hD n, ← hE n, ← hE (n + 1)] at hh
  have hd : sylvesterDefect (a n : ℤ) (a (n + 1) : ℤ) = 0 := by
    unfold sylvesterDefect
    rw [hS]
    exact sub_self _
  rw [hd, zero_mul] at hh
  omega
end ErdosProblems.Erdos243.PaperCompleteR8

open Filter Classical
open scoped BigOperators
open ErdosProblems in
open ErdosProblems.Erdos243 in
open ErdosProblems.Erdos243.PaperCompleteR8 in
theorem solution
    (a C D : ℕ → ℕ) (E : ℕ → ℤ)
    (ha : ∀ n, 0 < a n)
    (hC : ∀ n, C (n + 1) + D n = a n * C n)
    (hD : ∀ n, D (n + 1) = a n * D n)
    (hE : ∀ n, E n = centeredState (a n : ℤ) (D n : ℤ) (C n : ℤ))
    (hv : ∀ K : ℕ, ∃ N, ∀ n, N ≤ n → K * Int.natAbs (E n) < C n)
    (hS : ∃ N, ∀ n, N ≤ n → (a (n + 1) : ℤ) = sylvesterNext (a n : ℤ)) :
    ∃ N, ∀ n, N ≤ n → E n = 0 := by
  obtain ⟨N, hN⟩ := hS
  refine ⟨N, ?_⟩
  intro n hNn
  by_contra hne
  have habspos : 1 ≤ Int.natAbs (E n) := by
    have hnabs : Int.natAbs (E n) ≠ 0 := by
      intro hz
      exact hne (Int.natAbs_eq_zero.mp hz)
    omega
  have htransport : ∀ t, n ≤ t →
      Int.natAbs (E (t + 1)) = (a t) ^ 2 * Int.natAbs (E t) := by
    intro t hnt
    have he := error_square_transport_of_sylvester a C D E hC hD hE t
      (hN t (hNn.trans hnt))
    have hcast : (a t : ℤ) ^ 2 = ((a t ^ 2 : ℕ) : ℤ) := by norm_cast
    rw [he, hcast, Int.natAbs_mul, Int.natAbs_natCast]
  have hbound : ∀ t, n ≤ t → C t ≤ C n * Int.natAbs (E t) := by
    intro t hnt
    induction t, hnt using Nat.le_induction with
    | base => nlinarith [habspos]
    | succ t hnt ih =>
        have hCstep : C (t + 1) ≤ a t * C t := by
          have hh := hC t
          omega
        have ha1 : 1 ≤ a t := ha t
        have hasq : a t ≤ a t ^ 2 := by nlinarith
        have hscaled := Nat.mul_le_mul_right (C t) hasq
        have hscaled' := Nat.mul_le_mul_left (a t ^ 2) ih
        rw [htransport t hnt]
        calc
          C (t + 1) ≤ a t * C t := hCstep
          _ ≤ a t ^ 2 * C t := hscaled
          _ ≤ a t ^ 2 * (C n * Int.natAbs (E t)) := hscaled'
          _ = C n * (a t ^ 2 * Int.natAbs (E t)) := by ring
  obtain ⟨T, hT⟩ := hv (C n)
  have hh := hT (max T n) (le_max_left _ _)
  have hb := hbound (max T n) (le_max_right _ _)
  omega
