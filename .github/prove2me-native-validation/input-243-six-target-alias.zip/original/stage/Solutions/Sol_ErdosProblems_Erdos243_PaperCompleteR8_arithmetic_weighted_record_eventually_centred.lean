import Definitions.Def_ErdosProblems_Erdos243_ReciprocalTailRigidity
import Definitions.Def_ErdosProblems_Erdos243_GlobalLcmHeight
import Definitions.Def_ErdosProblems_Erdos243_CumulativeLcmTransfer
import Definitions.Def_ErdosProblems_Erdos243_LcmCriticalBoundary
import Definitions.Def_ErdosProblems_Erdos243_LcmRecordCrossing
import Definitions.Def_ErdosProblems_Erdos243_LcmRecordDivergence
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR7_Limits
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR7_RealTail_v243UnionFbf41fb8
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR7_CanonicalState_v243UnionFbf41fb8
import Definitions.Def_ErdosProblems_Erdos243_PrimitiveRecordBarrier
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR7_ProductDefect_v243UnionFbf41fb8
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR7_LcmDefect_v243UnionFbf41fb8
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR8_WeightAnalysis_v243UnionFbf41fb8
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR8_WeightedRecords_v243UnionFbf41fb8
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR8_CanonicalWeightedRecords_v243UnionFbf41fb8
import Theorems.Thm_ErdosProblems_Erdos243_PaperCompleteR8_cofinal_records
import Theorems.Thm_ErdosProblems_Erdos243_PaperCompleteR8_bounded_eventually_no_record
import Theorems.Thm_ErdosProblems_Erdos243_PaperCompleteR8_not_bounded_iff_unbounded
import Theorems.Thm_ErdosProblems_Erdos243_PaperCompleteR8_rawRecordWeight_nonneg
import Theorems.Thm_ErdosProblems_Erdos243_PaperCompleteR8_record_shift_iff
import Theorems.Thm_ErdosProblems_Erdos243_PaperCompleteR8_shift_unbounded
import Theorems.Thm_ErdosProblems_Erdos243_PaperCompleteR8_summable_of_eventually_zero_nonneg
import Theorems.Thm_ErdosProblems_Erdos243_PaperCompleteR8_summable_shift_iff
import Theorems.Thm_ErdosProblems_Erdos243_PaperCompleteR8_unbounded_record_charge_not_summable
import Mathlib
import Mathlib.Algebra.Order.BigOperators.GroupWithZero.Finset
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Analysis.SumIntegralComparisons
import Mathlib.Data.Fin.Pigeonhole
import Mathlib.Data.Nat.ChineseRemainder
import Mathlib.Data.Nat.Factorization.Basic
import Mathlib.Data.Nat.Find
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.ZMod.Basic
import Mathlib.Order.Filter.AtTopBot.Basic
import Mathlib.Tactic
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.InfiniteSum.NatInt
import Mathlib.Topology.Algebra.InfiniteSum.Real

/-!
# The canonical weighted-record equivalence

Complete compiled candidates for both occurrences of `res:weightedrecord`.
The rational value is supplied as `HasSum ... (p/q)`, exactly as in the
repaired r7 canonical-state theorem. All tail integrality and small-error
facts come from that theorem; none are additional hypotheses here.

The eventual-centred arithmetic theorem is obtained by shifting at a genuine
running maximum. Shifting at an arbitrary index would change the record set.
The converse implication uses the exact squared-error transport on a
Sylvester tail, rather than presuming zero error from the recurrence.

Mathlib facts used for casts and products also occur in the repaired r7
`LcmDefect.lean`: Int.natAbs_mul, Int.natAbs_natCast,
Nat.mul_lt_mul_left. All substantial arithmetic imports are supplied sources.
-/

namespace ErdosProblems.Erdos243.PaperCompleteR8
open Filter Classical
open scoped BigOperators
end ErdosProblems.Erdos243.PaperCompleteR8

open Filter Classical
open scoped BigOperators
open ErdosProblems in
open ErdosProblems.Erdos243 in
open ErdosProblems.Erdos243.PaperCompleteR8 in
theorem solution
    (o : LcmOrbit)
    (hc : ∃ N, ∀ n, N ≤ n → -(o.U n : ℤ) ≤ 2 * o.V n)
    (B : ℕ) (f : ℕ → ℝ) (hf : Antitone f)
    (hpos : ∀ n, 0 ≤ f n) (hdiv : ¬ Summable f) :
    HeightBounded o.U ↔ Summable (rawRecordWeight o.U o.V B f) := by
  constructor
  · intro hb
    apply summable_of_eventually_zero_nonneg _ (rawRecordWeight_nonneg _ _ _ _ hpos)
    obtain ⟨T, hT⟩ := bounded_eventually_no_record o.U hb
    refine ⟨T, fun n hn => ?_⟩
    exact if_neg (hT n hn)
  · intro hs
    by_contra hb
    have hu := (not_bounded_iff_unbounded o.U).mp hb
    obtain ⟨N, hN⟩ := hc
    obtain ⟨r, hNr, hr⟩ := cofinal_records o.U hu N
    let T := r + 1
    have hTmax : ∀ j, j ≤ T → o.U j ≤ o.U T := by
      intro j hj
      by_cases heq : j = T
      · rw [heq]
      · exact (hr j (by dsimp [T] at *; omega)).le
    have hct : ∀ n, -((o.shift T).U n : ℤ) ≤ 2 * (o.shift T).V n := by
      intro n
      exact hN (T + n) (by dsimp [T]; omega)
    have heq : rawRecordWeight (o.shift T).U (o.shift T).V B f =
        fun n => rawRecordWeight o.U o.V B f (T + n) := by
      funext n
      change (if Record (fun k => o.U (T + k)) n then
        (((-o.V (T + n) - B).toNat : ℕ) : ℝ) * f (o.U (T + n)) else 0) = _
      rw [record_shift_iff o.U T n hTmax]
      rfl
    have ht : Summable (rawRecordWeight (o.shift T).U (o.shift T).V B f) := by
      rw [heq]
      exact (summable_shift_iff _ T).mpr hs
    exact unbounded_record_charge_not_summable (o.shift T) hct
      (shift_unbounded o.U hu T) B f hf hpos hdiv ht
