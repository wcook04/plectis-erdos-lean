import Definitions.Def_ErdosProblems_Erdos243_ReciprocalTailRigidity
import Mathlib.Algebra.Order.BigOperators.GroupWithZero.Finset
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.Data.Fin.Pigeonhole
import Mathlib.Data.Nat.ChineseRemainder
import Mathlib.Data.Nat.Find
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.ZMod.Basic
import Mathlib.Order.Filter.AtTopBot.Basic
import Mathlib.Tactic.Ring

/-!
# Erdős #243: the slow-rise barrier by common-divisor persistence

`ReciprocalTailRigidity.lean` excludes a *bounded* negative part by stabilising
the tail gcd, reducing the orbit, and running a CRT block against the
pairwise-coprime reduced multipliers.  Gcd stabilisation needs bounded negative
magnitudes, so that route stops exactly at the bounded regime.

This module replaces gcd stabilisation by *persistence*: a common divisor of
one tail state `Cₙ` and denominator state `Dₙ` divides every later `Cₜ`, `Dₜ`,
and therefore every later centred error `Eₜ = Dₜ - (aₜ - 1) Cₜ`.  A landing on a
CRT block therefore locks a whole block modulus into every later error, and the
next negative error is at least that modulus.  The CRT block is placed in
`[P, 2P)` for `P` the block product, so the rise bound is only needed below `2P`.

Consequences kernel-checked here:

* `exists_consecutiveMultiples_between`: the bounded CRT block.
* `commonDivisor_persists`, `multiplierOverlap_persists`,
  `multiplierOverlap_dvd_laterCenteredState`: persistence, and the unconditional
  fact that `gcd(aₙ, Dₙ)` divides every later centred error.
* `slowRise_landing`: a tail state starting below the block product that rises
  by at most `B` while below `2P` lands on a block modulus, which then divides
  every later state.
* `no_slowNegative_of_coprimeBlock`: with cofinal negativity and every negative
  error below `2P + B` smaller than every block modulus, contradiction.
* `no_slowRise_reducedTail`: the reduced-tail form, generalising
  `no_boundedRise_reducedTail` from a uniform rise bound to a rise bound that is
  only required below twice the product of `B` consecutive multipliers.

No hypothesis of periodicity, bounded negative part, or stable gcd appears.
The analytic transfer (which moduli to choose on the canonical orbit, and that
`(1 - δ) log₂ log₂ Cₙ` is an admissible rise bound) is an ordinary proof in
`SlowNegativePartRigidity.md`; it is not formalised.  Nothing here settles
Erdős #243.
-/

namespace ErdosProblems.Erdos243
/-! ## The bounded CRT block -/
end ErdosProblems.Erdos243

open ErdosProblems in
open ErdosProblems.Erdos243 in
theorem solution
    {k : ℕ}
    (m : Fin k → ℕ)
    (hm : ∀ i, 1 < m i)
    (hpair : ∀ i j, i ≠ j → Nat.Coprime (m i) (m j)) :
    ∃ x, (∏ i, m i) ≤ x ∧ x < 2 * ∏ i, m i ∧ ∀ i : Fin k, m i ∣ x + i.1 := by
  classical
  let residue : Fin k → ℕ := fun i ↦ m i - i.1 % m i
  have hm0 : ∀ i ∈ (Finset.univ : Finset (Fin k)), m i ≠ 0 := by
    intro i _
    have := hm i
    omega
  have hpairSet : Set.Pairwise
      (↑(Finset.univ : Finset (Fin k)) : Set (Fin k))
      (fun i j ↦ Nat.Coprime (m i) (m j)) := by
    intro i _ j _ hij
    exact hpair i j hij
  let y := Nat.chineseRemainderOfFinset residue m Finset.univ hm0 hpairSet
  let P := ∏ i : Fin k, m i
  have hPpos : 0 < P := by
    dsimp [P]
    exact Finset.prod_pos fun i _ ↦ by have := hm i; omega
  let x := (y : ℕ) % P + P
  have hmodLt : (y : ℕ) % P < P := Nat.mod_lt _ hPpos
  refine ⟨x, ?_, ?_, fun i ↦ ?_⟩
  · dsimp [x, P]
    omega
  · dsimp [x, P] at hmodLt ⊢
    omega
  · have hy : (y : ℕ) ≡ residue i [MOD m i] :=
      y.property i (Finset.mem_univ i)
    have hmP : m i ∣ P := by
      dsimp [P]
      simpa using Finset.dvd_prod_of_mem m (Finset.mem_univ i)
    have hyP : (y : ℕ) % P ≡ (y : ℕ) [MOD m i] :=
      (Nat.mod_modEq (y : ℕ) P).of_dvd hmP
    have hremLt : i.1 % m i < m i := Nat.mod_lt _ (by have := hm i; omega)
    have hresidueDvd : m i ∣ residue i + i.1 := by
      refine ⟨i.1 / m i + 1, ?_⟩
      dsimp [residue]
      calc
        m i - i.1 % m i + i.1 =
            m i - i.1 % m i + (i.1 % m i + m i * (i.1 / m i)) := by
              rw [Nat.mod_add_div]
        _ = m i + m i * (i.1 / m i) := by omega
        _ = m i * (i.1 / m i + 1) := by ring
    have hcong : (y : ℕ) % P + i.1 ≡ residue i + i.1 [MOD m i] :=
      (hyP.trans hy).add_right i.1
    have hyDvd : m i ∣ (y : ℕ) % P + i.1 :=
      Nat.modEq_zero_iff_dvd.mp
        (hcong.trans (Nat.modEq_zero_iff_dvd.mpr hresidueDvd))
    have hx : x + i.1 = ((y : ℕ) % P + i.1) + P := by
      dsimp [x]
      omega
    rw [hx]
    exact dvd_add hyDvd hmP
