import Definitions.Def_ErdosProblems_Erdos243_ReciprocalTailRigidity
import Definitions.Def_ErdosProblems_Erdos243_LcmRecordCrossing
import Theorems.Thm_ErdosProblems_Erdos243_LcmRecordCrossing_exists_unique_firstCrossing
import Mathlib
import Mathlib.Algebra.Order.BigOperators.GroupWithZero.Finset
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.Data.Fin.Pigeonhole
import Mathlib.Data.Nat.ChineseRemainder
import Mathlib.Data.Nat.Find
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.ZMod.Basic
import Mathlib.Order.Filter.AtTopBot.Basic
import Mathlib.Tactic.Ring

namespace LcmRecordExcess
end LcmRecordExcess

/-!
# Counting the CRT heights crossed by one arithmetic step

The heights are the actual arithmetic progression `x + k * P`, not an
assumed cardinality bound. This supplies the finite local charging step in
the weighted-record argument of `LcmRecordExcess.md`. First-crossing existence,
uniqueness, and the finite partition across time require no monotonicity of
the numerator sequence. The existing CRT construction supplies the covering
from any finite family of sufficiently large pairwise-coprime old divisors.
Producing that family from an infinite canonical orbit and the analytic
divergence argument are not asserted by this module.
-/

namespace ErdosProblems.Erdos243.LcmRecordCrossing
open LcmRecordExcess
end ErdosProblems.Erdos243.LcmRecordCrossing

open LcmRecordExcess
open ErdosProblems in
open ErdosProblems.Erdos243 in
open ErdosProblems.Erdos243.LcmRecordCrossing in
open ErdosProblems.Erdos243.LcmRecordExcess in
theorem solution (s : Finset ℕ) (U t : ℕ → ℕ)
    (N : ℕ) (w : ℕ → ℝ)
    (hzero : ∀ k ∈ s, U 0 < t k)
    (hN : ∀ k ∈ s, ∃ j ≤ N, t k ≤ U j) :
    ∑ k ∈ s, w k =
      ∑ n ∈ Finset.range N, ∑ k ∈ s,
        if FirstCrossing U (t k) n then w k else 0 := by
  classical
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro k hk
  obtain ⟨n, hn, hunique⟩ := exists_unique_firstCrossing U (t k) N
    (hzero k hk) (hN k hk)
  have hiff : ∀ m ∈ Finset.range N, FirstCrossing U (t k) m ↔ m = n := by
    intro m hm
    constructor
    · intro h
      exact hunique m ⟨Finset.mem_range.mp hm, h⟩
    · intro h
      simpa only [h] using hn.2
  symm
  calc
    ∑ m ∈ Finset.range N, (if FirstCrossing U (t k) m then w k else 0) =
        ∑ m ∈ Finset.range N, (if m = n then w k else 0) := by
      apply Finset.sum_congr rfl
      intro m hm
      simp only [hiff m hm]
    _ = w k := by simp [Finset.mem_range.mpr hn.1]
