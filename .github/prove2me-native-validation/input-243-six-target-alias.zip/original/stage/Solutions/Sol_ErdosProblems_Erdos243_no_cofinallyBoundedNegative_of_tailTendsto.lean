import Definitions.Def_ErdosProblems_Erdos243_ReciprocalTailRigidity
import Theorems.Thm_ErdosProblems_Erdos243_no_eventuallyBoundedRise_reducedTail
import Theorems.Thm_ErdosProblems_Erdos243_tailGcd_eventuallyConstant_of_cofinally_boundedNegative
import Mathlib.Algebra.Order.BigOperators.GroupWithZero.Finset
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.Data.Fin.Pigeonhole
import Mathlib.Data.Nat.ChineseRemainder
import Mathlib.Data.Nat.Find
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.ZMod.Basic
import Mathlib.Order.Filter.AtTopBot.Basic
import Mathlib.Tactic.Ring

/-!
# Erdős #243: reciprocal-tail rigidity

This module owns the exact centered integer dynamics behind the rational case.
It proves the algebraic defect identity and the well-founded stabilization step:
if the centered errors are eventually nonnegative, the natural tail state is
nonincreasing and the errors eventually vanish.  It excludes both constant
negative centered states and, in the natural tail regime, every positive
eventually periodic negative-state magnitude.  It also proves the arithmetic
core of the stronger bounded-aperiodic route: an exact reduced tail tending to
infinity cannot have bounded upward increments.  That proof combines exact
coprimality, whole-modulus avoidance, a shifted CRT barrier, and first crossing.

It does not settle the unrestricted problem, whose live obstruction is an
integer centered state with cofinally unbounded negative excursions.  The full
bounded-negative-part regime is closed below without a periodicity hypothesis.
For the remaining branch, dynamic gcd reduction is also made exact: every gcd
growth factor is paid for by old-prime overlap.  Normalized centered-state
vanishing now yields local near-unit tail growth, explicit subexponential tail
growth, and hence sublinear strict gcd growth through the finite `2^r` budget.
The residual is to turn sparse old-prime reuse into a contradiction.
-/

namespace ErdosProblems.Erdos243
/-! The entire integer-state system is equivariant under a common scale.  This
removes a large family of duplicate constant-negative-state searches. -/







/-! ## Excluding the normalized constant-negative orbit

If `Eₙ = -1` and `C₀ = 1`, then `Cₙ = n + 1` and the centered-state
identity becomes

`Dₙ + 1 = (n + 1) (aₙ - 1)`.

On the other hand, `Dₙ₊₁ = aₙ Dₙ` makes every `Dₙ` with `n ≥ 1`
divisible by `a₀`.  Evaluating the displayed identity at `n = a₀ - 1`
would make both `Dₙ` and `Dₙ + 1` divisible by `a₀`, impossible for
`a₀ ≥ 2`.  This consumes the exact multiplicative denominator update above
and closes the normalized branch explored by `FiniteHorizonResidue`.
-/









/-! ## Excluding phase-primitive periodic negative magnitudes

The constant-negative argument has a periodic analogue.  Write `eₙ = -Eₙ`
for a positive negative-state magnitude, so that `Cₙ₊₁ = Cₙ + eₙ` and

`Dₙ + eₙ = (aₙ - 1) Cₙ`.

If a divisor `p` occurs in two distinct multiplier states `aⱼ` and `aₖ`, then
the first occurrence puts `p` into `Dₖ`, while the second occurrence forces
`p ∣ Cₖ₊₁`.  From there `p` divides every later `D`, `C`, and `e`.
When `e` is periodic and `C` has a fixed positive drift over one period, any
prime divisor of that drift propagates back to all phases.  A finite-prime
pigeonhole argument therefore excludes a phase-primitive periodic orbit.
-/



















/-! ## The bounded aperiodic route: a CRT barrier

Periodicity is not needed once the reduced exact tail supplies infinitely many
pairwise-coprime moduli which every later numerator must avoid.  The finite
producer below places a consecutive forbidden block past any prescribed
height. -/















/-! The remaining bounded-negative wrapper needs the tail gcd to stabilise.
The next lemmas kernel-check that exact arithmetic reduction. -/

/-! ## Dynamic cancellation and the gcd-growth budget

Before the tail gcd stabilises, reduction at consecutive indices introduces a
growth factor `h`.  The exact normalized step below shows that `h` is paid for
by overlap between the current multiplier and the reduced denominator.  The
finite counting lemmas then quantify how expensive strict gcd growth is.
-/
end ErdosProblems.Erdos243

open ErdosProblems in
open ErdosProblems.Erdos243 in
theorem solution
    (a C D : ℕ → ℕ) (B : ℕ)
    (hB : 0 < B)
    (ha : ∀ n, 1 < a n)
    (hCpos : ∀ n, 0 < C n)
    (hC : ∀ n, C (n + 1) + D n = a n * C n)
    (hD : ∀ n, D (n + 1) = a n * D n)
    (hRise : ∀ n, C (n + 1) ≤ C n + B)
    (hnegative : ∀ n, ∃ t e, n ≤ t ∧ 0 < e ∧ e ≤ B ∧
      D t + e = (a t - 1) * C t)
    (hCTop : Filter.Tendsto C Filter.atTop Filter.atTop) :
    False := by
  obtain ⟨N, hG⟩ := tailGcd_eventuallyConstant_of_cofinally_boundedNegative
    a C D B hCpos hC hD hnegative
  let g := Nat.gcd (C N) (D N)
  have hgPos : 0 < g := by
    dsimp [g]
    exact Nat.gcd_pos_of_pos_left (D N) (hCpos N)
  have hgC : ∀ n, N ≤ n → g ∣ C n := by
    intro n hn
    dsimp [g]
    rw [← hG n hn]
    exact Nat.gcd_dvd_left (C n) (D n)
  have hgD : ∀ n, N ≤ n → g ∣ D n := by
    intro n hn
    dsimp [g]
    rw [← hG n hn]
    exact Nat.gcd_dvd_right (C n) (D n)
  let u : ℕ → ℕ := fun n ↦ C n / g
  let v : ℕ → ℕ := fun n ↦ D n / g
  have hred : ∀ n, N ≤ n → Nat.Coprime (u n) (v n) := by
    intro n hn
    have hcop := Nat.coprime_div_gcd_div_gcd
      (Nat.gcd_pos_of_pos_left (D n) (hCpos n))
    dsimp [u, v]
    simpa [hG n hn] using hcop
  have hu : ∀ n, N ≤ n → u (n + 1) + v n = a n * u n := by
    intro n hn
    apply Nat.eq_of_mul_eq_mul_left hgPos
    dsimp [u, v]
    calc
      g * (C (n + 1) / g + D n / g) = C (n + 1) + D n := by
        rw [Nat.mul_add, Nat.mul_div_cancel' (hgC (n + 1) (by omega)),
          Nat.mul_div_cancel' (hgD n hn)]
      _ = a n * C n := hC n
      _ = g * (a n * (C n / g)) := by
        have hCn : C n = g * (C n / g) :=
          (Nat.mul_div_cancel' (hgC n hn)).symm
        calc
          a n * C n = a n * (g * (C n / g)) :=
            congrArg (fun x ↦ a n * x) hCn
          _ = g * (a n * (C n / g)) := by ring
  have hv : ∀ n, N ≤ n → v (n + 1) = a n * v n := by
    intro n hn
    dsimp [v]
    rw [hD n]
    exact Nat.mul_div_assoc (a n) (hgD n hn)
  have huRise : ∀ n, N ≤ n → u (n + 1) ≤ u n + B := by
    intro n hn
    have hmul : g * (C (n + 1) / g) ≤ g * (C n / g + B) := by
      rw [Nat.mul_div_cancel' (hgC (n + 1) (by omega)), Nat.mul_add,
        Nat.mul_div_cancel' (hgC n hn)]
      have hBmul : B ≤ g * B := by
        simpa [Nat.mul_comm] using Nat.le_mul_of_pos_right B hgPos
      exact (hRise n).trans (Nat.add_le_add_left hBmul (C n))
    dsimp [u]
    exact Nat.le_of_mul_le_mul_left hmul hgPos
  have huTop : Filter.Tendsto u Filter.atTop Filter.atTop := by
    have hdivMap : Filter.Tendsto (fun x : ℕ ↦ x / g)
        Filter.atTop Filter.atTop :=
      le_of_eq (Filter.map_div_atTop_eq_nat g hgPos)
    exact hdivMap.comp hCTop
  exact no_eventuallyBoundedRise_reducedTail a u v N B hB
    (fun n _ ↦ ha n) hred hu hv huRise huTop
