import Definitions.Def_ErdosProblems_Erdos243_ReciprocalTailRigidity
import Definitions.Def_ErdosProblems_Erdos243_GlobalLcmHeight
import Definitions.Def_ErdosProblems_Erdos243_CumulativeLcmTransfer
import Definitions.Def_ErdosProblems_Erdos243_LcmCriticalBoundary
import Definitions.Def_ErdosProblems_Erdos243_LcmRecordCrossing
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR7_Limits
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR7_RealTail_v243UnionFbf41fb8
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR7_CanonicalState_v243UnionFbf41fb8
import Definitions.Def_ErdosProblems_Erdos243_PrimitiveRecordBarrier
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_RecordDivisibility_v243UnionFbf41fb8
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_CoprimeCores_v243UnionFbf41fb8
import Theorems.Thm_ErdosProblems_Erdos243_LcmRecordCrossing_exists_crt_covering_progression
import Theorems.Thm_ErdosProblems_Erdos243_PaperCompleteR11_bounded_by_record_cover
import Theorems.Thm_ErdosProblems_Erdos243_PaperCompleteR11_le_coprimeCore_mul_gcd_bound
import Theorems.Thm_ErdosProblems_Erdos243_PaperCompleteR11_quotient_dvd_quotient_of_dvd
import Mathlib
import Mathlib.Algebra.Order.BigOperators.GroupWithZero.Finset
import Mathlib.Algebra.Ring.Basic
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Data.Fin.Pigeonhole
import Mathlib.Data.Nat.ChineseRemainder
import Mathlib.Data.Nat.Factorization.Basic
import Mathlib.Data.Nat.Find
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.Rat.Defs
import Mathlib.Data.ZMod.Basic
import Mathlib.Order.Filter.AtTopBot.Basic
import Mathlib.Tactic
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.InfiniteSum.NatInt

/-!
# Coprime cores of a finite non-coprime family

Removing gcd(A_i, product of all other A_j) yields pairwise-coprime
cores. The loss is bounded by the product of the pairwise gcds. This avoids
an unproved supply of pairwise-coprime original multipliers in the
non-stabilised-gcd branch of the inclusive argument.
-/

namespace ErdosProblems.Erdos243.PaperCompleteR11
open scoped BigOperators









theorem coprimeCore_mul_denom {B : ℕ} (A : Fin B → ℕ) (i : Fin B) :
    coprimeCore A i * coreDenom A i = A i :=
  Nat.div_mul_cancel (Nat.gcd_dvd_left _ _)

theorem coprimeCore_dvd {B : ℕ} (A : Fin B → ℕ) (i : Fin B) :
    coprimeCore A i ∣ A i := ⟨coreDenom A i, (coprimeCore_mul_denom A i).symm⟩

theorem pair_gcd_dvd_coreDenom {B : ℕ} (A : Fin B → ℕ)
    {i j : Fin B} (hij : i ≠ j) : Nat.gcd (A i) (A j) ∣ coreDenom A i := by
  apply Nat.dvd_gcd (Nat.gcd_dvd_left _ _)
  apply (Nat.gcd_dvd_right (A i) (A j)).trans
  apply Finset.dvd_prod_of_mem
  simp only [Finset.mem_erase, Finset.mem_univ, and_true]
  exact Ne.symm hij

/-- Pairwise coprimality does not require that any original pair be coprime. -/
theorem coprimeCore_pairwise {B : ℕ} (A : Fin B → ℕ)
    (hA : ∀ i, 0 < A i) :
    ∀ i j, i ≠ j → Nat.Coprime (coprimeCore A i) (coprimeCore A j) := by
  intro i j hij
  have hqi : coprimeCore A i ∣ A i / Nat.gcd (A i) (A j) :=
    quotient_dvd_quotient_of_dvd (A i) (coreDenom A i) (Nat.gcd (A i) (A j))
      (hA i) (pair_gcd_dvd_coreDenom A hij) (Nat.gcd_dvd_left _ _)
  have hqj : coprimeCore A j ∣ A j / Nat.gcd (A i) (A j) := by
    rw [Nat.gcd_comm (A i) (A j)]
    exact quotient_dvd_quotient_of_dvd (A j) (coreDenom A j) (Nat.gcd (A j) (A i))
      (hA j) (pair_gcd_dvd_coreDenom A (Ne.symm hij)) (Nat.gcd_dvd_left _ _)
  have hc := Nat.coprime_div_gcd_div_gcd (Nat.gcd_pos_of_pos_left (A j) (hA i))
  exact (hc.of_dvd_left hqi).of_dvd_right hqj
end ErdosProblems.Erdos243.PaperCompleteR11

open scoped BigOperators
open ErdosProblems in
open ErdosProblems.Erdos243 in
open ErdosProblems.Erdos243.PaperCompleteR11 in
theorem solution
    (U : ℕ → ℕ) (D a b : ℕ → ℤ) (T B H : ℕ) (hB : 0 < B)
    (A : Fin B → ℕ) (hA : ∀ i, 0 < A i)
    (hC : ∀ n, (U (n + 1) : ℤ) = a n * U n - b n * D n)
    (hD : ∀ n, D (n + 1) = a n * D n)
    (hpair : ∀ i j, i ≠ j → Nat.gcd (A i) (A j) ≤ H)
    (hlarge : ∀ i, (max B (runningMax U T)) * H ^ (B - 1) < A i)
    (hOld : ∀ i n, T ≤ n → (A i : ℤ) ∣ D n) :
    ∃ x P : ℕ, P ≤ x ∧ x < 2 * P ∧ P ≤ (∏ i, A i) ∧
      runningMax U T < x ∧
      ((∀ n, T ≤ n → runningMax U n < x + B →
          runningMax U n < U (n + 1) →
          U (n + 1) - runningMax U n ≤ B) →
        ∀ n, U n < x + B) := by
  classical
  have hcores : ∀ i, max B (runningMax U T) < coprimeCore A i := by
    intro i
    have hloss := le_coprimeCore_mul_gcd_bound A hA H hpair i
    have hl := hlarge i
    by_contra hnot
    have hmul := Nat.mul_le_mul_right (H ^ (B - 1))
      (show coprimeCore A i ≤ max B (runningMax U T) by omega)
    omega
  let m : Fin B → ℕ := coprimeCore A
  have hm : ∀ i, B < m i := fun i ↦ (le_max_left B _).trans_lt (hcores i)
  have hpairm := coprimeCore_pairwise A hA
  obtain ⟨x, hBP, hPx, hxP, hcover⟩ :=
    LcmRecordCrossing.exists_crt_covering_progression m hm hpairm
  let P : ℕ := ∏ i, m i
  have hprodpos : 0 < P := by
    apply Finset.prod_pos
    intro i hi
    have hh := hm i
    omega
  let i0 : Fin B := ⟨0, hB⟩
  have hdiv : m i0 ∣ P := by
    dsimp [P]
    exact Finset.dvd_prod_of_mem _ (Finset.mem_univ i0)
  have hR : runningMax U T < x := by
    have hh := hcores i0
    have hmle := Nat.le_of_dvd hprodpos hdiv
    have hmax := le_max_right B (runningMax U T)
    exact (hmax.trans_lt hh).trans_le (hmle.trans hPx)
  have hprodle : P ≤ ∏ i, A i := by
    apply Finset.prod_le_prod'
    intro i hi
    exact Nat.le_of_dvd (hA i) (coprimeCore_dvd A i)
  refine ⟨x, P, hPx, hxP, hprodle, hR, ?_⟩
  intro hcap
  apply bounded_by_record_cover U D a b T x B hC hD hR
  · intro j hj z hzlo hzhi
    have hmD : ∀ i, (m i : ℤ) ∣ D j := by
      intro i
      exact (Int.natCast_dvd_natCast.mpr (coprimeCore_dvd A i)).trans (hOld i j hj)
    obtain ⟨d, hd, hdD, hdz⟩ := hcover (D j) hmD 0 (z : ℤ)
      (by push_cast; omega) (by push_cast; omega)
    exact ⟨d, hd, hdz, hdD⟩
  · exact hcap
