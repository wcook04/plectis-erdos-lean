import Definitions.Def_ErdosProblems_Erdos243_ReciprocalTailRigidity
import Definitions.Def_ErdosProblems_Erdos243_LcmRecordCrossing
import Theorems.Thm_ErdosProblems_Erdos243_LcmRecordCrossing_crossed_progression_card_le_excess
import Theorems.Thm_ErdosProblems_Erdos243_LcmRecordCrossing_sum_firstCrossing_partition
import Mathlib
import Mathlib.Algebra.Order.BigOperators.GroupWithZero.Finset
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.Data.Fin.Pigeonhole
import Mathlib.Data.Nat.ChineseRemainder
import Mathlib.Data.Nat.Find
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.ZMod.Basic
import Mathlib.Order.Filter.AtTopBot.Basic
import Mathlib.Tactic.Ring

namespace LcmRecordExcess
end LcmRecordExcess

/-!
# Counting the CRT heights crossed by one arithmetic step

The heights are the actual arithmetic progression `x + k * P`, not an
assumed cardinality bound. This supplies the finite local charging step in
the weighted-record argument of `LcmRecordExcess.md`. First-crossing existence,
uniqueness, and the finite partition across time require no monotonicity of
the numerator sequence. The existing CRT construction supplies the covering
from any finite family of sufficiently large pairwise-coprime old divisors.
Producing that family from an infinite canonical orbit and the analytic
divergence argument are not asserted by this module.
-/

namespace ErdosProblems.Erdos243.LcmRecordCrossing
open LcmRecordExcess













/-- A first crossing is automatically a strict record, not merely a rise
after a drawdown. -/
theorem FirstCrossing.is_record {U : ℕ → ℕ} {t n : ℕ}
    (h : FirstCrossing U t n) : ∀ j ≤ n, U j < U (n + 1) := by
  intro j hj
  exact (h.1 j hj).trans_le h.2







/-- The full local weighted charge, with no assumed wall-count inequality.
The source can lie below the previous record: only the heights crossed by
this actual step enter the hypotheses. -/
theorem crossed_progression_weighted_charge (s : Finset ℕ)
    (x P U d B : ℕ) (a L : ℤ) (hP : B < P)
    (hlo : ∀ k ∈ s, U < x + k * P)
    (hhi : ∀ k ∈ s, x + k * P ≤ U + d)
    (hfeedback : (d : ℤ) = (a - 1) * U - L)
    (hcover : ∀ k ∈ s, ∀ z : ℤ,
      (x + k * P : ℕ) - (B : ℤ) ≤ z → z < (x + k * P : ℕ) →
      ∃ m : ℤ, (B : ℤ) < m ∧ m ∣ L ∧ m ∣ z)
    (f : ℕ → ℝ) (hf : Antitone f) (hpos : 0 ≤ f U) :
    ∑ k ∈ s, f (x + k * P) ≤ ((d - B : ℕ) : ℝ) * f U := by
  have hc := crossed_progression_card_le_excess s x P U d B a L hP hlo hhi
    hfeedback hcover
  calc
    ∑ k ∈ s, f (x + k * P) ≤ ∑ _k ∈ s, f U :=
      Finset.sum_le_sum (fun k hk => hf (Nat.le_of_lt (hlo k hk)))
    _ = (s.card : ℝ) * f U := by simp
    _ ≤ ((d - B : ℕ) : ℝ) * f U :=
      mul_le_mul_of_nonneg_right (by exact_mod_cast hc) hpos
end ErdosProblems.Erdos243.LcmRecordCrossing

open LcmRecordExcess
open ErdosProblems in
open ErdosProblems.Erdos243 in
open ErdosProblems.Erdos243.LcmRecordCrossing in
open ErdosProblems.Erdos243.LcmRecordExcess in
theorem solution (s : Finset ℕ) (U : ℕ → ℕ)
    (a L : ℕ → ℤ) (x P B N : ℕ) (hP : B < P)
    (hzero : ∀ k ∈ s, U 0 < x + k * P)
    (hN : ∀ k ∈ s, ∃ j ≤ N, x + k * P ≤ U j)
    (hfeedback : ∀ n < N, (∀ j ≤ n, U j < U (n + 1)) →
      ((U (n + 1) - U n : ℕ) : ℤ) = (a n - 1) * U n - L n)
    (hcover : ∀ n < N, ∀ k ∈ s, ∀ z : ℤ,
      (x + k * P : ℕ) - (B : ℤ) ≤ z → z < (x + k * P : ℕ) →
      ∃ m : ℤ, (B : ℤ) < m ∧ m ∣ L n ∧ m ∣ z)
    (f : ℕ → ℝ) (hf : Antitone f) (hpos : ∀ u, 0 ≤ f u) :
    ∑ k ∈ s, f (x + k * P) ≤
      ∑ n ∈ Finset.range N,
        if (∀ j ≤ n, U j < U (n + 1)) then
          ((U (n + 1) - U n - B : ℕ) : ℝ) * f (U n) else 0 := by
  classical
  rw [sum_firstCrossing_partition s U (fun k => x + k * P) N
    (fun k => f (x + k * P)) hzero hN]
  apply Finset.sum_le_sum
  intro n hn
  have hnN := Finset.mem_range.mp hn
  by_cases hr : ∀ j ≤ n, U j < U (n + 1)
  · rw [if_pos hr]
    let crossed := s.filter (fun k => FirstCrossing U (x + k * P) n)
    have hlocal := crossed_progression_weighted_charge crossed x P (U n)
      (U (n + 1) - U n) B (a n) (L n) hP
      (by
        intro k hk
        have hcross := (Finset.mem_filter.mp hk).2
        exact hcross.1 n (Nat.le_refl n))
      (by
        intro k hk
        have hcross := (Finset.mem_filter.mp hk).2.2
        have hrise := hr n (Nat.le_refl n)
        omega)
      (hfeedback n hnN hr)
      (by
        intro k hk
        exact hcover n hnN k (Finset.mem_filter.mp hk).1)
      f hf (hpos (U n))
    simpa only [crossed, Finset.sum_filter] using hlocal
  · rw [if_neg hr]
    apply le_of_eq
    apply Finset.sum_eq_zero
    intro k hk
    exact if_neg (fun h => hr h.is_record)
