import Definitions.Def_ErdosProblems_Erdos243_ReciprocalTailRigidity
import Definitions.Def_ErdosProblems_Erdos243_LcmRecordCrossing
import Definitions.Def_ErdosProblems_Erdos243_LcmRecordDivergence
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR7_Limits
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR7_RealTail_v243UnionFbf41fb8
import Definitions.Def_ErdosProblems_Erdos243_PrimitiveRecordBarrier
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR8_WeightAnalysis_v243UnionFbf41fb8
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR8_WeightedRecords_v243UnionFbf41fb8
import Theorems.Thm_ErdosProblems_Erdos243_LcmRecordCrossing_exists_crt_covering_progression
import Theorems.Thm_ErdosProblems_Erdos243_LcmRecordCrossing_not_summable_recordExcessWeight_of_progression
import Theorems.Thm_ErdosProblems_Erdos243_PaperCompleteR8_LcmOrbit_old_digit_dvd
import Theorems.Thm_ErdosProblems_Erdos243_PaperCompleteR8_LcmOrbit_record_fresh
import Theorems.Thm_ErdosProblems_Erdos243_PaperCompleteR8_LcmOrbit_cofinal_large_records
import Theorems.Thm_ErdosProblems_Erdos243_PaperCompleteR8_LcmOrbit_record_digits_coprime
import Theorems.Thm_ErdosProblems_Erdos243_PaperCompleteR8_record_shift_iff
import Theorems.Thm_ErdosProblems_Erdos243_PaperCompleteR8_shift_unbounded
import Theorems.Thm_ErdosProblems_Erdos243_PaperCompleteR8_summable_shift_iff
import Theorems.Thm_ErdosProblems_Erdos243_PaperCompleteR8_progression_not_summable
import Mathlib
import Mathlib.Algebra.Order.BigOperators.GroupWithZero.Finset
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Analysis.SumIntegralComparisons
import Mathlib.Data.Fin.Pigeonhole
import Mathlib.Data.Nat.ChineseRemainder
import Mathlib.Data.Nat.Factorization.Basic
import Mathlib.Data.Nat.Find
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.ZMod.Basic
import Mathlib.Order.Filter.AtTopBot.Basic
import Mathlib.Tactic
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.InfiniteSum.NatInt
import Mathlib.Topology.Algebra.InfiniteSum.Real

namespace ErdosProblems.Erdos243.PaperCompleteR8
open Filter Classical
open scoped BigOperators
/-- Actual and raw record charges coincide under the lower centring bound. -/
theorem rawRecordWeight_eq_actual
    (o : LcmOrbit) (hc : ∀ n, -(o.U n : ℤ) ≤ 2 * o.V n)
    (B : ℕ) (f : ℕ → ℝ) :
    rawRecordWeight o.U o.V B f =
      LcmRecordCrossing.recordExcessWeight o.U B f := by
  funext n
  classical
  unfold rawRecordWeight LcmRecordCrossing.recordExcessWeight Record
  split_ifs with hr
  · have hs := o.step n
    rw [o.record_fresh hc hr, Nat.cast_one, one_mul] at hs
    have hn := hr n le_rfl
    have heq : (-o.V n - (B : ℤ)).toNat = o.U (n + 1) - o.U n - B := by omega
    rw [heq]
  · rfl
end ErdosProblems.Erdos243.PaperCompleteR8

open ErdosProblems
open ErdosProblems.Erdos243
open ErdosProblems.Erdos243.PaperCompleteR8
open Filter Classical
open scoped BigOperators
open ErdosProblems in
open ErdosProblems.Erdos243 in
open ErdosProblems.Erdos243.PaperCompleteR8 in
theorem solution
    (o : LcmOrbit) (hc : ∀ n, -(o.U n : ℤ) ≤ 2 * o.V n)
    (hu : HeightUnbounded o.U)
    (B : ℕ) (f : ℕ → ℝ) (hf : Antitone f)
    (hpos : ∀ n, 0 ≤ f n) (hdiv : ¬ Summable f) :
    ¬ Summable (rawRecordWeight o.U o.V B f) := by
  classical
  intro hsum
  let pick : ℕ → ℕ := fun T => Classical.choose (o.cofinal_large_records hc hu B T)
  have hpick : ∀ T, T ≤ pick T ∧ Record o.U (pick T) ∧ B < o.a (pick T) :=
    fun T => Classical.choose_spec (o.cofinal_large_records hc hu B T)
  let s : ℕ → ℕ := Nat.rec (pick 0) (fun _ prev => pick (prev + 1))
  have hs0 : s 0 = pick 0 := rfl
  have hss : ∀ i, s (i + 1) = pick (s i + 1) := fun _ => rfl
  have hsmono : StrictMono s := by
    apply strictMono_nat_of_lt_succ
    intro i
    rw [hss]
    have hh := (hpick (s i + 1)).1
    omega
  have hsdata : ∀ i, Record o.U (s i) ∧ B < o.a (s i) := by
    intro i
    cases i with
    | zero => exact (hpick 0).2
    | succ i => exact (hpick (s i + 1)).2
  let m : Fin B → ℕ := fun i => o.a (s i.val)
  have hm : ∀ i, B < m i := fun i => (hsdata i.val).2
  have hpair : ∀ i j : Fin B, i ≠ j → Nat.Coprime (m i) (m j) := by
    intro i j hij
    have hij' : i.val ≠ j.val := fun h => hij (Fin.ext h)
    rcases lt_or_gt_of_ne hij' with hlt | hgt
    · exact o.record_digits_coprime hc (hsdata i.val).1 (hsdata j.val).1 (hsmono hlt)
    · exact (o.record_digits_coprime hc (hsdata j.val).1 (hsdata i.val).1 (hsmono hgt)).symm
  let T := s B + 1
  have hTmax : ∀ j, j ≤ T → o.U j ≤ o.U T := by
    intro j hj
    by_cases heq : j = T
    · rw [heq]
    · exact ((hsdata B).1 j (by dsimp [T] at *; omega)).le
  have hmold : ∀ n, ∀ i : Fin B, m i ∣ o.L (T + n) := by
    intro n i
    apply o.old_digit_dvd
    have hi := hsmono i.isLt
    dsimp [T]
    omega
  obtain ⟨x, hBP, hxP, _hxhi, hcover⟩ :=
    LcmRecordCrossing.exists_crt_covering_progression m hm hpair
  let P : ℕ := ∏ i, m i
  let k0 := o.U T + 1
  let x0 := x + B + k0 * P
  have hP : 0 < P := by dsimp [P]; omega
  have hstart : o.U T < x0 := by
    have hk : k0 ≤ k0 * P := by nlinarith
    dsimp [x0, k0] at *
    omega
  have hweightshift : rawRecordWeight (fun n => o.U (T + n))
      (fun n => o.V (T + n)) B f = fun n => rawRecordWeight o.U o.V B f (T + n) := by
    funext n
    unfold rawRecordWeight
    rw [record_shift_iff o.U T n hTmax]
  have htail : Summable (rawRecordWeight (o.shift T).U (o.shift T).V B f) := by
    change Summable (rawRecordWeight (fun n => o.U (T + n))
      (fun n => o.V (T + n)) B f)
    rw [hweightshift]
    exact (summable_shift_iff _ T).mpr hsum
  have hctail : ∀ n, -((o.shift T).U n : ℤ) ≤ 2 * (o.shift T).V n :=
    fun n => hc (T + n)
  rw [rawRecordWeight_eq_actual (o.shift T) hctail B f] at htail
  apply LcmRecordCrossing.not_summable_recordExcessWeight_of_progression
    (fun n => o.U (T + n)) (fun n => (o.a (T + n) : ℤ))
    (fun n => (o.L (T + n) : ℤ)) x0 P B hBP
    (by simpa only [Nat.add_zero] using hstart)
    (fun H => by
      obtain ⟨n, hn⟩ := shift_unbounded o.U hu T H
      exact ⟨n, hn.le⟩)
    ?_ ?_ f hf hpos (progression_not_summable f hf hpos hdiv x0 P hP) htail
  · intro n hr
    have hrecord := (record_shift_iff o.U T n hTmax).mp hr
    have hs := o.step (T + n)
    rw [o.record_fresh hc hrecord, Nat.cast_one, one_mul, o.digit (T + n)] at hs
    have hle : o.U (T + n) ≤ o.U (T + n + 1) := (hrecord _ le_rfl).le
    have hcast : ((o.U (T + n + 1) - o.U (T + n) : ℕ) : ℤ) =
        (o.U (T + n + 1) : ℤ) - o.U (T + n) := Int.ofNat_sub hle
    simpa only [Nat.add_assoc] using (show
      ((o.U (T + n + 1) - o.U (T + n) : ℕ) : ℤ) =
        ((o.a (T + n) : ℤ) - 1) * o.U (T + n) - o.L (T + n) by
          rw [hcast]
          nlinarith [hs])
  · intro n k z hlo hhi
    have hwall : x0 + k * P = x + B + (k0 + k) * P := by dsimp [x0]; ring
    rw [hwall] at hlo hhi
    exact hcover (o.L (T + n)) (fun i => by exact_mod_cast hmold n i)
      (k0 + k) z hlo hhi
