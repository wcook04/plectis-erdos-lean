import Mathlib

namespace ErdosProblems.Erdos243.LcmRecordExcess
end ErdosProblems.Erdos243.LcmRecordExcess

/-!
# Finite arithmetic and weighted charging for LCM record crossings

These lemmas verify the local arithmetic and charging steps of
`LcmRecordExcess.md`. They do not formalise its analytic divergence theorem,
its canonical-orbit transfer, or unrestricted Erdős 243.
-/

open ErdosProblems in
open ErdosProblems.Erdos243 in
open ErdosProblems.Erdos243.LcmRecordExcess in
theorem solution {U d L a tau B : ℤ}
    (hd : 0 < d) (hsource : U < tau) (hcross : tau ≤ U + d)
    (hfeedback : d = (a - 1) * U - L)
    (hcover : ∀ z : ℤ, tau - B ≤ z → z < tau →
      ∃ m : ℤ, B < m ∧ m ∣ L ∧ m ∣ z) : B < d := by
  by_contra h
  have hsmall : d ≤ B := by omega
  obtain ⟨m, hm, hmL, hmU⟩ := hcover U (by omega) hsource
  have hmd : m ∣ d := by
    rw [hfeedback]
    exact dvd_sub (dvd_mul_of_dvd_right hmU (a - 1)) hmL
  have hle : m ≤ d := Int.le_of_dvd hd hmd
  omega
