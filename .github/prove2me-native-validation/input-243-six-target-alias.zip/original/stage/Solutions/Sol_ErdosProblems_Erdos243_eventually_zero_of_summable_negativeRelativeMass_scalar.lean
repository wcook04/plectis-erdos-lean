import Definitions.Def_ErdosProblems_Erdos243_ReciprocalTailRigidity
import Definitions.Def_ErdosProblems_Erdos243_SparseResetRecovery
import Theorems.Thm_ErdosProblems_Erdos243_antitone_nat_eventually_constant
import Theorems.Thm_ErdosProblems_Erdos243_bounded_of_summable_negativeRelativeMass
import Mathlib.Algebra.Order.BigOperators.GroupWithZero.Finset
import Mathlib.Analysis.SpecialFunctions.Log.Summable
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.Data.Fin.Pigeonhole
import Mathlib.Data.Nat.ChineseRemainder
import Mathlib.Data.Nat.Find
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.ZMod.Basic
import Mathlib.Order.Filter.AtTopBot.Basic
import Mathlib.Tactic.Ring

/-!
# Erdős #243: sparse reset recovery

This module isolates the order-theoretic recovery forest behind dynamically
reduced reciprocal-tail orbits.  It also gives a division-free finite-product
bound for the full reset payment on a recovery interval.

The declarations do not exclude the unrestricted divergent-negative-mass
branch and therefore do not prove Erdős #243.
-/

namespace ErdosProblems.Erdos243
open scoped BigOperators

/-! ## Recovery intervals -/



















/-! ## Division-free payment bounds -/











/-! ## A checked endpoint consumer -/













/-! ## Scalar finite mass, without normalised vanishing

Type B r2 (file 05, Proposition J) observed that the product bound already
caps `C_n`, so a strict integer rise costs a definite relative mass `≥ 1/K`
and only finitely many rises can occur.  After the last rise the tail is
nonincreasing, hence eventually constant by
`antitone_nat_eventually_constant`.  Normalised vanishing is not used. -/
end ErdosProblems.Erdos243

open scoped BigOperators
open ErdosProblems in
open ErdosProblems.Erdos243 in
theorem solution
    (C : ℕ → ℕ) (E : ℕ → ℤ)
    (hCpos : ∀ n, 0 < C n)
    (hstep :
      ∀ n, (C (n + 1) : ℤ) = (C n : ℤ) - E n)
    (hsum : Summable (negativeRelativeMass C E)) :
    ∃ N, ∀ n, N ≤ n → E n = 0 := by
  obtain ⟨M, hM⟩ :=
    bounded_of_summable_negativeRelativeMass C E hCpos hstep hsum
  have hMpos : 0 < M :=
    (hCpos 0).trans_le (hM 0)
  have hδ : ∀ n, 0 ≤ negativeRelativeMass C E n := fun n =>
    div_nonneg (by positivity) (by positivity)
  have hto : Filter.Tendsto (negativeRelativeMass C E) Filter.atTop (nhds 0) :=
    hsum.tendsto_atTop_zero
  have hpos : 0 < (1 : ℝ) / M := by positivity
  obtain ⟨N₀, hN₀⟩ :
      ∃ N₀, ∀ n, N₀ ≤ n →
        negativeRelativeMass C E n < (1 : ℝ) / M := by
    have hball := Metric.tendsto_atTop.mp hto ((1 : ℝ) / M) hpos
    obtain ⟨N₀, hN₀⟩ := hball
    refine ⟨N₀, fun n hn => ?_⟩
    have habs : |negativeRelativeMass C E n| < (1 : ℝ) / M := by
      simpa [Real.dist_eq] using hN₀ n hn
    rwa [abs_of_nonneg (hδ n)] at habs
  have hanti : ∀ n, N₀ ≤ n → C (n + 1) ≤ C n := by
    intro n hn
    have hδlt := hN₀ n hn
    by_contra hnot
    have hrise : C n < C (n + 1) := Nat.lt_of_not_ge hnot
    have hneg : E n < 0 := by
      have hE : E n = (C n : ℤ) - (C (n + 1) : ℤ) := by
        have := hstep n
        omega
      have : (C n : ℤ) < C (n + 1) := Int.ofNat_lt.mpr hrise
      omega
    have hmass : (1 : ℝ) / M ≤ negativeRelativeMass C E n := by
      have hmin : min (E n) 0 = E n := min_eq_left hneg.le
      have habspos : 1 ≤ Int.natAbs (E n) := by
        have : (E n).natAbs ≠ 0 := Int.natAbs_ne_zero.mpr (ne_of_lt hneg)
        exact Nat.succ_le_of_lt (Nat.pos_of_ne_zero this)
      have hCpos' : (0 : ℝ) < C n := by exact_mod_cast (hCpos n)
      have hge :
          (Int.natAbs (min (E n) 0) : ℝ) / C n ≥ (1 : ℝ) / C n := by
        rw [hmin]
        exact div_le_div_of_nonneg_right (by exact_mod_cast habspos) hCpos'.le
      have hCle : (C n : ℝ) ≤ M := by exact_mod_cast (hM n)
      have hrecip : (1 : ℝ) / M ≤ (1 : ℝ) / C n :=
        one_div_le_one_div_of_le hCpos' hCle
      exact le_trans hrecip hge
    exact (not_le_of_gt hδlt) hmass
  have hshift : ∀ k, C (N₀ + k + 1) ≤ C (N₀ + k) := fun k =>
    hanti _ (Nat.le_add_right _ _)
  obtain ⟨K, hK⟩ :=
    antitone_nat_eventually_constant (fun k => C (N₀ + k)) hshift
  refine ⟨N₀ + K, fun n hn => ?_⟩
  have hNle : N₀ ≤ n := (Nat.le_add_right N₀ K).trans hn
  have hnK : K ≤ n - N₀ := Nat.le_sub_of_add_le (by
    simpa [Nat.add_comm N₀ K] using hn)
  have hconst : C n = C (N₀ + K) := by
    have hnk : n = N₀ + (n - N₀) := (Nat.add_sub_of_le hNle).symm
    rw [hnk]
    exact hK (n - N₀) hnK
  have hconst' : C (n + 1) = C (N₀ + K) := by
    have hle : N₀ + K ≤ n + 1 := hn.trans (Nat.le_succ n)
    have hNle' : N₀ ≤ n + 1 := hNle.trans (Nat.le_succ n)
    have hn1 : K ≤ (n + 1) - N₀ := Nat.le_sub_of_add_le (by
      simpa [Nat.add_comm N₀ K] using hle)
    have hnk : n + 1 = N₀ + ((n + 1) - N₀) := (Nat.add_sub_of_le hNle').symm
    rw [hnk]
    exact hK ((n + 1) - N₀) hn1
  have hCeq : C (n + 1) = C n := hconst'.trans hconst.symm
  have := hstep n
  have : (C (n + 1) : ℤ) = C n := by exact_mod_cast hCeq
  omega
