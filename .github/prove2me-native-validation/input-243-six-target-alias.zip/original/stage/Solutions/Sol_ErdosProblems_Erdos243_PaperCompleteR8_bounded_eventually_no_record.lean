import Definitions.Def_ErdosProblems_Erdos243_ReciprocalTailRigidity
import Definitions.Def_ErdosProblems_Erdos243_LcmRecordCrossing
import Definitions.Def_ErdosProblems_Erdos243_LcmRecordDivergence
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR7_Limits
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR7_RealTail_v243UnionFbf41fb8
import Definitions.Def_ErdosProblems_Erdos243_PrimitiveRecordBarrier
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR8_WeightAnalysis_v243UnionFbf41fb8
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR8_WeightedRecords_v243UnionFbf41fb8
import Mathlib
import Mathlib.Algebra.Order.BigOperators.GroupWithZero.Finset
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Analysis.SumIntegralComparisons
import Mathlib.Data.Fin.Pigeonhole
import Mathlib.Data.Nat.ChineseRemainder
import Mathlib.Data.Nat.Factorization.Basic
import Mathlib.Data.Nat.Find
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.ZMod.Basic
import Mathlib.Order.Filter.AtTopBot.Basic
import Mathlib.Tactic
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.InfiniteSum.NatInt
import Mathlib.Topology.Algebra.InfiniteSum.Real

namespace ErdosProblems.Erdos243.PaperCompleteR8
open Filter Classical
open scoped BigOperators
end ErdosProblems.Erdos243.PaperCompleteR8

open ErdosProblems
open ErdosProblems.Erdos243
open ErdosProblems.Erdos243.PaperCompleteR8
open Filter Classical
open scoped BigOperators
open ErdosProblems in
open ErdosProblems.Erdos243 in
open ErdosProblems.Erdos243.PaperCompleteR8 in
theorem solution (U : ℕ → ℕ) (hb : HeightBounded U) :
    ∃ N, ∀ n, N ≤ n → ¬ Record U n := by
  classical
  let H := Nat.find hb
  have hH : ∀ n, U n ≤ H := Nat.find_spec hb
  have hhit : ∃ t, U t = H := by
    by_contra hn
    by_cases hzero : H = 0
    · exact hn ⟨0, by have := hH 0; omega⟩
    · have hsmall : ∀ n, U n ≤ H - 1 := by
        intro n
        have hle := hH n
        have hne : U n ≠ H := fun he => hn ⟨n, he⟩
        omega
      exact Nat.find_min hb (show H - 1 < Nat.find hb by dsimp [H] at *; omega) hsmall
  obtain ⟨t, ht⟩ := hhit
  refine ⟨t, ?_⟩
  intro n htn hr
  have hlt := hr t htn
  have hle := hH (n + 1)
  rw [ht] at hlt
  omega
