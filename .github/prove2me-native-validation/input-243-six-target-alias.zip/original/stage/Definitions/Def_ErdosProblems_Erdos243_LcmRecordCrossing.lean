import Definitions.Def_ErdosProblems_Erdos243_ReciprocalTailRigidity
import Mathlib
import Mathlib.Algebra.Order.BigOperators.GroupWithZero.Finset
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.Data.Fin.Pigeonhole
import Mathlib.Data.Nat.ChineseRemainder
import Mathlib.Data.Nat.Find
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.ZMod.Basic
import Mathlib.Order.Filter.AtTopBot.Basic
import Mathlib.Tactic.Ring

namespace ErdosProblems.Erdos243.LcmRecordExcess
end ErdosProblems.Erdos243.LcmRecordExcess

/-!
# Counting the CRT heights crossed by one arithmetic step

The heights are the actual arithmetic progression `x + k * P`, not an
assumed cardinality bound. This supplies the finite local charging step in
the weighted-record argument of `LcmRecordExcess.md`. First-crossing existence,
uniqueness, and the finite partition across time require no monotonicity of
the numerator sequence. The existing CRT construction supplies the covering
from any finite family of sufficiently large pairwise-coprime old divisors.
Producing that family from an infinite canonical orbit and the analytic
divergence argument are not asserted by this module.
-/

namespace ErdosProblems.Erdos243.LcmRecordCrossing

open LcmRecordExcess







/-- The step ending at `U (n+1)` first reaches height `t`: every earlier
state, including its source, was strictly below that height. -/
def FirstCrossing (U : ℕ → ℕ) (t n : ℕ) : Prop :=
  (∀ j ≤ n, U j < t) ∧ t ≤ U (n + 1)

noncomputable instance (U : ℕ → ℕ) (t n : ℕ) : Decidable (FirstCrossing U t n) :=
  Classical.propDecidable _

















end ErdosProblems.Erdos243.LcmRecordCrossing
