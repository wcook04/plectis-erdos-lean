import Definitions.Def_ErdosProblems_Erdos243_ReciprocalTailRigidity
import Mathlib.Algebra.Order.BigOperators.GroupWithZero.Finset
import Mathlib.Analysis.SpecialFunctions.Log.Summable
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.Data.Fin.Pigeonhole
import Mathlib.Data.Nat.ChineseRemainder
import Mathlib.Data.Nat.Find
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.ZMod.Basic
import Mathlib.Order.Filter.AtTopBot.Basic
import Mathlib.Tactic.Ring

/-!
# Erdős #243: sparse reset recovery

This module isolates the order-theoretic recovery forest behind dynamically
reduced reciprocal-tail orbits.  It also gives a division-free finite-product
bound for the full reset payment on a recovery interval.

The declarations do not exclude the unrestricted divergent-negative-mass
branch and therefore do not prove Erdős #243.
-/

namespace ErdosProblems.Erdos243

open scoped BigOperators

/-! ## Recovery intervals -/



















/-! ## Division-free payment bounds -/











/-! ## A checked endpoint consumer -/



/-- The normalized negative mass of an integral tail step. -/
noncomputable def negativeRelativeMass
    (C : ℕ → ℕ) (E : ℕ → ℤ) (n : ℕ) : ℝ :=
  (Int.natAbs (min (E n) 0) : ℝ) / C n









/-! ## Scalar finite mass, without normalised vanishing

Type B r2 (file 05, Proposition J) observed that the product bound already
caps `C_n`, so a strict integer rise costs a definite relative mass `≥ 1/K`
and only finitely many rises can occur.  After the last rise the tail is
nonincreasing, hence eventually constant by
`antitone_nat_eventually_constant`.  Normalised vanishing is not used. -/







end ErdosProblems.Erdos243
