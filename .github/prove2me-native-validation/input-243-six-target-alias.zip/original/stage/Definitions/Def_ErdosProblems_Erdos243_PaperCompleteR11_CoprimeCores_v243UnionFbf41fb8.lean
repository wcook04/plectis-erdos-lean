import Definitions.Def_ErdosProblems_Erdos243_ReciprocalTailRigidity
import Definitions.Def_ErdosProblems_Erdos243_GlobalLcmHeight
import Definitions.Def_ErdosProblems_Erdos243_CumulativeLcmTransfer
import Definitions.Def_ErdosProblems_Erdos243_LcmCriticalBoundary
import Definitions.Def_ErdosProblems_Erdos243_LcmRecordCrossing
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR7_Limits
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR7_RealTail_v243UnionFbf41fb8
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR7_CanonicalState_v243UnionFbf41fb8
import Definitions.Def_ErdosProblems_Erdos243_PrimitiveRecordBarrier
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_RecordDivisibility_v243UnionFbf41fb8
import Mathlib
import Mathlib.Algebra.Order.BigOperators.GroupWithZero.Finset
import Mathlib.Algebra.Ring.Basic
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Data.Fin.Pigeonhole
import Mathlib.Data.Nat.ChineseRemainder
import Mathlib.Data.Nat.Factorization.Basic
import Mathlib.Data.Nat.Find
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.Rat.Defs
import Mathlib.Data.ZMod.Basic
import Mathlib.Order.Filter.AtTopBot.Basic
import Mathlib.Tactic
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.InfiniteSum.NatInt

/-!
# Coprime cores of a finite non-coprime family

Removing gcd(A_i, product of all other A_j) yields pairwise-coprime
cores. The loss is bounded by the product of the pairwise gcds. This avoids
an unproved supply of pairwise-coprime original multipliers in the
non-stabilised-gcd branch of the inclusive argument.
-/

namespace ErdosProblems.Erdos243.PaperCompleteR11

open scoped BigOperators





noncomputable def coreDenom {B : ℕ} (A : Fin B → ℕ) (i : Fin B) : ℕ :=
  Nat.gcd (A i) (∏ j ∈ Finset.univ.erase i, A j)

noncomputable def coprimeCore {B : ℕ} (A : Fin B → ℕ) (i : Fin B) : ℕ :=
  A i / coreDenom A i















end ErdosProblems.Erdos243.PaperCompleteR11
