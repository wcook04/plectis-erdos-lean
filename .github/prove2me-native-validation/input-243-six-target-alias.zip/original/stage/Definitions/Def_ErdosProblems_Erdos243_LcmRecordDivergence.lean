import Definitions.Def_ErdosProblems_Erdos243_ReciprocalTailRigidity
import Definitions.Def_ErdosProblems_Erdos243_LcmRecordCrossing
import Mathlib
import Mathlib.Algebra.Order.BigOperators.GroupWithZero.Finset
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.Data.Fin.Pigeonhole
import Mathlib.Data.Nat.ChineseRemainder
import Mathlib.Data.Nat.Find
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.ZMod.Basic
import Mathlib.Order.Filter.AtTopBot.Basic
import Mathlib.Tactic.Ring

/-!
# From finite first crossings to divergent record mass

This module transfers nonsummability of the actual progression weights to
the record-excess series. The sequence need only reach arbitrarily large
heights; no monotonicity or limit at infinity is assumed. The analytic input
that a particular weight has divergent progression sum remains explicit.
-/

namespace ErdosProblems.Erdos243.LcmRecordCrossing

/-- The nonnegative charge at a strict record, zero at every other step. -/
noncomputable def recordExcessWeight (U : ℕ → ℕ) (B : ℕ) (f : ℕ → ℝ)
    (n : ℕ) : ℝ :=
  if (∀ j ≤ n, U j < U (n + 1)) then
    ((U (n + 1) - U n - B : ℕ) : ℝ) * f (U n) else 0



end ErdosProblems.Erdos243.LcmRecordCrossing
