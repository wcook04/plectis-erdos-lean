import Definitions.Def_ErdosProblems_Erdos243_ReciprocalTailRigidity
import Definitions.Def_ErdosProblems_Erdos243_GlobalLcmHeight
import Definitions.Def_ErdosProblems_Erdos243_CumulativeLcmTransfer
import Definitions.Def_ErdosProblems_Erdos243_LcmCriticalBoundary
import Definitions.Def_ErdosProblems_Erdos243_LcmRecordCrossing
import Definitions.Def_ErdosProblems_Erdos243_PrimitiveRecordBarrier
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_RecordDivisibility
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_CoprimeCores
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_LogLogNormaliser
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_PresievedCRT
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_RecordGcdReduction
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_InclusiveLimsup
import Mathlib
import Mathlib.Algebra.Order.BigOperators.GroupWithZero.Finset
import Mathlib.Algebra.Ring.Basic
import Mathlib.Analysis.SpecialFunctions.Log.Basic
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Analysis.SumIntegralComparisons
import Mathlib.Data.EReal.Basic
import Mathlib.Data.Fin.Pigeonhole
import Mathlib.Data.Fintype.BigOperators
import Mathlib.Data.Fintype.EquivFin
import Mathlib.Data.Nat.ChineseRemainder
import Mathlib.Data.Nat.Factorization.Basic
import Mathlib.Data.Nat.Find
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.Nat.Totient
import Mathlib.Data.Rat.Defs
import Mathlib.Data.ZMod.Basic
import Mathlib.Order.Filter.AtTopBot.Basic
import Mathlib.Order.LiminfLimsup
import Mathlib.Tactic
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.InfiniteSum.NatInt

namespace ErdosProblems.Erdos243.PaperCompleteR21
end ErdosProblems.Erdos243.PaperCompleteR21

/-!
# Erdős #243: the double-logarithmic implication for an exact orbit

Paper restatement of the displayed implication in the section "Further consequences"
(`sec:secondaryrate`) of the short #243 paper: under the hypotheses of Theorem 1.2
(`res:bounded`) other than (5),
`limsup_n (-E_n)_+ / log₂ log₂ max(4, C_n) ≤ 1  ⟹  E_n = 0 eventually`.

The paper says that its two steps are Lean theorems and that only their combination was
missing.  This file supplies that combination:

* `exactOrbit_recordTheta_gt_one` (strict record bound): if `E_n` is not eventually zero,
  then `1 < limsup_n (H_{n+1} - H_n) / log₂ log₂ max(4, H_n)` with `H_n = max_{j ≤ n} C_j`;
* `recordTheta_le_negativeError_limsup` (comparison with the negative part): that limit
  superior is at most the one in the display;
* `D₀ ≥ 1`, which follows from (6): if `D₀ = 0` then every `D_n = 0`, so
  `|E_n| = (a_n - 1) C_n ≥ C_n`, contradicting (6) with `K = 1`.

The limit superior is taken in the extended reals `EReal`, so an unbounded quotient has
limit superior `+∞` rather than a junk real value.  Hypothesis (4) follows from (6) with
`K = 1` and is not used separately.
-/


open Filter
open ErdosProblems.Erdos243
open ErdosProblems.Erdos243.PaperCompleteR11

open ErdosProblems.Erdos243.PaperCompleteR21

theorem ErdosProblems.Erdos243.PaperCompleteR21.exactOrbit_double_logarithmic_bound
    (a C D : ℕ → ℕ) (E : ℕ → ℤ)
    (h1 : ∀ n, 1 < a n ∧ 0 < C n)
    (h2 : ∀ n, C (n + 1) + D n = a n * C n ∧ D (n + 1) = a n * D n)
    (h3 : ∀ n, E n = (D n : ℤ) - ((a n : ℤ) - 1) * (C n : ℤ))
    (_h4 : ∃ N, ∀ n, N ≤ n → |E n| < (C n : ℤ))
    (h6 : ∀ K : ℤ, 1 ≤ K → ∃ N, ∀ n, N ≤ n → K * |E n| < (C n : ℤ)) :
    limsup (fun n => ((((max (-E n) 0 : ℤ) : ℝ) /
        Real.logb 2 (Real.logb 2 (max 4 (C n : ℝ))) : ℝ) : EReal)) atTop ≤ 1 →
      ∃ N, ∀ n, N ≤ n → E n = 0 := by sorry
