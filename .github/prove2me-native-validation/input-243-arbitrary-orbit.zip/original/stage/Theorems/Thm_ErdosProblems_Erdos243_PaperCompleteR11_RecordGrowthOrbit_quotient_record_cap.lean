import Definitions.Def_ErdosProblems_Erdos243_ReciprocalTailRigidity
import Definitions.Def_ErdosProblems_Erdos243_LcmRecordCrossing
import Definitions.Def_ErdosProblems_Erdos243_PrimitiveRecordBarrier
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_RecordDivisibility
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_CoprimeCores
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_LogLogNormaliser
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_PresievedCRT
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_RecordGcdReduction
import Mathlib
import Mathlib.Algebra.Order.BigOperators.GroupWithZero.Finset
import Mathlib.Algebra.Ring.Basic
import Mathlib.Analysis.SpecialFunctions.Log.Basic
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Analysis.SumIntegralComparisons
import Mathlib.Data.Fin.Pigeonhole
import Mathlib.Data.Fintype.BigOperators
import Mathlib.Data.Fintype.EquivFin
import Mathlib.Data.Nat.ChineseRemainder
import Mathlib.Data.Nat.Factorization.Basic
import Mathlib.Data.Nat.Find
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.Nat.Totient
import Mathlib.Data.Rat.Defs
import Mathlib.Data.ZMod.Basic
import Mathlib.Order.Filter.AtTopBot.Basic
import Mathlib.Tactic
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.InfiniteSum.NatInt

/-!
# Exact record-preserving quotient tails


The growth record below packages already derived orbit properties, not
any assertion about record gaps. Quotients are constructed from a genuine
common divisor. A global attained record is used as the starting index,
so the original running maximum is preserved exactly, including its prefix.
-/

open ErdosProblems.Erdos243.PaperCompleteR11

theorem ErdosProblems.Erdos243.PaperCompleteR11.RecordGrowthOrbit.quotient_record_cap (O : RecordGrowthOrbit)
    (s g : ℕ) (hg : 0 < g) (hUg : g ∣ O.U s) (hDg : g ∣ O.D s)
    (hs : O.U s = runningMax O.U s) (c : ℝ) (T : ℕ)
    (hcap : ∀ n, T ≤ n → runningMax O.U n < O.U (n + 1) →
      ((O.U (n + 1) - runningMax O.U n : ℕ) : ℝ) ≤ c * recordLogLog (runningMax O.U n)) :
    let V := O.quotientAt s g hg hUg hDg
    ∀ n : ℕ, T ≤ n → runningMax V.U n < V.U (n + 1) →
      ((V.U (n + 1) - runningMax V.U n : ℕ) : ℝ) ≤
        (c / g) * recordLogLog (g * runningMax V.U n : ℕ) := by sorry
