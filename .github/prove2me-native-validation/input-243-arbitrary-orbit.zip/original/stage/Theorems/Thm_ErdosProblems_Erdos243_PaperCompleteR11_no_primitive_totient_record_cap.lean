import Definitions.Def_ErdosProblems_Erdos243_ReciprocalTailRigidity
import Definitions.Def_ErdosProblems_Erdos243_LcmRecordCrossing
import Definitions.Def_ErdosProblems_Erdos243_PrimitiveRecordBarrier
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_RecordDivisibility
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_CoprimeCores
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_LogLogNormaliser
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_PresievedCRT
import Mathlib
import Mathlib.Algebra.Order.BigOperators.GroupWithZero.Finset
import Mathlib.Algebra.Ring.Basic
import Mathlib.Analysis.SpecialFunctions.Log.Basic
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Analysis.SumIntegralComparisons
import Mathlib.Data.Fin.Pigeonhole
import Mathlib.Data.Fintype.BigOperators
import Mathlib.Data.Fintype.EquivFin
import Mathlib.Data.Nat.ChineseRemainder
import Mathlib.Data.Nat.Factorization.Basic
import Mathlib.Data.Nat.Find
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.Nat.Totient
import Mathlib.Data.Rat.Defs
import Mathlib.Data.ZMod.Basic
import Mathlib.Order.Filter.AtTopBot.Basic
import Mathlib.Tactic
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.InfiniteSum.NatInt

namespace PaperCompleteR7
end PaperCompleteR7

/-!
# Strict primitive totient amplification


The physical width is W*k^2, whereas only phi(W)*k^2 consecutive
multipliers are needed. The exact cardinality supplies the assignment;
the actual denominator supplies the product-height estimate. Neither
CRT phases nor growing blocks are supplied as extra hypotheses.
-/


open PaperCompleteR7
open scoped BigOperators

open ErdosProblems.Erdos243.PaperCompleteR11

theorem ErdosProblems.Erdos243.PaperCompleteR11.no_primitive_totient_record_cap
    (a U D : ℕ → ℕ) (ha : StrictMono a)
    (hapos : ∀ n, 0 < a n) (hUpos : ∀ n, 0 < U n) (hDpos : ∀ n, 0 < D n)
    (hU : ∀ n, U (n + 1) + D n = a n * U n)
    (hD : ∀ n, D (n + 1) = a n * D n)
    (hred : ∀ n, Nat.Coprime (U n) (D n))
    (hlower : ∃ N : ℕ, ∀ k, 2 * binaryTower k ≤ a (N + k))
    (hrecord : ∃ K : ℕ, ∀ n, runningMax U n ≤ 2 ^ (K + n))
    (hden : ∃ L : ℕ, ∀ n, D n ≤ binaryTower (n + L))
    (hunbounded : ∀ H : ℕ, ∃ n, H ≤ U n)
    (W S : ℕ) (hW : 1 < W) (hWS : W ∣ D S)
    (g : ℕ) (c : ℝ) (hc0 : 0 ≤ c) (hcW : c * Nat.totient W < W) :
    ¬ ∃ T : ℕ, ∀ n, T ≤ n → runningMax U n < U (n + 1) →
      ((U (n + 1) - runningMax U n : ℕ) : ℝ) ≤
        c * recordLogLog (g * runningMax U n : ℕ) := by sorry
