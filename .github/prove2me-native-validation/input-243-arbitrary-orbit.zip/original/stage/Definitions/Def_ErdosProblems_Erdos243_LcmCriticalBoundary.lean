import Definitions.Def_ErdosProblems_Erdos243_ReciprocalTailRigidity
import Mathlib.Algebra.Order.BigOperators.GroupWithZero.Finset
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.Data.Fin.Pigeonhole
import Mathlib.Data.Nat.ChineseRemainder
import Mathlib.Data.Nat.Find
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.ZMod.Basic
import Mathlib.Order.Filter.AtTopBot.Basic
import Mathlib.Tactic.Ring

open scoped BigOperators

/-!
# Erdős 243: the LCM critical boundary

This module formalizes the strict-rise CRT consumer and weighted block
telescope arising from the LCM-cleared tail state.
-/

namespace ErdosProblems.Erdos243













/-- Multiplicative LCM weight on the first `k` steps after `r`. -/
def lcmBlockWeight (g : ℕ → ℕ) (r : ℕ) : ℕ → ℕ
  | 0 => 1
  | k + 1 => lcmBlockWeight g r k * g (r + k)

















end ErdosProblems.Erdos243
