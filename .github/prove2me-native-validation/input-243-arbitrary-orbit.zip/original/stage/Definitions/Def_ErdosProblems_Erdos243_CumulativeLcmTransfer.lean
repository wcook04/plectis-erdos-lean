import Definitions.Def_ErdosProblems_Erdos243_ReciprocalTailRigidity
import Definitions.Def_ErdosProblems_Erdos243_GlobalLcmHeight
import Mathlib.Algebra.Order.BigOperators.GroupWithZero.Finset
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.Data.Fin.Pigeonhole
import Mathlib.Data.Nat.ChineseRemainder
import Mathlib.Data.Nat.Find
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.ZMod.Basic
import Mathlib.Order.Filter.AtTopBot.Basic
import Mathlib.Tactic.Ring

/-!
# Erdős #243: cumulative-LCM transfer

`GlobalLcmHeight.lean` introduces the cumulative LCM `Λₙ`, the product-cleared
denominator scale `Dₙ`, the overlap debt `Mₙ`, and the exact relocation identity
`Mₙ Λₙ = Dₙ`.  What it does not supply is the transfer of that identity to the
*numerator*: whether the irreversible overlap payments recorded in `Mₙ` are
actually carried by the reciprocal-tail state `Cₙ`.

This module lands that transfer and its consequences.

* `cumulativeOverlapDebt_dvd_tailNumerator`: `Mₙ ∣ Cₙ`, by induction using only
  `ρₙ ∣ Λₙ` and `ρₙ ∣ aₙ`.  No positivity hypothesis is needed: `Mₙ₊₁` divides
  `aₙ Cₙ` and `Dₙ` separately, hence their difference.
* `cumulativeOverlapDebt_dvd_centeredState`: `Mₙ ∣ Eₙ` over `ℤ`.
* The LCM-normalised state `Uₙ = Cₙ / Mₙ`, `Vₙ = Λₙ - (aₙ - 1) Uₙ`, with the
  exact reconstruction `Mₙ Uₙ = Cₙ`, `Mₙ Vₙ = Eₙ` and the exact recurrence
  `ρₙ Uₙ₊₁ = Uₙ - Vₙ`.  `Vₙ` is *defined* by the centred formula, so the
  centring identity is definitional and no truncated division appears in any
  equation.
* `pow_lcmNonFreshCount_le_overlapDebt`: the division-free freshness budget
  `2^{#{j<n : ρⱼ > 1}} ≤ Mₙ`, hence `≤ Cₙ`.  This is the exact finite
  inequality behind "LCM freshness has density one".
* `lcmFresh_pairwiseCoprime`: multipliers at LCM-fresh indices are coprime to
  every earlier multiplier.
* `lcmNonFreshCount_sublinear_of_subexponential` and its exact-orbit
  specialisation: subexponential tail growth makes the non-fresh count
  sublinear in the division-free sense `K · count < n`.
* `no_lcmState_of_freshBlock`: the finite shifted-CRT first-crossing
  contradiction for the LCM-normalised state.  Unlike
  `LcmCriticalBoundary.no_boundedNegative_lcmState_of_oldPrimeSupply` the
  moduli are *whole numbers*, not primes, the block is finite, and the rise
  bound is only required below twice the block product.

Nothing here settles Erdős #243.  The analytic input that would place a block
of `B` pairwise-coprime old moduli all exceeding `B` by time `B + o(B)` is not
formalised.
-/

namespace ErdosProblems.Erdos243

/-! ## The cumulative LCM chain -/









/-! ## The overlap multiplier -/

/-- The one-step LCM overlap payment `ρₙ = gcd(Λₙ, aₙ)`. -/
def lcmOverlap (q : ℕ) (a : ℕ → ℕ) (n : ℕ) : ℕ :=
  Nat.gcd (cumulativeDigitLcm q a n) (a n)















/-! ## The keystone: overlap debt divides the tail numerator -/





/-! ## The LCM-normalised state and its exact system -/















/-! ## The freshness budget -/

/-- Number of LCM-non-fresh steps strictly before `n`: the indices where the
current multiplier shares a factor with the accumulated LCM. -/
def lcmNonFreshCount (q : ℕ) (a : ℕ → ℕ) : ℕ → ℕ
  | 0 => 0
  | n + 1 => lcmNonFreshCount q a n + if 1 < lcmOverlap q a n then 1 else 0









/-! ## Coprimality of fresh multipliers -/





/-! ## Sublinearity of the non-fresh count -/





/-! ## The shifted-CRT first-crossing barrier for the normalised state -/





end ErdosProblems.Erdos243
