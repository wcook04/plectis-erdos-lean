import Definitions.Def_ErdosProblems_Erdos243_ReciprocalTailRigidity
import Definitions.Def_ErdosProblems_Erdos243_LcmRecordCrossing
import Definitions.Def_ErdosProblems_Erdos243_PrimitiveRecordBarrier
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_RecordDivisibility
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_LogLogNormaliser
import Theorems.Thm_ErdosProblems_Erdos243_PaperCompleteR11_binaryTower_mono
import Theorems.Thm_ErdosProblems_Erdos243_PaperCompleteR11_log_two_pos
import Mathlib
import Mathlib.Algebra.Order.BigOperators.GroupWithZero.Finset
import Mathlib.Algebra.Ring.Basic
import Mathlib.Analysis.SpecialFunctions.Log.Basic
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Analysis.SumIntegralComparisons
import Mathlib.Data.Fin.Pigeonhole
import Mathlib.Data.Nat.ChineseRemainder
import Mathlib.Data.Nat.Factorization.Basic
import Mathlib.Data.Nat.Find
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.Rat.Defs
import Mathlib.Data.ZMod.Basic
import Mathlib.Order.Filter.AtTopBot.Basic
import Mathlib.Tactic
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.InfiniteSum.NatInt

/-!
# Exact base-two log-log normalisation


The cut-off is exactly `max 4 x`, as in the paper. The tower identities
are exact, including the normalisation constant: no change of logarithm
base is absorbed into an unspecified asymptotic constant.
-/

open ErdosProblems in
open ErdosProblems.Erdos243 in
open ErdosProblems.Erdos243.PaperCompleteR11 in
theorem solution (n : ℕ) (hn : 1 ≤ n) :
    recordLogLog (binaryTower n : ℝ) = (n : ℝ) := by
  have hfourN : 4 ≤ binaryTower n := by
    have h := binaryTower_mono hn
    norm_num [binaryTower] at h
    exact h
  have hfour : (4 : ℝ) ≤ (binaryTower n : ℝ) := by exact_mod_cast hfourN
  have ht : (binaryTower n : ℝ) = (2 : ℝ) ^ (2 ^ n) := by
    simp only [binaryTower, Nat.cast_pow, Nat.cast_ofNat]
  have hl : Real.log (2 : ℝ) ≠ 0 := log_two_pos.ne'
  unfold recordLogLog
  rw [max_eq_right hfour, ht, Real.log_pow, mul_div_cancel_right₀ _ hl]
  have hpow : ((2 ^ n : ℕ) : ℝ) = (2 : ℝ) ^ n := by push_cast; rfl
  rw [hpow, Real.log_pow, mul_div_cancel_right₀ _ hl]
