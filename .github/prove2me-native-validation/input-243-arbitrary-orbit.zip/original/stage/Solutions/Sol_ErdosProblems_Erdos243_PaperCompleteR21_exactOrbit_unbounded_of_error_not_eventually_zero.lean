import Definitions.Def_ErdosProblems_Erdos243_ReciprocalTailRigidity
import Definitions.Def_ErdosProblems_Erdos243_LcmRecordCrossing
import Definitions.Def_ErdosProblems_Erdos243_PrimitiveRecordBarrier
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_RecordDivisibility
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_CoprimeCores
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_LogLogNormaliser
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_PresievedCRT
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_RecordGcdReduction
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_InclusiveLimsup
import Theorems.Thm_ErdosProblems_Erdos243_centeredState_zero_absorbing
import Theorems.Thm_ErdosProblems_Erdos243_eventually_nonzero_of_zero_absorbing
import Theorems.Thm_ErdosProblems_Erdos243_tailState_tendsto_atTop_of_nonzero_normalizedVanishes
import Mathlib
import Mathlib.Algebra.Order.BigOperators.GroupWithZero.Finset
import Mathlib.Algebra.Ring.Basic
import Mathlib.Analysis.SpecialFunctions.Log.Basic
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Analysis.SumIntegralComparisons
import Mathlib.Data.EReal.Basic
import Mathlib.Data.Fin.Pigeonhole
import Mathlib.Data.Fintype.BigOperators
import Mathlib.Data.Fintype.EquivFin
import Mathlib.Data.Nat.ChineseRemainder
import Mathlib.Data.Nat.Factorization.Basic
import Mathlib.Data.Nat.Find
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.Nat.Totient
import Mathlib.Data.Rat.Defs
import Mathlib.Data.ZMod.Basic
import Mathlib.Order.Filter.AtTopBot.Basic
import Mathlib.Order.LiminfLimsup
import Mathlib.Tactic
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.InfiniteSum.NatInt

namespace ErdosProblems.Erdos243.PaperCompleteR21
end ErdosProblems.Erdos243.PaperCompleteR21

noncomputable section

namespace ErdosProblems.Erdos243.PaperCompleteR21
open Filter
open ErdosProblems.Erdos243
open ErdosProblems.Erdos243.PaperCompleteR11
end ErdosProblems.Erdos243.PaperCompleteR21

open ErdosProblems
open ErdosProblems.Erdos243
open ErdosProblems.Erdos243.PaperCompleteR21
open Filter
open ErdosProblems.Erdos243
open ErdosProblems.Erdos243.PaperCompleteR11
open ErdosProblems in
open ErdosProblems.Erdos243 in
open ErdosProblems.Erdos243.PaperCompleteR21 in
theorem solution
    (a C D : ℕ → ℕ) (E : ℕ → ℤ)
    (hC : ∀ n, C (n + 1) + D n = a n * C n)
    (hD : ∀ n, D (n + 1) = a n * D n)
    (hE : ∀ n, E n = centeredState (a n : ℤ) (D n : ℤ) (C n : ℤ))
    (hvanish : ∀ K, ∃ N, ∀ n, N ≤ n → K * Int.natAbs (E n) < C n)
    (hnot : ¬ ∃ N, ∀ n, N ≤ n → E n = 0) :
    ∀ H : ℕ, ∃ n, H ≤ C n := by
  obtain ⟨N, hN⟩ := hvanish 1
  -- shift to `N`, where the centring bound holds at every index
  set a' : ℕ → ℕ := fun n ↦ a (N + n) with ha'
  set C' : ℕ → ℕ := fun n ↦ C (N + n) with hC'
  set D' : ℕ → ℕ := fun n ↦ D (N + n) with hD'
  set E' : ℕ → ℤ := fun n ↦ E (N + n) with hE'
  have hC1 : ∀ n, C' (n + 1) + D' n = a' n * C' n := by
    intro n
    simp only [ha', hC', hD', show ∀ m : ℕ, N + (m + 1) = (N + m) + 1 from fun m ↦ by omega]
    exact hC (N + n)
  have hD1 : ∀ n, D' (n + 1) = a' n * D' n := by
    intro n
    simp only [ha', hD', show ∀ m : ℕ, N + (m + 1) = (N + m) + 1 from fun m ↦ by omega]
    exact hD (N + n)
  have hE1 : ∀ n, E' n = centeredState (a' n : ℤ) (D' n : ℤ) (C' n : ℤ) := by
    intro n; exact hE (N + n)
  have hcentred : ∀ n, Int.natAbs (E' n) < C' n := by
    intro n
    have := hN (N + n) (by omega)
    simpa [hE', hC'] using (by omega : Int.natAbs (E (N + n)) < C (N + n))
  have habs : ∀ n, E' n = 0 → E' (n + 1) = 0 :=
    fun n hz ↦ centeredState_zero_absorbing a' C' D' E' hC1 hD1 hE1 hcentred n hz
  have hnot' : ¬ ∃ M, ∀ n, M ≤ n → E' n = 0 := by
    rintro ⟨M, hM⟩
    refine hnot ⟨N + M, fun n hn ↦ ?_⟩
    have hrw : E n = E' (n - N) := by
      simp only [hE']
      congr 1
      omega
    rw [hrw]
    exact hM _ (by omega)
  have hne : ∀ n, E' n ≠ 0 :=
    fun n ↦ eventually_nonzero_of_zero_absorbing E' 0 (fun m _ hz ↦ habs m hz) hnot' n
      (Nat.zero_le n)
  have hmag : ∀ n, 0 < Int.natAbs (E' n) := by
    intro n
    exact Int.natAbs_pos.mpr (hne n)
  have hvan' : ∀ K, ∃ M, ∀ n, M ≤ n → K * Int.natAbs (E' n) < C' n := by
    intro K
    obtain ⟨M, hM⟩ := hvanish K
    refine ⟨M, fun n hn ↦ ?_⟩
    simpa [hE', hC'] using hM (N + n) (by omega)
  have htend :=
    tailState_tendsto_atTop_of_nonzero_normalizedVanishes C' (fun n ↦ Int.natAbs (E' n))
      hmag hvan'
  intro H
  obtain ⟨n, hn⟩ := (Filter.tendsto_atTop_atTop.mp htend) H
  exact ⟨N + n, hn n le_rfl⟩
