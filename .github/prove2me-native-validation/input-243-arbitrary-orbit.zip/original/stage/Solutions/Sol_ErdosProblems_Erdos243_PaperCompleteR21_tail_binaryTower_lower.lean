import Definitions.Def_ErdosProblems_Erdos243_ReciprocalTailRigidity
import Definitions.Def_ErdosProblems_Erdos243_LcmRecordCrossing
import Definitions.Def_ErdosProblems_Erdos243_PrimitiveRecordBarrier
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_RecordDivisibility
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_CoprimeCores
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_LogLogNormaliser
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_PresievedCRT
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_RecordGcdReduction
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_InclusiveLimsup
import Theorems.Thm_ErdosProblems_Erdos243_PaperCompleteR11_binaryTower_mono
import Theorems.Thm_ErdosProblems_Erdos243_PaperCompleteR11_binaryTower_succ
import Theorems.Thm_ErdosProblems_Erdos243_PaperCompleteR21_tail_multiplier_quadratic_lower
import Mathlib
import Mathlib.Algebra.Order.BigOperators.GroupWithZero.Finset
import Mathlib.Algebra.Ring.Basic
import Mathlib.Analysis.SpecialFunctions.Log.Basic
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Analysis.SumIntegralComparisons
import Mathlib.Data.EReal.Basic
import Mathlib.Data.Fin.Pigeonhole
import Mathlib.Data.Fintype.BigOperators
import Mathlib.Data.Fintype.EquivFin
import Mathlib.Data.Nat.ChineseRemainder
import Mathlib.Data.Nat.Factorization.Basic
import Mathlib.Data.Nat.Find
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.Nat.Totient
import Mathlib.Data.Rat.Defs
import Mathlib.Data.ZMod.Basic
import Mathlib.Order.Filter.AtTopBot.Basic
import Mathlib.Order.LiminfLimsup
import Mathlib.Tactic
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.InfiniteSum.NatInt

namespace ErdosProblems.Erdos243.PaperCompleteR21
end ErdosProblems.Erdos243.PaperCompleteR21

noncomputable section

namespace ErdosProblems.Erdos243.PaperCompleteR21
open Filter
open ErdosProblems.Erdos243
open ErdosProblems.Erdos243.PaperCompleteR11
variable (a C D : ℕ → ℕ) (E : ℕ → ℤ)
/-- `a n ≥ 4` forces `a n ² ≤ 2 a (n+1)`, hence a strict rise. -/
theorem tail_square_step
    (ha : ∀ n, 1 < a n) (hCpos : ∀ n, 0 < C n)
    (hC : ∀ n, C (n + 1) + D n = a n * C n)
    (hD : ∀ n, D (n + 1) = a n * D n)
    (hE : ∀ n, E n = centeredState (a n : ℤ) (D n : ℤ) (C n : ℤ))
    (n : ℕ) (hsmall : 4 * Int.natAbs (E n) < C n) (h4 : 4 ≤ a n) :
    a n ^ 2 ≤ 2 * a (n + 1) := by
  have hkey := tail_multiplier_quadratic_lower a C D E ha hCpos hC hD hE n hsmall
  nlinarith [hkey, h4]
end ErdosProblems.Erdos243.PaperCompleteR21

open ErdosProblems
open ErdosProblems.Erdos243
open ErdosProblems.Erdos243.PaperCompleteR21
open Filter
open ErdosProblems.Erdos243
open ErdosProblems.Erdos243.PaperCompleteR11
variable (a C D : ℕ → ℕ) (E : ℕ → ℤ)
open ErdosProblems in
open ErdosProblems.Erdos243 in
open ErdosProblems.Erdos243.PaperCompleteR21 in
theorem solution
    (ha : ∀ n, 1 < a n) (hCpos : ∀ n, 0 < C n)
    (hC : ∀ n, C (n + 1) + D n = a n * C n)
    (hD : ∀ n, D (n + 1) = a n * D n)
    (hE : ∀ n, E n = centeredState (a n : ℤ) (D n : ℤ) (C n : ℤ))
    (N : ℕ) (hN : ∀ n, N ≤ n → 4 * Int.natAbs (E n) < C n) (h4 : 4 ≤ a N) :
    ∀ k, 2 * binaryTower k ≤ a (N + k) := by
  intro k
  induction k with
  | zero => simpa [binaryTower] using h4
  | succ k ih =>
      have hbt : 2 ≤ binaryTower k := by
        have := binaryTower_mono (Nat.zero_le k)
        simpa [binaryTower] using this
      have h4k : 4 ≤ a (N + k) := by omega
      have hsq := tail_square_step a C D E ha hCpos hC hD hE (N + k)
        (hN (N + k) (by omega)) h4k
      have hstep : (2 * binaryTower k) ^ 2 ≤ a (N + k) ^ 2 :=
        Nat.pow_le_pow_left ih 2
      have hsucc : binaryTower (k + 1) = binaryTower k ^ 2 := binaryTower_succ k
      have hexp : (2 * binaryTower k) ^ 2 = 4 * binaryTower (k + 1) := by
        rw [hsucc]; ring
      have : 4 * binaryTower (k + 1) ≤ 2 * a (N + k + 1) := by omega
      have heq : N + (k + 1) = N + k + 1 := by omega
      rw [heq]
      omega
