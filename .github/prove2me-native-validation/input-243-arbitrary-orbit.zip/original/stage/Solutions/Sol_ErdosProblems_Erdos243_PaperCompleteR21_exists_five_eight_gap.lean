import Definitions.Def_ErdosProblems_Erdos243_ReciprocalTailRigidity
import Definitions.Def_ErdosProblems_Erdos243_GlobalLcmHeight
import Definitions.Def_ErdosProblems_Erdos243_CumulativeLcmTransfer
import Definitions.Def_ErdosProblems_Erdos243_LcmCriticalBoundary
import Definitions.Def_ErdosProblems_Erdos243_LcmRecordCrossing
import Definitions.Def_ErdosProblems_Erdos243_PrimitiveRecordBarrier
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_RecordDivisibility
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_CoprimeCores
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_LogLogNormaliser
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_PresievedCRT
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_RecordGcdReduction
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_InclusiveLimsup
import Mathlib
import Mathlib.Algebra.Order.BigOperators.GroupWithZero.Finset
import Mathlib.Algebra.Ring.Basic
import Mathlib.Analysis.SpecialFunctions.Log.Basic
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Analysis.SumIntegralComparisons
import Mathlib.Data.EReal.Basic
import Mathlib.Data.Fin.Pigeonhole
import Mathlib.Data.Fintype.BigOperators
import Mathlib.Data.Fintype.EquivFin
import Mathlib.Data.Nat.ChineseRemainder
import Mathlib.Data.Nat.Factorization.Basic
import Mathlib.Data.Nat.Find
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.Nat.Totient
import Mathlib.Data.Rat.Defs
import Mathlib.Data.ZMod.Basic
import Mathlib.Order.Filter.AtTopBot.Basic
import Mathlib.Order.LiminfLimsup
import Mathlib.Tactic
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.InfiniteSum.NatInt

namespace ErdosProblems.Erdos243.PaperCompleteR21
end ErdosProblems.Erdos243.PaperCompleteR21

noncomputable section

namespace ErdosProblems.Erdos243.PaperCompleteR21
open Filter
open ErdosProblems.Erdos243
open ErdosProblems.Erdos243.PaperCompleteR11
end ErdosProblems.Erdos243.PaperCompleteR21

open ErdosProblems
open ErdosProblems.Erdos243
open ErdosProblems.Erdos243.PaperCompleteR21
open Filter
open ErdosProblems.Erdos243
open ErdosProblems.Erdos243.PaperCompleteR11
open ErdosProblems in
open ErdosProblems.Erdos243 in
open ErdosProblems.Erdos243.PaperCompleteR21 in
theorem solution (c : ℕ) : ∃ m : ℕ, c * 5 ^ m < 8 ^ m := by
  refine ⟨3 * (c + 1), ?_⟩
  have h1 : c < 4 ^ (c + 1) := by
    have hc : c < 2 ^ c := Nat.lt_two_pow_self
    have h2 : (2 : ℕ) ^ c ≤ 4 ^ c := Nat.pow_le_pow_left (by norm_num) c
    have h3 : (4 : ℕ) ^ c ≤ 4 ^ (c + 1) := Nat.pow_le_pow_right (by norm_num) (by omega)
    omega
  have h2 : (5 : ℕ) ^ (3 * (c + 1)) = 125 ^ (c + 1) := by
    rw [pow_mul]; norm_num
  have h3 : (8 : ℕ) ^ (3 * (c + 1)) = 512 ^ (c + 1) := by
    rw [pow_mul]; norm_num
  rw [h2, h3]
  have hpos : 0 < (125 : ℕ) ^ (c + 1) := by positivity
  calc c * 125 ^ (c + 1) < 4 ^ (c + 1) * 125 ^ (c + 1) :=
        Nat.mul_lt_mul_of_lt_of_le h1 (le_refl _) hpos
  _ = 500 ^ (c + 1) := by rw [← Nat.mul_pow]
  _ ≤ 512 ^ (c + 1) := Nat.pow_le_pow_left (by norm_num) _
