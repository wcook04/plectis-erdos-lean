import Definitions.Def_ErdosProblems_Erdos243_ReciprocalTailRigidity
import Definitions.Def_ErdosProblems_Erdos243_GlobalLcmHeight
import Definitions.Def_ErdosProblems_Erdos243_CumulativeLcmTransfer
import Definitions.Def_ErdosProblems_Erdos243_LcmCriticalBoundary
import Definitions.Def_ErdosProblems_Erdos243_LcmRecordCrossing
import Definitions.Def_ErdosProblems_Erdos243_PrimitiveRecordBarrier
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_RecordDivisibility
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_PresievedCRT
import Mathlib
import Mathlib.Algebra.Order.BigOperators.GroupWithZero.Finset
import Mathlib.Algebra.Ring.Basic
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Data.Fin.Pigeonhole
import Mathlib.Data.Nat.ChineseRemainder
import Mathlib.Data.Nat.Factorization.Basic
import Mathlib.Data.Nat.Find
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.Nat.Totient
import Mathlib.Data.Rat.Defs
import Mathlib.Data.ZMod.Basic
import Mathlib.Order.Filter.AtTopBot.Basic
import Mathlib.Tactic
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.InfiniteSum.NatInt

/-!
# Exact finite pre-sieving and the primitive record fence


The modulus W is part of the CRT construction, not merely mentioned in
an offset-counting hypothesis.  Thus x is a multiple of W, and only the
phi(W)/W proportion of offsets coprime to W need individual old moduli.
The exact count, its asymptotic proportion, the bounded CRT phase and the
primitive first-crossing contradiction are all supplied here.  Selection
of the canonical moduli and the final log-log limit remain separate.
-/

namespace ErdosProblems.Erdos243.PaperCompleteR11
open Filter
open scoped BigOperators Topology
end ErdosProblems.Erdos243.PaperCompleteR11

open Filter
open scoped BigOperators Topology
open ErdosProblems in
open ErdosProblems.Erdos243 in
open ErdosProblems.Erdos243.PaperCompleteR11 in
theorem solution
    (W B x : ℕ) (m : {r // r ∈ presievedOffsets W B} → ℕ)
    (hWx : W ∣ x)
    (hphase : ∀ i, m i ∣ x + i.val)
    (z : ℕ) (hxz : x ≤ z) (hzb : z < x + B) (hcop : Nat.Coprime W z) :
    ∃ i : {r // r ∈ presievedOffsets W B}, m i ∣ z := by
  let r := z - x
  have hxr : x + r = z := Nat.add_sub_of_le hxz
  have hrB : r < B := by dsimp [r]; omega
  have hcopr : Nat.Coprime W r := by
    have hdW := Nat.gcd_dvd_left W r
    have hdr := Nat.gcd_dvd_right W r
    have hdz : Nat.gcd W r ∣ z := by
      rw [← hxr]
      exact dvd_add (hdW.trans hWx) hdr
    have hd1 : Nat.gcd W r ∣ 1 := by
      simpa only [hcop.gcd_eq_one] using Nat.dvd_gcd hdW hdz
    exact Nat.dvd_one.mp hd1
  let i : {r // r ∈ presievedOffsets W B} :=
    ⟨r, by simp only [presievedOffsets, Finset.mem_filter, Finset.mem_range]; exact ⟨hrB, hcopr⟩⟩
  refine ⟨i, ?_⟩
  simpa only [i, hxr] using hphase i
