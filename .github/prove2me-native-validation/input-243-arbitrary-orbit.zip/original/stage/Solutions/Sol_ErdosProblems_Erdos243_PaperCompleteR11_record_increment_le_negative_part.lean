import Definitions.Def_ErdosProblems_Erdos243_ReciprocalTailRigidity
import Definitions.Def_ErdosProblems_Erdos243_LcmRecordCrossing
import Definitions.Def_ErdosProblems_Erdos243_PrimitiveRecordBarrier
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_RecordDivisibility
import Mathlib
import Mathlib.Algebra.Order.BigOperators.GroupWithZero.Finset
import Mathlib.Algebra.Ring.Basic
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Data.Fin.Pigeonhole
import Mathlib.Data.Nat.ChineseRemainder
import Mathlib.Data.Nat.Factorization.Basic
import Mathlib.Data.Nat.Find
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.Rat.Defs
import Mathlib.Data.ZMod.Basic
import Mathlib.Order.Filter.AtTopBot.Basic
import Mathlib.Tactic
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.InfiniteSum.NatInt

namespace PaperCompleteR9
end PaperCompleteR9

/-!
# Finite inclusive-boundary transfer

These are the exact finite inequalities used at the final step of the
inclusive log--log corollary.  They do not claim the still-missing limsup,
totient, or asymptotic selection argument.
-/

namespace ErdosProblems.Erdos243.PaperCompleteR11
open PaperCompleteR9
end ErdosProblems.Erdos243.PaperCompleteR11

open PaperCompleteR9
open ErdosProblems in
open ErdosProblems.Erdos243 in
open ErdosProblems.Erdos243.PaperCompleteR11 in
theorem solution
    (U : ℕ → ℕ) (V : ℕ → ℤ)
    (hstep : ∀ n, (U (n + 1) : ℤ) = (U n : ℤ) - V n) (n : ℕ) :
    ((U (n + 1) - runningMax U n : ℕ) : ℤ) ≤ max (-V n) 0 := by
  by_cases hrecord : runningMax U n < U (n + 1)
  · have hsource : U n ≤ runningMax U n := le_runningMax U (le_rfl : n ≤ n)
    have hgap : ((U (n + 1) - runningMax U n : ℕ) : ℤ) =
        (U (n + 1) : ℤ) - runningMax U n := by
      omega
    rw [hgap]
    have hdiff : (U (n + 1) : ℤ) - U n = -V n := by
      have hs := hstep n
      omega
    calc
      (U (n + 1) : ℤ) - runningMax U n ≤ (U (n + 1) : ℤ) - U n := by
        exact sub_le_sub_left (by exact_mod_cast hsource) _
      _ = -V n := hdiff
      _ ≤ max (-V n) 0 := le_max_left _ _
  · have hzero : U (n + 1) - runningMax U n = 0 :=
      Nat.sub_eq_zero_of_le (by omega)
    rw [hzero]
    simp
