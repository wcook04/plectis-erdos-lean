import Definitions.Def_ErdosProblems_Erdos243_ReciprocalTailRigidity
import Definitions.Def_ErdosProblems_Erdos243_GlobalLcmHeight
import Definitions.Def_ErdosProblems_Erdos243_CumulativeLcmTransfer
import Definitions.Def_ErdosProblems_Erdos243_LcmCriticalBoundary
import Definitions.Def_ErdosProblems_Erdos243_LcmRecordCrossing
import Definitions.Def_ErdosProblems_Erdos243_PrimitiveRecordBarrier
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_RecordDivisibility
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_CoprimeCores
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_LogLogNormaliser
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_PresievedCRT
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_RecordGcdReduction
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_InclusiveLimsup
import Theorems.Thm_ErdosProblems_Erdos243_cumulativeDigitLcm_succ
import Theorems.Thm_ErdosProblems_Erdos243_cumulativeDigitLcm_zero
import Theorems.Thm_ErdosProblems_Erdos243_lcmBlockWeight_succ
import Theorems.Thm_ErdosProblems_Erdos243_lcmBlockWeight_zero
import Theorems.Thm_ErdosProblems_Erdos243_lcmNonFreshCount_succ
import Theorems.Thm_ErdosProblems_Erdos243_lcmNonFreshCount_zero
import Mathlib
import Mathlib.Algebra.Order.BigOperators.GroupWithZero.Finset
import Mathlib.Algebra.Ring.Basic
import Mathlib.Analysis.SpecialFunctions.Log.Basic
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Analysis.SumIntegralComparisons
import Mathlib.Data.EReal.Basic
import Mathlib.Data.Fin.Pigeonhole
import Mathlib.Data.Fintype.BigOperators
import Mathlib.Data.Fintype.EquivFin
import Mathlib.Data.Nat.ChineseRemainder
import Mathlib.Data.Nat.Factorization.Basic
import Mathlib.Data.Nat.Find
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.Nat.Totient
import Mathlib.Data.Rat.Defs
import Mathlib.Data.ZMod.Basic
import Mathlib.Order.Filter.AtTopBot.Basic
import Mathlib.Order.LiminfLimsup
import Mathlib.Tactic
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.InfiniteSum.NatInt

namespace ErdosProblems.Erdos243.PaperCompleteR21
end ErdosProblems.Erdos243.PaperCompleteR21

noncomputable section

namespace ErdosProblems.Erdos243.PaperCompleteR21
open Filter
open ErdosProblems.Erdos243
open ErdosProblems.Erdos243.PaperCompleteR11
variable (a C D : ℕ → ℕ) (E : ℕ → ℤ)
end ErdosProblems.Erdos243.PaperCompleteR21

open ErdosProblems
open ErdosProblems.Erdos243
open ErdosProblems.Erdos243.PaperCompleteR21
open Filter
open ErdosProblems.Erdos243
open ErdosProblems.Erdos243.PaperCompleteR11
variable (a C D : ℕ → ℕ) (E : ℕ → ℤ)
open ErdosProblems in
open ErdosProblems.Erdos243 in
open ErdosProblems.Erdos243.PaperCompleteR21 in
theorem solution (N : ℕ)
    (h : ∀ n, N ≤ n → 4 * C (n + 1) ≤ 5 * C n) :
    ∀ m, 4 ^ m * C (N + m) ≤ 5 ^ m * C N := by
  intro m
  induction m with
  | zero => simp
  | succ m ih =>
      have hstep := h (N + m) (by omega)
      calc (4 : ℕ) ^ (m + 1) * C (N + (m + 1))
          = 4 ^ m * (4 * C ((N + m) + 1)) := by
            rw [show N + (m + 1) = (N + m) + 1 by omega]; ring
      _ ≤ 4 ^ m * (5 * C (N + m)) := Nat.mul_le_mul (le_refl _) hstep
      _ = 5 * (4 ^ m * C (N + m)) := by ring
      _ ≤ 5 * (5 ^ m * C N) := Nat.mul_le_mul (le_refl _) ih
      _ = 5 ^ (m + 1) * C N := by ring
