import Definitions.Def_ErdosProblems_Erdos243_ReciprocalTailRigidity
import Definitions.Def_ErdosProblems_Erdos243_LcmRecordCrossing
import Definitions.Def_ErdosProblems_Erdos243_PrimitiveRecordBarrier
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_RecordDivisibility
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_PresievedCRT
import Mathlib
import Mathlib.Algebra.Order.BigOperators.GroupWithZero.Finset
import Mathlib.Algebra.Ring.Basic
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Data.Fin.Pigeonhole
import Mathlib.Data.Nat.ChineseRemainder
import Mathlib.Data.Nat.Factorization.Basic
import Mathlib.Data.Nat.Find
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.Nat.Totient
import Mathlib.Data.Rat.Defs
import Mathlib.Data.ZMod.Basic
import Mathlib.Order.Filter.AtTopBot.Basic
import Mathlib.Tactic
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.InfiniteSum.NatInt

/-!
# Exact finite pre-sieving and the primitive record fence


The modulus W is part of the CRT construction, not merely mentioned in
an offset-counting hypothesis.  Thus x is a multiple of W, and only the
phi(W)/W proportion of offsets coprime to W need individual old moduli.
The exact count, its asymptotic proportion, the bounded CRT phase and the
primitive first-crossing contradiction are all supplied here.  Selection
of the canonical moduli and the final log-log limit remain separate.
-/

namespace ErdosProblems.Erdos243.PaperCompleteR11
open Filter
open scoped BigOperators Topology
end ErdosProblems.Erdos243.PaperCompleteR11

open Filter
open scoped BigOperators Topology
open ErdosProblems in
open ErdosProblems.Erdos243 in
open ErdosProblems.Erdos243.PaperCompleteR11 in
theorem solution (W : ℕ) (hW : 1 < W) :
    (1 : ℝ) < (W : ℝ) / (Nat.totient W : ℝ) := by
  have hphi : (0 : ℝ) < (Nat.totient W : ℝ) := by
    exact_mod_cast (Nat.totient_pos.mpr (by omega : 0 < W))
  apply (lt_div_iff₀ hphi).2
  simpa only [one_mul] using (show (Nat.totient W : ℝ) < (W : ℝ) by
    exact_mod_cast Nat.totient_lt W hW)
