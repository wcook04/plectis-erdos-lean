import Definitions.Def_ErdosProblems_Erdos243_ReciprocalTailRigidity
import Definitions.Def_ErdosProblems_Erdos243_GlobalLcmHeight
import Mathlib.Algebra.Order.BigOperators.GroupWithZero.Finset
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.Data.Fin.Pigeonhole
import Mathlib.Data.Nat.ChineseRemainder
import Mathlib.Data.Nat.Find
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.ZMod.Basic
import Mathlib.Order.Filter.AtTopBot.Basic
import Mathlib.Tactic.Ring

/-!
# Erdős #243: cumulative-LCM height

Global coordinates which retain digit-overlap payments that can disappear
from the dynamically reduced numerator-denominator pair.
-/

open ErdosProblems in
open ErdosProblems.Erdos243 in
@[simp]
theorem solution (q : ℕ) (a : ℕ → ℕ) (n : ℕ) :
    cumulativeDigitLcm q a (n + 1) =
      Nat.lcm (cumulativeDigitLcm q a n) (a n) := rfl
