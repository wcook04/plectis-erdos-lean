import Definitions.Def_ErdosProblems_Erdos243_ReciprocalTailRigidity
import Definitions.Def_ErdosProblems_Erdos243_LcmCriticalBoundary
import Mathlib.Algebra.Order.BigOperators.GroupWithZero.Finset
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.Data.Fin.Pigeonhole
import Mathlib.Data.Nat.ChineseRemainder
import Mathlib.Data.Nat.Find
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.ZMod.Basic
import Mathlib.Order.Filter.AtTopBot.Basic
import Mathlib.Tactic.Ring

open scoped BigOperators

/-!
# Erdős 243: the LCM critical boundary

This module formalizes the strict-rise CRT consumer and weighted block
telescope arising from the LCM-cleared tail state.
-/

open ErdosProblems in
open ErdosProblems.Erdos243 in
@[simp]
theorem solution (g : ℕ → ℕ) (r k : ℕ) :
    lcmBlockWeight g r (k + 1) =
      lcmBlockWeight g r k * g (r + k) := rfl
