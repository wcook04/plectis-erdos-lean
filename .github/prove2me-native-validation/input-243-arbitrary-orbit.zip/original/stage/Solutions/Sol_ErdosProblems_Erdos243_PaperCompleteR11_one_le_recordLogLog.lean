import Definitions.Def_ErdosProblems_Erdos243_ReciprocalTailRigidity
import Definitions.Def_ErdosProblems_Erdos243_LcmRecordCrossing
import Definitions.Def_ErdosProblems_Erdos243_PrimitiveRecordBarrier
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_RecordDivisibility
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_LogLogNormaliser
import Theorems.Thm_ErdosProblems_Erdos243_PaperCompleteR11_log_two_pos
import Theorems.Thm_ErdosProblems_Erdos243_PaperCompleteR11_inner_logLog_ge_two
import Mathlib
import Mathlib.Algebra.Order.BigOperators.GroupWithZero.Finset
import Mathlib.Algebra.Ring.Basic
import Mathlib.Analysis.SpecialFunctions.Log.Basic
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Analysis.SumIntegralComparisons
import Mathlib.Data.Fin.Pigeonhole
import Mathlib.Data.Nat.ChineseRemainder
import Mathlib.Data.Nat.Factorization.Basic
import Mathlib.Data.Nat.Find
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.Rat.Defs
import Mathlib.Data.ZMod.Basic
import Mathlib.Order.Filter.AtTopBot.Basic
import Mathlib.Tactic
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.InfiniteSum.NatInt

/-!
# Exact base-two log-log normalisation


The cut-off is exactly `max 4 x`, as in the paper. The tower identities
are exact, including the normalisation constant: no change of logarithm
base is absorbed into an unspecified asymptotic constant.
-/

open ErdosProblems in
open ErdosProblems.Erdos243 in
open ErdosProblems.Erdos243.PaperCompleteR11 in
theorem solution (x : ℝ) : 1 ≤ recordLogLog x := by
  unfold recordLogLog
  apply (le_div_iff₀ log_two_pos).2
  have h := Real.log_le_log (by norm_num : (0 : ℝ) < 2) (inner_logLog_ge_two x)
  simpa only [one_mul] using h
