import Definitions.Def_ErdosProblems_Erdos243_ReciprocalTailRigidity
import Definitions.Def_ErdosProblems_Erdos243_LcmRecordCrossing
import Definitions.Def_ErdosProblems_Erdos243_PrimitiveRecordBarrier
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_RecordDivisibility
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_CoprimeCores
import Mathlib
import Mathlib.Algebra.Order.BigOperators.GroupWithZero.Finset
import Mathlib.Algebra.Ring.Basic
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Data.Fin.Pigeonhole
import Mathlib.Data.Nat.ChineseRemainder
import Mathlib.Data.Nat.Factorization.Basic
import Mathlib.Data.Nat.Find
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.Rat.Defs
import Mathlib.Data.ZMod.Basic
import Mathlib.Order.Filter.AtTopBot.Basic
import Mathlib.Tactic
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.InfiniteSum.NatInt

/-!
# Coprime cores of a finite non-coprime family

Removing gcd(A_i, product of all other A_j) yields pairwise-coprime
cores. The loss is bounded by the product of the pairwise gcds. This avoids
an unproved supply of pairwise-coprime original multipliers in the
non-stabilised-gcd branch of the inclusive argument.
-/

namespace ErdosProblems.Erdos243.PaperCompleteR11
open scoped BigOperators



/-- Gcd with a product divides the product of the individual gcds. -/
theorem gcd_prod_dvd_prod_gcd {ι : Type*} [DecidableEq ι]
    (A : ℕ) (s : Finset ι) (f : ι → ℕ) :
    Nat.gcd A (∏ j ∈ s, f j) ∣ ∏ j ∈ s, Nat.gcd A (f j) := by
  induction s using Finset.induction_on with
  | empty => simp
  | @insert j s hj ih =>
      rw [Finset.prod_insert hj, Finset.prod_insert hj]
      exact (_root_.gcd_mul_dvd_mul_gcd A (f j) (∏ k ∈ s, f k)).trans
        (mul_dvd_mul (dvd_refl _) ih)





theorem coprimeCore_mul_denom {B : ℕ} (A : Fin B → ℕ) (i : Fin B) :
    coprimeCore A i * coreDenom A i = A i :=
  Nat.div_mul_cancel (Nat.gcd_dvd_left _ _)
end ErdosProblems.Erdos243.PaperCompleteR11

open scoped BigOperators
open ErdosProblems in
open ErdosProblems.Erdos243 in
open ErdosProblems.Erdos243.PaperCompleteR11 in
theorem solution {B : ℕ} (A : Fin B → ℕ)
    (hA : ∀ i, 0 < A i) (H : ℕ)
    (hpair : ∀ i j, i ≠ j → Nat.gcd (A i) (A j) ≤ H) (i : Fin B) :
    A i ≤ coprimeCore A i * H ^ (B - 1) := by
  classical
  have hprodpos : 0 < ∏ j ∈ Finset.univ.erase i, Nat.gcd (A i) (A j) := by
    apply Finset.prod_pos
    intro j hj
    exact Nat.gcd_pos_of_pos_left (A j) (hA i)
  have hGle : coreDenom A i ≤ ∏ j ∈ Finset.univ.erase i, Nat.gcd (A i) (A j) :=
    Nat.le_of_dvd hprodpos (gcd_prod_dvd_prod_gcd (A i) (Finset.univ.erase i) A)
  have hprodle : (∏ j ∈ Finset.univ.erase i, Nat.gcd (A i) (A j)) ≤ H ^ (B - 1) := by
    calc
      (∏ j ∈ Finset.univ.erase i, Nat.gcd (A i) (A j)) ≤
          ∏ _j ∈ Finset.univ.erase i, H := by
        apply Finset.prod_le_prod'
        intro j hj
        exact hpair i j (Ne.symm (Finset.mem_erase.mp hj).1)
      _ = H ^ (B - 1) := by simp
  calc
    A i = coprimeCore A i * coreDenom A i := (coprimeCore_mul_denom A i).symm
    _ ≤ coprimeCore A i * H ^ (B - 1) := Nat.mul_le_mul_left _ (hGle.trans hprodle)
