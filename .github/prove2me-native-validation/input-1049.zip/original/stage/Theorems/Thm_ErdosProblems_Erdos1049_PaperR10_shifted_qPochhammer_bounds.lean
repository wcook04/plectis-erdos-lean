import Definitions.Def_ErdosProblems_Erdos1049_QProductBoundsR10
import Mathlib.Analysis.SpecialFunctions.Log.Basic
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.Tactic
import Mathlib.Topology.Algebra.InfiniteSum.Real
import Mathlib.Topology.Algebra.InfiniteSum.Ring

/-!
# Positive q-products and q-binomial ratio coefficients

The infinite product is constructed from an absolutely
convergent logarithmic series, and is proved to be the limit of its finite
products. Its positivity is therefore not an assumed supplier.
-/
open Filter
open scoped BigOperators Topology

open ErdosProblems.Erdos1049.PaperR10

theorem ErdosProblems.Erdos1049.PaperR10.shifted_qPochhammer_bounds {q : ℝ} (hq0 : 0 < q) (hq1 : q < 1)
    (s n : ℕ) (hs : 1 ≤ s) :
    qPochhammerInfinity q q ≤ qPochhammerFinite (q ^ s) q n ∧
      qPochhammerFinite (q ^ s) q n ≤ 1 := by sorry
