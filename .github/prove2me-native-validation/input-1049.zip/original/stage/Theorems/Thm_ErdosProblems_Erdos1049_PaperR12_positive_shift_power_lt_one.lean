import Definitions.Def_ErdosProblems_Erdos1049_QProductBoundsR10
import Mathlib
import Mathlib.Analysis.SpecialFunctions.Log.Basic
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.Tactic
import Mathlib.Topology.Algebra.InfiniteSum.Real
import Mathlib.Topology.Algebra.InfiniteSum.Ring

namespace ErdosProblems.Erdos1049.PaperR12
end ErdosProblems.Erdos1049.PaperR12

namespace PaperR10
end PaperR10

/-!
# The actual analytic moment generating identity

Proves summability, positivity, and the identity v_m^* = P^4 G_q(q^(m+1)).

Unlike a positive-measure consumer, this file starts with the literal finite
q-product summand in the 2016 normalised moment. It proves summability and
performs the finite/infinite product cancellation at w=q^(m+1). No moment
identity, atom identity, summability, or product nonvanishing is a premise.

The subsequent coefficient expansion of G, comparison of its coefficients,
and infinite Cauchy--Binet passage are separate obligations; this file does
not mislabel those consequences as established merely by the identity below.
-/
open PaperR10
open scoped BigOperators

open ErdosProblems.Erdos1049.PaperR12

open ErdosProblems.Erdos1049.PaperR10

theorem ErdosProblems.Erdos1049.PaperR12.positive_shift_power_lt_one {q : ℝ} (hq0 : 0 < q) (hq1 : q < 1)
    (s : ℕ) (hs : 1 ≤ s) : q ^ s < 1 := by sorry
