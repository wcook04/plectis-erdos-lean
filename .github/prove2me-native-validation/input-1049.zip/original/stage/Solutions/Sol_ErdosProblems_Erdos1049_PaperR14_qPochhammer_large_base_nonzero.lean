import Definitions.Def_ErdosProblems_Erdos1049_QBinomialUnitIdentity
import Definitions.Def_ErdosProblems_Erdos1049_FiniteResidueInterpolationR14
import Definitions.Def_ErdosProblems_Erdos1049_QProductBoundsR10
import Definitions.Def_ErdosProblems_Erdos1049_ReciprocalPochhammerR14
import Theorems.Thm_ErdosProblems_Erdos1049_PaperR14_finite_qPochhammer_product
import Mathlib
import Mathlib.Algebra.BigOperators.Group.Finset.Basic
import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Algebra.Polynomial.Coeff
import Mathlib.Algebra.Polynomial.Eval.Defs
import Mathlib.Algebra.Polynomial.Roots
import Mathlib.Analysis.SpecialFunctions.Log.Basic
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.Data.Nat.Choose.Basic
import Mathlib.Tactic
import Mathlib.Topology.Algebra.InfiniteSum.Real
import Mathlib.Topology.Algebra.InfiniteSum.Ring

/-!
# Reciprocal factorials and reflected finite products

Reversal of finite q-factorials and the erased pole product. These are finite algebraic
identities. In particular no analytic source identity is used as a premise.
-/

namespace ErdosProblems.Erdos1049.PaperR14
set_option maxHeartbeats 1000000
open Finset Polynomial
open scoped BigOperators

variable {K : Type*} [Field K]
end ErdosProblems.Erdos1049.PaperR14

set_option maxHeartbeats 1000000
open Finset Polynomial
open scoped BigOperators
variable {K : Type*} [Field K]
open ErdosProblems in
open ErdosProblems.Erdos1049 in
open ErdosProblems.Erdos1049.PaperR14 in
theorem solution {p : ℝ} (hp : 1 < p) (m : ℕ) :
    qPochhammer p p m ≠ 0 := by
  rw [finite_qPochhammer_product]
  apply prod_ne_zero_iff.mpr
  intro i hi
  have hbase : p ≤ p ^ (i + 1) := by
    simpa only [pow_one] using pow_le_pow_right₀ hp.le (show 1 ≤ i + 1 by omega)
  have hpow : 1 < p ^ (i + 1) := hp.trans_le hbase
  rw [← pow_succ']
  exact sub_ne_zero.mpr (ne_of_lt hpow)
