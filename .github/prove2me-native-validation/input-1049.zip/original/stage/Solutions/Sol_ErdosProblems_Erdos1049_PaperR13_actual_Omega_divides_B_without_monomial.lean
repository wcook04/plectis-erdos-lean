import Definitions.Def_ErdosProblems_Erdos1049_QBinomialUnitIdentity
import Definitions.Def_ErdosProblems_Erdos1049_ZudilinConeArithmetic
import Definitions.Def_ErdosProblems_Erdos1049_PaperOmegaIndicatorR7
import Definitions.Def_ErdosProblems_Erdos1049_SourcePolynomialR11
import Definitions.Def_ErdosProblems_Erdos1049_SourceBClearingR12
import Definitions.Def_ErdosProblems_Erdos1049_GaussianDegreeR12
import Definitions.Def_ErdosProblems_Erdos1049_SourceFiniteTransformR12
import Definitions.Def_ErdosProblems_Erdos1049_SourceHomogeneousR12
import Definitions.Def_ErdosProblems_Erdos1049_RootUnityLocalCancellationR13
import Definitions.Def_ErdosProblems_Erdos1049_SourceBMonomialR12
import Definitions.Def_ErdosProblems_Erdos1049_SourceBTopDegreeR13
import Definitions.Def_ErdosProblems_Erdos1049_SourceRootCarriesR13
import Definitions.Def_ErdosProblems_Erdos1049_SourceRootBlocksR13
import Definitions.Def_ErdosProblems_Erdos1049_SourceOmegaCancellationR13
import Theorems.Thm_ErdosProblems_Erdos1049_PaperR11_sourceWeight_zero_or_one
import Theorems.Thm_ErdosProblems_Erdos1049_PaperR13_sourceOmega_monic
import Theorems.Thm_ErdosProblems_Erdos1049_PaperR13_actual_B_cyclotomic_dvd
import Mathlib
import Mathlib.Algebra.BigOperators.Group.Finset.Basic
import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Algebra.Order.Floor.Ring
import Mathlib.Algebra.Polynomial.Coeff
import Mathlib.Algebra.Polynomial.Eval.Defs
import Mathlib.Data.Fintype.Pigeonhole
import Mathlib.Data.Nat.Choose.Basic
import Mathlib.Data.Real.Basic
import Mathlib.Data.ZMod.Basic
import Mathlib.Data.ZMod.Coprime
import Mathlib.RingTheory.Polynomial.Cyclotomic.Basic
import Mathlib.Tactic

namespace PaperR11
end PaperR11

namespace PaperR12
end PaperR12

namespace ErdosProblems.Erdos1049.PaperR13
open Polynomial PaperR11 PaperR12 Finset
open scoped BigOperators
lemma coprime_finset_product_right {R : Type*} [CommSemiring R]
    (a : R) (s : Finset ℕ) (f : ℕ → R)
    (h : ∀ i ∈ s, IsCoprime a (f i)) : IsCoprime a (∏ i ∈ s, f i) := by
  classical
  revert h
  induction s using Finset.induction_on with
  | empty => intro h; simpa using (isCoprime_one_right : IsCoprime a 1)
  | @insert i s hi ih =>
      intro h
      rw [prod_insert hi]
      exact (h i (mem_insert_self _ _)).mul_right
        (ih (fun j hj => h j (mem_insert_of_mem hj)))
lemma pairwise_coprime_finset_product_dvd {R : Type*} [CommSemiring R]
    (s : Finset ℕ) (f : ℕ → R) (p : R)
    (hpair : ∀ i ∈ s, ∀ j ∈ s, i ≠ j → IsCoprime (f i) (f j))
    (hdiv : ∀ i ∈ s, f i ∣ p) : (∏ i ∈ s, f i) ∣ p := by
  classical
  revert hpair hdiv
  induction s using Finset.induction_on with
  | empty => intro hpair hdiv; simp
  | @insert i s hi ih =>
      intro hpair hdiv
      rw [prod_insert hi]
      have hcop := coprime_finset_product_right (f i) s f (fun j hj =>
        hpair i (mem_insert_self _ _) j (mem_insert_of_mem hj)
          (fun hij => hi (by simpa only [hij] using hj)))
      apply hcop.mul_dvd (hdiv i (mem_insert_self _ _))
      apply ih
      · intro a ha b hb hab
        exact hpair a (mem_insert_of_mem ha) b (mem_insert_of_mem hb) hab
      · intro a ha
        exact hdiv a (mem_insert_of_mem ha)
end ErdosProblems.Erdos1049.PaperR13

open ErdosProblems
open ErdosProblems.Erdos1049
open ErdosProblems.Erdos1049.PaperR13
open Polynomial PaperR11 PaperR12 Finset
open scoped BigOperators
open ErdosProblems in
open ErdosProblems.Erdos1049 in
open ErdosProblems.Erdos1049.PaperR13 in
open ErdosProblems.Erdos1049.PaperR11 in
open ErdosProblems.Erdos1049.PaperR12 in
theorem solution (n : ℕ) :
    sourceOmega n ∣ sourceBWithoutMonomial n := by
  classical
  let f : ℤ →+* ℚ := Int.castRingHom ℚ
  apply (Polynomial.map_dvd_map f Int.cast_injective (sourceOmega_monic n)).mp
  have hOmega : (sourceOmega n).map f =
      ∏ ell ∈ Icc 1 (15 * n), (cyclotomic ell ℚ) ^ (sourceWeight n ell).toNat := by
    simp only [sourceOmega, Polynomial.map_prod, Polynomial.map_pow]
    apply prod_congr rfl
    intro ell hell
    dsimp only [f]
    rw [map_cyclotomic_int ell ℚ]
  rw [hOmega]
  apply pairwise_coprime_finset_product_dvd
  · intro i hi j hj hij
    rcases sourceWeight_zero_or_one n i with hwi | hwi
    · simpa [hwi] using
        (isCoprime_one_left : IsCoprime (1 : ℚ[X])
          ((cyclotomic j ℚ) ^ (sourceWeight n j).toNat))
    rcases sourceWeight_zero_or_one n j with hwj | hwj
    · simpa [hwj] using
        (isCoprime_one_right : IsCoprime
          ((cyclotomic i ℚ) ^ (sourceWeight n i).toNat) (1 : ℚ[X]))
    simpa [hwi, hwj] using (Polynomial.cyclotomic.isCoprime_rat hij)
  · intro ell hell
    rcases sourceWeight_zero_or_one n ell with hw | hw
    · simp [hw]
    simp only [hw, Int.toNat_one, pow_one]
    have h := actual_B_cyclotomic_dvd n ell (mem_Icc.mp hell).1 (mem_Icc.mp hell).2 hw
    obtain ⟨p, hp⟩ := h
    refine ⟨p.map f, ?_⟩
    rw [hp, Polynomial.map_mul, map_cyclotomic_int]
