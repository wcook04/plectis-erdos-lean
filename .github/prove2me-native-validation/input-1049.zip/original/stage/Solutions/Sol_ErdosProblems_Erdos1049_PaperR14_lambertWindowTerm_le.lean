import Definitions.Def_ErdosProblems_Erdos1049_QBinomialUnitIdentity
import Definitions.Def_ErdosProblems_Erdos1049_ZudilinHeightRegion
import Definitions.Def_ErdosProblems_Erdos1049_RationalBaseContour
import Definitions.Def_ErdosProblems_Erdos1049_ZudilinConeArithmetic
import Definitions.Def_ErdosProblems_Erdos1049_PaperLinearFormsR7
import Definitions.Def_ErdosProblems_Erdos1049_PaperOmegaIndicatorR7
import Definitions.Def_ErdosProblems_Erdos1049_QProductBoundsR10
import Definitions.Def_ErdosProblems_Erdos1049_SourcePolynomialR11
import Definitions.Def_ErdosProblems_Erdos1049_SourceBClearingR12
import Definitions.Def_ErdosProblems_Erdos1049_LambertSourceSummationR14
import Theorems.Thm_ErdosProblems_Erdos1049_PaperR10_qpow_antitone
import Lean.Elab.Tactic.Omega
import Mathlib
import Mathlib.Algebra.BigOperators.Group.Finset.Basic
import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Algebra.Module.BigOperators
import Mathlib.Algebra.Module.Prod
import Mathlib.Algebra.Order.Floor.Ring
import Mathlib.Algebra.Order.Ring.Abs
import Mathlib.Algebra.Polynomial.Coeff
import Mathlib.Algebra.Polynomial.Eval.Defs
import Mathlib.Analysis.PSeries
import Mathlib.Analysis.Real.Pi.Bounds
import Mathlib.Analysis.SpecialFunctions.Log.Basic
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.Data.Fintype.Pi
import Mathlib.Data.Fintype.Pigeonhole
import Mathlib.Data.Nat.Choose.Basic
import Mathlib.Data.Real.Basic
import Mathlib.Data.ZMod.Basic
import Mathlib.Data.ZMod.Coprime
import Mathlib.NumberTheory.Real.Irrational
import Mathlib.NumberTheory.ZetaValues
import Mathlib.RingTheory.Coprime.Basic
import Mathlib.RingTheory.Polynomial.Cyclotomic.Basic
import Mathlib.Tactic
import Mathlib.Tactic.Choose
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Push
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.InfiniteSum.Real
import Mathlib.Topology.Algebra.InfiniteSum.Ring
import Mathlib.Topology.MetricSpace.Pseudo.Defs

namespace PaperR10
end PaperR10

namespace PaperR11
end PaperR11

namespace PaperR12
end PaperR12

/-!
# Absolutely convergent Lambert-window summation for the literal source B

Proves A_n F - B_n equals the absolutely convergent pole series.

The finite correction terms are exactly those of `sourceBReal`, not a newly
chosen constant term. All geometric and Lambert sums below have a summability
proof before `tsum` is used. The terminal theorem identifies A*F-B with the
actual partial-fraction series. The separate residue/interpolation calculation
must still identify that series with the positive hypergeometric H.
-/

namespace ErdosProblems.Erdos1049.PaperR14
set_option maxHeartbeats 1000000
open Polynomial Finset
open PaperR10 PaperR11 PaperR12
open scoped BigOperators
end ErdosProblems.Erdos1049.PaperR14

set_option maxHeartbeats 1000000
open Polynomial Finset
open PaperR10 PaperR11 PaperR12
open scoped BigOperators
open ErdosProblems in
open ErdosProblems.Erdos1049 in
open ErdosProblems.Erdos1049.PaperR14 in
open ErdosProblems.Erdos1049.PaperR10 in
open ErdosProblems.Erdos1049.PaperR11 in
open ErdosProblems.Erdos1049.PaperR12 in
theorem solution {q : ℝ} (hq0 : 0 < q) (hq1 : q < 1)
    (a c t : ℕ) :
    lambertWindowTerm q a c t ≤ (1 - q)⁻¹ * q ^ (c + 1) * q ^ t := by
  have hbase : q ^ (c + 1 + t) ≤ q := by
    simpa using qpow_antitone hq0.le hq1.le (by omega : 1 ≤ c + 1 + t)
  have hexp : c + 1 + t ≤ (a + 1) * (c + 1 + t) := by nlinarith
  have hnum := qpow_antitone hq0.le hq1.le hexp
  have hden : 0 < 1 - q := sub_pos.mpr hq1
  have hden' : 1 - q ≤ 1 - q ^ (c + 1 + t) := by linarith
  unfold lambertWindowTerm
  calc
    _ ≤ q ^ (c + 1 + t) / (1 - q ^ (c + 1 + t)) :=
      div_le_div_of_nonneg_right hnum (hden.le.trans hden')
    _ ≤ q ^ (c + 1 + t) / (1 - q) :=
      div_le_div_of_nonneg_left (pow_nonneg hq0.le _) hden hden'
    _ = _ := by rw [pow_add]; ring
