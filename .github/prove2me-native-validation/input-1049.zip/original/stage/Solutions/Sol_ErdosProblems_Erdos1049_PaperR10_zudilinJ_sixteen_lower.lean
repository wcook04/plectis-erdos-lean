import Definitions.Def_ErdosProblems_Erdos1049_BezoutPluckerJets
import Definitions.Def_ErdosProblems_Erdos1049_ZudilinHeightRegion
import Definitions.Def_ErdosProblems_Erdos1049_RationalBaseContour
import Definitions.Def_ErdosProblems_Erdos1049_ZudilinConeArithmetic
import Definitions.Def_ErdosProblems_Erdos1049_PaperLinearFormsR7
import Definitions.Def_ErdosProblems_Erdos1049_PaperAsymptoticsR9
import Definitions.Def_ErdosProblems_Erdos1049_QuadraticMeasureR10
import Definitions.Def_ErdosProblems_Erdos1049_MeasureConstantsR10
import Theorems.Thm_ErdosProblems_Erdos1049_sum_le_trigammaSeries_sub
import Lean.Elab.Tactic.Omega
import Mathlib.Algebra.BigOperators.Group.Finset.Basic
import Mathlib.Algebra.Module.BigOperators
import Mathlib.Algebra.Module.Prod
import Mathlib.Algebra.Order.Ring.Abs
import Mathlib.Algebra.Polynomial.Eval.Defs
import Mathlib.Analysis.Asymptotics.Defs
import Mathlib.Analysis.PSeries
import Mathlib.Analysis.Real.Pi.Bounds
import Mathlib.Analysis.SpecialFunctions.Log.Basic
import Mathlib.Analysis.SpecialFunctions.Pow.Real
import Mathlib.Data.Fintype.Pi
import Mathlib.Data.Fintype.Pigeonhole
import Mathlib.Data.Real.Basic
import Mathlib.Data.ZMod.Basic
import Mathlib.Data.ZMod.Coprime
import Mathlib.NumberTheory.Real.Irrational
import Mathlib.NumberTheory.ZetaValues
import Mathlib.RingTheory.Coprime.Basic
import Mathlib.RingTheory.Polynomial.Cyclotomic.Basic
import Mathlib.Tactic
import Mathlib.Tactic.Choose
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Push
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.InfiniteSum.Real
import Mathlib.Topology.MetricSpace.Pseudo.Defs

/-!
# Exact constants for the power-uniform 31/4 bound

Finite rational sums bound the actual infinite trigamma
constant from below. These are unconditional parameter theorems, not an
assertion that the analytic source-form supplier has been formalised.
-/

namespace ErdosProblems.Erdos1049.PaperR10
set_option maxRecDepth 100000
set_option maxHeartbeats 4000000
end ErdosProblems.Erdos1049.PaperR10

set_option maxRecDepth 100000
set_option maxHeartbeats 4000000
open ErdosProblems in
open ErdosProblems.Erdos1049 in
open ErdosProblems.Erdos1049.PaperR10 in
theorem solution : (779418 : ℝ) / 10000 < zudilinJ := by
  have h1 := sum_le_trigammaSeries_sub
    (u := (1 / 14)) (v := (1 / 12)) (by norm_num) (by norm_num) 16
  have c1 : (5202337678 : ℝ) / 100000000 <
      ∑ k ∈ Finset.range 16,
        (1 / ((k : ℝ) + (1 / 14)) ^ 2 - 1 / ((k : ℝ) + (1 / 12)) ^ 2) := by
    norm_num [Finset.sum_range_succ]
  have b1 : (5202337678 : ℝ) / 100000000 < zudilinJTerm (1 / 14) (1 / 12) :=
    c1.trans_le h1
  have h2 := sum_le_trigammaSeries_sub
    (u := (1 / 7)) (v := (1 / 6)) (by norm_num) (by norm_num) 16
  have c2 : (1303886129 : ℝ) / 100000000 <
      ∑ k ∈ Finset.range 16,
        (1 / ((k : ℝ) + (1 / 7)) ^ 2 - 1 / ((k : ℝ) + (1 / 6)) ^ 2) := by
    norm_num [Finset.sum_range_succ]
  have b2 : (1303886129 : ℝ) / 100000000 < zudilinJTerm (1 / 7) (1 / 6) :=
    c2.trans_le h2
  have h3 := sum_le_trigammaSeries_sub
    (u := (3 / 14)) (v := (1 / 4)) (by norm_num) (by norm_num) 16
  have c3 : (582689310 : ℝ) / 100000000 <
      ∑ k ∈ Finset.range 16,
        (1 / ((k : ℝ) + (3 / 14)) ^ 2 - 1 / ((k : ℝ) + (1 / 4)) ^ 2) := by
    norm_num [Finset.sum_range_succ]
  have b3 : (582689310 : ℝ) / 100000000 < zudilinJTerm (3 / 14) (1 / 4) :=
    c3.trans_le h3
  have h4 := sum_le_trigammaSeries_sub
    (u := (2 / 7)) (v := (1 / 3)) (by norm_num) (by norm_num) 16
  have c4 : (330583528 : ℝ) / 100000000 <
      ∑ k ∈ Finset.range 16,
        (1 / ((k : ℝ) + (2 / 7)) ^ 2 - 1 / ((k : ℝ) + (1 / 3)) ^ 2) := by
    norm_num [Finset.sum_range_succ]
  have b4 : (330583528 : ℝ) / 100000000 < zudilinJTerm (2 / 7) (1 / 3) :=
    c4.trans_le h4
  have h5 := sum_le_trigammaSeries_sub
    (u := (5 / 14)) (v := (2 / 5)) (by norm_num) (by norm_num) 16
  have c5 : (163395902 : ℝ) / 100000000 <
      ∑ k ∈ Finset.range 16,
        (1 / ((k : ℝ) + (5 / 14)) ^ 2 - 1 / ((k : ℝ) + (2 / 5)) ^ 2) := by
    norm_num [Finset.sum_range_succ]
  have b5 : (163395902 : ℝ) / 100000000 < zudilinJTerm (5 / 14) (2 / 5) :=
    c5.trans_le h5
  have h6 := sum_le_trigammaSeries_sub
    (u := (3 / 7)) (v := (7 / 15)) (by norm_num) (by norm_num) 16
  have c6 : (88704481 : ℝ) / 100000000 <
      ∑ k ∈ Finset.range 16,
        (1 / ((k : ℝ) + (3 / 7)) ^ 2 - 1 / ((k : ℝ) + (7 / 15)) ^ 2) := by
    norm_num [Finset.sum_range_succ]
  have b6 : (88704481 : ℝ) / 100000000 < zudilinJTerm (3 / 7) (7 / 15) :=
    c6.trans_le h6
  have h7 := sum_le_trigammaSeries_sub
    (u := (1 / 2)) (v := (8 / 15)) (by norm_num) (by norm_num) 16
  have c7 : (51110980 : ℝ) / 100000000 <
      ∑ k ∈ Finset.range 16,
        (1 / ((k : ℝ) + (1 / 2)) ^ 2 - 1 / ((k : ℝ) + (8 / 15)) ^ 2) := by
    norm_num [Finset.sum_range_succ]
  have b7 : (51110980 : ℝ) / 100000000 < zudilinJTerm (1 / 2) (8 / 15) :=
    c7.trans_le h7
  have h8 := sum_le_trigammaSeries_sub
    (u := (4 / 7)) (v := (3 / 5)) (by norm_num) (by norm_num) 16
  have c8 : (30517746 : ℝ) / 100000000 <
      ∑ k ∈ Finset.range 16,
        (1 / ((k : ℝ) + (4 / 7)) ^ 2 - 1 / ((k : ℝ) + (3 / 5)) ^ 2) := by
    norm_num [Finset.sum_range_succ]
  have b8 : (30517746 : ℝ) / 100000000 < zudilinJTerm (4 / 7) (3 / 5) :=
    c8.trans_le h8
  have h9 := sum_le_trigammaSeries_sub
    (u := (9 / 14)) (v := (2 / 3)) (by norm_num) (by norm_num) 16
  have c9 : (18505297 : ℝ) / 100000000 <
      ∑ k ∈ Finset.range 16,
        (1 / ((k : ℝ) + (9 / 14)) ^ 2 - 1 / ((k : ℝ) + (2 / 3)) ^ 2) := by
    norm_num [Finset.sum_range_succ]
  have b9 : (18505297 : ℝ) / 100000000 < zudilinJTerm (9 / 14) (2 / 3) :=
    c9.trans_le h9
  have h10 := sum_le_trigammaSeries_sub
    (u := (5 / 7)) (v := (11 / 15)) (by norm_num) (by norm_num) 16
  have c10 : (11153720 : ℝ) / 100000000 <
      ∑ k ∈ Finset.range 16,
        (1 / ((k : ℝ) + (5 / 7)) ^ 2 - 1 / ((k : ℝ) + (11 / 15)) ^ 2) := by
    norm_num [Finset.sum_range_succ]
  have b10 : (11153720 : ℝ) / 100000000 < zudilinJTerm (5 / 7) (11 / 15) :=
    c10.trans_le h10
  have h11 := sum_le_trigammaSeries_sub
    (u := (11 / 14)) (v := (4 / 5)) (by norm_num) (by norm_num) 16
  have c11 : (6483917 : ℝ) / 100000000 <
      ∑ k ∈ Finset.range 16,
        (1 / ((k : ℝ) + (11 / 14)) ^ 2 - 1 / ((k : ℝ) + (4 / 5)) ^ 2) := by
    norm_num [Finset.sum_range_succ]
  have b11 : (6483917 : ℝ) / 100000000 < zudilinJTerm (11 / 14) (4 / 5) :=
    c11.trans_le h11
  have h12 := sum_le_trigammaSeries_sub
    (u := (6 / 7)) (v := (13 / 15)) (by norm_num) (by norm_num) 16
  have c12 : (3430313 : ℝ) / 100000000 <
      ∑ k ∈ Finset.range 16,
        (1 / ((k : ℝ) + (6 / 7)) ^ 2 - 1 / ((k : ℝ) + (13 / 15)) ^ 2) := by
    norm_num [Finset.sum_range_succ]
  have b12 : (3430313 : ℝ) / 100000000 < zudilinJTerm (6 / 7) (13 / 15) :=
    c12.trans_le h12
  have h13 := sum_le_trigammaSeries_sub
    (u := (13 / 14)) (v := (14 / 15)) (by norm_num) (by norm_num) 16
  have c13 : (1388390 : ℝ) / 100000000 <
      ∑ k ∈ Finset.range 16,
        (1 / ((k : ℝ) + (13 / 14)) ^ 2 - 1 / ((k : ℝ) + (14 / 15)) ^ 2) := by
    norm_num [Finset.sum_range_succ]
  have b13 : (1388390 : ℝ) / 100000000 < zudilinJTerm (13 / 14) (14 / 15) :=
    c13.trans_le h13
  unfold zudilinJ
  linarith only [b1, b2, b3, b4, b5, b6, b7, b8, b9, b10, b11, b12, b13]
