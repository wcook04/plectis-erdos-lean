import Definitions.Def_ErdosProblems_Erdos1049_ZudilinHeightRegion
import Definitions.Def_ErdosProblems_Erdos1049_RationalBaseContour
import Definitions.Def_ErdosProblems_Erdos1049_ZudilinConeArithmetic
import Definitions.Def_ErdosProblems_Erdos1049_PaperLinearFormsR7
import Definitions.Def_ErdosProblems_Erdos1049_PaperAsymptoticsR9
import Definitions.Def_ErdosProblems_Erdos1049_QuadraticMeasureR10
import Definitions.Def_ErdosProblems_Erdos1049_MeasureConstantsR10
import Theorems.Thm_ErdosProblems_Erdos1049_zudilinC1_pos
import Theorems.Thm_ErdosProblems_Erdos1049_PaperR10_zudilinJ_sixteen_lower
import Lean.Elab.Tactic.Omega
import Mathlib.Algebra.BigOperators.Group.Finset.Basic
import Mathlib.Algebra.Module.BigOperators
import Mathlib.Algebra.Module.Prod
import Mathlib.Algebra.Order.Ring.Abs
import Mathlib.Algebra.Polynomial.Eval.Defs
import Mathlib.Analysis.Asymptotics.Defs
import Mathlib.Analysis.PSeries
import Mathlib.Analysis.Real.Pi.Bounds
import Mathlib.Analysis.SpecialFunctions.Log.Basic
import Mathlib.Analysis.SpecialFunctions.Pow.Real
import Mathlib.Data.Fintype.Pi
import Mathlib.Data.Fintype.Pigeonhole
import Mathlib.Data.Real.Basic
import Mathlib.Data.ZMod.Basic
import Mathlib.Data.ZMod.Coprime
import Mathlib.NumberTheory.Real.Irrational
import Mathlib.NumberTheory.ZetaValues
import Mathlib.RingTheory.Coprime.Basic
import Mathlib.RingTheory.Polynomial.Cyclotomic.Basic
import Mathlib.Tactic
import Mathlib.Tactic.Choose
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Push
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.InfiniteSum.Real
import Mathlib.Topology.MetricSpace.Pseudo.Defs

/-!
# Exact constants for the power-uniform 31/4 bound

Finite rational sums bound the actual infinite trigamma
constant from below. These are unconditional parameter theorems, not an
assertion that the analytic source-form supplier has been formalised.
-/

namespace ErdosProblems.Erdos1049.PaperR10
set_option maxRecDepth 100000
set_option maxHeartbeats 4000000
end ErdosProblems.Erdos1049.PaperR10

set_option maxRecDepth 100000
set_option maxHeartbeats 4000000
open ErdosProblems in
open ErdosProblems.Erdos1049 in
open ErdosProblems.Erdos1049.PaperR10 in
theorem solution : (40568 : ℝ) / 100000 < zudilinContour := by
  have hJ := zudilinJ_sixteen_lower
  have hpi : (314159 : ℝ) / 100000 < Real.pi := by
    have h := Real.pi_gt_d6
    linarith
  have hpi2 : ((314159 : ℝ) / 100000) ^ 2 < Real.pi ^ 2 := by
    nlinarith [Real.pi_pos]
  have hc : 3 / Real.pi ^ 2 < 3 / ((314159 : ℝ) / 100000) ^ 2 :=
    div_lt_div_of_pos_left (by norm_num) (by norm_num) hpi2
  have hp : 3 / Real.pi ^ 2 * (225 - zudilinJ) <
      3 / ((314159 : ℝ) / 100000) ^ 2 * (225 - 779418 / 10000) := by
    calc
      _ ≤ 3 / Real.pi ^ 2 * (225 - 779418 / 10000) :=
        mul_le_mul_of_nonneg_left (by linarith) (by positivity)
      _ < _ := mul_lt_mul_of_pos_right hc (by norm_num)
  unfold zudilinContour
  apply (lt_div_iff₀ zudilinC1_pos).mpr
  unfold zudilinC0 zudilinC1
  norm_num at hp ⊢
  linarith
