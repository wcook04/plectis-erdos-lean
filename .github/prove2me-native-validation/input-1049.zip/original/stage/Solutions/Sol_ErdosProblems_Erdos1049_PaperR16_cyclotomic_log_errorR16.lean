import Definitions.Def_ErdosProblems_Erdos1049_QBinomialUnitIdentity
import Definitions.Def_ErdosProblems_Erdos1049_FiniteResidueInterpolationR14
import Definitions.Def_ErdosProblems_Erdos1049_ZudilinHeightRegion
import Definitions.Def_ErdosProblems_Erdos1049_RationalBaseContour
import Definitions.Def_ErdosProblems_Erdos1049_ZudilinConeArithmetic
import Definitions.Def_ErdosProblems_Erdos1049_PaperLinearFormsR7
import Definitions.Def_ErdosProblems_Erdos1049_PaperOmegaIndicatorR7
import Definitions.Def_ErdosProblems_Erdos1049_QProductBoundsR10
import Definitions.Def_ErdosProblems_Erdos1049_SourcePolynomialR11
import Definitions.Def_ErdosProblems_Erdos1049_SourceBClearingR12
import Definitions.Def_ErdosProblems_Erdos1049_LambertSourceSummationR14
import Definitions.Def_ErdosProblems_Erdos1049_ReciprocalPochhammerR14
import Definitions.Def_ErdosProblems_Erdos1049_ActualSourceResiduesR14
import Definitions.Def_ErdosProblems_Erdos1049_PaperAsymptoticsR9
import Definitions.Def_ErdosProblems_Erdos1049_SourcePositiveHBoundsR10
import Definitions.Def_ErdosProblems_Erdos1049_ActualSourceAnalyticIdentityR14
import Definitions.Def_ErdosProblems_Erdos1049_GaussianDegreeR12
import Definitions.Def_ErdosProblems_Erdos1049_PaperShortCapR9
import Definitions.Def_ErdosProblems_Erdos1049_SourceFiniteTransformR12
import Definitions.Def_ErdosProblems_Erdos1049_SourceHomogeneousR12
import Definitions.Def_ErdosProblems_Erdos1049_RootUnityLocalCancellationR13
import Definitions.Def_ErdosProblems_Erdos1049_SourceBMonomialR12
import Definitions.Def_ErdosProblems_Erdos1049_SourceBTopDegreeR13
import Definitions.Def_ErdosProblems_Erdos1049_SourceRootCarriesR13
import Definitions.Def_ErdosProblems_Erdos1049_SourceRootBlocksR13
import Definitions.Def_ErdosProblems_Erdos1049_SourceOmegaCancellationR13
import Definitions.Def_ErdosProblems_Erdos1049_G02ArithmeticR16
import Definitions.Def_ErdosProblems_Erdos1049_SourceHeightRateR14
import Definitions.Def_ErdosProblems_Erdos1049_WeightedFloorBlocksR12
import Definitions.Def_ErdosProblems_Erdos1049_G02WeightedBlocksR16
import Definitions.Def_ErdosProblems_Erdos1049_G02CyclotomicR16
import Theorems.Thm_ErdosProblems_Erdos1049_PaperR10_summable_nonneg_dominated
import Theorems.Thm_ErdosProblems_Erdos1049_PaperR16_mu_abs_le_oneR16
import Theorems.Thm_ErdosProblems_Erdos1049_PaperR16_antidiagonal_nonzeroR16
import Theorems.Thm_ErdosProblems_Erdos1049_PaperR10_hasSum_qPochhammer_log_majorant
import Theorems.Thm_ErdosProblems_Erdos1049_PaperR16_cyclotomic_log_residual_identityR16
import Theorems.Thm_ErdosProblems_Erdos1049_PaperR16_logTailTerm_boundsR16
import Lean.Elab.Tactic.Omega
import Mathlib
import Mathlib.Algebra.BigOperators.Group.Finset.Basic
import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Algebra.Module.BigOperators
import Mathlib.Algebra.Module.Prod
import Mathlib.Algebra.Order.Floor.Ring
import Mathlib.Algebra.Order.Ring.Abs
import Mathlib.Algebra.Order.Ring.Int
import Mathlib.Algebra.Polynomial.Coeff
import Mathlib.Algebra.Polynomial.Eval.Defs
import Mathlib.Algebra.Polynomial.Roots
import Mathlib.Analysis.Asymptotics.Defs
import Mathlib.Analysis.PSeries
import Mathlib.Analysis.Real.Pi.Bounds
import Mathlib.Analysis.SpecialFunctions.Log.Basic
import Mathlib.Analysis.SpecialFunctions.Pow.Asymptotics
import Mathlib.Analysis.SpecialFunctions.Pow.Real
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.Data.Fintype.Pi
import Mathlib.Data.Fintype.Pigeonhole
import Mathlib.Data.Nat.Choose.Basic
import Mathlib.Data.Real.Basic
import Mathlib.Data.ZMod.Basic
import Mathlib.Data.ZMod.Coprime
import Mathlib.NumberTheory.ArithmeticFunction.Moebius
import Mathlib.NumberTheory.Harmonic.Bounds
import Mathlib.NumberTheory.Real.Irrational
import Mathlib.NumberTheory.ZetaValues
import Mathlib.Order.LiminfLimsup
import Mathlib.RingTheory.Coprime.Basic
import Mathlib.RingTheory.Polynomial.Cyclotomic.Basic
import Mathlib.Tactic
import Mathlib.Tactic.Choose
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Push
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.InfiniteSum.Real
import Mathlib.Topology.Algebra.InfiniteSum.Ring
import Mathlib.Topology.MetricSpace.Pseudo.Defs

namespace PaperR10
end PaperR10

namespace PaperR11
end PaperR11

namespace PaperR12
end PaperR12

namespace PaperR14
end PaperR14

/-!
# G02 fixed-base cyclotomic logarithms

The factors are the literal integer cyclotomic polynomials, including Φ₁.
The all-index O_p(n) estimate uses a uniform summable-log majorant, rather
than an incorrect O(log l) estimate near the moving unit circle.
Proves the quadratic log rate of the source complement at each real p > 1.
-/

namespace ErdosProblems.Erdos1049.PaperR16
open Polynomial Finset Filter Asymptotics
open PaperR10 PaperR11 PaperR12 PaperR14
open scoped BigOperators Topology
set_option maxHeartbeats 3000000










lemma hasSum_logTail_majorantR16 (q : ℝ) (hq0 : 0 < q) (hq1 : q < 1) :
    HasSum (fun k : ℕ => q^(k+1)/(1-q)) (logTailMajorantR16 q) := by
  have h := hasSum_qPochhammer_log_majorant (a := q) hq0.le hq1
  convert h using 1 <;> simp only [logTailMajorantR16, pow_succ, pow_two] <;> ring

lemma logTailTerm_summableR16 (q : ℝ) (hq0 : 0 < q) (hq1 : q < 1) :
    Summable (logTailTermR16 q) :=
  summable_nonneg_dominated (fun k => (logTailTerm_boundsR16 q hq0 hq1 k).1)
    (fun k => (logTailTerm_boundsR16 q hq0 hq1 k).2)
    (hasSum_logTail_majorantR16 q hq0 hq1).summable

lemma logTailTerm_tsum_boundR16 (q : ℝ) (hq0 : 0 < q) (hq1 : q < 1) :
    (∑' k, logTailTermR16 q k) ≤ logTailMajorantR16 q := by
  have h := (logTailTerm_summableR16 q hq0 hq1).tsum_le_tsum
    (fun k => (logTailTerm_boundsR16 q hq0 hq1 k).2)
    (hasSum_logTail_majorantR16 q hq0 hq1).summable
  simpa only [(hasSum_logTail_majorantR16 q hq0 hq1).tsum_eq] using h





















lemma antidiagonal_logTail_sum_leR16 (q : ℝ) (hq0 : 0 < q) (hq1 : q < 1)
    (l : ℕ) :
    (∑ x ∈ l.divisorsAntidiagonal, logTailTermR16 q (x.2-1)) ≤
      logTailMajorantR16 q := by
  classical
  have hi : ∀ x ∈ l.divisorsAntidiagonal, ∀ y ∈ l.divisorsAntidiagonal,
      x.2-1=y.2-1 → x=y := by
    intro x hx y hy h
    have hx0 := (antidiagonal_nonzeroR16 hx).2
    have hy0 := (antidiagonal_nonzeroR16 hy).2
    have hd : x.2=y.2 := by omega
    have hxp := (Nat.mem_divisorsAntidiagonal.mp hx).1
    have hyp := (Nat.mem_divisorsAntidiagonal.mp hy).1
    have ha : x.1=y.1 := by
      rw [← hd] at hyp
      exact mul_right_cancel₀ hx0 (hxp.trans hyp.symm)
    exact Prod.ext ha hd
  have he : (∑ x ∈ l.divisorsAntidiagonal, logTailTermR16 q (x.2-1)) =
      ∑ k ∈ l.divisorsAntidiagonal.image (fun x => x.2-1), logTailTermR16 q k := by
    rw [Finset.sum_image]
    exact hi
  rw [he]
  exact ((logTailTerm_summableR16 q hq0 hq1).sum_le_tsum _
    (fun k _ => (logTailTerm_boundsR16 q hq0 hq1 k).1)).trans
      (logTailTerm_tsum_boundR16 q hq0 hq1)
end ErdosProblems.Erdos1049.PaperR16

open Polynomial Finset Filter Asymptotics
open PaperR10 PaperR11 PaperR12 PaperR14
open scoped BigOperators Topology
set_option maxHeartbeats 3000000
open ErdosProblems in
open ErdosProblems.Erdos1049 in
open ErdosProblems.Erdos1049.PaperR16 in
open ErdosProblems.Erdos1049.PaperR10 in
open ErdosProblems.Erdos1049.PaperR11 in
open ErdosProblems.Erdos1049.PaperR12 in
open ErdosProblems.Erdos1049.PaperR14 in
theorem solution (p : ℝ) (hp : 1 < p) (l : ℕ) (hl : 0 < l) :
    |Real.log (cyclotomicEvalR16 p l) - (l.totient : ℝ)*Real.log p| ≤
      logTailMajorantR16 p⁻¹ := by
  have hp0 := zero_lt_one.trans hp
  have hq0 := inv_pos.mpr hp0
  have hq1 := (inv_lt_one₀ hp0).2 hp
  rw [cyclotomic_log_residual_identityR16 p hp l hl]
  apply (Finset.abs_sum_le_sum_abs _ _).trans
  apply (sum_le_sum (g := fun x => logTailTermR16 p⁻¹ (x.2-1)) ?_).trans
    (antidiagonal_logTail_sum_leR16 p⁻¹ hq0 hq1 l)
  intro x hx
  have hd : 1 ≤ x.2 := by
    have := (antidiagonal_nonzeroR16 hx).2
    omega
  have hb := logTailTerm_boundsR16 p⁻¹ hq0 hq1 (x.2-1)
  have he : |Real.log (1-p⁻¹^x.2)| = logTailTermR16 p⁻¹ (x.2-1) := by
    dsimp [logTailTermR16] at hb ⊢
    rw [Nat.sub_add_cancel hd] at hb ⊢
    rw [abs_of_nonpos (by linarith [hb.1])]
  rw [abs_mul, he]
  exact (mul_le_mul_of_nonneg_right (mu_abs_le_oneR16 x.1) hb.1).trans_eq (one_mul _)
