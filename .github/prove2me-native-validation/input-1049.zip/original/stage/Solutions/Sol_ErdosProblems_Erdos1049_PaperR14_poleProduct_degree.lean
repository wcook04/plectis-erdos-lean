import Definitions.Def_ErdosProblems_Erdos1049_QBinomialUnitIdentity
import Definitions.Def_ErdosProblems_Erdos1049_FiniteResidueInterpolationR14
import Mathlib
import Mathlib.Algebra.BigOperators.Group.Finset.Basic
import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Algebra.Polynomial.Coeff
import Mathlib.Algebra.Polynomial.Eval.Defs
import Mathlib.Algebra.Polynomial.Roots
import Mathlib.Data.Nat.Choose.Basic
import Mathlib.Tactic

/-!
# Finite simple-pole interpolation, without a partial-fractions assumption

Interpolation in the pole basis and the finite simple-pole expansion.

The numerator is reconstructed from its values at the inverse pole parameters.
The only degree premise is the ordinary proper-fraction degree condition;
there is no premise asserting the partial-fraction identity. The following
source module supplies the concrete parameters and the numerator degree.
-/

namespace ErdosProblems.Erdos1049.PaperR14
set_option maxHeartbeats 1000000
open Polynomial Finset
open scoped BigOperators

variable {K : Type*} [Field K] {ι : Type*} [DecidableEq ι]
end ErdosProblems.Erdos1049.PaperR14

set_option maxHeartbeats 1000000
open Polynomial Finset
open scoped BigOperators
variable {K : Type*} [Field K] {ι : Type*} [DecidableEq ι]
open ErdosProblems in
open ErdosProblems.Erdos1049 in
open ErdosProblems.Erdos1049.PaperR14 in
theorem solution (b : ι → K) (s : Finset ι) :
    (poleProduct b s).natDegree ≤ s.card := by
  classical
  induction s using Finset.induction_on with
  | empty => simp [poleProduct]
  | @insert i s hi ih =>
      have he : poleProduct b (insert i s) =
          (1 - C (b i) * X) * poleProduct b s := by simp [poleProduct, hi]
      rw [he, card_insert_of_notMem hi]
      have hlin : (1 - C (b i) * X : K[X]).natDegree ≤ 1 := by
        apply (natDegree_sub_le _ _).trans
        apply max_le
        · simp
        · exact natDegree_mul_le.trans (by simp)
      exact natDegree_mul_le.trans (by omega)
