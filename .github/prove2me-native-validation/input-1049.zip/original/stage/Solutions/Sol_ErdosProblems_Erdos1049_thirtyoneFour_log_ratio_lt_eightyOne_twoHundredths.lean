import Definitions.Def_ErdosProblems_Erdos1049_ZudilinHeightRegion
import Mathlib.Algebra.BigOperators.Group.Finset.Basic
import Mathlib.Analysis.Real.Pi.Bounds
import Mathlib.Analysis.SpecialFunctions.Log.Basic
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Ring

/-!
# Erdős #1049: elementary height-region certificates

Define the height region by
`log b / log a < 81 / 200`.  Exact integer and logarithmic inequalities place
`31 / 4` and all its positive powers inside this region, place `31 / 4`
outside the Bundschuh--Väänänen region, and place `3 / 2` outside both.

These are elementary parameter inequalities.  No hypergeometric asymptotic or
irrationality theorem is imported as an axiom.  Membership becomes useful only
after a separate analytic theorem is applied, while failure of membership is
method inapplicability and proves neither rationality nor irrationality.
-/

namespace ErdosProblems.Erdos1049
/-- The exact integer comparison behind the `31 / 4` parameter certificate. -/
theorem thirtyoneFour_power_certificate : 4 ^ 200 < 31 ^ 81 := by
  norm_num
end ErdosProblems.Erdos1049

open ErdosProblems in
open ErdosProblems.Erdos1049 in
theorem solution :
    Real.log 4 / Real.log 31 < (81 : ℝ) / 200 := by
  have hpows : (4 : ℝ) ^ 200 < (31 : ℝ) ^ 81 := by
    exact_mod_cast thirtyoneFour_power_certificate
  have hlogs :
      Real.log ((4 : ℝ) ^ 200) < Real.log ((31 : ℝ) ^ 81) :=
    Real.strictMonoOn_log
      (Set.mem_Ioi.mpr (by positivity)) (Set.mem_Ioi.mpr (by positivity)) hpows
  rw [Real.log_pow, Real.log_pow] at hlogs
  norm_num at hlogs
  have hlog31 : 0 < Real.log (31 : ℝ) := Real.log_pos (by norm_num)
  apply (div_lt_iff₀ hlog31).2
  nlinarith
