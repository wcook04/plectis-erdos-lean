import Definitions.Def_ErdosProblems_Erdos1049_BezoutPluckerJets
import Definitions.Def_ErdosProblems_Erdos1049_ZudilinHeightRegion
import Definitions.Def_ErdosProblems_Erdos1049_RationalBaseContour
import Definitions.Def_ErdosProblems_Erdos1049_ZudilinConeArithmetic
import Definitions.Def_ErdosProblems_Erdos1049_PaperLinearFormsR7
import Theorems.Thm_ErdosProblems_Erdos1049_rational_integerLinearForm_gap
import Lean.Elab.Tactic.Omega
import Mathlib.Algebra.BigOperators.Group.Finset.Basic
import Mathlib.Algebra.Module.BigOperators
import Mathlib.Algebra.Module.Prod
import Mathlib.Algebra.Order.Ring.Abs
import Mathlib.Algebra.Polynomial.Eval.Defs
import Mathlib.Analysis.PSeries
import Mathlib.Analysis.Real.Pi.Bounds
import Mathlib.Analysis.SpecialFunctions.Log.Basic
import Mathlib.Data.Fintype.Pi
import Mathlib.Data.Fintype.Pigeonhole
import Mathlib.Data.Real.Basic
import Mathlib.Data.ZMod.Basic
import Mathlib.Data.ZMod.Coprime
import Mathlib.NumberTheory.Real.Irrational
import Mathlib.NumberTheory.ZetaValues
import Mathlib.RingTheory.Coprime.Basic
import Mathlib.RingTheory.Polynomial.Cyclotomic.Basic
import Mathlib.Tactic
import Mathlib.Tactic.Choose
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Push
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.InfiniteSum.Real
import Mathlib.Topology.MetricSpace.Pseudo.Defs

/-!
# R7: the integer-form irrationality consumer and its polynomial bridge

No axioms and no admitted proofs.

`CancelledApproximationSupply` is an OPEN analytic/source obligation. There is
no declaration asserting that it exists. In particular the conditional region
and power corollaries below are not advertised as proofs of the displayed
unconditional irrationality theorems. The coverage ledger retains that gap.
-/

namespace ErdosProblems.Erdos1049.PaperR7
open Filter
open scoped Topology BigOperators
end ErdosProblems.Erdos1049.PaperR7

open Filter
open scoped Topology BigOperators
open ErdosProblems in
open ErdosProblems.Erdos1049 in
open ErdosProblems.Erdos1049.PaperR7 in
theorem solution (ξ : ℝ)
    (hsmall : ∀ q : ℕ, 0 < q → ∃ A B : ℤ,
      (A : ℝ) * ξ - B ≠ 0 ∧ |(A : ℝ) * ξ - B| < 1 / (q : ℝ)) :
    Irrational ξ := by
  intro hrat
  obtain ⟨r, hr⟩ := hrat
  have hden : 0 < r.den := Nat.pos_of_ne_zero r.den_nz
  obtain ⟨A, B, hne, hlt⟩ := hsmall r.den hden
  have hξ : ξ = (r.num : ℝ) / (r.den : ℝ) := by
    rw [← hr]
    exact Rat.cast_def r
  rw [hξ] at hne hlt
  have hgap := rational_integerLinearForm_gap r.num (r.den : ℤ) B A
    (by exact_mod_cast hden) (by simpa using hne)
  have hgap' : (1 : ℝ) / (r.den : ℝ) ≤
      |(A : ℝ) * ((r.num : ℝ) / (r.den : ℝ)) - B| := by
    simpa using hgap
  exact (not_lt_of_ge hgap') hlt
