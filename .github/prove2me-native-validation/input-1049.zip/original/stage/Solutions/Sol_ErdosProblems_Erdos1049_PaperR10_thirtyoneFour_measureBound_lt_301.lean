import Definitions.Def_ErdosProblems_Erdos1049_BezoutPluckerJets
import Definitions.Def_ErdosProblems_Erdos1049_ZudilinHeightRegion
import Definitions.Def_ErdosProblems_Erdos1049_RationalBaseContour
import Definitions.Def_ErdosProblems_Erdos1049_ZudilinConeArithmetic
import Definitions.Def_ErdosProblems_Erdos1049_PaperLinearFormsR7
import Definitions.Def_ErdosProblems_Erdos1049_PaperAsymptoticsR9
import Definitions.Def_ErdosProblems_Erdos1049_QuadraticMeasureR10
import Definitions.Def_ErdosProblems_Erdos1049_MeasureConstantsR10
import Theorems.Thm_ErdosProblems_Erdos1049_PaperR10_zudilinContour_gt_40568
import Lean.Elab.Tactic.Omega
import Mathlib.Algebra.BigOperators.Group.Finset.Basic
import Mathlib.Algebra.Module.BigOperators
import Mathlib.Algebra.Module.Prod
import Mathlib.Algebra.Order.Ring.Abs
import Mathlib.Algebra.Polynomial.Eval.Defs
import Mathlib.Analysis.Asymptotics.Defs
import Mathlib.Analysis.PSeries
import Mathlib.Analysis.Real.Pi.Bounds
import Mathlib.Analysis.SpecialFunctions.Log.Basic
import Mathlib.Analysis.SpecialFunctions.Pow.Real
import Mathlib.Data.Fintype.Pi
import Mathlib.Data.Fintype.Pigeonhole
import Mathlib.Data.Real.Basic
import Mathlib.Data.ZMod.Basic
import Mathlib.Data.ZMod.Coprime
import Mathlib.NumberTheory.Real.Irrational
import Mathlib.NumberTheory.ZetaValues
import Mathlib.RingTheory.Coprime.Basic
import Mathlib.RingTheory.Polynomial.Cyclotomic.Basic
import Mathlib.Tactic
import Mathlib.Tactic.Choose
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Push
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.InfiniteSum.Real
import Mathlib.Topology.MetricSpace.Pseudo.Defs

/-!
# Exact constants for the power-uniform 31/4 bound

Finite rational sums bound the actual infinite trigamma
constant from below. These are unconditional parameter theorems, not an
assertion that the analytic source-form supplier has been formalised.
-/

namespace ErdosProblems.Erdos1049.PaperR10
set_option maxRecDepth 100000
set_option maxHeartbeats 4000000





/-- Exact integer certificate; no floating-point logarithm is used. -/
theorem thirtyoneFour_power_certificate_2217 :
    (4 : ℕ) ^ 2217 < 31 ^ 895 := by decide

theorem thirtyoneFour_ratio_lt_895_2217 :
    Real.log 4 / Real.log 31 < (895 : ℝ) / 2217 := by
  have hpows : (4 : ℝ) ^ 2217 < (31 : ℝ) ^ 895 := by
    exact_mod_cast thirtyoneFour_power_certificate_2217
  have hlogs := Real.strictMonoOn_log
    (Set.mem_Ioi.mpr (by positivity : (0 : ℝ) < 4 ^ 2217))
    (Set.mem_Ioi.mpr (by positivity : (0 : ℝ) < 31 ^ 895)) hpows
  rw [Real.log_pow, Real.log_pow] at hlogs
  norm_num at hlogs
  apply (div_lt_iff₀ (Real.log_pos (by norm_num : (1 : ℝ) < 31))).mpr
  nlinarith









/-- Algebraic comparison keeps strict inequalities at the rounded boundaries. -/
theorem quotient_lt_301 {t z : ℝ}
    (ht : t < (895 : ℝ) / 2217)
    (hz : (40568 : ℝ) / 100000 < z) :
    (1 - t) / (z - t) < 301 := by
  have hden : 0 < z - t := by linarith
  apply (div_lt_iff₀ hden).mpr
  linarith
end ErdosProblems.Erdos1049.PaperR10

set_option maxRecDepth 100000
set_option maxHeartbeats 4000000
open ErdosProblems in
open ErdosProblems.Erdos1049 in
open ErdosProblems.Erdos1049.PaperR10 in
theorem solution : rationalBaseMeasureBound 31 4 < 301 :=
  quotient_lt_301 thirtyoneFour_ratio_lt_895_2217 zudilinContour_gt_40568
