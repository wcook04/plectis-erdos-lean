import Definitions.Def_ErdosProblems_Erdos1049_QBinomialUnitIdentity
import Definitions.Def_ErdosProblems_Erdos1049_ZudilinConeArithmetic
import Definitions.Def_ErdosProblems_Erdos1049_PaperOmegaIndicatorR7
import Definitions.Def_ErdosProblems_Erdos1049_SourcePolynomialR11
import Definitions.Def_ErdosProblems_Erdos1049_SourceBClearingR12
import Definitions.Def_ErdosProblems_Erdos1049_GaussianDegreeR12
import Definitions.Def_ErdosProblems_Erdos1049_SourceFiniteTransformR12
import Definitions.Def_ErdosProblems_Erdos1049_SourceHomogeneousR12
import Definitions.Def_ErdosProblems_Erdos1049_RootUnityLocalCancellationR13
import Definitions.Def_ErdosProblems_Erdos1049_SourceBMonomialR12
import Definitions.Def_ErdosProblems_Erdos1049_SourceBTopDegreeR13
import Definitions.Def_ErdosProblems_Erdos1049_SourceRootCarriesR13
import Theorems.Thm_ErdosProblems_Erdos1049_PaperR13_floor_nat_ratio_int
import Mathlib
import Mathlib.Algebra.BigOperators.Group.Finset.Basic
import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Algebra.Order.Floor.Ring
import Mathlib.Algebra.Polynomial.Coeff
import Mathlib.Algebra.Polynomial.Eval.Defs
import Mathlib.Data.Fintype.Pigeonhole
import Mathlib.Data.Nat.Choose.Basic
import Mathlib.Data.Real.Basic
import Mathlib.Data.ZMod.Basic
import Mathlib.Data.ZMod.Coprime
import Mathlib.RingTheory.Polynomial.Cyclotomic.Basic
import Mathlib.Tactic

namespace PaperR11
end PaperR11

namespace PaperR12
end PaperR12

namespace ErdosProblems.Erdos1049.PaperR13
open Polynomial PaperR11 PaperR12
open scoped BigOperators
/-- No numerical comparison of floors is substituted for the literal weight. -/
theorem sourceWeight_eq_carries (n ell : ℕ) :
    sourceWeight n ell = max 0 (max (sourceCarryOne n ell) (sourceCarryTwo n ell)) := by
  have hf (c : ℕ) : ⌊(c : ℝ) * ((n : ℝ) / (ell : ℝ))⌋ =
      ((c * n / ell : ℕ) : ℤ) := by
    rw [← mul_div_assoc, ← Nat.cast_mul]
    exact floor_nat_ratio_int _ _
  unfold sourceWeight PaperR7.omegaWeight sourceCarryOne sourceCarryTwo
  rw [show (14 : ℝ) = ((14 : ℕ) : ℝ) by norm_num, hf 14,
    show (13 : ℝ) = ((13 : ℕ) : ℝ) by norm_num, hf 13,
    show (12 : ℝ) = ((12 : ℕ) : ℝ) by norm_num, hf 12,
    show (15 : ℝ) = ((15 : ℕ) : ℝ) by norm_num, hf 15]
end ErdosProblems.Erdos1049.PaperR13

open ErdosProblems
open ErdosProblems.Erdos1049
open ErdosProblems.Erdos1049.PaperR13
open Polynomial PaperR11 PaperR12
open scoped BigOperators
open ErdosProblems in
open ErdosProblems.Erdos1049 in
open ErdosProblems.Erdos1049.PaperR13 in
open ErdosProblems.Erdos1049.PaperR11 in
open ErdosProblems.Erdos1049.PaperR12 in
theorem solution (n ell : ℕ) (hw : sourceWeight n ell = 1) :
    sourceCarryOne n ell = 1 ∨
      (sourceCarryOne n ell ≤ 0 ∧ sourceCarryTwo n ell = 1) := by
  rw [sourceWeight_eq_carries] at hw
  simp only [max_def] at hw
  split_ifs at hw <;> omega
