import Definitions.Def_ErdosProblems_Erdos1049_BezoutPluckerJets
import Definitions.Def_ErdosProblems_Erdos1049_QBinomialUnitIdentity
import Definitions.Def_ErdosProblems_Erdos1049_FiniteResidueInterpolationR14
import Definitions.Def_ErdosProblems_Erdos1049_ZudilinHeightRegion
import Definitions.Def_ErdosProblems_Erdos1049_RationalBaseContour
import Definitions.Def_ErdosProblems_Erdos1049_ZudilinConeArithmetic
import Definitions.Def_ErdosProblems_Erdos1049_PaperLinearFormsR7
import Definitions.Def_ErdosProblems_Erdos1049_PaperOmegaIndicatorR7
import Definitions.Def_ErdosProblems_Erdos1049_QProductBoundsR10
import Definitions.Def_ErdosProblems_Erdos1049_SourcePolynomialR11
import Definitions.Def_ErdosProblems_Erdos1049_SourceBClearingR12
import Definitions.Def_ErdosProblems_Erdos1049_LambertSourceSummationR14
import Definitions.Def_ErdosProblems_Erdos1049_ReciprocalPochhammerR14
import Definitions.Def_ErdosProblems_Erdos1049_ActualSourceResiduesR14
import Definitions.Def_ErdosProblems_Erdos1049_PaperAsymptoticsR9
import Definitions.Def_ErdosProblems_Erdos1049_SourcePositiveHBoundsR10
import Definitions.Def_ErdosProblems_Erdos1049_ActualSourceAnalyticIdentityR14
import Theorems.Thm_ErdosProblems_Erdos1049_BezoutPluckerJets_bezoutPluckerEquiv_apply
import Theorems.Thm_ErdosProblems_Erdos1049_gaussBinom_zero_succ
import Theorems.Thm_ErdosProblems_Erdos1049_qPochhammer_zero
import Theorems.Thm_ErdosProblems_Erdos1049_PaperR12_positive_shift_power_lt_one
import Theorems.Thm_ErdosProblems_Erdos1049_PaperR14_finite_qPochhammer_product
import Theorems.Thm_ErdosProblems_Erdos1049_PaperR14_inverse_power_mul_power
import Theorems.Thm_ErdosProblems_Erdos1049_PaperR14_poleProduct_eval
import Theorems.Thm_ErdosProblems_Erdos1049_PaperR14_actual_source_partial_fractions
import Theorems.Thm_ErdosProblems_Erdos1049_PaperR14_qPochhammerFinite_eq
import Theorems.Thm_ErdosProblems_Erdos1049_PaperR14_sourcePoleSeriesTerm_summable
import Lean.Elab.Tactic.Omega
import Mathlib
import Mathlib.Algebra.BigOperators.Group.Finset.Basic
import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Algebra.Module.BigOperators
import Mathlib.Algebra.Module.Prod
import Mathlib.Algebra.Order.Floor.Ring
import Mathlib.Algebra.Order.Ring.Abs
import Mathlib.Algebra.Polynomial.Coeff
import Mathlib.Algebra.Polynomial.Eval.Defs
import Mathlib.Algebra.Polynomial.Roots
import Mathlib.Analysis.Asymptotics.Defs
import Mathlib.Analysis.PSeries
import Mathlib.Analysis.Real.Pi.Bounds
import Mathlib.Analysis.SpecialFunctions.Log.Basic
import Mathlib.Analysis.SpecialFunctions.Pow.Real
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.Data.Fintype.Pi
import Mathlib.Data.Fintype.Pigeonhole
import Mathlib.Data.Nat.Choose.Basic
import Mathlib.Data.Real.Basic
import Mathlib.Data.ZMod.Basic
import Mathlib.Data.ZMod.Coprime
import Mathlib.NumberTheory.Real.Irrational
import Mathlib.NumberTheory.ZetaValues
import Mathlib.RingTheory.Coprime.Basic
import Mathlib.RingTheory.Polynomial.Cyclotomic.Basic
import Mathlib.Tactic
import Mathlib.Tactic.Choose
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Push
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.InfiniteSum.Real
import Mathlib.Topology.Algebra.InfiniteSum.Ring
import Mathlib.Topology.MetricSpace.Pseudo.Defs

namespace PaperR10
end PaperR10

namespace PaperR11
end PaperR11

namespace PaperR12
end PaperR12

/-!
# The actual analytic identity A_n F - B_n = H_n

Proves A_n F - B_n = H_n for the literal source at every 0 < q < 1.

The proof uses the actual residues, proves that the first 12*n terms vanish,
and shifts the absolutely convergent series. The last Pochhammer has length
13*n+1, including n=0. No source identity or summability assertion is assumed.
-/

namespace ErdosProblems.Erdos1049.PaperR14
set_option maxHeartbeats 1000000
open Polynomial Finset
open PaperR10 PaperR11 PaperR12
open scoped BigOperators

lemma power_quotient_eq (q : ℝ) (hq : q ≠ 0) {a b : ℕ} (h : b ≤ a) :
    q ^ a / q ^ b = q ^ (a - b) := by
  rw [div_eq_mul_inv, ← inv_pow]
  simpa only [mul_comm] using inverse_power_mul_power q hq h

lemma source_shifted_pole (q : ℝ) (hq : q ≠ 0) (n s t : ℕ) :
    q ^ (14 * n + 1 + s) * (q ^ t / q ^ (12 * n)) =
      q ^ (2 * n + s + 1 + t) := by
  rw [← mul_div_assoc, ← pow_add, power_quotient_eq q hq (by omega)]
  congr 1
  omega

lemma source_shifted_residue_power (q : ℝ) (hq : q ≠ 0) (n s t : ℕ) :
    (q ^ ((14 * n + 1) * t) / q ^ ((14 * n + 1) * (12 * n))) *
      q ^ ((14 * n + 1) * (14 * n + 1 + s)) =
        q ^ ((14 * n + 1) * (2 * n + s + 1 + t)) := by
  rw [div_mul_eq_mul_div, ← pow_add]
  have hle : (14 * n + 1) * (12 * n) ≤
      (14 * n + 1) * t + (14 * n + 1) * (14 * n + 1 + s) := by nlinarith
  rw [power_quotient_eq q hq hle]
  congr 1
  have he : (14 * n + 1) * t + (14 * n + 1) * (14 * n + 1 + s) =
      (14 * n + 1) * (12 * n) + (14 * n + 1) * (2 * n + s + 1 + t) := by ring
  omega



lemma sourcePoleSeriesTerm_eq_extended {q : ℝ} (hq0 : 0 < q) (hq1 : q < 1)
    (n t : ℕ) : sourcePoleSeriesTerm q n t = sourceExtendedKernelTerm q n t := by
  have hz : ∀ s ∈ range (13 * n + 1),
      1 - q ^ (14 * n + 1 + s) * (q ^ t / q ^ (12 * n)) ≠ 0 := by
    intro s hs
    rw [source_shifted_pole q hq0.ne']
    exact (sub_pos.mpr
      (positive_shift_power_lt_one hq0 hq1 (2 * n + s + 1 + t) (by omega))).ne'
  unfold sourceExtendedKernelTerm
  rw [actual_source_partial_fractions hq0 hq1 n _ hz, mul_sum]
  unfold sourcePoleSeriesTerm
  apply sum_congr rfl
  intro s hs
  rw [source_shifted_pole q hq0.ne']
  unfold lambertWindowTerm
  have he := source_shifted_residue_power q hq0.ne' n s t
  calc
    _ = (sourceASummand n s).eval₂ (Int.castRingHom ℝ) q⁻¹ *
      (((q ^ ((14 * n + 1) * t) / q ^ ((14 * n + 1) * (12 * n))) *
        q ^ ((14 * n + 1) * (14 * n + 1 + s))) /
          (1 - q ^ (2 * n + s + 1 + t))) := by rw [he]
    _ = _ := by ring

lemma sourceExtendedKernelTerm_initial_zero (q : ℝ) (hq : q ≠ 0)
    (n t : ℕ) (ht : t < 12 * n) : sourceExtendedKernelTerm q n t = 0 := by
  have hi : 12 * n - t - 1 ∈ range (12 * n) := mem_range.mpr (by omega)
  have hf :
      1 - q ^ ((12 * n - t - 1) + 1) * (q ^ t / q ^ (12 * n)) = 0 := by
    have he : (12 * n - t - 1) + 1 + t = 12 * n := by omega
    rw [← mul_div_assoc, ← pow_add, he, div_self (pow_ne_zero _ hq), sub_self]
  have hprod :
      (poleProduct (fun i : ℕ => q ^ (i + 1)) (range (12 * n))).eval
        (q ^ t / q ^ (12 * n)) = 0 := by
    rw [poleProduct_eval]
    exact prod_eq_zero hi hf
  simp [sourceExtendedKernelTerm, sourceRationalKernel, sourceKernelNumerator, hprod]

lemma sourcePoleProduct_eval_power (q : ℝ) (a m t : ℕ) :
    (poleProduct (fun i : ℕ => q ^ (a + i)) (range m)).eval (q ^ t) =
      qPochhammer q (q ^ (a + t)) m := by
  rw [poleProduct_eval, finite_qPochhammer_product]
  apply prod_congr rfl
  intro i hi
  rw [← pow_add, ← pow_add]
  congr 2
  omega

lemma sourceExtendedKernelTerm_shift (q : ℝ) (hq : q ≠ 0) (n t : ℕ) :
    sourceExtendedKernelTerm q n (12 * n + t) = sourcePositiveHTerm q n t := by
  have hz : q ^ (12 * n + t) / q ^ (12 * n) = q ^ t := by
    rw [pow_add]
    field_simp [hq]
  have hw :
      q ^ ((14 * n + 1) * (12 * n + t)) /
        q ^ ((14 * n + 1) * (12 * n)) = q ^ ((14 * n + 1) * t) := by
    rw [Nat.mul_add, pow_add]
    field_simp [hq]
  unfold sourceExtendedKernelTerm
  rw [hz, hw]
  unfold sourceRationalKernel sourceKernelNumerator sourceKernelDenominator
  simp only [eval_mul, eval_C, sourcePoleParameter]
  have hnum :
      (poleProduct (fun i : ℕ => q ^ (i + 1)) (range (12 * n))).eval (q ^ t) =
        qPochhammer q (q ^ (t + 1)) (12 * n) := by
    simpa only [Nat.add_comm] using sourcePoleProduct_eval_power q 1 (12 * n) t
  rw [hnum]
  unfold sourcePoleParameter
  rw [sourcePoleProduct_eval_power]
  unfold sourcePositiveHTerm
  simp only [qPochhammerFinite_eq]
  ring
end ErdosProblems.Erdos1049.PaperR14

set_option maxHeartbeats 1000000
open Polynomial Finset
open PaperR10 PaperR11 PaperR12
open scoped BigOperators
open ErdosProblems in
open ErdosProblems.Erdos1049 in
open ErdosProblems.Erdos1049.PaperR14 in
open ErdosProblems.Erdos1049.PaperR10 in
open ErdosProblems.Erdos1049.PaperR11 in
open ErdosProblems.Erdos1049.PaperR12 in
theorem solution {q : ℝ} (hq0 : 0 < q) (hq1 : q < 1) (n : ℕ) :
    sourcePoleSeries q n = sourcePositiveH q n := by
  have hsum := (sourcePoleSeriesTerm_summable hq0 hq1 n).sum_add_tsum_nat_add (12 * n)
  have hzero : (∑ t ∈ range (12 * n), sourcePoleSeriesTerm q n t) = 0 := by
    apply sum_eq_zero
    intro t ht
    rw [sourcePoleSeriesTerm_eq_extended hq0 hq1]
    exact sourceExtendedKernelTerm_initial_zero q hq0.ne' n t (mem_range.mp ht)
  have htail : (∑' t : ℕ, sourcePoleSeriesTerm q n (t + 12 * n)) = sourcePositiveH q n := by
    unfold sourcePositiveH
    apply tsum_congr
    intro t
    rw [sourcePoleSeriesTerm_eq_extended hq0 hq1, Nat.add_comm t (12 * n),
      sourceExtendedKernelTerm_shift q hq0.ne']
  rw [hzero, htail, zero_add] at hsum
  exact hsum.symm
