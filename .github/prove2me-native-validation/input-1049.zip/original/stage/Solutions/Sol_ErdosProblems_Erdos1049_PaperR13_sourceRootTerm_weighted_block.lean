import Definitions.Def_ErdosProblems_Erdos1049_QBinomialUnitIdentity
import Definitions.Def_ErdosProblems_Erdos1049_ZudilinConeArithmetic
import Definitions.Def_ErdosProblems_Erdos1049_PaperOmegaIndicatorR7
import Definitions.Def_ErdosProblems_Erdos1049_SourcePolynomialR11
import Definitions.Def_ErdosProblems_Erdos1049_SourceBClearingR12
import Definitions.Def_ErdosProblems_Erdos1049_GaussianDegreeR12
import Definitions.Def_ErdosProblems_Erdos1049_SourceFiniteTransformR12
import Definitions.Def_ErdosProblems_Erdos1049_SourceHomogeneousR12
import Definitions.Def_ErdosProblems_Erdos1049_RootUnityLocalCancellationR13
import Definitions.Def_ErdosProblems_Erdos1049_SourceBMonomialR12
import Definitions.Def_ErdosProblems_Erdos1049_SourceBTopDegreeR13
import Definitions.Def_ErdosProblems_Erdos1049_SourceRootCarriesR13
import Definitions.Def_ErdosProblems_Erdos1049_SourceRootBlocksR13
import Theorems.Thm_ErdosProblems_Erdos1049_gaussBinom_eq_zero_of_lt
import Theorems.Thm_ErdosProblems_Erdos1049_gaussBinom_self
import Theorems.Thm_ErdosProblems_Erdos1049_gaussBinom_zero_succ
import Theorems.Thm_ErdosProblems_Erdos1049_qPochhammer_zero
import Theorems.Thm_ErdosProblems_Erdos1049_qBinomialTerm_zero
import Theorems.Thm_ErdosProblems_Erdos1049_qPochhammer_eq_sum
import Theorems.Thm_ErdosProblems_Erdos1049_PaperR13_gaussian_first_root_block_zero
import Theorems.Thm_ErdosProblems_Erdos1049_PaperR13_root_power_reduce
import Theorems.Thm_ErdosProblems_Erdos1049_PaperR13_gaussian_qLucas
import Theorems.Thm_ErdosProblems_Erdos1049_PaperR13_choose_two_add_r13
import Theorems.Thm_ErdosProblems_Erdos1049_PaperR13_root_block_digits_carry
import Theorems.Thm_ErdosProblems_Erdos1049_PaperR13_root_block_digits_no_carry
import Theorems.Thm_ErdosProblems_Erdos1049_PaperR13_source_second_carry_wrapped_zero_geometry
import Theorems.Thm_ErdosProblems_Erdos1049_PaperR13_source_surviving_harmonic_floor
import Theorems.Thm_ErdosProblems_Erdos1049_qPochhammer_one
import Mathlib
import Mathlib.Algebra.BigOperators.Group.Finset.Basic
import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Algebra.Order.Floor.Ring
import Mathlib.Algebra.Polynomial.Coeff
import Mathlib.Algebra.Polynomial.Eval.Defs
import Mathlib.Data.Fintype.Pigeonhole
import Mathlib.Data.Nat.Choose.Basic
import Mathlib.Data.Real.Basic
import Mathlib.Data.ZMod.Basic
import Mathlib.Data.ZMod.Coprime
import Mathlib.RingTheory.Polynomial.Cyclotomic.Basic
import Mathlib.Tactic

namespace PaperR11
end PaperR11

namespace PaperR12
end PaperR12

namespace ErdosProblems.Erdos1049.PaperR13
open Polynomial PaperR11 PaperR12 Finset
open scoped BigOperators
variable {K : Type*} [Field K]
lemma gaussianPhase_add (q : K) (a b : ℕ) :
    gaussianPhase q (a + b) = gaussianPhase q a * gaussianPhase q b * q ^ (a * b) := by
  simp only [gaussianPhase, choose_two_add_r13, pow_add]
  ring
lemma gaussianPhase_at_root_order (q : K) {ell : ℕ} (hell : 0 < ell)
    (hroot : q ^ ell = 1)
    (hprimitive : ∀ j : ℕ, 0 < j → j < ell → q ^ j ≠ 1) :
    gaussianPhase q ell = -1 := by
  have hsum : (∑ j ∈ range ell, qBinomialTerm q (1 : K) ell j) = 1 := by
    rw [sum_eq_single 0]
    · exact qBinomialTerm_zero _ _ _
    · intro j hj hj0
      simp only [qBinomialTerm,
        gaussian_first_root_block_zero q hroot hprimitive (by omega) (mem_range.mp hj),
        zero_mul]
    · intro hnot
      exact (hnot (mem_range.mpr hell)).elim
  have hz := qPochhammer_one q hell
  rw [qPochhammer_eq_sum, sum_range_succ, hsum] at hz
  have he : 1 + gaussianPhase q ell = 0 := by
    simpa [qBinomialTerm, gaussianPhase, gaussBinom_self] using hz
  calc
    gaussianPhase q ell = (1 + gaussianPhase q ell) - 1 := by ring
    _ = -1 := by rw [he]; ring
lemma gaussianPhase_root_block (q : K) {ell : ℕ} (hell : 0 < ell)
    (hroot : q ^ ell = 1)
    (hprimitive : ∀ j : ℕ, 0 < j → j < ell → q ^ j ≠ 1) (t h : ℕ) :
    gaussianPhase q (t * ell + h) = (-1 : K) ^ t * gaussianPhase q h := by
  induction t with
  | zero => simp [gaussianPhase]
  | succ t ih =>
      have he : (t + 1) * ell + h = (t * ell + h) + ell := by ring
      have hp : q ^ ((t * ell + h) * ell) = 1 := by
        rw [Nat.mul_comm, pow_mul, hroot, one_pow]
      rw [he, gaussianPhase_add, gaussianPhase_at_root_order q hell hroot hprimitive,
        hp, mul_one, ih, pow_succ]
      ring
lemma root_linear_phase_block (q : K) {ell : ℕ} (hroot : q ^ ell = 1)
    (n t h : ℕ) :
    q ^ ((n + 1) * (t * ell + h)) = q ^ ((n % ell + 1) * h) := by
  have hblock : q ^ (t * ell + h) = q ^ h := by
    rw [pow_add, Nat.mul_comm t ell, pow_mul, hroot, one_pow, one_mul]
  have hn : q ^ (n + 1) = q ^ (n % ell + 1) := by
    rw [pow_succ, root_power_reduce q hroot n, ← pow_succ]
  calc
    _ = (q ^ (t * ell + h)) ^ (n + 1) := by rw [← pow_mul, Nat.mul_comm]
    _ = (q ^ h) ^ (n + 1) := by rw [hblock]
    _ = (q ^ (n + 1)) ^ h := by rw [← pow_mul, ← pow_mul, Nat.mul_comm]
    _ = _ := by rw [hn, ← pow_mul]
end ErdosProblems.Erdos1049.PaperR13

open ErdosProblems
open ErdosProblems.Erdos1049
open ErdosProblems.Erdos1049.PaperR13
open Polynomial PaperR11 PaperR12 Finset
open scoped BigOperators
variable {K : Type*} [Field K]
open ErdosProblems in
open ErdosProblems.Erdos1049 in
open ErdosProblems.Erdos1049.PaperR13 in
open ErdosProblems.Erdos1049.PaperR11 in
open ErdosProblems.Erdos1049.PaperR12 in
theorem solution (q : K) (hq : q ≠ 0)
    (n ell t h : ℕ) (hell : 0 < ell) (hroot : q ^ ell = 1)
    (hprimitive : ∀ j : ℕ, 0 < j → j < ell → q ^ j ≠ 1)
    (hfirst : sourceCarryOne n ell ≤ 0) (hsecond : sourceCarryTwo n ell = 1)
    (hh : h < ell) (f : ℕ → K) :
    sourceRootTerm q n (t * ell + h) * f ((2 * n + (t * ell + h)) / ell) =
      ((-1 : K) ^ t * ((13 * n / ell).choose t : K) *
        ((14 * n / ell + t).choose (12 * n / ell) : K) *
          f (t + (14 * n / ell - 12 * n / ell))) *
        localGaussianTerm q ((14 * n) % ell) ((12 * n) % ell) (n % ell) ((13 * n) % ell) h := by
  have ha_lt := Nat.mod_lt (12 * n) hell
  have hv_lt := Nat.mod_lt (13 * n) hell
  have hw_lt := Nat.mod_lt (14 * n) hell
  have hs : (t * ell + h) / ell = t ∧ (t * ell + h) % ell = h := by
    simpa using root_block_digits_no_carry 0 t h ell hell (by simpa using hh)
  have hG2 := gaussian_qLucas q hq hell hroot hprimitive (13 * n) (t * ell + h)
  rw [hs.1, hs.2] at hG2
  by_cases hv : h ≤ (13 * n) % ell
  · by_cases hwrap : ell ≤ (14 * n) % ell + h
    · have hd := root_block_digits_carry (14 * n) t h ell hell hwrap (by omega)
      have hz := source_second_carry_wrapped_zero_geometry n ell h hell hfirst hsecond hv hwrap
      have hbig : gaussBinom q (14 * n + (t * ell + h)) (12 * n) = 0 := by
        rw [gaussian_qLucas q hq hell hroot hprimitive]
        have hre : (14 * n + (t * ell + h)) % ell = (14 * n) % ell + h - ell := by
          simpa only [Nat.add_assoc] using hd.2
        rw [hre, gaussBinom_eq_zero_of_lt q hz, mul_zero]
      have hsmall : gaussBinom q ((14 * n) % ell + h) ((12 * n) % ell) = 0 := by
        rw [gaussian_qLucas q hq hell hroot hprimitive]
        have hmod : ((14 * n) % ell + h) % ell = (14 * n) % ell + h - ell := by
          have hx := root_block_digits_carry ((14 * n) % ell) 0 h ell hell
            (by simpa using hwrap) (by simpa using (show (14 * n) % ell + h < 2 * ell by omega))
          simpa using hx.2
        rw [hmod, Nat.mod_eq_of_lt ha_lt, gaussBinom_eq_zero_of_lt q hz, mul_zero]
      simp only [sourceRootTerm, localGaussianTerm, hbig, hsmall, mul_zero, zero_mul]
    · have hnowrap : (14 * n) % ell + h < ell := by omega
      have hd := root_block_digits_no_carry (14 * n) t h ell hell hnowrap
      have hG1 : gaussBinom q (14 * n + (t * ell + h)) (12 * n) =
          ((14 * n / ell + t).choose (12 * n / ell) : K) *
            gaussBinom q ((14 * n) % ell + h) ((12 * n) % ell) := by
        rw [gaussian_qLucas q hq hell hroot hprimitive]
        have hd' :
            (14 * n + (t * ell + h)) / ell = 14 * n / ell + t ∧
              (14 * n + (t * ell + h)) % ell = 14 * n % ell + h := by
          simpa only [Nat.add_assoc] using hd
        rw [hd'.1, hd'.2]
      by_cases hlo : (12 * n) % ell ≤ (14 * n) % ell + h
      · have hfloor := source_surviving_harmonic_floor n ell h hell hlo hnowrap
        have hfshift := (root_block_digits_no_carry (2 * n + h) t 0 ell hell
          (by simpa using Nat.mod_lt (2 * n + h) hell)).1
        have hf : (2 * n + (t * ell + h)) / ell = t + (14 * n / ell - 12 * n / ell) := by
          have hre : 2 * n + h + t * ell + 0 = 2 * n + (t * ell + h) := by ring
          rw [hre, hfloor] at hfshift
          omega
        simp only [sourceRootTerm, hG1, hG2, hf]
        rw [gaussianPhase_root_block q hell hroot hprimitive,
          root_linear_phase_block q hroot]
        simp only [localGaussianTerm, gaussianPhase, pow_add]
        ring
      · have hz : gaussBinom q ((14 * n) % ell + h) ((12 * n) % ell) = 0 :=
          gaussBinom_eq_zero_of_lt q (by omega)
        simp only [sourceRootTerm, hG1, localGaussianTerm, hz, mul_zero, zero_mul]
  · have hz : gaussBinom q ((13 * n) % ell) h = 0 := gaussBinom_eq_zero_of_lt q (by omega)
    simp only [sourceRootTerm, hG2, localGaussianTerm, hz, mul_zero, zero_mul]
