import Definitions.Def_ErdosProblems_Erdos1049_PaperAsymptoticsR9
import Theorems.Thm_ErdosProblems_Erdos1049_PaperR9_tendsto_zero_of_exp_bound
import Lean.Elab.Tactic.Omega
import Mathlib.Algebra.BigOperators.Group.Finset.Basic
import Mathlib.Algebra.Module.BigOperators
import Mathlib.Algebra.Module.Prod
import Mathlib.Analysis.Asymptotics.Defs
import Mathlib.Analysis.SpecialFunctions.Log.Basic
import Mathlib.Analysis.SpecialFunctions.Pow.Real
import Mathlib.Data.Fintype.Pi
import Mathlib.Data.ZMod.Basic
import Mathlib.NumberTheory.Real.Irrational
import Mathlib.RingTheory.Coprime.Basic
import Mathlib.Tactic
import Mathlib.Tactic.Choose
import Mathlib.Tactic.Push
import Mathlib.Tactic.Ring
import Mathlib.Topology.MetricSpace.Pseudo.Defs

/-!
Quadratic asymptotic transfer, revision of the round-8 return.
Compiled. This file contains proof text, not a kernel receipt.

The asymptotic hypotheses below are estimates, not assumptions of the conclusions.
In particular `cross_product_limits` proves both successor products. The integer
contradiction is the desk's repaired PaperRankTwoCapR7 theorem, reused unchanged.

Pinned API: Mathlib 5e932f97dd25535344f80f9dd8da3aab83df0fe6.
Filter/metric API: Order/Filter/AtTopBot/Basic.lean and
Topology/MetricSpace/Pseudo/Defs.lean. Exponential/log API:
Analysis/SpecialFunctions/Exp.lean and Log/Basic.lean. Elementary ordered-field
algebra is handled by ring, linarith and explicitly supplied polynomial facts.
-/

namespace ErdosProblems.Erdos1049.PaperR9
open Filter Asymptotics
open scoped Topology
end ErdosProblems.Erdos1049.PaperR9

open Filter Asymptotics
open scoped Topology
open ErdosProblems in
open ErdosProblems.Erdos1049 in
open ErdosProblems.Erdos1049.PaperR9 in
theorem solution {f : ℕ → ℝ} {a : ℝ}
    (hf : QuadExpUpper f a) (ha : a < 0) : Tendsto f atTop (𝓝 0) := by
  have hc : 0 < -a / 2 := by linarith
  apply tendsto_zero_of_exp_bound f (-a / 2) hc
  filter_upwards [hf (-a / 2) hc] with n hn
  have he : a + -a / 2 = -(-a / 2) := by ring
  simpa only [he] using hn
