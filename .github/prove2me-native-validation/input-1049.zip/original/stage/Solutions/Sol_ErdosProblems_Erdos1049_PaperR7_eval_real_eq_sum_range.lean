import Definitions.Def_ErdosProblems_Erdos1049_ZudilinConeArithmetic
import Mathlib.Algebra.Polynomial.Eval.Defs
import Mathlib.Data.Fintype.Pigeonhole
import Mathlib.Data.ZMod.Basic
import Mathlib.Data.ZMod.Coprime
import Mathlib.RingTheory.Polynomial.Cyclotomic.Basic
import Mathlib.Tactic

namespace ErdosProblems.Erdos1049.PaperR7
end ErdosProblems.Erdos1049.PaperR7

/-!
# R7: integral homogeneous evaluation at a rational base

Compiled proof-source candidate. This is the finite algebraic bridge in the
main irrationality proof, not the existence or asymptotics of the cancelled
source forms. It reuses `homEval`; it does not define a different clearing.

All degrees below are natural degrees. This is harmless for a zero polynomial:
its natural degree is zero and every displayed evaluation identity still holds.
-/

namespace ErdosProblems.Erdos1049.PaperR7
open scoped BigOperators
end ErdosProblems.Erdos1049.PaperR7

open scoped BigOperators
open ErdosProblems in
open ErdosProblems.Erdos1049 in
open ErdosProblems.Erdos1049.PaperR7 in
theorem solution (P : Polynomial ℤ) (W : ℕ) (x : ℝ)
    (hdegree : P.natDegree ≤ W) :
    P.eval₂ (Int.castRingHom ℝ) x =
      ∑ i ∈ Finset.range (W + 1), (P.coeff i : ℝ) * x ^ i := by
  classical
  rw [Polynomial.eval₂_eq_sum]
  change (∑ i ∈ P.support, (P.coeff i : ℝ) * x ^ i) = _
  apply Finset.sum_subset
  · intro i hi
    apply Finset.mem_range.mpr
    have hi' : i ≤ P.natDegree :=
      Polynomial.le_natDegree_of_ne_zero (Polynomial.mem_support_iff.mp hi)
    omega
  · intro i _ hi
    have hzero : P.coeff i = 0 := by
      by_contra hn
      exact hi (Polynomial.mem_support_iff.mpr hn)
    simp [hzero]
