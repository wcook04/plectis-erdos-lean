import Definitions.Def_ErdosProblems_Erdos1049_BezoutPluckerJets
import Definitions.Def_ErdosProblems_Erdos1049_ZudilinHeightRegion
import Definitions.Def_ErdosProblems_Erdos1049_RationalBaseContour
import Definitions.Def_ErdosProblems_Erdos1049_ZudilinConeArithmetic
import Definitions.Def_ErdosProblems_Erdos1049_PaperLinearFormsR7
import Theorems.Thm_ErdosProblems_Erdos1049_PaperR7_cleared_linear_form_identity
import Theorems.Thm_ErdosProblems_Erdos1049_PaperR7_irrational_of_integer_forms_below_every_denominator
import Lean.Elab.Tactic.Omega
import Mathlib.Algebra.BigOperators.Group.Finset.Basic
import Mathlib.Algebra.Module.BigOperators
import Mathlib.Algebra.Module.Prod
import Mathlib.Algebra.Order.Ring.Abs
import Mathlib.Algebra.Polynomial.Eval.Defs
import Mathlib.Analysis.PSeries
import Mathlib.Analysis.Real.Pi.Bounds
import Mathlib.Analysis.SpecialFunctions.Log.Basic
import Mathlib.Data.Fintype.Pi
import Mathlib.Data.Fintype.Pigeonhole
import Mathlib.Data.Real.Basic
import Mathlib.Data.ZMod.Basic
import Mathlib.Data.ZMod.Coprime
import Mathlib.NumberTheory.Real.Irrational
import Mathlib.NumberTheory.ZetaValues
import Mathlib.RingTheory.Coprime.Basic
import Mathlib.RingTheory.Polynomial.Cyclotomic.Basic
import Mathlib.Tactic
import Mathlib.Tactic.Choose
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Push
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.InfiniteSum.Real
import Mathlib.Topology.MetricSpace.Pseudo.Defs

/-!
# R7: the integer-form irrationality consumer and its polynomial bridge

No axioms and no admitted proofs.

`CancelledApproximationSupply` is an OPEN analytic/source obligation. There is
no declaration asserting that it exists. In particular the conditional region
and power corollaries below are not advertised as proofs of the displayed
unconditional irrationality theorems. The coverage ledger retains that gap.
-/

namespace ErdosProblems.Erdos1049.PaperR7
open Filter
open scoped Topology BigOperators





/-- The same criterion from an actual convergent sequence of integral forms.
Eventual nonvanishing suffices; the earlier finite prefix is irrelevant. -/
theorem irrational_of_integer_forms_tendsto_zero (ξ : ℝ)
    (A B : ℕ → ℤ)
    (hne : ∀ᶠ n in atTop, (A n : ℝ) * ξ - B n ≠ 0)
    (hlim : Tendsto (fun n => (A n : ℝ) * ξ - B n) atTop (𝓝 0)) :
    Irrational ξ := by
  apply irrational_of_integer_forms_below_every_denominator ξ
  intro q hq
  have hqR : (0 : ℝ) < (q : ℝ) := by exact_mod_cast hq
  obtain ⟨N, hN⟩ := Metric.tendsto_atTop.1 hlim (1 / (q : ℝ)) (one_div_pos.mpr hqR)
  obtain ⟨M, hM⟩ := eventually_atTop.1 hne
  let n := max N M
  refine ⟨A n, B n, hM n (le_max_right _ _), ?_⟩
  simpa only [Real.dist_eq, sub_zero] using hN n (le_max_left _ _)
end ErdosProblems.Erdos1049.PaperR7

open Filter
open scoped Topology BigOperators
open ErdosProblems in
open ErdosProblems.Erdos1049 in
open ErdosProblems.Erdos1049.PaperR7 in
theorem solution
    (a b : ℕ) (hb : 0 < b) (ξ : ℝ)
    (U V : ℕ → Polynomial ℤ) (W : ℕ → ℕ)
    (hU : ∀ n, (U n).natDegree ≤ W n)
    (hV : ∀ n, (V n).natDegree ≤ W n)
    (hne : ∀ᶠ n in atTop,
      (U n).eval₂ (Int.castRingHom ℝ) ((a : ℝ) / b) * ξ -
        (V n).eval₂ (Int.castRingHom ℝ) ((a : ℝ) / b) ≠ 0)
    (hlim : Tendsto (fun n => (b : ℝ) ^ (W n) *
      ((U n).eval₂ (Int.castRingHom ℝ) ((a : ℝ) / b) * ξ -
        (V n).eval₂ (Int.castRingHom ℝ) ((a : ℝ) / b))) atTop (𝓝 0)) :
    Irrational ξ := by
  let A : ℕ → ℤ := fun n => homEval a b (W n) (U n)
  let B : ℕ → ℤ := fun n => homEval a b (W n) (V n)
  have hid : ∀ n, (A n : ℝ) * ξ - B n = (b : ℝ) ^ (W n) *
      ((U n).eval₂ (Int.castRingHom ℝ) ((a : ℝ) / b) * ξ -
        (V n).eval₂ (Int.castRingHom ℝ) ((a : ℝ) / b)) := by
    intro n
    exact cleared_linear_form_identity a b (W n) (U n) (V n) ξ hb.ne' (hU n) (hV n)
  apply irrational_of_integer_forms_tendsto_zero ξ A B
  · filter_upwards [hne] with n hn
    rw [hid n]
    exact mul_ne_zero (pow_ne_zero _ (by exact_mod_cast hb.ne')) hn
  · simpa only [hid] using hlim
