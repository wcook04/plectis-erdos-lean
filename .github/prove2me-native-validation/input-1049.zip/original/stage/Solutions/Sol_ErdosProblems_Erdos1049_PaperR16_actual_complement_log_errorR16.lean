import Definitions.Def_ErdosProblems_Erdos1049_BezoutPluckerJets
import Definitions.Def_ErdosProblems_Erdos1049_QBinomialUnitIdentity
import Definitions.Def_ErdosProblems_Erdos1049_FiniteResidueInterpolationR14
import Definitions.Def_ErdosProblems_Erdos1049_ZudilinHeightRegion
import Definitions.Def_ErdosProblems_Erdos1049_RationalBaseContour
import Definitions.Def_ErdosProblems_Erdos1049_ZudilinConeArithmetic
import Definitions.Def_ErdosProblems_Erdos1049_PaperLinearFormsR7
import Definitions.Def_ErdosProblems_Erdos1049_PaperOmegaIndicatorR7
import Definitions.Def_ErdosProblems_Erdos1049_QProductBoundsR10
import Definitions.Def_ErdosProblems_Erdos1049_SourcePolynomialR11
import Definitions.Def_ErdosProblems_Erdos1049_SourceBClearingR12
import Definitions.Def_ErdosProblems_Erdos1049_LambertSourceSummationR14
import Definitions.Def_ErdosProblems_Erdos1049_ReciprocalPochhammerR14
import Definitions.Def_ErdosProblems_Erdos1049_ActualSourceResiduesR14
import Definitions.Def_ErdosProblems_Erdos1049_PaperAsymptoticsR9
import Definitions.Def_ErdosProblems_Erdos1049_SourcePositiveHBoundsR10
import Definitions.Def_ErdosProblems_Erdos1049_ActualSourceAnalyticIdentityR14
import Definitions.Def_ErdosProblems_Erdos1049_GaussianDegreeR12
import Definitions.Def_ErdosProblems_Erdos1049_PaperShortCapR9
import Definitions.Def_ErdosProblems_Erdos1049_SourceFiniteTransformR12
import Definitions.Def_ErdosProblems_Erdos1049_SourceHomogeneousR12
import Definitions.Def_ErdosProblems_Erdos1049_RootUnityLocalCancellationR13
import Definitions.Def_ErdosProblems_Erdos1049_SourceBMonomialR12
import Definitions.Def_ErdosProblems_Erdos1049_SourceBTopDegreeR13
import Definitions.Def_ErdosProblems_Erdos1049_SourceRootCarriesR13
import Definitions.Def_ErdosProblems_Erdos1049_SourceRootBlocksR13
import Definitions.Def_ErdosProblems_Erdos1049_SourceOmegaCancellationR13
import Definitions.Def_ErdosProblems_Erdos1049_G02ArithmeticR16
import Definitions.Def_ErdosProblems_Erdos1049_SourceHeightRateR14
import Definitions.Def_ErdosProblems_Erdos1049_WeightedFloorBlocksR12
import Definitions.Def_ErdosProblems_Erdos1049_G02WeightedBlocksR16
import Definitions.Def_ErdosProblems_Erdos1049_G02CyclotomicR16
import Theorems.Thm_ErdosProblems_Erdos1049_BezoutPluckerJets_bezoutPluckerEquiv_apply
import Theorems.Thm_ErdosProblems_Erdos1049_gaussBinom_zero_succ
import Theorems.Thm_ErdosProblems_Erdos1049_qPochhammer_zero
import Theorems.Thm_ErdosProblems_Erdos1049_PaperR12_sourceComplement_monic_degree
import Theorems.Thm_ErdosProblems_Erdos1049_PaperR16_cyclotomic_real_posR16
import Theorems.Thm_ErdosProblems_Erdos1049_PaperR16_cyclotomic_log_errorR16
import Lean.Elab.Tactic.Omega
import Mathlib
import Mathlib.Algebra.BigOperators.Group.Finset.Basic
import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Algebra.Module.BigOperators
import Mathlib.Algebra.Module.Prod
import Mathlib.Algebra.Order.Floor.Ring
import Mathlib.Algebra.Order.Ring.Abs
import Mathlib.Algebra.Order.Ring.Int
import Mathlib.Algebra.Polynomial.Coeff
import Mathlib.Algebra.Polynomial.Eval.Defs
import Mathlib.Algebra.Polynomial.Roots
import Mathlib.Analysis.Asymptotics.Defs
import Mathlib.Analysis.PSeries
import Mathlib.Analysis.Real.Pi.Bounds
import Mathlib.Analysis.SpecialFunctions.Log.Basic
import Mathlib.Analysis.SpecialFunctions.Pow.Asymptotics
import Mathlib.Analysis.SpecialFunctions.Pow.Real
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.Data.Fintype.Pi
import Mathlib.Data.Fintype.Pigeonhole
import Mathlib.Data.Nat.Choose.Basic
import Mathlib.Data.Real.Basic
import Mathlib.Data.ZMod.Basic
import Mathlib.Data.ZMod.Coprime
import Mathlib.NumberTheory.ArithmeticFunction.Moebius
import Mathlib.NumberTheory.Harmonic.Bounds
import Mathlib.NumberTheory.Real.Irrational
import Mathlib.NumberTheory.ZetaValues
import Mathlib.Order.LiminfLimsup
import Mathlib.RingTheory.Coprime.Basic
import Mathlib.RingTheory.Polynomial.Cyclotomic.Basic
import Mathlib.Tactic
import Mathlib.Tactic.Choose
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Push
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.InfiniteSum.Real
import Mathlib.Topology.Algebra.InfiniteSum.Ring
import Mathlib.Topology.MetricSpace.Pseudo.Defs

namespace PaperR10
end PaperR10

namespace PaperR11
end PaperR11

namespace PaperR12
end PaperR12

namespace PaperR14
end PaperR14

/-!
# G02 fixed-base cyclotomic logarithms

The factors are the literal integer cyclotomic polynomials, including Φ₁.
The all-index O_p(n) estimate uses a uniform summable-log majorant, rather
than an incorrect O(log l) estimate near the moving unit circle.
Proves the quadratic log rate of the source complement at each real p > 1.
-/

namespace ErdosProblems.Erdos1049.PaperR16
open Polynomial Finset Filter Asymptotics
open PaperR10 PaperR11 PaperR12 PaperR14
open scoped BigOperators Topology
set_option maxHeartbeats 3000000








































lemma actual_complement_eval_productR16 (p : ℝ) (n : ℕ) :
    complementEvalR16 p n = ∏ l ∈ Icc 1 (15*n),
      if sourceWeight n l=0 then cyclotomicEvalR16 p l else 1 := by
  classical
  change (eval₂RingHom (Int.castRingHom ℝ) p) (sourceComplement n) = _
  simp only [sourceComplement, map_prod]
  apply prod_congr rfl
  intro l hl
  split_ifs <;> simp [cyclotomicEvalR16]



lemma actual_complement_log_productR16 (p : ℝ) (hp : 1 < p) (n : ℕ) :
    Real.log (complementEvalR16 p n) = ∑ l ∈ Icc 1 (15*n),
      if sourceWeight n l=0 then Real.log (cyclotomicEvalR16 p l) else 0 := by
  rw [actual_complement_eval_productR16,
    Real.log_prod (by
      intro l hl
      split_ifs
      · exact (cyclotomic_real_posR16 p hp l (by have := (mem_Icc.mp hl).1; omega)).ne'
      · norm_num)]
  apply sum_congr rfl
  intro l hl
  split_ifs <;> simp
end ErdosProblems.Erdos1049.PaperR16

open Polynomial Finset Filter Asymptotics
open PaperR10 PaperR11 PaperR12 PaperR14
open scoped BigOperators Topology
set_option maxHeartbeats 3000000
open ErdosProblems in
open ErdosProblems.Erdos1049 in
open ErdosProblems.Erdos1049.PaperR16 in
open ErdosProblems.Erdos1049.PaperR10 in
open ErdosProblems.Erdos1049.PaperR11 in
open ErdosProblems.Erdos1049.PaperR12 in
open ErdosProblems.Erdos1049.PaperR14 in
theorem solution (p : ℝ) (hp : 1 < p) (n : ℕ) :
    |Real.log (complementEvalR16 p n)-complementDegreeR16 n*Real.log p| ≤
      15*(n : ℝ)*logTailMajorantR16 p⁻¹ := by
  classical
  have hp0 := zero_lt_one.trans hp
  have hq0 : 0 < p⁻¹ := inv_pos.mpr hp0
  have hq1 : p⁻¹ < 1 := (inv_lt_one₀ hp0).2 hp
  have hA : 0 ≤ logTailMajorantR16 p⁻¹ := by unfold logTailMajorantR16; positivity
  have hd : complementDegreeR16 n =
      ∑ l ∈ Icc 1 (15*n), if sourceWeight n l=0 then (l.totient : ℝ) else 0 := by
    unfold complementDegreeR16
    rw [(sourceComplement_monic_degree n).2]
    push_cast
    try rfl
  rw [actual_complement_log_productR16 p hp n, hd, Finset.sum_mul, ← sum_sub_distrib]
  calc
    _ ≤ ∑ l ∈ Icc 1 (15*n),
        |(if sourceWeight n l=0 then Real.log (cyclotomicEvalR16 p l) else 0) -
          (if sourceWeight n l=0 then (l.totient : ℝ) else 0)*Real.log p| :=
      Finset.abs_sum_le_sum_abs _ _
    _ ≤ ∑ _l ∈ Icc 1 (15*n), logTailMajorantR16 p⁻¹ := by
      apply sum_le_sum
      intro l hl
      split_ifs
      · exact cyclotomic_log_errorR16 p hp l (by have := (mem_Icc.mp hl).1; omega)
      · simpa using hA
    _ = _ := by simp [Nat.card_Icc] <;> ring
