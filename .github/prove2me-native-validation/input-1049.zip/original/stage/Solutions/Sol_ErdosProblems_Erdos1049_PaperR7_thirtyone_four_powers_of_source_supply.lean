import Definitions.Def_ErdosProblems_Erdos1049_BezoutPluckerJets
import Definitions.Def_ErdosProblems_Erdos1049_ZudilinHeightRegion
import Definitions.Def_ErdosProblems_Erdos1049_RationalBaseContour
import Definitions.Def_ErdosProblems_Erdos1049_ZudilinConeArithmetic
import Definitions.Def_ErdosProblems_Erdos1049_PaperLinearFormsR7
import Theorems.Thm_ErdosProblems_Erdos1049_PaperR7_rational_base_region_of_source_supply
import Theorems.Thm_ErdosProblems_Erdos1049_thirtyoneFour_power_mem_zudilinContourRegion
import Lean.Elab.Tactic.Omega
import Mathlib.Algebra.BigOperators.Group.Finset.Basic
import Mathlib.Algebra.Module.BigOperators
import Mathlib.Algebra.Module.Prod
import Mathlib.Algebra.Order.Ring.Abs
import Mathlib.Algebra.Polynomial.Eval.Defs
import Mathlib.Analysis.PSeries
import Mathlib.Analysis.Real.Pi.Bounds
import Mathlib.Analysis.SpecialFunctions.Log.Basic
import Mathlib.Data.Fintype.Pi
import Mathlib.Data.Fintype.Pigeonhole
import Mathlib.Data.Real.Basic
import Mathlib.Data.ZMod.Basic
import Mathlib.Data.ZMod.Coprime
import Mathlib.NumberTheory.Real.Irrational
import Mathlib.NumberTheory.ZetaValues
import Mathlib.RingTheory.Coprime.Basic
import Mathlib.RingTheory.Polynomial.Cyclotomic.Basic
import Mathlib.Tactic
import Mathlib.Tactic.Choose
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Push
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.InfiniteSum.Real
import Mathlib.Topology.MetricSpace.Pseudo.Defs

/-!
# R7: the integer-form irrationality consumer and its polynomial bridge

No axioms and no admitted proofs.

`CancelledApproximationSupply` is an OPEN analytic/source obligation. There is
no declaration asserting that it exists. In particular the conditional region
and power corollaries below are not advertised as proofs of the displayed
unconditional irrationality theorems. The coverage ledger retains that gap.
-/

namespace ErdosProblems.Erdos1049.PaperR7
open Filter
open scoped Topology BigOperators
end ErdosProblems.Erdos1049.PaperR7

open Filter
open scoped Topology BigOperators
open ErdosProblems in
open ErdosProblems.Erdos1049 in
open ErdosProblems.Erdos1049.PaperR7 in
theorem solution
    (hsource : ContourSourceSupply) (r : ℕ) (hr : 0 < r) :
    Irrational (paperLambert (((31 : ℝ) / 4) ^ r)) := by
  have hb : 0 < (4 : ℕ) ^ r := Nat.pow_pos (by norm_num)
  have hab : (4 : ℕ) ^ r < 31 ^ r :=
    Nat.pow_lt_pow_left (by norm_num) hr.ne'
  have hc : ((31 : ℕ) ^ r).Coprime (4 ^ r) :=
    (show Nat.Coprime 31 4 by norm_num).pow r r
  have ht := rational_base_region_of_source_supply hsource (31 ^ r) (4 ^ r)
    hb hab hc (thirtyoneFour_power_mem_zudilinContourRegion r hr)
  simpa only [Nat.cast_pow, Nat.cast_ofNat, div_pow] using ht
