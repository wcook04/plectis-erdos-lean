import Definitions.Def_ErdosProblems_Erdos1049_BezoutPluckerJets
import Definitions.Def_ErdosProblems_Erdos1049_QBinomialUnitIdentity
import Definitions.Def_ErdosProblems_Erdos1049_FiniteResidueInterpolationR14
import Definitions.Def_ErdosProblems_Erdos1049_ZudilinHeightRegion
import Definitions.Def_ErdosProblems_Erdos1049_RationalBaseContour
import Definitions.Def_ErdosProblems_Erdos1049_ZudilinConeArithmetic
import Definitions.Def_ErdosProblems_Erdos1049_PaperLinearFormsR7
import Definitions.Def_ErdosProblems_Erdos1049_PaperOmegaIndicatorR7
import Definitions.Def_ErdosProblems_Erdos1049_QProductBoundsR10
import Definitions.Def_ErdosProblems_Erdos1049_SourcePolynomialR11
import Definitions.Def_ErdosProblems_Erdos1049_SourceBClearingR12
import Definitions.Def_ErdosProblems_Erdos1049_LambertSourceSummationR14
import Definitions.Def_ErdosProblems_Erdos1049_ReciprocalPochhammerR14
import Definitions.Def_ErdosProblems_Erdos1049_ActualSourceResiduesR14
import Theorems.Thm_ErdosProblems_Erdos1049_PaperR14_actual_source_residue
import Theorems.Thm_ErdosProblems_Erdos1049_PaperR14_poleProduct_degree
import Theorems.Thm_ErdosProblems_Erdos1049_PaperR14_simple_pole_expansion
import Lean.Elab.Tactic.Omega
import Mathlib
import Mathlib.Algebra.BigOperators.Group.Finset.Basic
import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Algebra.Module.BigOperators
import Mathlib.Algebra.Module.Prod
import Mathlib.Algebra.Order.Floor.Ring
import Mathlib.Algebra.Order.Ring.Abs
import Mathlib.Algebra.Polynomial.Coeff
import Mathlib.Algebra.Polynomial.Eval.Defs
import Mathlib.Algebra.Polynomial.Roots
import Mathlib.Analysis.PSeries
import Mathlib.Analysis.Real.Pi.Bounds
import Mathlib.Analysis.SpecialFunctions.Log.Basic
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.Data.Fintype.Pi
import Mathlib.Data.Fintype.Pigeonhole
import Mathlib.Data.Nat.Choose.Basic
import Mathlib.Data.Real.Basic
import Mathlib.Data.ZMod.Basic
import Mathlib.Data.ZMod.Coprime
import Mathlib.NumberTheory.Real.Irrational
import Mathlib.NumberTheory.ZetaValues
import Mathlib.RingTheory.Coprime.Basic
import Mathlib.RingTheory.Polynomial.Cyclotomic.Basic
import Mathlib.Tactic
import Mathlib.Tactic.Choose
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Push
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.InfiniteSum.Real
import Mathlib.Topology.Algebra.InfiniteSum.Ring
import Mathlib.Topology.MetricSpace.Pseudo.Defs

namespace PaperR10
end PaperR10

namespace PaperR11
end PaperR11

namespace PaperR12
end PaperR12

/-!
# Residues of the literal 2004 rational kernel

Proves the partial-fraction residues of the 2004 rational kernel.

The denominator has 13*n+1 factors, as in the corrected analytic source.
Its residues are proved to be the existing integral A_s evaluated at 1/q,
with the exact pole-power factor. No abstract A/B pair is substituted.
-/

namespace ErdosProblems.Erdos1049.PaperR14
set_option maxHeartbeats 1000000
open Polynomial Finset
open PaperR10 PaperR11 PaperR12
open scoped BigOperators









lemma sourceKernelNumerator_degree (q : ℝ) (n : ℕ) :
    (sourceKernelNumerator q n).natDegree < (range (13 * n + 1)).card := by
  have hm := natDegree_mul_le
    (p := C (qPochhammer q q (13 * n) / qPochhammer q q (12 * n)))
    (q := poleProduct (fun i : ℕ => q ^ (i + 1)) (range (12 * n)))
  have hp := poleProduct_degree (fun i : ℕ => q ^ (i + 1)) (range (12 * n))
  simp only [natDegree_C, zero_add, card_range] at hm hp ⊢
  unfold sourceKernelNumerator
  omega

lemma sourcePoleParameter_nonzero {q : ℝ} (hq0 : 0 < q) (n s : ℕ) :
    sourcePoleParameter q n s ≠ 0 := pow_ne_zero _ hq0.ne'

lemma sourcePoleParameter_injective {q : ℝ} (hq0 : 0 < q) (hq1 : q < 1) (n : ℕ) :
    Function.Injective (sourcePoleParameter q n) := by
  intro s t h
  have he := (pow_right_strictAnti₀ hq0 hq1).injective h
  omega
end ErdosProblems.Erdos1049.PaperR14

set_option maxHeartbeats 1000000
open Polynomial Finset
open PaperR10 PaperR11 PaperR12
open scoped BigOperators
open ErdosProblems in
open ErdosProblems.Erdos1049 in
open ErdosProblems.Erdos1049.PaperR14 in
open ErdosProblems.Erdos1049.PaperR10 in
open ErdosProblems.Erdos1049.PaperR11 in
open ErdosProblems.Erdos1049.PaperR12 in
theorem solution {q : ℝ} (hq0 : 0 < q) (hq1 : q < 1)
    (n : ℕ) (z : ℝ)
    (hz : ∀ s ∈ range (13 * n + 1), 1 - q ^ (14 * n + 1 + s) * z ≠ 0) :
    sourceRationalKernel q n z =
      ∑ s ∈ range (13 * n + 1),
        (q ^ ((14 * n + 1) * (14 * n + 1 + s)) *
          (sourceASummand n s).eval₂ (Int.castRingHom ℝ) q⁻¹) /
          (1 - q ^ (14 * n + 1 + s) * z) := by
  unfold sourceRationalKernel sourceKernelDenominator
  rw [simple_pole_expansion _ _ _ (sourceKernelNumerator_degree q n)
    (fun s _ => sourcePoleParameter_nonzero hq0 n s)
    (sourcePoleParameter_injective hq0 hq1 n).injOn z hz]
  apply sum_congr rfl
  intro s hs
  rw [actual_source_residue hq0 hq1 n s (by have := mem_range.mp hs; omega)]
  rfl
