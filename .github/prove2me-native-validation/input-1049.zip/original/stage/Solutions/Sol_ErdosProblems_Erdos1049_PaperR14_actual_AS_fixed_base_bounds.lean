import Definitions.Def_ErdosProblems_Erdos1049_BezoutPluckerJets
import Definitions.Def_ErdosProblems_Erdos1049_QBinomialUnitIdentity
import Definitions.Def_ErdosProblems_Erdos1049_FiniteResidueInterpolationR14
import Definitions.Def_ErdosProblems_Erdos1049_ZudilinHeightRegion
import Definitions.Def_ErdosProblems_Erdos1049_RationalBaseContour
import Definitions.Def_ErdosProblems_Erdos1049_ZudilinConeArithmetic
import Definitions.Def_ErdosProblems_Erdos1049_PaperLinearFormsR7
import Definitions.Def_ErdosProblems_Erdos1049_PaperOmegaIndicatorR7
import Definitions.Def_ErdosProblems_Erdos1049_QProductBoundsR10
import Definitions.Def_ErdosProblems_Erdos1049_SourcePolynomialR11
import Definitions.Def_ErdosProblems_Erdos1049_SourceBClearingR12
import Definitions.Def_ErdosProblems_Erdos1049_LambertSourceSummationR14
import Definitions.Def_ErdosProblems_Erdos1049_ReciprocalPochhammerR14
import Definitions.Def_ErdosProblems_Erdos1049_ActualSourceResiduesR14
import Definitions.Def_ErdosProblems_Erdos1049_PaperAsymptoticsR9
import Definitions.Def_ErdosProblems_Erdos1049_SourcePositiveHBoundsR10
import Definitions.Def_ErdosProblems_Erdos1049_ActualSourceAnalyticIdentityR14
import Definitions.Def_ErdosProblems_Erdos1049_GaussianDegreeR12
import Definitions.Def_ErdosProblems_Erdos1049_PaperShortCapR9
import Definitions.Def_ErdosProblems_Erdos1049_SourceFiniteTransformR12
import Definitions.Def_ErdosProblems_Erdos1049_SourceHomogeneousR12
import Definitions.Def_ErdosProblems_Erdos1049_RootUnityLocalCancellationR13
import Definitions.Def_ErdosProblems_Erdos1049_SourceBMonomialR12
import Definitions.Def_ErdosProblems_Erdos1049_SourceBTopDegreeR13
import Definitions.Def_ErdosProblems_Erdos1049_SourceRootCarriesR13
import Definitions.Def_ErdosProblems_Erdos1049_SourceRootBlocksR13
import Definitions.Def_ErdosProblems_Erdos1049_SourceOmegaCancellationR13
import Definitions.Def_ErdosProblems_Erdos1049_ActualAGrowthR14
import Theorems.Thm_ErdosProblems_Erdos1049_PaperR11_twice_choose_two_int
import Theorems.Thm_ErdosProblems_Erdos1049_gaussBinom_succ
import Theorems.Thm_ErdosProblems_Erdos1049_gaussBinom_zero_succ
import Theorems.Thm_ErdosProblems_Erdos1049_qPochhammer_zero
import Theorems.Thm_ErdosProblems_Erdos1049_gaussBinom_mul_qPochhammer_qPochhammer
import Theorems.Thm_ErdosProblems_Erdos1049_gaussBinom_mul_qPochhammer
import Theorems.Thm_ErdosProblems_Erdos1049_PaperR10_qPochhammerInfinity_pos
import Theorems.Thm_ErdosProblems_Erdos1049_PaperR10_quotient_of_unit_interval_bounds
import Theorems.Thm_ErdosProblems_Erdos1049_PaperR10_shifted_qPochhammer_bounds
import Theorems.Thm_ErdosProblems_Erdos1049_PaperR14_qPochhammer_large_base_nonzero
import Theorems.Thm_ErdosProblems_Erdos1049_PaperR14_qPochhammer_reciprocal_div
import Theorems.Thm_ErdosProblems_Erdos1049_PaperR14_qPochhammerFinite_eq
import Theorems.Thm_ErdosProblems_Erdos1049_PaperR14_qPochhammer_q_nonzero
import Lean.Elab.Tactic.Omega
import Mathlib
import Mathlib.Algebra.BigOperators.Group.Finset.Basic
import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Algebra.Module.BigOperators
import Mathlib.Algebra.Module.Prod
import Mathlib.Algebra.Order.Floor.Ring
import Mathlib.Algebra.Order.Ring.Abs
import Mathlib.Algebra.Polynomial.Coeff
import Mathlib.Algebra.Polynomial.Eval.Defs
import Mathlib.Algebra.Polynomial.Roots
import Mathlib.Analysis.Asymptotics.Defs
import Mathlib.Analysis.PSeries
import Mathlib.Analysis.Real.Pi.Bounds
import Mathlib.Analysis.SpecialFunctions.Log.Basic
import Mathlib.Analysis.SpecialFunctions.Pow.Real
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Data.Fintype.Pi
import Mathlib.Data.Fintype.Pigeonhole
import Mathlib.Data.Nat.Choose.Basic
import Mathlib.Data.Real.Basic
import Mathlib.Data.ZMod.Basic
import Mathlib.Data.ZMod.Coprime
import Mathlib.NumberTheory.Real.Irrational
import Mathlib.NumberTheory.ZetaValues
import Mathlib.RingTheory.Coprime.Basic
import Mathlib.RingTheory.Polynomial.Cyclotomic.Basic
import Mathlib.Tactic
import Mathlib.Tactic.Choose
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Push
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.InfiniteSum.Real
import Mathlib.Topology.Algebra.InfiniteSum.Ring
import Mathlib.Topology.MetricSpace.Pseudo.Defs

namespace PaperR10
end PaperR10

namespace PaperR11
end PaperR11

namespace PaperR12
end PaperR12

section
open scoped BigOperators
open Finset Polynomial
namespace ErdosProblems.Erdos1049
variable {R : Type*} [CommRing R]
lemma eval₂_gaussBinom (q : R) : ∀ n k,
    eval₂ (Int.castRingHom R) q (gaussBinom (X : ℤ[X]) n k) = gaussBinom q n k
  | 0, 0 => by simp [gaussBinom]
  | 0, k + 1 => by simp [gaussBinom]
  | n + 1, 0 => by simp [gaussBinom]
  | n + 1, k + 1 => by
      rw [gaussBinom_succ, gaussBinom_succ, eval₂_add]
      split_ifs with h
      · rw [eval₂_mul, eval₂_pow, eval₂_X, eval₂_gaussBinom q n (k + 1),
          eval₂_gaussBinom q n k]
      · rw [eval₂_zero, eval₂_gaussBinom q n (k + 1)]
end ErdosProblems.Erdos1049
end

/-!
# Fixed-base growth of the actual alternating A polynomial

Proves two-sided fixed-base bounds and the quadratic log rate of A_n(p).

Gaussian reciprocity is proved from finite factorial identities. Every earlier
summand loses at least n powers against the last one. The resulting tail is
bounded by a constant times n*q^n, which tends to zero. Thus possible alternating
cancellation is controlled before logarithms or a quadratic rate are asserted.
-/

namespace ErdosProblems.Erdos1049.PaperR14
set_option maxHeartbeats 1000000
open Polynomial Finset Filter Asymptotics
open PaperR10 PaperR11 PaperR12
open scoped BigOperators Topology

lemma triangularExponent_split (N k : ℕ) (hk : k ≤ N) :
    triangularExponent N = triangularExponent k + triangularExponent (N - k) + k * (N - k) := by
  have h0 := twice_choose_two_int N
  have h1 := twice_choose_two_int k
  have h2 := twice_choose_two_int (N - k)
  have he : ((N - k : ℕ) : ℤ) = (N : ℤ) - (k : ℤ) := Nat.cast_sub hk
  have hh : ((triangularExponent N : ℕ) : ℤ) =
      ((triangularExponent k + triangularExponent (N - k) + k * (N - k) : ℕ) : ℤ) := by
    simp only [triangularExponent, Nat.cast_add, Nat.cast_mul] at *
    rw [he] at h2 ⊢
    nlinarith
  exact_mod_cast hh

lemma gaussian_reciprocal_real (p : ℝ) (hp : 1 < p) (N k : ℕ) (hk : k ≤ N) :
    gaussBinom p N k = p ^ (k * (N - k)) * gaussBinom p⁻¹ N k := by
  have hp0 := (zero_lt_one.trans hp).ne'
  have hq0 : 0 < p⁻¹ := inv_pos.mpr (zero_lt_one.trans hp)
  have hq1 : p⁻¹ < 1 := (inv_lt_one₀ (zero_lt_one.trans hp)).mpr hp
  have hpk := qPochhammer_large_base_nonzero hp k
  have hpn := qPochhammer_large_base_nonzero hp (N - k)
  have hqk := qPochhammer_q_nonzero hq0 hq1 k
  have hqn := qPochhammer_q_nonzero hq0 hq1 (N - k)
  have hgp : gaussBinom p N k = qPochhammer p p N /
      (qPochhammer p p k * qPochhammer p p (N - k)) := by
    apply (eq_div_iff (mul_ne_zero hpk hpn)).mpr
    simpa only [mul_assoc] using gaussBinom_mul_qPochhammer_qPochhammer p N k hk
  have hgq : gaussBinom p⁻¹ N k = qPochhammer p⁻¹ p⁻¹ N /
      (qPochhammer p⁻¹ p⁻¹ k * qPochhammer p⁻¹ p⁻¹ (N - k)) := by
    apply (eq_div_iff (mul_ne_zero hqk hqn)).mpr
    simpa only [mul_assoc] using gaussBinom_mul_qPochhammer_qPochhammer p⁻¹ N k hk
  rw [hgp, hgq, qPochhammer_reciprocal_div p hp0 N,
    qPochhammer_reciprocal_div p hp0 k,
    qPochhammer_reciprocal_div p hp0 (N - k)]
  have hs : (-1 : ℝ) ^ N = (-1 : ℝ) ^ k * (-1 : ℝ) ^ (N - k) := by
    rw [← pow_add]
    congr 1
    omega
  rw [hs, triangularExponent_split N k hk, pow_add, pow_add]
  field_simp [hp0, hpk, hpn]
  <;> ring

lemma gaussian_small_base_bounds {q : ℝ} (hq0 : 0 < q) (hq1 : q < 1)
    (N k : ℕ) (hk : k ≤ N) :
    qPochhammerInfinity q q ≤ gaussBinom q N k ∧
      gaussBinom q N k ≤ (qPochhammerInfinity q q)⁻¹ := by
  have hden := qPochhammer_q_nonzero hq0 hq1 k
  have he : gaussBinom q N k =
      qPochhammer q (q ^ (N - k + 1)) k / qPochhammer q q k := by
    exact (eq_div_iff hden).mpr (gaussBinom_mul_qPochhammer q hk)
  rw [he, ← qPochhammerFinite_eq, ← qPochhammerFinite_eq]
  have ha := shifted_qPochhammer_bounds hq0 hq1 (N - k + 1) k (by omega)
  have hb := shifted_qPochhammer_bounds hq0 hq1 1 k (by omega)
  simp only [pow_one] at hb
  exact quotient_of_unit_interval_bounds (qPochhammerInfinity_pos q q) ha hb

lemma actual_AS_abs_reciprocal (p : ℝ) (hp : 1 < p) (n s : ℕ) (hs : s ≤ 13 * n) :
    |(sourceASummand n s).eval₂ (Int.castRingHom ℝ) p| =
      p ^ sourceASummandDegree n s *
        (gaussBinom p⁻¹ (14 * n + s) (12 * n) *
          gaussBinom p⁻¹ (13 * n) (13 * n - s)) := by
  have hp0 := zero_lt_one.trans hp
  have hq0 := inv_pos.mpr hp0
  have hq1 := (inv_lt_one₀ hp0).mpr hp
  have hG1 : 0 < gaussBinom p⁻¹ (14 * n + s) (12 * n) :=
    (qPochhammerInfinity_pos _ _).trans_le
      (gaussian_small_base_bounds hq0 hq1 _ _ (by omega)).1
  have hG2 : 0 < gaussBinom p⁻¹ (13 * n) (13 * n - s) :=
    (qPochhammerInfinity_pos _ _).trans_le
      (gaussian_small_base_bounds hq0 hq1 _ _ (Nat.sub_le _ _)).1
  have hraw : (sourceASummand n s).eval₂ (Int.castRingHom ℝ) p =
      (-1 : ℝ) ^ s * p ^ sourceASummandDegree n s *
        (gaussBinom p⁻¹ (14 * n + s) (12 * n) *
          gaussBinom p⁻¹ (13 * n) (13 * n - s)) := by
    simp only [sourceASummand, sourceGaussianProduct, eval₂_mul, eval₂_C, eval₂_pow,
      eval₂_X, eval₂_neg, eval₂_one, map_pow, map_neg, map_one, eval₂_gaussBinom]
    rw [gaussian_reciprocal_real p hp _ _ (by omega),
      gaussian_reciprocal_real p hp _ _ (Nat.sub_le _ _)]
    have he1 : 14 * n + s - 12 * n = 2 * n + s := by omega
    have he2 : 13 * n - (13 * n - s) = s := by omega
    simp only [sourceASummandDegree, he1, he2, pow_add]
    ring
  rw [hraw, abs_mul, abs_mul, abs_pow, abs_neg, abs_one, one_pow, one_mul,
    abs_of_pos (pow_pos hp0 _), abs_of_pos (mul_pos hG1 hG2)]
end ErdosProblems.Erdos1049.PaperR14

set_option maxHeartbeats 1000000
open Polynomial Finset Filter Asymptotics
open PaperR10 PaperR11 PaperR12
open scoped BigOperators Topology
open ErdosProblems in
open ErdosProblems.Erdos1049 in
open ErdosProblems.Erdos1049.PaperR14 in
open ErdosProblems.Erdos1049.PaperR10 in
open ErdosProblems.Erdos1049.PaperR11 in
open ErdosProblems.Erdos1049.PaperR12 in
theorem solution (p : ℝ) (hp : 1 < p) (n s : ℕ) (hs : s ≤ 13 * n) :
    p ^ sourceASummandDegree n s * (qPochhammerInfinity p⁻¹ p⁻¹) ^ 2 ≤
      |(sourceASummand n s).eval₂ (Int.castRingHom ℝ) p| ∧
    |(sourceASummand n s).eval₂ (Int.castRingHom ℝ) p| ≤
      p ^ sourceASummandDegree n s * ((qPochhammerInfinity p⁻¹ p⁻¹)⁻¹) ^ 2 := by
  have hp0 := zero_lt_one.trans hp
  have hq0 := inv_pos.mpr hp0
  have hq1 := (inv_lt_one₀ hp0).mpr hp
  have hP := qPochhammerInfinity_pos p⁻¹ p⁻¹
  have hg1 := gaussian_small_base_bounds hq0 hq1 (14 * n + s) (12 * n) (by omega)
  have hg2 := gaussian_small_base_bounds hq0 hq1 (13 * n) (13 * n - s) (Nat.sub_le _ _)
  rw [actual_AS_abs_reciprocal p hp n s hs]
  constructor
  · exact mul_le_mul_of_nonneg_left
      (by simpa only [pow_two] using mul_le_mul hg1.1 hg2.1 hP.le (hP.le.trans hg1.1))
      (pow_nonneg hp0.le _)
  · exact mul_le_mul_of_nonneg_left
      (by simpa only [pow_two] using mul_le_mul hg1.2 hg2.2 (hP.le.trans hg2.1) (inv_nonneg.mpr hP.le))
      (pow_nonneg hp0.le _)
