import Definitions.Def_ErdosProblems_Erdos1049_QProductBoundsR10
import Theorems.Thm_ErdosProblems_Erdos1049_PaperR10_qpow_antitone
import Mathlib
import Mathlib.Analysis.SpecialFunctions.Log.Basic
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.Tactic
import Mathlib.Topology.Algebra.InfiniteSum.Real
import Mathlib.Topology.Algebra.InfiniteSum.Ring

namespace ErdosProblems.Erdos1049.PaperR12
end ErdosProblems.Erdos1049.PaperR12

namespace PaperR10
end PaperR10

/-!
# The actual analytic moment generating identity

Proves summability, positivity, and the identity v_m^* = P^4 G_q(q^(m+1)).

Unlike a positive-measure consumer, this file starts with the literal finite
q-product summand in the 2016 normalised moment. It proves summability and
performs the finite/infinite product cancellation at w=q^(m+1). No moment
identity, atom identity, summability, or product nonvanishing is a premise.

The subsequent coefficient expansion of G, comparison of its coefficients,
and infinite Cauchy--Binet passage are separate obligations; this file does
not mislabel those consequences as established merely by the identity below.
-/

namespace ErdosProblems.Erdos1049.PaperR12
open PaperR10
open scoped BigOperators
end ErdosProblems.Erdos1049.PaperR12

open PaperR10
open scoped BigOperators
open ErdosProblems in
open ErdosProblems.Erdos1049 in
open ErdosProblems.Erdos1049.PaperR12 in
open ErdosProblems.Erdos1049.PaperR10 in
theorem solution {q : ℝ} (hq0 : 0 < q) (hq1 : q < 1)
    (s : ℕ) (hs : 1 ≤ s) : q ^ s < 1 := by
  have h : q ^ s ≤ q := by simpa using qpow_antitone hq0.le hq1.le hs
  exact h.trans_lt hq1
