import Definitions.Def_ErdosProblems_Erdos1049_QBinomialUnitIdentity
import Definitions.Def_ErdosProblems_Erdos1049_FiniteResidueInterpolationR14
import Definitions.Def_ErdosProblems_Erdos1049_QProductBoundsR10
import Definitions.Def_ErdosProblems_Erdos1049_ReciprocalPochhammerR14
import Theorems.Thm_ErdosProblems_Erdos1049_PaperR14_finite_qPochhammer_product
import Theorems.Thm_ErdosProblems_Erdos1049_PaperR14_inverse_power_mul_power
import Mathlib
import Mathlib.Algebra.BigOperators.Group.Finset.Basic
import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Algebra.Polynomial.Coeff
import Mathlib.Algebra.Polynomial.Eval.Defs
import Mathlib.Algebra.Polynomial.Roots
import Mathlib.Analysis.SpecialFunctions.Log.Basic
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.Data.Nat.Choose.Basic
import Mathlib.Tactic
import Mathlib.Topology.Algebra.InfiniteSum.Real
import Mathlib.Topology.Algebra.InfiniteSum.Ring

/-!
# Reciprocal factorials and reflected finite products

Reversal of finite q-factorials and the erased pole product. These are finite algebraic
identities. In particular no analytic source identity is used as a premise.
-/

namespace ErdosProblems.Erdos1049.PaperR14
set_option maxHeartbeats 1000000
open Finset Polynomial
open scoped BigOperators

variable {K : Type*} [Field K]
end ErdosProblems.Erdos1049.PaperR14

set_option maxHeartbeats 1000000
open Finset Polynomial
open scoped BigOperators
variable {K : Type*} [Field K]
open ErdosProblems in
open ErdosProblems.Erdos1049 in
open ErdosProblems.Erdos1049.PaperR14 in
theorem solution (p : K) (hp : p ≠ 0)
    (a L s : ℕ) (hs : s ≤ L) :
    (∏ j ∈ (range (L + 1)).erase s,
      (1 - (p⁻¹) ^ (a + j) * p ^ (a + s))) =
        qPochhammer p p s * qPochhammer p⁻¹ p⁻¹ (L - s) := by
  have hset : (range (L + 1)).erase s =
      range s ∪ ((range (L - s)).image (fun j => s + 1 + j)) := by
    ext j
    simp only [mem_erase, mem_range, mem_union, mem_image]
    constructor
    · intro hj
      by_cases hjs : j < s
      · exact Or.inl hjs
      · right
        refine ⟨j - (s + 1), by omega, by omega⟩
    · rintro (hj | ⟨k, hk, rfl⟩) <;> omega
  have hdis : Disjoint (range s) ((range (L - s)).image (fun j => s + 1 + j)) := by
    apply disjoint_left.mpr
    intro j hj hj'
    rcases mem_image.mp hj' with ⟨k, hk, rfl⟩
    have := mem_range.mp hj
    omega
  rw [hset, prod_union hdis, prod_image]
  · have hleft : (∏ j ∈ range s, (1 - (p⁻¹) ^ (a + j) * p ^ (a + s))) =
        qPochhammer p p s := by
      rw [finite_qPochhammer_product]
      calc
        _ = ∏ j ∈ range s, (1 - p * p ^ (s - 1 - j)) := by
          apply prod_congr rfl
          intro j hj
          have hjs := mem_range.mp hj
          rw [inverse_power_mul_power p hp (by omega), ← pow_succ']
          congr 2
          omega
        _ = _ := prod_range_reflect (fun j => 1 - p * p ^ j) s
    rw [hleft]
    congr 1
    rw [finite_qPochhammer_product]
    apply prod_congr rfl
    intro j hj
    have he : a + (s + 1 + j) = (a + s) + (j + 1) := by omega
    rw [he, pow_add]
    have hc : (p⁻¹) ^ (a + s) * p ^ (a + s) = 1 := by
      simpa using inverse_power_mul_power p hp (le_refl (a + s))
    have hh : (p⁻¹) ^ (a + s) * (p⁻¹) ^ (j + 1) * p ^ (a + s) =
        (p⁻¹) ^ (j + 1) := by
      calc
        _ = ((p⁻¹) ^ (a + s) * p ^ (a + s)) * (p⁻¹) ^ (j + 1) := by ring
        _ = _ := by rw [hc, one_mul]
    rw [hh, pow_succ']
  · intro i hi j hj hij
    have hij' : s + 1 + i = s + 1 + j := hij
    omega
