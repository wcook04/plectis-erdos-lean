import Definitions.Def_ErdosProblems_Erdos1049_BezoutPluckerJets
import Definitions.Def_ErdosProblems_Erdos1049_QBinomialUnitIdentity
import Definitions.Def_ErdosProblems_Erdos1049_FiniteResidueInterpolationR14
import Definitions.Def_ErdosProblems_Erdos1049_ZudilinHeightRegion
import Definitions.Def_ErdosProblems_Erdos1049_RationalBaseContour
import Definitions.Def_ErdosProblems_Erdos1049_ZudilinConeArithmetic
import Definitions.Def_ErdosProblems_Erdos1049_PaperLinearFormsR7
import Definitions.Def_ErdosProblems_Erdos1049_PaperOmegaIndicatorR7
import Definitions.Def_ErdosProblems_Erdos1049_QProductBoundsR10
import Definitions.Def_ErdosProblems_Erdos1049_SourcePolynomialR11
import Definitions.Def_ErdosProblems_Erdos1049_SourceBClearingR12
import Definitions.Def_ErdosProblems_Erdos1049_LambertSourceSummationR14
import Definitions.Def_ErdosProblems_Erdos1049_ReciprocalPochhammerR14
import Definitions.Def_ErdosProblems_Erdos1049_ActualSourceResiduesR14
import Definitions.Def_ErdosProblems_Erdos1049_PaperAsymptoticsR9
import Definitions.Def_ErdosProblems_Erdos1049_SourcePositiveHBoundsR10
import Definitions.Def_ErdosProblems_Erdos1049_ActualSourceAnalyticIdentityR14
import Definitions.Def_ErdosProblems_Erdos1049_GaussianDegreeR12
import Definitions.Def_ErdosProblems_Erdos1049_PaperShortCapR9
import Definitions.Def_ErdosProblems_Erdos1049_SourceFiniteTransformR12
import Definitions.Def_ErdosProblems_Erdos1049_SourceHomogeneousR12
import Definitions.Def_ErdosProblems_Erdos1049_RootUnityLocalCancellationR13
import Definitions.Def_ErdosProblems_Erdos1049_SourceBMonomialR12
import Definitions.Def_ErdosProblems_Erdos1049_SourceBTopDegreeR13
import Definitions.Def_ErdosProblems_Erdos1049_SourceRootCarriesR13
import Definitions.Def_ErdosProblems_Erdos1049_SourceRootBlocksR13
import Definitions.Def_ErdosProblems_Erdos1049_SourceOmegaCancellationR13
import Definitions.Def_ErdosProblems_Erdos1049_ActualAGrowthR14
import Definitions.Def_ErdosProblems_Erdos1049_G02ArithmeticR16
import Definitions.Def_ErdosProblems_Erdos1049_SourceHeightRateR14
import Definitions.Def_ErdosProblems_Erdos1049_WeightedFloorBlocksR12
import Definitions.Def_ErdosProblems_Erdos1049_G02WeightedBlocksR16
import Definitions.Def_ErdosProblems_Erdos1049_G02CyclotomicR16
import Definitions.Def_ErdosProblems_Erdos1049_G02SourceRatesR16
import Definitions.Def_ErdosProblems_Erdos1049_QuadraticMeasureR10
import Definitions.Def_ErdosProblems_Erdos1049_IrrationalityExponentR11
import Definitions.Def_ErdosProblems_Erdos1049_MeasureConstantsR10
import Definitions.Def_ErdosProblems_Erdos1049_PaperR17_SourceConsumers
import Theorems.Thm_ErdosProblems_Erdos1049_PaperR9_QuadLogRate_exp_upper
import Theorems.Thm_ErdosProblems_Erdos1049_PaperR10_approximationExponentUpper_of_quadratic_forms
import Theorems.Thm_ErdosProblems_Erdos1049_PaperR10_rate_quotient_eq_contour
import Theorems.Thm_ErdosProblems_Erdos1049_PaperR16_actual_remainder_posR16
import Theorems.Thm_ErdosProblems_Erdos1049_PaperR16_quadLogRate_congrR16
import Theorems.Thm_ErdosProblems_Erdos1049_PaperR16_actual_cleared_remainder_rateR16
import Theorems.Thm_ErdosProblems_Erdos1049_PaperR16_sourceDelta_posR16
import Theorems.Thm_ErdosProblems_Erdos1049_PaperR17_rational_base_gt_one
import Theorems.Thm_ErdosProblems_Erdos1049_PaperR17_clearedA_rate
import Theorems.Thm_ErdosProblems_Erdos1049_PaperR17_cleared_error_identity
import Theorems.Thm_ErdosProblems_Erdos1049_PaperR17_supplier_C0_eq
import Theorems.Thm_ErdosProblems_Erdos1049_PaperR17_supplier_C1_eq
import Theorems.Thm_ErdosProblems_Erdos1049_PaperR17_region_iff_positive_decay
import Theorems.Thm_ErdosProblems_Erdos1049_PaperR17_supplier_delta_eq
import Lean.Elab.Tactic.Omega
import Mathlib
import Mathlib.Algebra.BigOperators.Group.Finset.Basic
import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Algebra.Module.BigOperators
import Mathlib.Algebra.Module.Prod
import Mathlib.Algebra.Order.Floor.Ring
import Mathlib.Algebra.Order.Ring.Abs
import Mathlib.Algebra.Order.Ring.Int
import Mathlib.Algebra.Polynomial.Coeff
import Mathlib.Algebra.Polynomial.Eval.Defs
import Mathlib.Algebra.Polynomial.Roots
import Mathlib.Analysis.Asymptotics.Defs
import Mathlib.Analysis.PSeries
import Mathlib.Analysis.Real.Pi.Bounds
import Mathlib.Analysis.SpecialFunctions.Log.Basic
import Mathlib.Analysis.SpecialFunctions.Pow.Asymptotics
import Mathlib.Analysis.SpecialFunctions.Pow.Real
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Data.Fintype.Pi
import Mathlib.Data.Fintype.Pigeonhole
import Mathlib.Data.Nat.Choose.Basic
import Mathlib.Data.Real.Basic
import Mathlib.Data.ZMod.Basic
import Mathlib.Data.ZMod.Coprime
import Mathlib.NumberTheory.ArithmeticFunction.Moebius
import Mathlib.NumberTheory.Harmonic.Bounds
import Mathlib.NumberTheory.Real.Irrational
import Mathlib.NumberTheory.ZetaValues
import Mathlib.Order.LiminfLimsup
import Mathlib.RingTheory.Coprime.Basic
import Mathlib.RingTheory.Polynomial.Cyclotomic.Basic
import Mathlib.Tactic
import Mathlib.Tactic.Choose
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Push
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.InfiniteSum.Real
import Mathlib.Topology.Algebra.InfiniteSum.Ring
import Mathlib.Topology.MetricSpace.Pseudo.Defs

namespace PaperR10
end PaperR10

namespace PaperR11
end PaperR11

namespace PaperR12
end PaperR12

namespace PaperR13
end PaperR13

namespace PaperR16
end PaperR16

namespace PaperR7
end PaperR7

namespace PaperR9
end PaperR9

/-!
# The literal G02 supplier, the original R7 consumer, and the power-uniform measure

Proves F(a/b) irrational on the contour region and F((31/4)^r) irrational.
No source-supply, rate, nonvanishing or positivity hypothesis is left in the
source endpoints. Homogeneous evaluations use the actual pair width.
-/

namespace ErdosProblems.Erdos1049.PaperR17
open PaperR7 PaperR9 PaperR10 PaperR11 PaperR12 PaperR13 PaperR16
open Filter
open scoped Topology BigOperators
set_option maxHeartbeats 3000000

















theorem cleared_error_pos (a b n : ℕ) (hb : 0 < b) (hab : b < a) :
    0 < (clearedA a b n : ℝ) * paperLambert ((a : ℝ) / b) - clearedB a b n := by
  rw [cleared_error_identity a b n hb]
  exact mul_pos (pow_pos (by exact_mod_cast hb) _)
    (actual_remainder_posR16 _ (rational_base_gt_one a b hb hab) n)

theorem cleared_error_rate (a b : ℕ) (hb : 0 < b) (hab : b < a) :
    QuadLogRate
      (fun n => (clearedA a b n : ℝ) * paperLambert ((a : ℝ) / b) - clearedB a b n)
      (-decayRate a b) := by
  have h := actual_cleared_remainder_rateR16 (a : ℝ) (b : ℝ)
    (by exact_mod_cast hb) (by exact_mod_cast hab)
  have hc : sourceC1R16 * Real.log b - sourceC0R16 * Real.log a = -decayRate a b := by
    unfold decayRate
    ring
  rw [hc] at h
  exact quadLogRate_congrR16 h
    (Eventually.of_forall (fun n => (cleared_error_identity a b n hb).symm))













lemma coefficientRate_nonneg (a b : ℕ) (hb : 0 < b) (hab : b < a) :
    0 ≤ coefficientRate a := by
  have ha : 1 < a := by omega
  exact (mul_pos sourceDelta_posR16 (Real.log_pos (by exact_mod_cast ha))).le

lemma source_measure_quotient (a b : ℕ) (hb : 0 < b) (hab : b < a)
    (hr : ZudilinContourRegion a b) :
    1 + coefficientRate a / decayRate a b = rationalBaseMeasureBound a b := by
  have ha : 1 < a := by omega
  have hla : 0 < Real.log (a : ℝ) := Real.log_pos (by exact_mod_cast ha)
  have hd : 0 < decayRate a b := (region_iff_positive_decay a b hb hab).mp hr
  have hd' : 0 < zudilinC0 * Real.log a - zudilinC1 * Real.log b := by
    simpa only [decayRate, supplier_C0_eq, supplier_C1_eq] using hd
  simpa only [coefficientRate, decayRate, supplier_delta_eq,
    supplier_C0_eq, supplier_C1_eq] using rate_quotient_eq_contour a b hla hd'
end ErdosProblems.Erdos1049.PaperR17

open PaperR7 PaperR9 PaperR10 PaperR11 PaperR12 PaperR13 PaperR16
open Filter
open scoped Topology BigOperators
set_option maxHeartbeats 3000000
open ErdosProblems in
open ErdosProblems.Erdos1049 in
open ErdosProblems.Erdos1049.PaperR17 in
open ErdosProblems.Erdos1049.PaperR10 in
open ErdosProblems.Erdos1049.PaperR11 in
open ErdosProblems.Erdos1049.PaperR12 in
open ErdosProblems.Erdos1049.PaperR13 in
open ErdosProblems.Erdos1049.PaperR16 in
open ErdosProblems.Erdos1049.PaperR7 in
open ErdosProblems.Erdos1049.PaperR9 in
theorem solution (a b : ℕ) (hb : 0 < b) (hab : b < a)
    (hr : ZudilinContourRegion a b) :
    ApproximationExponentUpper (paperLambert ((a : ℝ) / b)) (rationalBaseMeasureBound a b) := by
  have hd : 0 < decayRate a b := (region_iff_positive_decay a b hb hab).mp hr
  have h := approximationExponentUpper_of_quadratic_forms
    (clearedA a b) (clearedB a b) (paperLambert ((a : ℝ) / b))
    (coefficientRate a) (decayRate a b)
    (coefficientRate_nonneg a b hb hab) hd
    (Eventually.of_forall (fun n => (cleared_error_pos a b n hb hab).ne'))
    (clearedA_rate a b hb hab).exp_upper (cleared_error_rate a b hb hab)
  rwa [source_measure_quotient a b hb hab hr] at h
