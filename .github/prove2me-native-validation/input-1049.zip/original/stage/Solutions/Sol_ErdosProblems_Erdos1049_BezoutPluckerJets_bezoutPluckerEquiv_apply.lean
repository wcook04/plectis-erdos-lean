import Definitions.Def_ErdosProblems_Erdos1049_BezoutPluckerJets
import Lean.Elab.Tactic.Omega
import Mathlib.Algebra.BigOperators.Group.Finset.Basic
import Mathlib.Algebra.Module.BigOperators
import Mathlib.Algebra.Module.Prod
import Mathlib.Data.Fintype.Pi
import Mathlib.Data.ZMod.Basic
import Mathlib.RingTheory.Coprime.Basic
import Mathlib.Tactic.Choose
import Mathlib.Tactic.Push
import Mathlib.Tactic.Ring

namespace ErdosProblems.Erdos1049.BezoutPluckerJets
variable {R : Type*} [CommRing R]
end ErdosProblems.Erdos1049.BezoutPluckerJets

open ErdosProblems
open ErdosProblems.Erdos1049
open ErdosProblems.Erdos1049.BezoutPluckerJets
variable {R : Type*} [CommRing R]
open ErdosProblems in
open ErdosProblems.Erdos1049 in
open ErdosProblems.Erdos1049.BezoutPluckerJets in
@[simp] theorem solution (a b u v : R) (h : u * a + v * b = 1) (x y : R) :
    bezoutPluckerEquiv a b u v h (x, y) = (u * x + v * y, a * y - b * x) := rfl
