import Definitions.Def_ErdosProblems_Erdos1049_BezoutPluckerJets
import Definitions.Def_ErdosProblems_Erdos1049_QBinomialUnitIdentity
import Definitions.Def_ErdosProblems_Erdos1049_FiniteResidueInterpolationR14
import Definitions.Def_ErdosProblems_Erdos1049_ZudilinHeightRegion
import Definitions.Def_ErdosProblems_Erdos1049_RationalBaseContour
import Definitions.Def_ErdosProblems_Erdos1049_ZudilinConeArithmetic
import Definitions.Def_ErdosProblems_Erdos1049_PaperLinearFormsR7
import Definitions.Def_ErdosProblems_Erdos1049_PaperOmegaIndicatorR7
import Definitions.Def_ErdosProblems_Erdos1049_QProductBoundsR10
import Definitions.Def_ErdosProblems_Erdos1049_SourcePolynomialR11
import Definitions.Def_ErdosProblems_Erdos1049_SourceBClearingR12
import Definitions.Def_ErdosProblems_Erdos1049_LambertSourceSummationR14
import Definitions.Def_ErdosProblems_Erdos1049_ReciprocalPochhammerR14
import Definitions.Def_ErdosProblems_Erdos1049_ActualSourceResiduesR14
import Definitions.Def_ErdosProblems_Erdos1049_PaperAsymptoticsR9
import Definitions.Def_ErdosProblems_Erdos1049_SourcePositiveHBoundsR10
import Definitions.Def_ErdosProblems_Erdos1049_ActualSourceAnalyticIdentityR14
import Definitions.Def_ErdosProblems_Erdos1049_GaussianDegreeR12
import Definitions.Def_ErdosProblems_Erdos1049_PaperShortCapR9
import Definitions.Def_ErdosProblems_Erdos1049_SourceFiniteTransformR12
import Definitions.Def_ErdosProblems_Erdos1049_SourceHomogeneousR12
import Definitions.Def_ErdosProblems_Erdos1049_RootUnityLocalCancellationR13
import Definitions.Def_ErdosProblems_Erdos1049_SourceBMonomialR12
import Definitions.Def_ErdosProblems_Erdos1049_SourceBTopDegreeR13
import Definitions.Def_ErdosProblems_Erdos1049_SourceRootCarriesR13
import Definitions.Def_ErdosProblems_Erdos1049_SourceRootBlocksR13
import Definitions.Def_ErdosProblems_Erdos1049_SourceOmegaCancellationR13
import Definitions.Def_ErdosProblems_Erdos1049_ActualAGrowthR14
import Definitions.Def_ErdosProblems_Erdos1049_G02ArithmeticR16
import Definitions.Def_ErdosProblems_Erdos1049_SourceHeightRateR14
import Definitions.Def_ErdosProblems_Erdos1049_WeightedFloorBlocksR12
import Definitions.Def_ErdosProblems_Erdos1049_G02WeightedBlocksR16
import Definitions.Def_ErdosProblems_Erdos1049_G02CyclotomicR16
import Definitions.Def_ErdosProblems_Erdos1049_G02SourceRatesR16
import Theorems.Thm_ErdosProblems_Erdos1049_PaperR16_rate_of_eventual_linear_errorR16
import Theorems.Thm_ErdosProblems_Erdos1049_PaperR10_sourcePositiveH_pos
import Theorems.Thm_ErdosProblems_Erdos1049_PaperR14_actual_cancelled_remainder_identity
import Theorems.Thm_ErdosProblems_Erdos1049_PaperR16_actual_complement_posR16
import Theorems.Thm_ErdosProblems_Erdos1049_PaperR10_sourcePositiveH_quadLogRate_zero
import Theorems.Thm_ErdosProblems_Erdos1049_PaperR16_actual_complement_quadLogRateR16
import Theorems.Thm_ErdosProblems_Erdos1049_PaperR16_quadLogRate_congrR16
import Theorems.Thm_ErdosProblems_Erdos1049_PaperR16_quadLogRate_divR16
import Theorems.Thm_ErdosProblems_Erdos1049_PaperR16_quadLogRate_mulR16
import Theorems.Thm_ErdosProblems_Erdos1049_PaperR16_quadLogRate_powerR16
import Lean.Elab.Tactic.Omega
import Mathlib
import Mathlib.Algebra.BigOperators.Group.Finset.Basic
import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Algebra.Module.BigOperators
import Mathlib.Algebra.Module.Prod
import Mathlib.Algebra.Order.Floor.Ring
import Mathlib.Algebra.Order.Ring.Abs
import Mathlib.Algebra.Order.Ring.Int
import Mathlib.Algebra.Polynomial.Coeff
import Mathlib.Algebra.Polynomial.Eval.Defs
import Mathlib.Algebra.Polynomial.Roots
import Mathlib.Analysis.Asymptotics.Defs
import Mathlib.Analysis.PSeries
import Mathlib.Analysis.Real.Pi.Bounds
import Mathlib.Analysis.SpecialFunctions.Log.Basic
import Mathlib.Analysis.SpecialFunctions.Pow.Asymptotics
import Mathlib.Analysis.SpecialFunctions.Pow.Real
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Data.Fintype.Pi
import Mathlib.Data.Fintype.Pigeonhole
import Mathlib.Data.Nat.Choose.Basic
import Mathlib.Data.Real.Basic
import Mathlib.Data.ZMod.Basic
import Mathlib.Data.ZMod.Coprime
import Mathlib.NumberTheory.ArithmeticFunction.Moebius
import Mathlib.NumberTheory.Harmonic.Bounds
import Mathlib.NumberTheory.Real.Irrational
import Mathlib.NumberTheory.ZetaValues
import Mathlib.Order.LiminfLimsup
import Mathlib.RingTheory.Coprime.Basic
import Mathlib.RingTheory.Polynomial.Cyclotomic.Basic
import Mathlib.Tactic
import Mathlib.Tactic.Choose
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Push
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.InfiniteSum.Real
import Mathlib.Topology.Algebra.InfiniteSum.Ring
import Mathlib.Topology.MetricSpace.Pseudo.Defs

namespace PaperR10
end PaperR10

namespace PaperR11
end PaperR11

namespace PaperR12
end PaperR12

namespace PaperR13
end PaperR13

namespace PaperR14
end PaperR14

namespace PaperR9
end PaperR9

/-!
# G02 literal source-rate assembly

Every endpoint below specialises the actual R11/R13 U,V and R9 remainder.
No totient, cyclotomic, degree, or remainder rate is a hypothesis of the
final source theorem. Proves exact quadratic rates of U, V, A and the remainder.
This is not a construction of a new common-width four-jet family.
-/

namespace ErdosProblems.Erdos1049.PaperR16
open Polynomial Finset Filter Asymptotics
open PaperR9 PaperR10 PaperR11 PaperR12 PaperR13 PaperR14
open scoped BigOperators Topology
set_option maxHeartbeats 3000000






lemma sourceM_rateR16 : QuadRateR16 (fun n => (sourceM n : ℝ)) 266 := by
  apply rate_of_eventual_linear_errorR16 _ 266 35 (by norm_num)
  exact Eventually.of_forall (fun n => by
    have hn0 : (0 : ℝ) ≤ n := Nat.cast_nonneg _
    have he : (sourceM n : ℝ)-266*sqScale n = 34*(n : ℝ)+1 := by
      simp only [sourceM, sqScale, Nat.cast_add, Nat.cast_mul, Nat.cast_pow, Nat.cast_ofNat]
      ring
    rw [he, abs_of_nonneg (by positivity)]
    nlinarith)
end ErdosProblems.Erdos1049.PaperR16

open Polynomial Finset Filter Asymptotics
open PaperR9 PaperR10 PaperR11 PaperR12 PaperR13 PaperR14
open scoped BigOperators Topology
set_option maxHeartbeats 3000000
open ErdosProblems in
open ErdosProblems.Erdos1049 in
open ErdosProblems.Erdos1049.PaperR16 in
open ErdosProblems.Erdos1049.PaperR10 in
open ErdosProblems.Erdos1049.PaperR11 in
open ErdosProblems.Erdos1049.PaperR12 in
open ErdosProblems.Erdos1049.PaperR13 in
open ErdosProblems.Erdos1049.PaperR14 in
open ErdosProblems.Erdos1049.PaperR9 in
theorem solution (p : ℝ) (hp : 1 < p) :
    QuadLogRate (sourceRemainderR16 p) (-sourceC0R16*Real.log p) := by
  have hp0 := zero_lt_one.trans hp
  have hq0 := inv_pos.mpr hp0
  have hq1 := (inv_lt_one₀ hp0).2 hp
  have hC := actual_complement_quadLogRateR16 p hp
  have hH := sourcePositiveH_quadLogRate_zero hq0 hq1
  have hCn : ∀ᶠ n in atTop, complementEvalR16 p n ≠ 0 :=
    Eventually.of_forall (fun n => (actual_complement_posR16 p hp n).ne')
  have hHn : ∀ᶠ n in atTop, sourcePositiveH p⁻¹ n ≠ 0 :=
    Eventually.of_forall (fun n => (sourcePositiveH_pos hq0 hq1 n).ne')
  have hm := quadLogRate_powerR16 sourceM 266 p hp0 sourceM_rateR16
  have hmn : ∀ᶠ n in atTop, p^sourceM n ≠ 0 :=
    Eventually.of_forall (fun n => pow_ne_zero _ hp0.ne')
  have h := quadLogRate_divR16 (quadLogRate_mulR16 hC hH hCn hHn) hm
    (by filter_upwards [hCn, hHn] with n hn hm; exact mul_ne_zero hn hm) hmn
  have hc : sourceGammaR16*Real.log p+0-266*Real.log p =
      -sourceC0R16*Real.log p := by
    unfold sourceC0R16
    ring
  rw [hc] at h
  apply quadLogRate_congrR16 h
  exact Eventually.of_forall (fun n =>
    (actual_cancelled_remainder_identity p hp n).symm)
