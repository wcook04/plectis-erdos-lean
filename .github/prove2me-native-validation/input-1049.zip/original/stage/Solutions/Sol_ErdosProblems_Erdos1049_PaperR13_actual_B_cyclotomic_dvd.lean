import Definitions.Def_ErdosProblems_Erdos1049_QBinomialUnitIdentity
import Definitions.Def_ErdosProblems_Erdos1049_ZudilinConeArithmetic
import Definitions.Def_ErdosProblems_Erdos1049_PaperOmegaIndicatorR7
import Definitions.Def_ErdosProblems_Erdos1049_SourcePolynomialR11
import Definitions.Def_ErdosProblems_Erdos1049_SourceBClearingR12
import Definitions.Def_ErdosProblems_Erdos1049_GaussianDegreeR12
import Definitions.Def_ErdosProblems_Erdos1049_SourceFiniteTransformR12
import Definitions.Def_ErdosProblems_Erdos1049_SourceHomogeneousR12
import Definitions.Def_ErdosProblems_Erdos1049_RootUnityLocalCancellationR13
import Definitions.Def_ErdosProblems_Erdos1049_SourceBMonomialR12
import Definitions.Def_ErdosProblems_Erdos1049_SourceBTopDegreeR13
import Definitions.Def_ErdosProblems_Erdos1049_SourceRootCarriesR13
import Definitions.Def_ErdosProblems_Erdos1049_SourceRootBlocksR13
import Definitions.Def_ErdosProblems_Erdos1049_SourceOmegaCancellationR13
import Theorems.Thm_ErdosProblems_Erdos1049_PaperR12_actual_B_monomial_factor
import Theorems.Thm_ErdosProblems_Erdos1049_PaperR13_actual_cleared_B_first_carry_zero
import Theorems.Thm_ErdosProblems_Erdos1049_PaperR13_actual_cleared_B_root_prefix_identity
import Theorems.Thm_ErdosProblems_Erdos1049_PaperR13_actual_source_second_carry_weighted_zero
import Theorems.Thm_ErdosProblems_Erdos1049_PaperR13_sourceWeight_one_carry_cases
import Mathlib
import Mathlib.Algebra.BigOperators.Group.Finset.Basic
import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Algebra.Order.Floor.Ring
import Mathlib.Algebra.Polynomial.Coeff
import Mathlib.Algebra.Polynomial.Eval.Defs
import Mathlib.Data.Fintype.Pigeonhole
import Mathlib.Data.Nat.Choose.Basic
import Mathlib.Data.Real.Basic
import Mathlib.Data.ZMod.Basic
import Mathlib.Data.ZMod.Coprime
import Mathlib.RingTheory.Polynomial.Cyclotomic.Basic
import Mathlib.Tactic

namespace PaperR11
end PaperR11

namespace PaperR12
end PaperR12

namespace ErdosProblems.Erdos1049.PaperR13
open Polynomial PaperR11 PaperR12 Finset
open scoped BigOperators
section
variable {K : Type*} [Field K]
/-- Complete root cancellation at every selected cyclotomic factor. -/
theorem actual_cleared_B_root_zero (q : K) (hq : q ≠ 0) (n ell : ℕ)
    (hell : 0 < ell) (helln : ell ≤ 15 * n) (hroot : q ^ ell = 1)
    (hprimitive : ∀ a : ℕ, 0 < a → a < ell → q ^ a ≠ 1)
    (hweight : sourceWeight n ell = 1) :
    (sourceClearedB n).eval₂ (Int.castRingHom K) q = 0 := by
  rcases sourceWeight_one_carry_cases n ell hweight with hfirst | ⟨hfirst, hsecond⟩
  · exact actual_cleared_B_first_carry_zero q hq n ell hell hroot hprimitive hfirst
  · rw [actual_cleared_B_root_prefix_identity q n ell hell helln hroot hprimitive]
    exact actual_source_second_carry_weighted_zero q hq n ell hell hroot hprimitive
      hfirst hsecond (fun L => sourcePolePrefix q n ell L + sourcePolePrefix q n ell (14 * n / ell))
end
end ErdosProblems.Erdos1049.PaperR13

open ErdosProblems
open ErdosProblems.Erdos1049
open ErdosProblems.Erdos1049.PaperR13
open Polynomial PaperR11 PaperR12 Finset
open scoped BigOperators
open ErdosProblems in
open ErdosProblems.Erdos1049 in
open ErdosProblems.Erdos1049.PaperR13 in
open ErdosProblems.Erdos1049.PaperR11 in
open ErdosProblems.Erdos1049.PaperR12 in
theorem solution (n ell : ℕ) (hell : 0 < ell)
    (helln : ell ≤ 15 * n) (hweight : sourceWeight n ell = 1) :
    cyclotomic ell ℤ ∣ sourceBWithoutMonomial n := by
  let q : ℂ := Complex.exp (2 * Real.pi * Complex.I / ell)
  have hp : IsPrimitiveRoot q ell := Complex.isPrimitiveRoot_exp ell hell.ne'
  have hq : q ≠ 0 := by
    intro hz
    have hh := hp.pow_eq_one
    rw [hz, zero_pow hell.ne'] at hh
    exact zero_ne_one hh
  have hprimitive : ∀ a : ℕ, 0 < a → a < ell → q ^ a ≠ 1 := by
    intro a ha0 haell hpow
    have hdiv := hp.dvd_of_pow_eq_one a hpow
    have hle := Nat.le_of_dvd ha0 hdiv
    omega
  have hzero := actual_cleared_B_root_zero q hq n ell hell helln hp.pow_eq_one hprimitive hweight
  rw [actual_B_monomial_factor, eval₂_mul, eval₂_pow, eval₂_X] at hzero
  have hb : (sourceBWithoutMonomial n).eval₂ (Int.castRingHom ℂ) q = 0 :=
    (mul_eq_zero.mp hzero).resolve_left (pow_ne_zero _ hq)
  rw [cyclotomic_eq_minpoly hp hell]
  apply minpoly.isIntegrallyClosed_dvd (hp.isIntegral hell)
  simpa only [aeval_def] using hb
