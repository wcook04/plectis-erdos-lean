import Definitions.Def_ErdosProblems_Erdos1049_QBinomialUnitIdentity
import Definitions.Def_ErdosProblems_Erdos1049_FiniteResidueInterpolationR14
import Definitions.Def_ErdosProblems_Erdos1049_ZudilinHeightRegion
import Definitions.Def_ErdosProblems_Erdos1049_RationalBaseContour
import Definitions.Def_ErdosProblems_Erdos1049_ZudilinConeArithmetic
import Definitions.Def_ErdosProblems_Erdos1049_PaperLinearFormsR7
import Definitions.Def_ErdosProblems_Erdos1049_PaperOmegaIndicatorR7
import Definitions.Def_ErdosProblems_Erdos1049_QProductBoundsR10
import Definitions.Def_ErdosProblems_Erdos1049_SourcePolynomialR11
import Definitions.Def_ErdosProblems_Erdos1049_SourceBClearingR12
import Definitions.Def_ErdosProblems_Erdos1049_LambertSourceSummationR14
import Definitions.Def_ErdosProblems_Erdos1049_ReciprocalPochhammerR14
import Definitions.Def_ErdosProblems_Erdos1049_ActualSourceResiduesR14
import Definitions.Def_ErdosProblems_Erdos1049_PaperAsymptoticsR9
import Definitions.Def_ErdosProblems_Erdos1049_SourcePositiveHBoundsR10
import Definitions.Def_ErdosProblems_Erdos1049_ActualSourceAnalyticIdentityR14
import Definitions.Def_ErdosProblems_Erdos1049_GaussianDegreeR12
import Definitions.Def_ErdosProblems_Erdos1049_PaperShortCapR9
import Definitions.Def_ErdosProblems_Erdos1049_SourceFiniteTransformR12
import Definitions.Def_ErdosProblems_Erdos1049_SourceHomogeneousR12
import Definitions.Def_ErdosProblems_Erdos1049_RootUnityLocalCancellationR13
import Definitions.Def_ErdosProblems_Erdos1049_SourceBMonomialR12
import Definitions.Def_ErdosProblems_Erdos1049_SourceBTopDegreeR13
import Definitions.Def_ErdosProblems_Erdos1049_SourceRootCarriesR13
import Definitions.Def_ErdosProblems_Erdos1049_SourceRootBlocksR13
import Definitions.Def_ErdosProblems_Erdos1049_SourceOmegaCancellationR13
import Theorems.Thm_ErdosProblems_Erdos1049_PaperR11_sourceD_factor
import Theorems.Thm_ErdosProblems_Erdos1049_PaperR12_actual_B_first_clearing
import Theorems.Thm_ErdosProblems_Erdos1049_PaperR13_actual_B_polynomial_inclusion
import Theorems.Thm_ErdosProblems_Erdos1049_PaperR14_actual_A_F_sub_B_eq_H_real
import Theorems.Thm_ErdosProblems_Erdos1049_PaperR14_actual_real_A_normalisation
import Theorems.Thm_ErdosProblems_Erdos1049_PaperR14_real_power_denominator_nonzero
import Theorems.Thm_ErdosProblems_Erdos1049_PaperR14_real_cyclotomic_eval_nonzero
import Lean.Elab.Tactic.Omega
import Mathlib
import Mathlib.Algebra.BigOperators.Group.Finset.Basic
import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Algebra.Module.BigOperators
import Mathlib.Algebra.Module.Prod
import Mathlib.Algebra.Order.Floor.Ring
import Mathlib.Algebra.Order.Ring.Abs
import Mathlib.Algebra.Polynomial.Coeff
import Mathlib.Algebra.Polynomial.Eval.Defs
import Mathlib.Algebra.Polynomial.Roots
import Mathlib.Analysis.Asymptotics.Defs
import Mathlib.Analysis.PSeries
import Mathlib.Analysis.Real.Pi.Bounds
import Mathlib.Analysis.SpecialFunctions.Log.Basic
import Mathlib.Analysis.SpecialFunctions.Pow.Real
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.Data.Fintype.Pi
import Mathlib.Data.Fintype.Pigeonhole
import Mathlib.Data.Nat.Choose.Basic
import Mathlib.Data.Real.Basic
import Mathlib.Data.ZMod.Basic
import Mathlib.Data.ZMod.Coprime
import Mathlib.NumberTheory.Real.Irrational
import Mathlib.NumberTheory.ZetaValues
import Mathlib.RingTheory.Coprime.Basic
import Mathlib.RingTheory.Polynomial.Cyclotomic.Basic
import Mathlib.Tactic
import Mathlib.Tactic.Choose
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Push
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.InfiniteSum.Real
import Mathlib.Topology.Algebra.InfiniteSum.Ring
import Mathlib.Topology.MetricSpace.Pseudo.Defs

namespace PaperR10
end PaperR10

namespace PaperR11
end PaperR11

namespace PaperR12
end PaperR12

namespace PaperR13
end PaperR13

/-!
# Evaluation and nonvanishing of the actual cancelled remainder

Proves the cancelled remainder is positive, with an exact log formula. The real normalisation is
proved directly from the actual integral inclusions. No nonzero source error,
analytic identity, or substitute polynomial pair is assumed.
-/

namespace ErdosProblems.Erdos1049.PaperR14
set_option maxHeartbeats 1000000
open Polynomial Finset
open PaperR10 PaperR11 PaperR12 PaperR13
open scoped BigOperators





lemma actual_source_D_real_nonzero (p : ℝ) (hp : 1 < p) (n : ℕ) :
    (sourceD n).eval₂ (Int.castRingHom ℝ) p ≠ 0 := by
  change (eval₂RingHom (Int.castRingHom ℝ) p) (sourceD n) ≠ 0
  simp only [sourceD, map_prod]
  exact prod_ne_zero_iff.mpr (fun j hj =>
    real_cyclotomic_eval_nonzero p hp j (mem_Icc.mp hj).1)

lemma actual_source_Omega_and_complement_real_nonzero (p : ℝ) (hp : 1 < p) (n : ℕ) :
    (sourceOmega n).eval₂ (Int.castRingHom ℝ) p ≠ 0 ∧
      (sourceComplement n).eval₂ (Int.castRingHom ℝ) p ≠ 0 := by
  have h := actual_source_D_real_nonzero p hp n
  rw [sourceD_factor, eval₂_mul] at h
  exact mul_ne_zero_iff.mp h

lemma actual_real_B_normalisation (p : ℝ) (hp : 1 < p) (n : ℕ) :
    (sourceComplement n).eval₂ (Int.castRingHom ℝ) p * sourceBReal n p =
      p ^ sourceM n * (sourceV n).eval₂ (Int.castRingHom ℝ) p := by
  let f : ℤ[X] →+* ℝ := eval₂RingHom (Int.castRingHom ℝ) p
  have hclear := actual_B_first_clearing f n
    (by simpa [f] using (zero_lt_one.trans hp).ne')
    (by
      intro j hj
      simpa [f] using real_power_denominator_nonzero p hp j (mem_Icc.mp hj).1)
  have hinc := congrArg f (actual_B_polynomial_inclusion n)
  have hsplit := congrArg f (sourceD_factor n)
  simp only [map_mul, map_pow] at hinc hsplit
  rw [hsplit] at hclear
  rw [hclear] at hinc
  have hO : f (sourceOmega n) ≠ 0 :=
    (actual_source_Omega_and_complement_real_nonzero p hp n).1
  apply mul_left_cancel₀ hO
  simpa only [f, sourceBReal, coe_eval₂RingHom, eval₂_X, mul_assoc] using hinc
end ErdosProblems.Erdos1049.PaperR14

set_option maxHeartbeats 1000000
open Polynomial Finset
open PaperR10 PaperR11 PaperR12 PaperR13
open scoped BigOperators
open ErdosProblems in
open ErdosProblems.Erdos1049 in
open ErdosProblems.Erdos1049.PaperR14 in
open ErdosProblems.Erdos1049.PaperR10 in
open ErdosProblems.Erdos1049.PaperR11 in
open ErdosProblems.Erdos1049.PaperR12 in
open ErdosProblems.Erdos1049.PaperR13 in
theorem solution (p : ℝ) (hp : 1 < p) (n : ℕ) :
    PaperR9.polynomialRemainder sourceU sourceV PaperR7.paperLambert p n =
      (sourceComplement n).eval₂ (Int.castRingHom ℝ) p * sourcePositiveH p⁻¹ n /
        p ^ sourceM n := by
  have hp0 := (zero_lt_one.trans hp).ne'
  apply (eq_div_iff (pow_ne_zero _ hp0)).mpr
  unfold PaperR9.polynomialRemainder
  have hA := actual_real_A_normalisation p n
  have hB := actual_real_B_normalisation p hp n
  have hH := actual_A_F_sub_B_eq_H_real p hp n
  calc
    _ = ((sourceComplement n).eval₂ (Int.castRingHom ℝ) p *
        (sourceA n).eval₂ (Int.castRingHom ℝ) p) * PaperR7.paperLambert p -
      (sourceComplement n).eval₂ (Int.castRingHom ℝ) p * sourceBReal n p := by
        rw [hA, hB]
        ring
    _ = _ := by rw [mul_assoc, ← mul_sub, hH]
