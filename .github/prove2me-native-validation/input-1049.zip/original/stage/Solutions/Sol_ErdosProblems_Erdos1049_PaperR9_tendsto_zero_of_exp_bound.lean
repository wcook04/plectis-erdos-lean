import Definitions.Def_ErdosProblems_Erdos1049_PaperAsymptoticsR9
import Lean.Elab.Tactic.Omega
import Mathlib.Algebra.BigOperators.Group.Finset.Basic
import Mathlib.Algebra.Module.BigOperators
import Mathlib.Algebra.Module.Prod
import Mathlib.Analysis.Asymptotics.Defs
import Mathlib.Analysis.SpecialFunctions.Log.Basic
import Mathlib.Analysis.SpecialFunctions.Pow.Real
import Mathlib.Data.Fintype.Pi
import Mathlib.Data.ZMod.Basic
import Mathlib.NumberTheory.Real.Irrational
import Mathlib.RingTheory.Coprime.Basic
import Mathlib.Tactic
import Mathlib.Tactic.Choose
import Mathlib.Tactic.Push
import Mathlib.Tactic.Ring
import Mathlib.Topology.MetricSpace.Pseudo.Defs

/-!
Quadratic asymptotic transfer, revision of the round-8 return.
Compiled. This file contains proof text, not a kernel receipt.

The asymptotic hypotheses below are estimates, not assumptions of the conclusions.
In particular `cross_product_limits` proves both successor products. The integer
contradiction is the desk's repaired PaperRankTwoCapR7 theorem, reused unchanged.

Pinned API: Mathlib 5e932f97dd25535344f80f9dd8da3aab83df0fe6.
Filter/metric API: Order/Filter/AtTopBot/Basic.lean and
Topology/MetricSpace/Pseudo/Defs.lean. Exponential/log API:
Analysis/SpecialFunctions/Exp.lean and Log/Basic.lean. Elementary ordered-field
algebra is handled by ring, linarith and explicitly supplied polynomial facts.
-/

namespace ErdosProblems.Erdos1049.PaperR9
open Filter Asymptotics
open scoped Topology
end ErdosProblems.Erdos1049.PaperR9

open Filter Asymptotics
open scoped Topology
open ErdosProblems in
open ErdosProblems.Erdos1049 in
open ErdosProblems.Erdos1049.PaperR9 in
theorem solution (f : ℕ → ℝ) (c : ℝ) (hc : 0 < c)
    (hf : ∀ᶠ n in atTop, |f n| ≤ Real.exp (-c * sqScale n)) :
    Tendsto f atTop (𝓝 0) := by
  apply Metric.tendsto_atTop.2
  intro ε hε
  obtain ⟨N, hN⟩ := eventually_atTop.1 hf
  obtain ⟨M, hM⟩ := exists_nat_gt (max 1 (-Real.log ε / c))
  refine ⟨max N M, ?_⟩
  intro n hn
  have hnN : N ≤ n := (le_max_left _ _).trans hn
  have hnM : M ≤ n := (le_max_right _ _).trans hn
  have hm : (M : ℝ) ≤ n := by exact_mod_cast hnM
  have hn1 : (1 : ℝ) ≤ n := (le_max_left _ _).trans (hM.le.trans hm)
  have hnlog : -Real.log ε / c < (n : ℝ) :=
    (le_max_right _ _).trans_lt (hM.trans_le hm)
  have hp : -Real.log ε < (n : ℝ) * c := (div_lt_iff₀ hc).mp hnlog
  have hsq : (n : ℝ) ≤ sqScale n := by
    dsimp [sqScale]
    nlinarith
  have hcscale := mul_le_mul_of_nonneg_left hsq hc.le
  have hexp : -c * sqScale n < Real.log ε := by nlinarith
  have hsmall : |f n| < ε := calc
    |f n| ≤ Real.exp (-c * sqScale n) := hN n hnN
    _ < Real.exp (Real.log ε) := Real.exp_lt_exp.mpr hexp
    _ = ε := Real.exp_log hε
  simpa only [Real.dist_eq, sub_zero] using hsmall
