import Definitions.Def_ErdosProblems_Erdos1049_BezoutPluckerJets
import Definitions.Def_ErdosProblems_Erdos1049_QBinomialUnitIdentity
import Definitions.Def_ErdosProblems_Erdos1049_FiniteResidueInterpolationR14
import Definitions.Def_ErdosProblems_Erdos1049_ZudilinHeightRegion
import Definitions.Def_ErdosProblems_Erdos1049_RationalBaseContour
import Definitions.Def_ErdosProblems_Erdos1049_ZudilinConeArithmetic
import Definitions.Def_ErdosProblems_Erdos1049_PaperLinearFormsR7
import Definitions.Def_ErdosProblems_Erdos1049_PaperOmegaIndicatorR7
import Definitions.Def_ErdosProblems_Erdos1049_QProductBoundsR10
import Definitions.Def_ErdosProblems_Erdos1049_SourcePolynomialR11
import Definitions.Def_ErdosProblems_Erdos1049_SourceBClearingR12
import Definitions.Def_ErdosProblems_Erdos1049_LambertSourceSummationR14
import Definitions.Def_ErdosProblems_Erdos1049_ReciprocalPochhammerR14
import Definitions.Def_ErdosProblems_Erdos1049_ActualSourceResiduesR14
import Definitions.Def_ErdosProblems_Erdos1049_PaperAsymptoticsR9
import Definitions.Def_ErdosProblems_Erdos1049_SourcePositiveHBoundsR10
import Definitions.Def_ErdosProblems_Erdos1049_ActualSourceAnalyticIdentityR14
import Definitions.Def_ErdosProblems_Erdos1049_GaussianDegreeR12
import Definitions.Def_ErdosProblems_Erdos1049_PaperShortCapR9
import Definitions.Def_ErdosProblems_Erdos1049_SourceFiniteTransformR12
import Definitions.Def_ErdosProblems_Erdos1049_SourceHomogeneousR12
import Definitions.Def_ErdosProblems_Erdos1049_RootUnityLocalCancellationR13
import Definitions.Def_ErdosProblems_Erdos1049_SourceBMonomialR12
import Definitions.Def_ErdosProblems_Erdos1049_SourceBTopDegreeR13
import Definitions.Def_ErdosProblems_Erdos1049_SourceRootCarriesR13
import Definitions.Def_ErdosProblems_Erdos1049_SourceRootBlocksR13
import Definitions.Def_ErdosProblems_Erdos1049_SourceOmegaCancellationR13
import Definitions.Def_ErdosProblems_Erdos1049_ActualAGrowthR14
import Theorems.Thm_ErdosProblems_Erdos1049_BezoutPluckerJets_bezoutPluckerEquiv_apply
import Theorems.Thm_ErdosProblems_Erdos1049_PaperR12_sourceASummandDegree_last
import Theorems.Thm_ErdosProblems_Erdos1049_PaperR12_sourceASummandDegree_succ
import Theorems.Thm_ErdosProblems_Erdos1049_PaperR12_sourceASummandDegree_strict
import Theorems.Thm_ErdosProblems_Erdos1049_gaussBinom_zero_succ
import Theorems.Thm_ErdosProblems_Erdos1049_qPochhammer_zero
import Theorems.Thm_ErdosProblems_Erdos1049_PaperR10_qPochhammerInfinity_pos
import Theorems.Thm_ErdosProblems_Erdos1049_PaperR14_actual_AS_fixed_base_bounds
import Lean.Elab.Tactic.Omega
import Mathlib
import Mathlib.Algebra.BigOperators.Group.Finset.Basic
import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Algebra.Module.BigOperators
import Mathlib.Algebra.Module.Prod
import Mathlib.Algebra.Order.Floor.Ring
import Mathlib.Algebra.Order.Ring.Abs
import Mathlib.Algebra.Polynomial.Coeff
import Mathlib.Algebra.Polynomial.Eval.Defs
import Mathlib.Algebra.Polynomial.Roots
import Mathlib.Analysis.Asymptotics.Defs
import Mathlib.Analysis.PSeries
import Mathlib.Analysis.Real.Pi.Bounds
import Mathlib.Analysis.SpecialFunctions.Log.Basic
import Mathlib.Analysis.SpecialFunctions.Pow.Real
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Data.Fintype.Pi
import Mathlib.Data.Fintype.Pigeonhole
import Mathlib.Data.Nat.Choose.Basic
import Mathlib.Data.Real.Basic
import Mathlib.Data.ZMod.Basic
import Mathlib.Data.ZMod.Coprime
import Mathlib.NumberTheory.Real.Irrational
import Mathlib.NumberTheory.ZetaValues
import Mathlib.RingTheory.Coprime.Basic
import Mathlib.RingTheory.Polynomial.Cyclotomic.Basic
import Mathlib.Tactic
import Mathlib.Tactic.Choose
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Push
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.InfiniteSum.Real
import Mathlib.Topology.Algebra.InfiniteSum.Ring
import Mathlib.Topology.MetricSpace.Pseudo.Defs

namespace PaperR10
end PaperR10

namespace PaperR11
end PaperR11

namespace PaperR12
end PaperR12

/-!
# Fixed-base growth of the actual alternating A polynomial

Proves two-sided fixed-base bounds and the quadratic log rate of A_n(p).

Gaussian reciprocity is proved from finite factorial identities. Every earlier
summand loses at least n powers against the last one. The resulting tail is
bounded by a constant times n*q^n, which tends to zero. Thus possible alternating
cancellation is controlled before logarithms or a quadratic rate are asserted.
-/

namespace ErdosProblems.Erdos1049.PaperR14
set_option maxHeartbeats 1000000
open Polynomial Finset Filter Asymptotics
open PaperR10 PaperR11 PaperR12
open scoped BigOperators Topology











lemma actual_A_degree_gap (n s : ℕ) (hs : s < 13 * n) :
    sourceASummandDegree n s + n ≤ sourceK n := by
  have hstep := sourceASummandDegree_succ n s hs
  have htop : sourceASummandDegree n (s + 1) ≤ sourceASummandDegree n (13 * n) := by
    rcases lt_or_eq_of_le (show s + 1 ≤ 13 * n by omega) with h | h
    · exact (sourceASummandDegree_strict n h le_rfl).le
    · rw [h]
  rw [sourceASummandDegree_last] at htop
  omega





lemma actual_A_earlier_bound (p : ℝ) (hp : 1 < p) (n : ℕ) :
    |actualAEarlierSum p n| ≤ p ^ sourceK n * actualATailBound p⁻¹ n := by
  have hp0 := zero_lt_one.trans hp
  unfold actualAEarlierSum
  apply (abs_sum_le_sum_abs _ _).trans
  calc
    _ ≤ ∑ s ∈ range (13 * n),
        p ^ sourceK n * ((qPochhammerInfinity p⁻¹ p⁻¹)⁻¹) ^ 2 * (p⁻¹) ^ n := by
      apply sum_le_sum
      intro s hs
      have hs' := mem_range.mp hs
      have hterm := (actual_AS_fixed_base_bounds p hp n s hs'.le).2
      have hpow := pow_le_pow_right₀ hp.le (actual_A_degree_gap n s hs')
      have hmul := mul_le_mul_of_nonneg_right hpow (pow_nonneg (inv_nonneg.mpr hp0.le) n)
      rw [pow_add] at hmul
      have he : (p ^ sourceASummandDegree n s * p ^ n) * (p⁻¹) ^ n =
          p ^ sourceASummandDegree n s := by simp [inv_pow, hp0.ne', mul_assoc]
      rw [he] at hmul
      exact hterm.trans (by
        have h := mul_le_mul_of_nonneg_right hmul (sq_nonneg ((qPochhammerInfinity p⁻¹ p⁻¹)⁻¹))
        simpa only [mul_assoc, mul_left_comm, mul_comm] using h)
    _ = _ := by simp [actualATailBound]; ring

lemma actual_A_last_split (p : ℝ) (n : ℕ) :
    (sourceA n).eval₂ (Int.castRingHom ℝ) p = actualAEarlierSum p n +
      (sourceASummand n (13 * n)).eval₂ (Int.castRingHom ℝ) p := by
  simp only [sourceA, eval₂_finset_sum, eval₂_add, sum_range_succ, actualAEarlierSum]

lemma actualATailBound_tendsto_zero {q : ℝ} (hq0 : 0 < q) (hq1 : q < 1) :
    Tendsto (actualATailBound q) atTop (𝓝 0) := by
  have hnorm : ‖q‖ < 1 := by simpa [Real.norm_eq_abs, abs_of_pos hq0] using hq1
  have h := (hasSum_coe_mul_geometric_of_norm_lt_one hnorm).summable.tendsto_atTop_zero
  have hm := h.const_mul (13 * ((qPochhammerInfinity q q)⁻¹) ^ 2)
  rw [mul_zero] at hm
  refine hm.congr (fun n => ?_)
  dsimp only [actualATailBound]
  ring
end ErdosProblems.Erdos1049.PaperR14

set_option maxHeartbeats 1000000
open Polynomial Finset Filter Asymptotics
open PaperR10 PaperR11 PaperR12
open scoped BigOperators Topology
open ErdosProblems in
open ErdosProblems.Erdos1049 in
open ErdosProblems.Erdos1049.PaperR14 in
open ErdosProblems.Erdos1049.PaperR10 in
open ErdosProblems.Erdos1049.PaperR11 in
open ErdosProblems.Erdos1049.PaperR12 in
theorem solution (p : ℝ) (hp : 1 < p) :
    ∃ L U : ℝ, 0 < L ∧ 0 < U ∧ ∀ᶠ n : ℕ in atTop,
      L * p ^ sourceK n ≤ |(sourceA n).eval₂ (Int.castRingHom ℝ) p| ∧
      |(sourceA n).eval₂ (Int.castRingHom ℝ) p| ≤ U * p ^ sourceK n := by
  let P := qPochhammerInfinity p⁻¹ p⁻¹
  have hP : 0 < P := qPochhammerInfinity_pos _ _
  have hp0 := zero_lt_one.trans hp
  have hq0 := inv_pos.mpr hp0
  have hq1 := (inv_lt_one₀ hp0).mpr hp
  refine ⟨P ^ 2 / 2, (P⁻¹) ^ 2 + P ^ 2 / 2, by positivity, by positivity, ?_⟩
  have hsmall : ∀ᶠ n in atTop, actualATailBound p⁻¹ n < P ^ 2 / 2 :=
    (actualATailBound_tendsto_zero hq0 hq1).eventually (Iio_mem_nhds (by positivity))
  filter_upwards [hsmall] with n hn
  have htop := actual_AS_fixed_base_bounds p hp n (13 * n) le_rfl
  rw [sourceASummandDegree_last] at htop
  have htail := actual_A_earlier_bound p hp n
  have hpow : 0 ≤ p ^ sourceK n := (pow_pos hp0 _).le
  have htail' : |actualAEarlierSum p n| ≤ p ^ sourceK n * (P ^ 2 / 2) :=
    htail.trans (mul_le_mul_of_nonneg_left hn.le hpow)
  have habs := abs_add_le (actualAEarlierSum p n)
    ((sourceASummand n (13 * n)).eval₂ (Int.castRingHom ℝ) p)
  rw [← actual_A_last_split] at habs
  have hrev := abs_sub ((sourceA n).eval₂ (Int.castRingHom ℝ) p) (actualAEarlierSum p n)
  have hdiff : (sourceA n).eval₂ (Int.castRingHom ℝ) p - actualAEarlierSum p n =
      (sourceASummand n (13 * n)).eval₂ (Int.castRingHom ℝ) p := by rw [actual_A_last_split]; ring
  rw [hdiff] at hrev
  change p ^ sourceK n * P ^ 2 ≤
      |(sourceASummand n (13 * n)).eval₂ (Int.castRingHom ℝ) p| ∧
    |(sourceASummand n (13 * n)).eval₂ (Int.castRingHom ℝ) p| ≤
      p ^ sourceK n * (P⁻¹) ^ 2 at htop
  constructor <;> nlinarith
