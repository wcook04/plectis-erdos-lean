import Definitions.Def_ErdosProblems_Erdos1049_BezoutPluckerJets
import Definitions.Def_ErdosProblems_Erdos1049_QBinomialUnitIdentity
import Definitions.Def_ErdosProblems_Erdos1049_FiniteResidueInterpolationR14
import Definitions.Def_ErdosProblems_Erdos1049_ZudilinHeightRegion
import Definitions.Def_ErdosProblems_Erdos1049_RationalBaseContour
import Definitions.Def_ErdosProblems_Erdos1049_ZudilinConeArithmetic
import Definitions.Def_ErdosProblems_Erdos1049_PaperLinearFormsR7
import Definitions.Def_ErdosProblems_Erdos1049_PaperOmegaIndicatorR7
import Definitions.Def_ErdosProblems_Erdos1049_QProductBoundsR10
import Definitions.Def_ErdosProblems_Erdos1049_SourcePolynomialR11
import Definitions.Def_ErdosProblems_Erdos1049_SourceBClearingR12
import Definitions.Def_ErdosProblems_Erdos1049_LambertSourceSummationR14
import Definitions.Def_ErdosProblems_Erdos1049_ReciprocalPochhammerR14
import Definitions.Def_ErdosProblems_Erdos1049_ActualSourceResiduesR14
import Definitions.Def_ErdosProblems_Erdos1049_PaperAsymptoticsR9
import Definitions.Def_ErdosProblems_Erdos1049_SourcePositiveHBoundsR10
import Definitions.Def_ErdosProblems_Erdos1049_ActualSourceAnalyticIdentityR14
import Definitions.Def_ErdosProblems_Erdos1049_GaussianDegreeR12
import Definitions.Def_ErdosProblems_Erdos1049_PaperShortCapR9
import Definitions.Def_ErdosProblems_Erdos1049_SourceFiniteTransformR12
import Definitions.Def_ErdosProblems_Erdos1049_SourceHomogeneousR12
import Definitions.Def_ErdosProblems_Erdos1049_RootUnityLocalCancellationR13
import Definitions.Def_ErdosProblems_Erdos1049_SourceBMonomialR12
import Definitions.Def_ErdosProblems_Erdos1049_SourceBTopDegreeR13
import Definitions.Def_ErdosProblems_Erdos1049_SourceRootCarriesR13
import Definitions.Def_ErdosProblems_Erdos1049_SourceRootBlocksR13
import Definitions.Def_ErdosProblems_Erdos1049_SourceOmegaCancellationR13
import Definitions.Def_ErdosProblems_Erdos1049_ActualAGrowthR14
import Theorems.Thm_ErdosProblems_Erdos1049_PaperR9_sqScale_nonneg
import Theorems.Thm_ErdosProblems_Erdos1049_PaperR9_eventually_linear_le_square
import Theorems.Thm_ErdosProblems_Erdos1049_PaperR14_sourceK_quadratic_residual
import Theorems.Thm_ErdosProblems_Erdos1049_PaperR14_actual_A_eventual_two_sided
import Lean.Elab.Tactic.Omega
import Mathlib
import Mathlib.Algebra.BigOperators.Group.Finset.Basic
import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Algebra.Module.BigOperators
import Mathlib.Algebra.Module.Prod
import Mathlib.Algebra.Order.Floor.Ring
import Mathlib.Algebra.Order.Ring.Abs
import Mathlib.Algebra.Polynomial.Coeff
import Mathlib.Algebra.Polynomial.Eval.Defs
import Mathlib.Algebra.Polynomial.Roots
import Mathlib.Analysis.Asymptotics.Defs
import Mathlib.Analysis.PSeries
import Mathlib.Analysis.Real.Pi.Bounds
import Mathlib.Analysis.SpecialFunctions.Log.Basic
import Mathlib.Analysis.SpecialFunctions.Pow.Real
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Data.Fintype.Pi
import Mathlib.Data.Fintype.Pigeonhole
import Mathlib.Data.Nat.Choose.Basic
import Mathlib.Data.Real.Basic
import Mathlib.Data.ZMod.Basic
import Mathlib.Data.ZMod.Coprime
import Mathlib.NumberTheory.Real.Irrational
import Mathlib.NumberTheory.ZetaValues
import Mathlib.RingTheory.Coprime.Basic
import Mathlib.RingTheory.Polynomial.Cyclotomic.Basic
import Mathlib.Tactic
import Mathlib.Tactic.Choose
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Push
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.InfiniteSum.Real
import Mathlib.Topology.Algebra.InfiniteSum.Ring
import Mathlib.Topology.MetricSpace.Pseudo.Defs

namespace PaperR10
end PaperR10

namespace PaperR11
end PaperR11

namespace PaperR12
end PaperR12

/-!
# Fixed-base growth of the actual alternating A polynomial

Proves two-sided fixed-base bounds and the quadratic log rate of A_n(p).

Gaussian reciprocity is proved from finite factorial identities. Every earlier
summand loses at least n powers against the last one. The resulting tail is
bounded by a constant times n*q^n, which tends to zero. Thus possible alternating
cancellation is controlled before logarithms or a quadratic rate are asserted.
-/

namespace ErdosProblems.Erdos1049.PaperR14
set_option maxHeartbeats 1000000
open Polynomial Finset Filter Asymptotics
open PaperR10 PaperR11 PaperR12
open scoped BigOperators Topology
end ErdosProblems.Erdos1049.PaperR14

set_option maxHeartbeats 1000000
open Polynomial Finset Filter Asymptotics
open PaperR10 PaperR11 PaperR12
open scoped BigOperators Topology
open ErdosProblems in
open ErdosProblems.Erdos1049 in
open ErdosProblems.Erdos1049.PaperR14 in
open ErdosProblems.Erdos1049.PaperR10 in
open ErdosProblems.Erdos1049.PaperR11 in
open ErdosProblems.Erdos1049.PaperR12 in
theorem solution (p : ℝ) (hp : 1 < p) :
    PaperR9.QuadLogRate (fun n => (sourceA n).eval₂ (Int.castRingHom ℝ) p)
      ((1091 / 2 : ℝ) * Real.log p) := by
  obtain ⟨L, U, hL, hU, hb⟩ := actual_A_eventual_two_sided p hp
  let C := |Real.log L| + |Real.log U|
  have hC : 0 ≤ C := add_nonneg (abs_nonneg _) (abs_nonneg _)
  have hp0 := zero_lt_one.trans hp
  have hlog : 0 ≤ Real.log p := Real.log_nonneg hp.le
  apply Asymptotics.IsLittleO.of_bound
  intro ε hε
  filter_upwards [hb,
    PaperR9.eventually_linear_le_square (C + 42 * Real.log p) ε
      (by positivity) hε] with n hn hεn
  have hA : 0 < |(sourceA n).eval₂ (Int.castRingHom ℝ) p| :=
    (mul_pos hL (pow_pos hp0 _)).trans_le hn.1
  have hlo := Real.log_le_log (mul_pos hL (pow_pos hp0 _)) hn.1
  have hup := Real.log_le_log hA hn.2
  rw [Real.log_mul hL.ne' (pow_ne_zero _ hp0.ne'), Real.log_pow] at hlo
  rw [Real.log_mul hU.ne' (pow_ne_zero _ hp0.ne'), Real.log_pow] at hup
  have hres : |Real.log |(sourceA n).eval₂ (Int.castRingHom ℝ) p| -
      (sourceK n : ℝ) * Real.log p| ≤ C := by
    rw [abs_le]
    dsimp [C]
    constructor <;> linarith [le_abs_self (Real.log U), neg_le_abs (Real.log L),
      abs_nonneg (Real.log L), abs_nonneg (Real.log U)]
  have hk := mul_le_mul_of_nonneg_right (sourceK_quadratic_residual n) hlog
  have hsplit :
      Real.log |(sourceA n).eval₂ (Int.castRingHom ℝ) p| -
          ((1091 / 2 : ℝ) * Real.log p) * PaperR9.sqScale n =
      (Real.log |(sourceA n).eval₂ (Int.castRingHom ℝ) p| -
          (sourceK n : ℝ) * Real.log p) +
        ((sourceK n : ℝ) - (1091 / 2 : ℝ) * (n : ℝ) ^ 2) * Real.log p := by
    simp only [PaperR9.sqScale]
    ring
  simp only [Real.norm_eq_abs, abs_of_nonneg (PaperR9.sqScale_nonneg n)]
  rw [hsplit]
  apply (abs_add_le _ _).trans
  have hk' : |((sourceK n : ℝ) - (1091 / 2 : ℝ) * (n : ℝ) ^ 2) * Real.log p| ≤
      42 * (2 * (n : ℝ) + 1) * Real.log p := by
    simpa only [abs_mul, abs_of_nonneg hlog] using hk
  have hn0 : (0 : ℝ) ≤ n := Nat.cast_nonneg n
  have htotal : C + 42 * (2 * (n : ℝ) + 1) * Real.log p ≤
      (C + 42 * Real.log p) * (2 * (n : ℝ) + 1) := by nlinarith
  exact (add_le_add hres hk').trans (htotal.trans hεn)
