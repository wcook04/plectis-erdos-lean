import Definitions.Def_ErdosProblems_Erdos1049_BezoutPluckerJets
import Definitions.Def_ErdosProblems_Erdos1049_QBinomialUnitIdentity
import Definitions.Def_ErdosProblems_Erdos1049_FiniteResidueInterpolationR14
import Definitions.Def_ErdosProblems_Erdos1049_ZudilinHeightRegion
import Definitions.Def_ErdosProblems_Erdos1049_RationalBaseContour
import Definitions.Def_ErdosProblems_Erdos1049_ZudilinConeArithmetic
import Definitions.Def_ErdosProblems_Erdos1049_PaperLinearFormsR7
import Definitions.Def_ErdosProblems_Erdos1049_PaperOmegaIndicatorR7
import Definitions.Def_ErdosProblems_Erdos1049_QProductBoundsR10
import Definitions.Def_ErdosProblems_Erdos1049_SourcePolynomialR11
import Definitions.Def_ErdosProblems_Erdos1049_SourceBClearingR12
import Definitions.Def_ErdosProblems_Erdos1049_LambertSourceSummationR14
import Definitions.Def_ErdosProblems_Erdos1049_ReciprocalPochhammerR14
import Definitions.Def_ErdosProblems_Erdos1049_ActualSourceResiduesR14
import Definitions.Def_ErdosProblems_Erdos1049_PaperAsymptoticsR9
import Definitions.Def_ErdosProblems_Erdos1049_SourcePositiveHBoundsR10
import Definitions.Def_ErdosProblems_Erdos1049_ActualSourceAnalyticIdentityR14
import Definitions.Def_ErdosProblems_Erdos1049_GaussianDegreeR12
import Definitions.Def_ErdosProblems_Erdos1049_PaperShortCapR9
import Definitions.Def_ErdosProblems_Erdos1049_SourceFiniteTransformR12
import Definitions.Def_ErdosProblems_Erdos1049_SourceHomogeneousR12
import Definitions.Def_ErdosProblems_Erdos1049_RootUnityLocalCancellationR13
import Definitions.Def_ErdosProblems_Erdos1049_SourceBMonomialR12
import Definitions.Def_ErdosProblems_Erdos1049_SourceBTopDegreeR13
import Definitions.Def_ErdosProblems_Erdos1049_SourceRootCarriesR13
import Definitions.Def_ErdosProblems_Erdos1049_SourceRootBlocksR13
import Definitions.Def_ErdosProblems_Erdos1049_SourceOmegaCancellationR13
import Definitions.Def_ErdosProblems_Erdos1049_G02ArithmeticR16
import Definitions.Def_ErdosProblems_Erdos1049_SourceHeightRateR14
import Definitions.Def_ErdosProblems_Erdos1049_WeightedFloorBlocksR12
import Definitions.Def_ErdosProblems_Erdos1049_G02WeightedBlocksR16
import Definitions.Def_ErdosProblems_Erdos1049_G02CyclotomicR16
import Theorems.Thm_ErdosProblems_Erdos1049_PaperR16_QuadRateR16_congr_eventually
import Theorems.Thm_ErdosProblems_Erdos1049_PaperR16_QuadRateR16_add
import Theorems.Thm_ErdosProblems_Erdos1049_PaperR16_QuadRateR16_const_mul
import Theorems.Thm_ErdosProblems_Erdos1049_PaperR16_actual_complement_degree_rateR16
import Theorems.Thm_ErdosProblems_Erdos1049_PaperR16_rate_of_eventual_linear_errorR16
import Theorems.Thm_ErdosProblems_Erdos1049_PaperR16_actual_complement_posR16
import Theorems.Thm_ErdosProblems_Erdos1049_PaperR16_actual_complement_log_errorR16
import Lean.Elab.Tactic.Omega
import Mathlib
import Mathlib.Algebra.BigOperators.Group.Finset.Basic
import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Algebra.Module.BigOperators
import Mathlib.Algebra.Module.Prod
import Mathlib.Algebra.Order.Floor.Ring
import Mathlib.Algebra.Order.Ring.Abs
import Mathlib.Algebra.Order.Ring.Int
import Mathlib.Algebra.Polynomial.Coeff
import Mathlib.Algebra.Polynomial.Eval.Defs
import Mathlib.Algebra.Polynomial.Roots
import Mathlib.Analysis.Asymptotics.Defs
import Mathlib.Analysis.PSeries
import Mathlib.Analysis.Real.Pi.Bounds
import Mathlib.Analysis.SpecialFunctions.Log.Basic
import Mathlib.Analysis.SpecialFunctions.Pow.Asymptotics
import Mathlib.Analysis.SpecialFunctions.Pow.Real
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.Data.Fintype.Pi
import Mathlib.Data.Fintype.Pigeonhole
import Mathlib.Data.Nat.Choose.Basic
import Mathlib.Data.Real.Basic
import Mathlib.Data.ZMod.Basic
import Mathlib.Data.ZMod.Coprime
import Mathlib.NumberTheory.ArithmeticFunction.Moebius
import Mathlib.NumberTheory.Harmonic.Bounds
import Mathlib.NumberTheory.Real.Irrational
import Mathlib.NumberTheory.ZetaValues
import Mathlib.Order.LiminfLimsup
import Mathlib.RingTheory.Coprime.Basic
import Mathlib.RingTheory.Polynomial.Cyclotomic.Basic
import Mathlib.Tactic
import Mathlib.Tactic.Choose
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Push
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.InfiniteSum.Real
import Mathlib.Topology.Algebra.InfiniteSum.Ring
import Mathlib.Topology.MetricSpace.Pseudo.Defs

namespace PaperR10
end PaperR10

namespace PaperR11
end PaperR11

namespace PaperR12
end PaperR12

namespace PaperR14
end PaperR14

/-!
# G02 fixed-base cyclotomic logarithms

The factors are the literal integer cyclotomic polynomials, including Φ₁.
The all-index O_p(n) estimate uses a uniform summable-log majorant, rather
than an incorrect O(log l) estimate near the moving unit circle.
Proves the quadratic log rate of the source complement at each real p > 1.
-/

namespace ErdosProblems.Erdos1049.PaperR16
open Polynomial Finset Filter Asymptotics
open PaperR10 PaperR11 PaperR12 PaperR14
open scoped BigOperators Topology
set_option maxHeartbeats 3000000
end ErdosProblems.Erdos1049.PaperR16

open Polynomial Finset Filter Asymptotics
open PaperR10 PaperR11 PaperR12 PaperR14
open scoped BigOperators Topology
set_option maxHeartbeats 3000000
open ErdosProblems in
open ErdosProblems.Erdos1049 in
open ErdosProblems.Erdos1049.PaperR16 in
open ErdosProblems.Erdos1049.PaperR10 in
open ErdosProblems.Erdos1049.PaperR11 in
open ErdosProblems.Erdos1049.PaperR12 in
open ErdosProblems.Erdos1049.PaperR14 in
theorem solution (p : ℝ) (hp : 1 < p) :
    PaperR9.QuadLogRate (complementEvalR16 p) (sourceGammaR16*Real.log p) := by
  have hA : 0 ≤ 15*logTailMajorantR16 p⁻¹ := by
    unfold logTailMajorantR16
    have hp0 := zero_lt_one.trans hp
    positivity
  have he : QuadRateR16 (fun n => Real.log (complementEvalR16 p n)-
      complementDegreeR16 n*Real.log p) 0 := by
    apply rate_of_eventual_linear_errorR16 _ 0 (15*logTailMajorantR16 p⁻¹) hA
    exact Eventually.of_forall (fun n => by
      have h := actual_complement_log_errorR16 p hp n
      have hn0 : (0 : ℝ) ≤ n := Nat.cast_nonneg _
      simp only [zero_mul, sub_zero]
      exact h.trans (by nlinarith))
  have hd := actual_complement_degree_rateR16.const_mul (Real.log p)
  have h := hd.add he
  simp only [add_zero] at h
  rw [mul_comm (Real.log p) sourceGammaR16] at h
  apply QuadRateR16.congr_eventually h
  exact Eventually.of_forall (fun n => by
    rw [abs_of_pos (actual_complement_posR16 p hp n)]
    ring)
