import Definitions.Def_ErdosProblems_Erdos1049_ZudilinConeArithmetic
import Theorems.Thm_ErdosProblems_Erdos1049_PaperR7_homEval_cast_eq_real_eval
import Mathlib.Algebra.Polynomial.Eval.Defs
import Mathlib.Data.Fintype.Pigeonhole
import Mathlib.Data.ZMod.Basic
import Mathlib.Data.ZMod.Coprime
import Mathlib.RingTheory.Polynomial.Cyclotomic.Basic
import Mathlib.Tactic

namespace ErdosProblems.Erdos1049.PaperR7
end ErdosProblems.Erdos1049.PaperR7

/-!
# R7: integral homogeneous evaluation at a rational base

Compiled proof-source candidate. This is the finite algebraic bridge in the
main irrationality proof, not the existence or asymptotics of the cancelled
source forms. It reuses `homEval`; it does not define a different clearing.

All degrees below are natural degrees. This is harmless for a zero polynomial:
its natural degree is zero and every displayed evaluation identity still holds.
-/

namespace ErdosProblems.Erdos1049.PaperR7
open scoped BigOperators
end ErdosProblems.Erdos1049.PaperR7

open scoped BigOperators
open ErdosProblems in
open ErdosProblems.Erdos1049 in
open ErdosProblems.Erdos1049.PaperR7 in
theorem solution (a b W : ℕ) (U V : Polynomial ℤ)
    (ξ : ℝ) (hb : b ≠ 0)
    (hU : U.natDegree ≤ W) (hV : V.natDegree ≤ W) :
    (homEval a b W U : ℝ) * ξ - (homEval a b W V : ℝ) =
      (b : ℝ) ^ W *
        (U.eval₂ (Int.castRingHom ℝ) ((a : ℝ) / b) * ξ -
          V.eval₂ (Int.castRingHom ℝ) ((a : ℝ) / b)) := by
  rw [homEval_cast_eq_real_eval a b W U hb hU,
    homEval_cast_eq_real_eval a b W V hb hV]
  ring
