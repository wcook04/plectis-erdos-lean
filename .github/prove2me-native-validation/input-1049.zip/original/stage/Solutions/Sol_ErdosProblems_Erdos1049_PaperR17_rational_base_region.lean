import Definitions.Def_ErdosProblems_Erdos1049_BezoutPluckerJets
import Definitions.Def_ErdosProblems_Erdos1049_QBinomialUnitIdentity
import Definitions.Def_ErdosProblems_Erdos1049_FiniteResidueInterpolationR14
import Definitions.Def_ErdosProblems_Erdos1049_ZudilinHeightRegion
import Definitions.Def_ErdosProblems_Erdos1049_RationalBaseContour
import Definitions.Def_ErdosProblems_Erdos1049_ZudilinConeArithmetic
import Definitions.Def_ErdosProblems_Erdos1049_PaperLinearFormsR7
import Definitions.Def_ErdosProblems_Erdos1049_PaperOmegaIndicatorR7
import Definitions.Def_ErdosProblems_Erdos1049_QProductBoundsR10
import Definitions.Def_ErdosProblems_Erdos1049_SourcePolynomialR11
import Definitions.Def_ErdosProblems_Erdos1049_SourceBClearingR12
import Definitions.Def_ErdosProblems_Erdos1049_LambertSourceSummationR14
import Definitions.Def_ErdosProblems_Erdos1049_ReciprocalPochhammerR14
import Definitions.Def_ErdosProblems_Erdos1049_ActualSourceResiduesR14
import Definitions.Def_ErdosProblems_Erdos1049_PaperAsymptoticsR9
import Definitions.Def_ErdosProblems_Erdos1049_SourcePositiveHBoundsR10
import Definitions.Def_ErdosProblems_Erdos1049_ActualSourceAnalyticIdentityR14
import Definitions.Def_ErdosProblems_Erdos1049_GaussianDegreeR12
import Definitions.Def_ErdosProblems_Erdos1049_PaperShortCapR9
import Definitions.Def_ErdosProblems_Erdos1049_SourceFiniteTransformR12
import Definitions.Def_ErdosProblems_Erdos1049_SourceHomogeneousR12
import Definitions.Def_ErdosProblems_Erdos1049_RootUnityLocalCancellationR13
import Definitions.Def_ErdosProblems_Erdos1049_SourceBMonomialR12
import Definitions.Def_ErdosProblems_Erdos1049_SourceBTopDegreeR13
import Definitions.Def_ErdosProblems_Erdos1049_SourceRootCarriesR13
import Definitions.Def_ErdosProblems_Erdos1049_SourceRootBlocksR13
import Definitions.Def_ErdosProblems_Erdos1049_SourceOmegaCancellationR13
import Definitions.Def_ErdosProblems_Erdos1049_ActualAGrowthR14
import Definitions.Def_ErdosProblems_Erdos1049_G02ArithmeticR16
import Definitions.Def_ErdosProblems_Erdos1049_SourceHeightRateR14
import Definitions.Def_ErdosProblems_Erdos1049_WeightedFloorBlocksR12
import Definitions.Def_ErdosProblems_Erdos1049_G02WeightedBlocksR16
import Definitions.Def_ErdosProblems_Erdos1049_G02CyclotomicR16
import Definitions.Def_ErdosProblems_Erdos1049_G02SourceRatesR16
import Definitions.Def_ErdosProblems_Erdos1049_QuadraticMeasureR10
import Definitions.Def_ErdosProblems_Erdos1049_IrrationalityExponentR11
import Definitions.Def_ErdosProblems_Erdos1049_MeasureConstantsR10
import Definitions.Def_ErdosProblems_Erdos1049_PaperR17_SourceConsumers
import Theorems.Thm_ErdosProblems_Erdos1049_PaperR9_QuadLogRate_exp_upper
import Theorems.Thm_ErdosProblems_Erdos1049_PaperR16_actual_remainder_posR16
import Theorems.Thm_ErdosProblems_Erdos1049_PaperR16_quadLogRate_congrR16
import Theorems.Thm_ErdosProblems_Erdos1049_PaperR16_actual_cleared_remainder_rateR16
import Theorems.Thm_ErdosProblems_Erdos1049_PaperR17_rational_base_gt_one
import Theorems.Thm_ErdosProblems_Erdos1049_PaperR17_sourceU_le_width
import Theorems.Thm_ErdosProblems_Erdos1049_PaperR17_cleared_error_identity
import Theorems.Thm_ErdosProblems_Erdos1049_PaperR17_region_iff_positive_decay
import Theorems.Thm_ErdosProblems_Erdos1049_PaperR7_irrational_paperLambert_of_supply
import Theorems.Thm_ErdosProblems_Erdos1049_PaperR9_QuadExpUpper_tendsto_zero
import Lean.Elab.Tactic.Omega
import Mathlib
import Mathlib.Algebra.BigOperators.Group.Finset.Basic
import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Algebra.Module.BigOperators
import Mathlib.Algebra.Module.Prod
import Mathlib.Algebra.Order.Floor.Ring
import Mathlib.Algebra.Order.Ring.Abs
import Mathlib.Algebra.Order.Ring.Int
import Mathlib.Algebra.Polynomial.Coeff
import Mathlib.Algebra.Polynomial.Eval.Defs
import Mathlib.Algebra.Polynomial.Roots
import Mathlib.Analysis.Asymptotics.Defs
import Mathlib.Analysis.PSeries
import Mathlib.Analysis.Real.Pi.Bounds
import Mathlib.Analysis.SpecialFunctions.Log.Basic
import Mathlib.Analysis.SpecialFunctions.Pow.Asymptotics
import Mathlib.Analysis.SpecialFunctions.Pow.Real
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Data.Fintype.Pi
import Mathlib.Data.Fintype.Pigeonhole
import Mathlib.Data.Nat.Choose.Basic
import Mathlib.Data.Real.Basic
import Mathlib.Data.ZMod.Basic
import Mathlib.Data.ZMod.Coprime
import Mathlib.NumberTheory.ArithmeticFunction.Moebius
import Mathlib.NumberTheory.Harmonic.Bounds
import Mathlib.NumberTheory.Real.Irrational
import Mathlib.NumberTheory.ZetaValues
import Mathlib.Order.LiminfLimsup
import Mathlib.RingTheory.Coprime.Basic
import Mathlib.RingTheory.Polynomial.Cyclotomic.Basic
import Mathlib.Tactic
import Mathlib.Tactic.Choose
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Push
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.InfiniteSum.Real
import Mathlib.Topology.Algebra.InfiniteSum.Ring
import Mathlib.Topology.MetricSpace.Pseudo.Defs

namespace PaperR10
end PaperR10

namespace PaperR11
end PaperR11

namespace PaperR12
end PaperR12

namespace PaperR13
end PaperR13

namespace PaperR16
end PaperR16

namespace PaperR7
end PaperR7

namespace PaperR9
end PaperR9

/-!
# The literal G02 supplier, the original R7 consumer, and the power-uniform measure

Proves F(a/b) irrational on the contour region and F((31/4)^r) irrational.
No source-supply, rate, nonvanishing or positivity hypothesis is left in the
source endpoints. Homogeneous evaluations use the actual pair width.
-/

namespace ErdosProblems.Erdos1049.PaperR17
open PaperR7 PaperR9 PaperR10 PaperR11 PaperR12 PaperR13 PaperR16
open Filter
open scoped Topology BigOperators
set_option maxHeartbeats 3000000









lemma sourceV_le_width (n : ℕ) :
    (sourceV n).natDegree ≤ pairWidth sourceU sourceV n := le_max_right _ _









theorem cleared_error_rate (a b : ℕ) (hb : 0 < b) (hab : b < a) :
    QuadLogRate
      (fun n => (clearedA a b n : ℝ) * paperLambert ((a : ℝ) / b) - clearedB a b n)
      (-decayRate a b) := by
  have h := actual_cleared_remainder_rateR16 (a : ℝ) (b : ℝ)
    (by exact_mod_cast hb) (by exact_mod_cast hab)
  have hc : sourceC1R16 * Real.log b - sourceC0R16 * Real.log a = -decayRate a b := by
    unfold decayRate
    ring
  rw [hc] at h
  exact quadLogRate_congrR16 h
    (Eventually.of_forall (fun n => (cleared_error_identity a b n hb).symm))



/-- This is a witness of the original source-supply definition, not a replacement definition. -/
theorem actual_cancelled_supply (a b : ℕ) (hb : 0 < b) (hab : b < a)
    (hr : ZudilinContourRegion a b) : CancelledApproximationSupply a b := by
  have hp := rational_base_gt_one a b hb hab
  have hd : 0 < decayRate a b := (region_iff_positive_decay a b hb hab).mp hr
  refine ⟨sourceU, sourceV, pairWidth sourceU sourceV,
    sourceU_le_width, sourceV_le_width, ?_, ?_⟩
  · exact Eventually.of_forall (fun n => (actual_remainder_posR16 _ hp n).ne')
  · have h := (cleared_error_rate a b hb hab).exp_upper.tendsto_zero
      (neg_neg_of_pos hd)
    simpa only [cleared_error_identity a b _ hb, sourceRemainderR16, polynomialRemainder] using h
end ErdosProblems.Erdos1049.PaperR17

open PaperR7 PaperR9 PaperR10 PaperR11 PaperR12 PaperR13 PaperR16
open Filter
open scoped Topology BigOperators
set_option maxHeartbeats 3000000
open ErdosProblems in
open ErdosProblems.Erdos1049 in
open ErdosProblems.Erdos1049.PaperR17 in
open ErdosProblems.Erdos1049.PaperR10 in
open ErdosProblems.Erdos1049.PaperR11 in
open ErdosProblems.Erdos1049.PaperR12 in
open ErdosProblems.Erdos1049.PaperR13 in
open ErdosProblems.Erdos1049.PaperR16 in
open ErdosProblems.Erdos1049.PaperR7 in
open ErdosProblems.Erdos1049.PaperR9 in
theorem solution (a b : ℕ) (hb : 0 < b) (hab : b < a)
    (hr : ZudilinContourRegion a b) : Irrational (paperLambert ((a : ℝ) / b)) :=
  irrational_paperLambert_of_supply a b hb (actual_cancelled_supply a b hb hab hr)
