import Definitions.Def_ErdosProblems_Erdos1049_QBinomialUnitIdentity
import Definitions.Def_ErdosProblems_Erdos1049_FiniteResidueInterpolationR14
import Theorems.Thm_ErdosProblems_Erdos1049_PaperR14_poleProduct_eval
import Theorems.Thm_ErdosProblems_Erdos1049_PaperR14_poleProduct_degree
import Mathlib
import Mathlib.Algebra.BigOperators.Group.Finset.Basic
import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Algebra.Polynomial.Coeff
import Mathlib.Algebra.Polynomial.Eval.Defs
import Mathlib.Algebra.Polynomial.Roots
import Mathlib.Data.Nat.Choose.Basic
import Mathlib.Tactic

/-!
# Finite simple-pole interpolation, without a partial-fractions assumption

Interpolation in the pole basis and the finite simple-pole expansion.

The numerator is reconstructed from its values at the inverse pole parameters.
The only degree premise is the ordinary proper-fraction degree condition;
there is no premise asserting the partial-fraction identity. The following
source module supplies the concrete parameters and the numerator degree.
-/

namespace ErdosProblems.Erdos1049.PaperR14
set_option maxHeartbeats 1000000
open Polynomial Finset
open scoped BigOperators

variable {K : Type*} [Field K] {ι : Type*} [DecidableEq ι]







lemma poleProduct_erase_eval_ne_zero (b : ι → K) (s : Finset ι) (i : ι)
    (hi : i ∈ s) (hb0 : ∀ j ∈ s, b j ≠ 0)
    (hb : Set.InjOn b s) :
    (poleProduct b (s.erase i)).eval (b i)⁻¹ ≠ 0 := by
  rw [poleProduct_eval]
  apply prod_ne_zero_iff.mpr
  intro j hj
  obtain ⟨hji, hjs⟩ := mem_erase.mp hj
  intro hz
  have he : b j * (b i)⁻¹ = 1 := (sub_eq_zero.mp hz).symm
  have he' : b j = b i := by
    have hh := congrArg (fun x : K => x * b i) he
    simpa [hb0 i hi, mul_assoc] using hh
  exact hji (hb hjs hi he')





lemma poleInterpolant_eval_node (P : K[X]) (b : ι → K) (s : Finset ι)
    (i : ι) (hi : i ∈ s) (hb0 : ∀ j ∈ s, b j ≠ 0) (hb : Set.InjOn b s) :
    (poleInterpolant P b s).eval (b i)⁻¹ = P.eval (b i)⁻¹ := by
  classical
  unfold poleInterpolant
  rw [eval_finset_sum]
  rw [sum_eq_single i]
  · simp only [eval_mul, eval_C, poleResidue]
    exact div_mul_cancel₀ _ (poleProduct_erase_eval_ne_zero b s i hi hb0 hb)
  · intro j hj hji
    have him : i ∈ s.erase j := mem_erase.mpr ⟨Ne.symm hji, hi⟩
    have hz : (poleProduct b (s.erase j)).eval (b i)⁻¹ = 0 := by
      rw [poleProduct_eval]
      apply prod_eq_zero him
      simp [hb0 i hi]
    simp [hz]
  · exact fun hn => (hn hi).elim

lemma poleInterpolant_degree (P : K[X]) (b : ι → K) (s : Finset ι) :
    (poleInterpolant P b s).natDegree ≤ s.card - 1 := by
  classical
  unfold poleInterpolant
  apply natDegree_sum_le_of_forall_le
  intro i hi
  apply natDegree_mul_le.trans
  have hd := poleProduct_degree b (s.erase i)
  have hc : (s.erase i).card = s.card - 1 := card_erase_of_mem hi
  simpa only [natDegree_C, zero_add, hc] using hd
end ErdosProblems.Erdos1049.PaperR14

set_option maxHeartbeats 1000000
open Polynomial Finset
open scoped BigOperators
variable {K : Type*} [Field K] {ι : Type*} [DecidableEq ι]
open ErdosProblems in
open ErdosProblems.Erdos1049 in
open ErdosProblems.Erdos1049.PaperR14 in
theorem solution (P : K[X]) (b : ι → K) (s : Finset ι)
    (hdeg : P.natDegree < s.card) (hb0 : ∀ i ∈ s, b i ≠ 0)
    (hb : Set.InjOn b s) :
    P = poleInterpolant P b s := by
  classical
  apply eq_of_natDegree_lt_card_of_eval_eq P (poleInterpolant P b s)
    (f := fun i : s => (b i)⁻¹)
  · intro i j he
    apply Subtype.ext
    apply hb i.property j.property
    exact inv_injective he
  · intro i
    exact (poleInterpolant_eval_node P b s i i.property hb0 hb).symm
  · rw [Fintype.card_coe]
    have hd := poleInterpolant_degree P b s
    exact max_lt hdeg (by omega)
