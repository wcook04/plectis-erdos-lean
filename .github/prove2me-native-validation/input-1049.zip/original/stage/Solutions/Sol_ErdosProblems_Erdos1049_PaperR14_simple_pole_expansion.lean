import Definitions.Def_ErdosProblems_Erdos1049_QBinomialUnitIdentity
import Definitions.Def_ErdosProblems_Erdos1049_FiniteResidueInterpolationR14
import Theorems.Thm_ErdosProblems_Erdos1049_PaperR14_poleProduct_eval
import Theorems.Thm_ErdosProblems_Erdos1049_PaperR14_pole_interpolation
import Mathlib
import Mathlib.Algebra.BigOperators.Group.Finset.Basic
import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Algebra.Polynomial.Coeff
import Mathlib.Algebra.Polynomial.Eval.Defs
import Mathlib.Algebra.Polynomial.Roots
import Mathlib.Data.Nat.Choose.Basic
import Mathlib.Tactic

/-!
# Finite simple-pole interpolation, without a partial-fractions assumption

Interpolation in the pole basis and the finite simple-pole expansion.

The numerator is reconstructed from its values at the inverse pole parameters.
The only degree premise is the ordinary proper-fraction degree condition;
there is no premise asserting the partial-fraction identity. The following
source module supplies the concrete parameters and the numerator degree.
-/

namespace ErdosProblems.Erdos1049.PaperR14
set_option maxHeartbeats 1000000
open Polynomial Finset
open scoped BigOperators

variable {K : Type*} [Field K] {ι : Type*} [DecidableEq ι]
end ErdosProblems.Erdos1049.PaperR14

set_option maxHeartbeats 1000000
open Polynomial Finset
open scoped BigOperators
variable {K : Type*} [Field K] {ι : Type*} [DecidableEq ι]
open ErdosProblems in
open ErdosProblems.Erdos1049 in
open ErdosProblems.Erdos1049.PaperR14 in
theorem solution (P : K[X]) (b : ι → K) (s : Finset ι)
    (hdeg : P.natDegree < s.card) (hb0 : ∀ i ∈ s, b i ≠ 0)
    (hb : Set.InjOn b s) (z : K) (hz : ∀ i ∈ s, 1 - b i * z ≠ 0) :
    P.eval z / (poleProduct b s).eval z =
      ∑ i ∈ s, poleResidue P b s i / (1 - b i * z) := by
  have hD : (poleProduct b s).eval z ≠ 0 := by
    rw [poleProduct_eval]
    exact prod_ne_zero_iff.mpr hz
  have he := congrArg (Polynomial.eval z) (pole_interpolation P b s hdeg hb0 hb)
  rw [poleInterpolant, eval_finset_sum] at he
  rw [he, sum_div]
  apply sum_congr rfl
  intro i hi
  have hfactor : (poleProduct b s).eval z =
      (1 - b i * z) * (poleProduct b (s.erase i)).eval z := by
    simp only [poleProduct_eval]
    exact (mul_prod_erase s (fun j => 1 - b j * z) hi).symm
  have hE : (poleProduct b (s.erase i)).eval z ≠ 0 := by
    intro hh
    rw [hfactor, hh, mul_zero] at hD
    exact hD rfl
  simp only [eval_mul, eval_C]
  rw [hfactor]
  exact mul_div_mul_right _ _ hE
