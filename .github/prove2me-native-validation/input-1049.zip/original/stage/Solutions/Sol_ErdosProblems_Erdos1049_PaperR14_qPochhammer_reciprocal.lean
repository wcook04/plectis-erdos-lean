import Definitions.Def_ErdosProblems_Erdos1049_QBinomialUnitIdentity
import Definitions.Def_ErdosProblems_Erdos1049_FiniteResidueInterpolationR14
import Definitions.Def_ErdosProblems_Erdos1049_QProductBoundsR10
import Definitions.Def_ErdosProblems_Erdos1049_ReciprocalPochhammerR14
import Theorems.Thm_ErdosProblems_Erdos1049_choose_two_succ
import Theorems.Thm_ErdosProblems_Erdos1049_gaussBinom_zero_succ
import Theorems.Thm_ErdosProblems_Erdos1049_qPochhammer_zero
import Theorems.Thm_ErdosProblems_Erdos1049_qPochhammer_succ
import Mathlib
import Mathlib.Algebra.BigOperators.Group.Finset.Basic
import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Algebra.Polynomial.Coeff
import Mathlib.Algebra.Polynomial.Eval.Defs
import Mathlib.Algebra.Polynomial.Roots
import Mathlib.Analysis.SpecialFunctions.Log.Basic
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.Data.Nat.Choose.Basic
import Mathlib.Tactic
import Mathlib.Topology.Algebra.InfiniteSum.Real
import Mathlib.Topology.Algebra.InfiniteSum.Ring

/-!
# Reciprocal factorials and reflected finite products

Reversal of finite q-factorials and the erased pole product. These are finite algebraic
identities. In particular no analytic source identity is used as a premise.
-/

namespace ErdosProblems.Erdos1049.PaperR14
set_option maxHeartbeats 1000000
open Finset Polynomial
open scoped BigOperators

variable {K : Type*} [Field K]



lemma triangularExponent_succ (m : ℕ) :
    triangularExponent (m + 1) = triangularExponent m + (m + 1) := by
  simp only [triangularExponent, choose_two_succ]



lemma reciprocal_factor (p : K) (hp : p ≠ 0) (m : ℕ) :
    (1 - (p⁻¹) ^ m) * p ^ m = -(1 - p ^ m) := by
  rw [inv_pow]
  field_simp
  <;> ring
end ErdosProblems.Erdos1049.PaperR14

set_option maxHeartbeats 1000000
open Finset Polynomial
open scoped BigOperators
variable {K : Type*} [Field K]
open ErdosProblems in
open ErdosProblems.Erdos1049 in
open ErdosProblems.Erdos1049.PaperR14 in
theorem solution (p : K) (hp : p ≠ 0) (m : ℕ) :
    qPochhammer p⁻¹ p⁻¹ m * p ^ triangularExponent m =
      (-1 : K) ^ m * qPochhammer p p m := by
  induction m with
  | zero => simp [triangularExponent]
  | succ m ih =>
      rw [qPochhammer_succ, qPochhammer_succ, triangularExponent_succ, pow_add]
      have hi : p⁻¹ * (p⁻¹) ^ m = (p⁻¹) ^ (m + 1) := by rw [pow_succ'];
      have hi' : p * p ^ m = p ^ (m + 1) := by rw [pow_succ'];
      rw [hi, hi']
      calc
        _ = (qPochhammer p⁻¹ p⁻¹ m * p ^ triangularExponent m) *
          ((1 - (p⁻¹) ^ (m + 1)) * p ^ (m + 1)) := by ring
        _ = ((-1 : K) ^ m * qPochhammer p p m) * -(1 - p ^ (m + 1)) := by
          rw [ih, reciprocal_factor p hp]
        _ = _ := by rw [pow_succ]; ring
