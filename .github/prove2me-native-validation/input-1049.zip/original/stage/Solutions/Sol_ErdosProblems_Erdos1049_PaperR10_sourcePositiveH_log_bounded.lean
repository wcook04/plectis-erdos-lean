import Definitions.Def_ErdosProblems_Erdos1049_BezoutPluckerJets
import Definitions.Def_ErdosProblems_Erdos1049_QProductBoundsR10
import Definitions.Def_ErdosProblems_Erdos1049_PaperAsymptoticsR9
import Definitions.Def_ErdosProblems_Erdos1049_SourcePositiveHBoundsR10
import Theorems.Thm_ErdosProblems_Erdos1049_PaperR10_qPochhammerInfinity_pos
import Theorems.Thm_ErdosProblems_Erdos1049_PaperR10_qpow_antitone
import Theorems.Thm_ErdosProblems_Erdos1049_PaperR10_sourcePositiveH_bounds
import Theorems.Thm_ErdosProblems_Erdos1049_PaperR10_sourcePositiveH_pos
import Lean.Elab.Tactic.Omega
import Mathlib.Algebra.BigOperators.Group.Finset.Basic
import Mathlib.Algebra.Module.BigOperators
import Mathlib.Algebra.Module.Prod
import Mathlib.Analysis.Asymptotics.Defs
import Mathlib.Analysis.SpecialFunctions.Log.Basic
import Mathlib.Analysis.SpecialFunctions.Pow.Real
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.Data.Fintype.Pi
import Mathlib.Data.ZMod.Basic
import Mathlib.NumberTheory.Real.Irrational
import Mathlib.RingTheory.Coprime.Basic
import Mathlib.Tactic
import Mathlib.Tactic.Choose
import Mathlib.Tactic.Push
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.InfiniteSum.Real
import Mathlib.Topology.Algebra.InfiniteSum.Ring
import Mathlib.Topology.MetricSpace.Pseudo.Defs

/-!
# The actual positive 2004 source series in direction (14,12,14;27)

This module CONSTRUCTS the positive hypergeometric series,
proves its convergence, proves uniform two-sided bounds, and proves its exact
zero quadratic logarithmic rate. In particular none of those properties is
an added hypothesis.

The last denominator has length 13*n+1. Replacing it by 13*n would be the
historical off-by-one error identified in the supplied notes.

The identity with the cancelled integer polynomial linear form is not asserted
here: that algebraic/arithmetic source transport remains separately identified.
-/

namespace ErdosProblems.Erdos1049.PaperR10
open Filter
open scoped BigOperators Topology















/-- Uniform in n: the denominator in the upper bound can be replaced by 1-q. -/
theorem sourcePositiveH_uniform_bounds {q : ℝ} (hq0 : 0 < q) (hq1 : q < 1) (n : ℕ) :
    (qPochhammerInfinity q q) ^ 2 ≤ sourcePositiveH q n ∧
      sourcePositiveH q n ≤ (qPochhammerInfinity q q)⁻¹ ^ 2 / (1 - q) := by
  have hb := sourcePositiveH_bounds hq0 hq1 n
  refine ⟨hb.1, hb.2.trans ?_⟩
  have hqn : q ^ (14 * n + 1) ≤ q := by
    simpa only [pow_one] using qpow_antitone hq0.le hq1.le (by omega : 1 ≤ 14 * n + 1)
  exact div_le_div_of_nonneg_left (sq_nonneg _) (sub_pos.mpr hq1) (by linarith)
end ErdosProblems.Erdos1049.PaperR10

open Filter
open scoped BigOperators Topology
open ErdosProblems in
open ErdosProblems.Erdos1049 in
open ErdosProblems.Erdos1049.PaperR10 in
theorem solution {q : ℝ} (hq0 : 0 < q) (hq1 : q < 1) :
    ∃ C : ℝ, 0 ≤ C ∧ ∀ n, |Real.log (sourcePositiveH q n)| ≤ C := by
  let L := (qPochhammerInfinity q q) ^ 2
  let U := (qPochhammerInfinity q q)⁻¹ ^ 2 / (1 - q)
  have hL : 0 < L := sq_pos_of_pos (qPochhammerInfinity_pos q q)
  have hU : 0 < U := by
    dsimp [U]
    exact div_pos (sq_pos_of_pos (inv_pos.mpr (qPochhammerInfinity_pos q q)))
      (sub_pos.mpr hq1)
  refine ⟨|Real.log L| + |Real.log U|, by positivity, ?_⟩
  intro n
  have hb := sourcePositiveH_uniform_bounds hq0 hq1 n
  have hlo := Real.log_le_log hL hb.1
  have hup := Real.log_le_log (sourcePositiveH_pos hq0 hq1 n) hb.2
  apply abs_le.mpr
  constructor
  · have hh := neg_abs_le (Real.log L)
    have hh' := abs_nonneg (Real.log U)
    linarith
  · have hh := le_abs_self (Real.log U)
    have hh' := abs_nonneg (Real.log L)
    linarith
