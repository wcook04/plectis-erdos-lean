import Definitions.Def_ErdosProblems_Erdos1049_QBinomialUnitIdentity
import Definitions.Def_ErdosProblems_Erdos1049_ZudilinConeArithmetic
import Definitions.Def_ErdosProblems_Erdos1049_PaperOmegaIndicatorR7
import Definitions.Def_ErdosProblems_Erdos1049_SourcePolynomialR11
import Definitions.Def_ErdosProblems_Erdos1049_SourceBClearingR12
import Definitions.Def_ErdosProblems_Erdos1049_GaussianDegreeR12
import Definitions.Def_ErdosProblems_Erdos1049_SourceFiniteTransformR12
import Definitions.Def_ErdosProblems_Erdos1049_SourceHomogeneousR12
import Definitions.Def_ErdosProblems_Erdos1049_RootUnityLocalCancellationR13
import Definitions.Def_ErdosProblems_Erdos1049_SourceBMonomialR12
import Definitions.Def_ErdosProblems_Erdos1049_SourceBTopDegreeR13
import Definitions.Def_ErdosProblems_Erdos1049_SourceRootCarriesR13
import Definitions.Def_ErdosProblems_Erdos1049_SourceRootBlocksR13
import Theorems.Thm_ErdosProblems_Erdos1049_gaussBinom_succ
import Theorems.Thm_ErdosProblems_Erdos1049_gaussBinom_eq_zero_of_lt
import Theorems.Thm_ErdosProblems_Erdos1049_gaussBinom_zero_succ
import Theorems.Thm_ErdosProblems_Erdos1049_qPochhammer_zero
import Theorems.Thm_ErdosProblems_Erdos1049_PaperR13_gaussian_field_symmetry
import Theorems.Thm_ErdosProblems_Erdos1049_PaperR13_actual_source_second_carry_local_zero
import Theorems.Thm_ErdosProblems_Erdos1049_PaperR13_finite_sum_rectangular_blocks
import Theorems.Thm_ErdosProblems_Erdos1049_PaperR13_sourceRootTerm_weighted_block
import Mathlib
import Mathlib.Algebra.BigOperators.Group.Finset.Basic
import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Algebra.Order.Floor.Ring
import Mathlib.Algebra.Polynomial.Coeff
import Mathlib.Algebra.Polynomial.Eval.Defs
import Mathlib.Data.Fintype.Pigeonhole
import Mathlib.Data.Nat.Choose.Basic
import Mathlib.Data.Real.Basic
import Mathlib.Data.ZMod.Basic
import Mathlib.Data.ZMod.Coprime
import Mathlib.RingTheory.Polynomial.Cyclotomic.Basic
import Mathlib.Tactic

namespace PaperR11
end PaperR11

namespace PaperR12
end PaperR12

section
open scoped BigOperators
open Finset Polynomial
namespace ErdosProblems.Erdos1049
variable {R : Type*} [CommRing R]
lemma eval₂_gaussBinom (q : R) : ∀ n k,
    eval₂ (Int.castRingHom R) q (gaussBinom (X : ℤ[X]) n k) = gaussBinom q n k
  | 0, 0 => by simp [gaussBinom]
  | 0, k + 1 => by simp [gaussBinom]
  | n + 1, 0 => by simp [gaussBinom]
  | n + 1, k + 1 => by
      rw [gaussBinom_succ, gaussBinom_succ, eval₂_add]
      split_ifs with h
      · rw [eval₂_mul, eval₂_pow, eval₂_X, eval₂_gaussBinom q n (k + 1),
          eval₂_gaussBinom q n k]
      · rw [eval₂_zero, eval₂_gaussBinom q n (k + 1)]
end ErdosProblems.Erdos1049
end

namespace ErdosProblems.Erdos1049.PaperR13
open Polynomial PaperR11 PaperR12 Finset
open scoped BigOperators
variable {K : Type*} [Field K]
lemma sourceRootTerm_eq_actual (q : K) (n s : ℕ) (hs : s ≤ 13 * n) :
    (sourceASummand n s).eval₂ (Int.castRingHom K) q =
      q ^ (sourceM n + 2 * n ^ 2) * sourceRootTerm q n s := by
  simp only [sourceASummand, sourceGaussianProduct, sourceAExponent, eval₂_mul,
    eval₂_C, eval₂_pow, eval₂_X, Int.cast_pow, Int.cast_neg, Int.cast_one,
    eval₂_gaussBinom]
  rw [← gaussian_field_symmetry q (13 * n) s hs]
  have hsign : (Int.castRingHom K) ((-1 : ℤ) ^ s) = (-1 : K) ^ s := by simp
  rw [hsign]
  simp only [sourceRootTerm, gaussianPhase, pow_add]
  ring
lemma sourceRootTerm_zero_above (q : K) (n s : ℕ) (hs : 13 * n < s) :
    sourceRootTerm q n s = 0 := by
  unfold sourceRootTerm
  rw [gaussBinom_eq_zero_of_lt q hs, mul_zero]
lemma localGaussianTerm_sum_full_block_zero (q : K) (hq : q ≠ 0)
    (n ell : ℕ) (hell : 0 < ell) (hroot : q ^ ell = 1)
    (hprimitive : ∀ j : ℕ, 0 < j → j < ell → q ^ j ≠ 1)
    (hfirst : sourceCarryOne n ell ≤ 0) (hsecond : sourceCarryTwo n ell = 1) :
    (∑ h ∈ range ell,
      localGaussianTerm q ((14 * n) % ell) ((12 * n) % ell) (n % ell) ((13 * n) % ell) h) = 0 := by
  have hv := Nat.mod_lt (13 * n) hell
  have he : (∑ h ∈ range ((13 * n) % ell + 1),
      localGaussianTerm q ((14 * n) % ell) ((12 * n) % ell) (n % ell) ((13 * n) % ell) h) =
      ∑ h ∈ range ell,
        localGaussianTerm q ((14 * n) % ell) ((12 * n) % ell) (n % ell) ((13 * n) % ell) h := by
    apply sum_subset (range_mono (by omega))
    intro h hh hnot
    have hz : (13 * n) % ell < h := by
      have hnot' := mt mem_range.mpr hnot
      omega
    simp only [localGaussianTerm, gaussBinom_eq_zero_of_lt q hz, mul_zero, zero_mul]
  rw [← he]
  exact actual_source_second_carry_local_zero q hq n ell hell hroot hprimitive hfirst hsecond
end ErdosProblems.Erdos1049.PaperR13

open ErdosProblems
open ErdosProblems.Erdos1049
open ErdosProblems.Erdos1049.PaperR13
open Polynomial PaperR11 PaperR12 Finset
open scoped BigOperators
variable {K : Type*} [Field K]
open ErdosProblems in
open ErdosProblems.Erdos1049 in
open ErdosProblems.Erdos1049.PaperR13 in
open ErdosProblems.Erdos1049.PaperR11 in
open ErdosProblems.Erdos1049.PaperR12 in
theorem solution (q : K) (hq : q ≠ 0)
    (n ell : ℕ) (hell : 0 < ell) (hroot : q ^ ell = 1)
    (hprimitive : ∀ j : ℕ, 0 < j → j < ell → q ^ j ≠ 1)
    (hfirst : sourceCarryOne n ell ≤ 0) (hsecond : sourceCarryTwo n ell = 1)
    (f : ℕ → K) :
    (∑ s ∈ range (13 * n + 1),
      (sourceASummand n s).eval₂ (Int.castRingHom K) q * f ((2 * n + s) / ell)) = 0 := by
  have hbound : 13 * n + 1 ≤ (13 * n / ell + 1) * ell := by
    have he := Nat.mod_add_div (13 * n) ell
    have hr := Nat.mod_lt (13 * n) hell
    nlinarith
  have hsum : (∑ s ∈ range (13 * n + 1),
      sourceRootTerm q n s * f ((2 * n + s) / ell)) =
      ∑ s ∈ range ((13 * n / ell + 1) * ell),
        sourceRootTerm q n s * f ((2 * n + s) / ell) := by
    apply sum_subset (range_mono hbound)
    intro s hs hnot
    have hs' : 13 * n < s := by have h := mt mem_range.mpr hnot; omega
    rw [sourceRootTerm_zero_above q n s hs', zero_mul]
  have hzero : (∑ s ∈ range (13 * n + 1),
      sourceRootTerm q n s * f ((2 * n + s) / ell)) = 0 := by
    rw [hsum, finite_sum_rectangular_blocks]
    apply sum_eq_zero
    intro t ht
    have he : (∑ h ∈ range ell,
        sourceRootTerm q n (t * ell + h) * f ((2 * n + (t * ell + h)) / ell)) =
        ((-1 : K) ^ t * ((13 * n / ell).choose t : K) *
          ((14 * n / ell + t).choose (12 * n / ell) : K) *
            f (t + (14 * n / ell - 12 * n / ell))) *
        ∑ h ∈ range ell,
          localGaussianTerm q ((14 * n) % ell) ((12 * n) % ell) (n % ell) ((13 * n) % ell) h := by
      rw [mul_sum]
      apply sum_congr rfl
      intro h hh
      exact sourceRootTerm_weighted_block q hq n ell t h hell hroot hprimitive
        hfirst hsecond (mem_range.mp hh) f
    rw [he, localGaussianTerm_sum_full_block_zero q hq n ell hell hroot hprimitive hfirst hsecond,
      mul_zero]
  calc
    _ = q ^ (sourceM n + 2 * n ^ 2) *
        ∑ s ∈ range (13 * n + 1), sourceRootTerm q n s * f ((2 * n + s) / ell) := by
      rw [mul_sum]
      apply sum_congr rfl
      intro s hs
      rw [sourceRootTerm_eq_actual q n s (by have h := mem_range.mp hs; omega)]
      ring
    _ = 0 := by rw [hzero, mul_zero]
