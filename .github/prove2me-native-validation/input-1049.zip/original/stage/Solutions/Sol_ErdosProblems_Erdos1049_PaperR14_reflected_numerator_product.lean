import Definitions.Def_ErdosProblems_Erdos1049_QBinomialUnitIdentity
import Definitions.Def_ErdosProblems_Erdos1049_FiniteResidueInterpolationR14
import Definitions.Def_ErdosProblems_Erdos1049_QProductBoundsR10
import Definitions.Def_ErdosProblems_Erdos1049_ReciprocalPochhammerR14
import Theorems.Thm_ErdosProblems_Erdos1049_PaperR14_finite_qPochhammer_product
import Theorems.Thm_ErdosProblems_Erdos1049_PaperR14_inverse_power_mul_power
import Mathlib
import Mathlib.Algebra.BigOperators.Group.Finset.Basic
import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Algebra.Polynomial.Coeff
import Mathlib.Algebra.Polynomial.Eval.Defs
import Mathlib.Algebra.Polynomial.Roots
import Mathlib.Analysis.SpecialFunctions.Log.Basic
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.Data.Nat.Choose.Basic
import Mathlib.Tactic
import Mathlib.Topology.Algebra.InfiniteSum.Real
import Mathlib.Topology.Algebra.InfiniteSum.Ring

/-!
# Reciprocal factorials and reflected finite products

Reversal of finite q-factorials and the erased pole product. These are finite algebraic
identities. In particular no analytic source identity is used as a premise.
-/

namespace ErdosProblems.Erdos1049.PaperR14
set_option maxHeartbeats 1000000
open Finset Polynomial
open scoped BigOperators

variable {K : Type*} [Field K]
end ErdosProblems.Erdos1049.PaperR14

set_option maxHeartbeats 1000000
open Finset Polynomial
open scoped BigOperators
variable {K : Type*} [Field K]
open ErdosProblems in
open ErdosProblems.Erdos1049 in
open ErdosProblems.Erdos1049.PaperR14 in
theorem solution (p : K) (hp : p ≠ 0) (u r : ℕ) :
    (∏ i ∈ range r, (1 - (p⁻¹) ^ (i + 1) * p ^ (u + r))) =
      qPochhammer p (p ^ u) r := by
  rw [finite_qPochhammer_product]
  calc
    _ = ∏ i ∈ range r, (1 - p ^ u * p ^ (r - 1 - i)) := by
      apply prod_congr rfl
      intro i hi
      have hir := mem_range.mp hi
      rw [inverse_power_mul_power p hp (by omega)]
      rw [← pow_add]
      congr 2
      omega
    _ = _ := prod_range_reflect (fun i => 1 - p ^ u * p ^ i) r
