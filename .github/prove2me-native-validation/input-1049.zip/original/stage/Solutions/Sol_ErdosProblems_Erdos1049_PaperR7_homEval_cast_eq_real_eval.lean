import Definitions.Def_ErdosProblems_Erdos1049_ZudilinConeArithmetic
import Theorems.Thm_ErdosProblems_Erdos1049_PaperR7_eval_real_eq_sum_range
import Mathlib.Algebra.Polynomial.Eval.Defs
import Mathlib.Data.Fintype.Pigeonhole
import Mathlib.Data.ZMod.Basic
import Mathlib.Data.ZMod.Coprime
import Mathlib.RingTheory.Polynomial.Cyclotomic.Basic
import Mathlib.Tactic

namespace ErdosProblems.Erdos1049.PaperR7
end ErdosProblems.Erdos1049.PaperR7

/-!
# R7: integral homogeneous evaluation at a rational base

Compiled proof-source candidate. This is the finite algebraic bridge in the
main irrationality proof, not the existence or asymptotics of the cancelled
source forms. It reuses `homEval`; it does not define a different clearing.

All degrees below are natural degrees. This is harmless for a zero polynomial:
its natural degree is zero and every displayed evaluation identity still holds.
-/

namespace ErdosProblems.Erdos1049.PaperR7
open scoped BigOperators
end ErdosProblems.Erdos1049.PaperR7

open scoped BigOperators
open ErdosProblems in
open ErdosProblems.Erdos1049 in
open ErdosProblems.Erdos1049.PaperR7 in
theorem solution (a b W : ℕ) (P : Polynomial ℤ)
    (hb : b ≠ 0) (hdegree : P.natDegree ≤ W) :
    (homEval a b W P : ℝ) =
      (b : ℝ) ^ W * P.eval₂ (Int.castRingHom ℝ) ((a : ℝ) / b) := by
  classical
  have hbR : (b : ℝ) ≠ 0 := by exact_mod_cast hb
  rw [eval_real_eq_sum_range P W _ hdegree, Finset.mul_sum]
  simp only [homEval, Int.cast_sum, Int.cast_mul, Int.cast_pow, Int.cast_natCast]
  apply Finset.sum_congr rfl
  intro i hi
  have hiW : i ≤ W := by
    have hi' := Finset.mem_range.mp hi
    omega
  have hsplit : (b : ℝ) ^ W = (b : ℝ) ^ i * (b : ℝ) ^ (W - i) := by
    rw [← pow_add, Nat.add_sub_of_le hiW]
  rw [div_pow, hsplit]
  field_simp [hbR]
