import Definitions.Def_ErdosProblems_Erdos1049_QBinomialUnitIdentity
import Definitions.Def_ErdosProblems_Erdos1049_ZudilinConeArithmetic
import Definitions.Def_ErdosProblems_Erdos1049_PaperOmegaIndicatorR7
import Definitions.Def_ErdosProblems_Erdos1049_SourcePolynomialR11
import Definitions.Def_ErdosProblems_Erdos1049_SourceBClearingR12
import Definitions.Def_ErdosProblems_Erdos1049_GaussianDegreeR12
import Definitions.Def_ErdosProblems_Erdos1049_SourceFiniteTransformR12
import Definitions.Def_ErdosProblems_Erdos1049_SourceHomogeneousR12
import Definitions.Def_ErdosProblems_Erdos1049_RootUnityLocalCancellationR13
import Definitions.Def_ErdosProblems_Erdos1049_SourceBMonomialR12
import Definitions.Def_ErdosProblems_Erdos1049_SourceBTopDegreeR13
import Mathlib
import Mathlib.Algebra.BigOperators.Group.Finset.Basic
import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Algebra.Order.Floor.Ring
import Mathlib.Algebra.Polynomial.Coeff
import Mathlib.Algebra.Polynomial.Eval.Defs
import Mathlib.Data.Fintype.Pigeonhole
import Mathlib.Data.Nat.Choose.Basic
import Mathlib.Data.Real.Basic
import Mathlib.Data.ZMod.Basic
import Mathlib.Data.ZMod.Coprime
import Mathlib.RingTheory.Polynomial.Cyclotomic.Basic
import Mathlib.Tactic

/-!
# Exact source carry geometry and the first Omega channel


The carry expressions are linked to the literal sourceWeight. The first
carry case is carried through to the actual cleared B polynomial. The
second case supplies its exact local-window geometry and constant harmonic
floor; its global residue-block assembly is not asserted by this file.
-/
namespace ErdosProblems.Erdos1049.PaperR13
open Polynomial PaperR11 PaperR12
open scoped BigOperators

def sourceCarryOne (n ell : ℕ) : ℤ :=
  ((14 * n / ell : ℕ) : ℤ) + (13 * n / ell : ℕ) - (12 * n / ell : ℕ) - (15 * n / ell : ℕ)

def sourceCarryTwo (n ell : ℕ) : ℤ :=
  2 * ((14 * n / ell : ℕ) : ℤ) - (13 * n / ell : ℕ) - (15 * n / ell : ℕ)



















section Field
variable {K : Type*} [Field K]











end Field
end ErdosProblems.Erdos1049.PaperR13
