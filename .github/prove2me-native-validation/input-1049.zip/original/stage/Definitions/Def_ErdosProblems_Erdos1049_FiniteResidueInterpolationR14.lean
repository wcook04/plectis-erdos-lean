import Definitions.Def_ErdosProblems_Erdos1049_QBinomialUnitIdentity
import Mathlib
import Mathlib.Algebra.BigOperators.Group.Finset.Basic
import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Algebra.Polynomial.Coeff
import Mathlib.Algebra.Polynomial.Eval.Defs
import Mathlib.Algebra.Polynomial.Roots
import Mathlib.Data.Nat.Choose.Basic
import Mathlib.Tactic

/-!
# Finite simple-pole interpolation, without a partial-fractions assumption

Interpolation in the pole basis and the finite simple-pole expansion.

The numerator is reconstructed from its values at the inverse pole parameters.
The only degree premise is the ordinary proper-fraction degree condition;
there is no premise asserting the partial-fraction identity. The following
source module supplies the concrete parameters and the numerator degree.
-/
namespace ErdosProblems.Erdos1049.PaperR14
set_option maxHeartbeats 1000000
open Polynomial Finset
open scoped BigOperators

variable {K : Type*} [Field K] {ι : Type*} [DecidableEq ι]

noncomputable def poleProduct (b : ι → K) (s : Finset ι) : K[X] :=
  ∏ i ∈ s, (1 - C (b i) * X)







noncomputable def poleResidue (P : K[X]) (b : ι → K) (s : Finset ι) (i : ι) : K :=
  P.eval (b i)⁻¹ / (poleProduct b (s.erase i)).eval (b i)⁻¹

noncomputable def poleInterpolant (P : K[X]) (b : ι → K) (s : Finset ι) : K[X] :=
  ∑ i ∈ s, C (poleResidue P b s i) * poleProduct b (s.erase i)











end ErdosProblems.Erdos1049.PaperR14
