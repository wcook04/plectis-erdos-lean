import Mathlib.Algebra.Polynomial.Eval.Defs
import Mathlib.Data.Fintype.Pigeonhole
import Mathlib.Data.ZMod.Basic
import Mathlib.Data.ZMod.Coprime
import Mathlib.RingTheory.Polynomial.Cyclotomic.Basic
import Mathlib.Tactic

/-!
# Erdős #1049: endpoint arithmetic for the Heine--Zudilin cone

This module isolates the source-independent arithmetic behind the returned
scalar-cone obstruction at the rational base `3 / 2`.  It does not construct
the Zudilin coefficient polynomials or import their analytic asymptotics.

The key finite observation is that homogeneous evaluation at `(3,2)` sees the
bottom polynomial endpoint modulo `3` and the top endpoint modulo `2`.
Consequently a unit at either endpoint prevents a common local factor.  The
endpoint-jet definitions record the exact additive congruence problem left
after scalar and multiplicative deformations have been exhausted.
-/

namespace ErdosProblems.Erdos1049

open Polynomial













































/-! ## Generic homogeneous evaluation and the cyclotomic endpoint theorem -/

/-- Integer homogeneous evaluation at a reduced numerator--denominator pair.

The existing `homEvalThreeTwo` is the specialization `(a,b) = (3,2)`.  This
generic form is the arithmetic object used in Proposition 3.6 of the paper. -/
def homEval (a b W : ℕ) (P : Polynomial ℤ) : ℤ :=
  ∑ i ∈ Finset.range (W + 1), P.coeff i * a ^ i * b ^ (W - i)



























end ErdosProblems.Erdos1049
