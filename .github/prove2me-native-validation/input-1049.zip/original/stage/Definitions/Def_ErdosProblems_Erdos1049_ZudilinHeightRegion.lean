import Mathlib.Algebra.BigOperators.Group.Finset.Basic
import Mathlib.Analysis.Real.Pi.Bounds
import Mathlib.Analysis.SpecialFunctions.Log.Basic
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Ring

/-!
# Erdős #1049: elementary height-region certificates

Define the height region by
`log b / log a < 81 / 200`.  Exact integer and logarithmic inequalities place
`31 / 4` and all its positive powers inside this region, place `31 / 4`
outside the Bundschuh--Väänänen region, and place `3 / 2` outside both.

These are elementary parameter inequalities.  No hypergeometric asymptotic or
irrationality theorem is imported as an axiom.  Membership becomes useful only
after a separate analytic theorem is applied, while failure of membership is
method inapplicability and proves neither rationality nor irrationality.
-/

namespace ErdosProblems.Erdos1049

/-- The parameter region cut out by the single inequality
`log b / log a < 81 / 200`; no analytic hypotheses are included. -/
def ZudilinHeightRegion (a b : ℕ) : Prop :=
  Real.log b / Real.log a < (81 : ℝ) / 200

























end ErdosProblems.Erdos1049
