import Definitions.Def_ErdosProblems_Erdos269_BoundedRadixTailEscape
import Definitions.Def_ErdosProblems_Erdos269_ResidueEscape
import Definitions.Def_ErdosProblems_Erdos269_ThreePrimeRunningLcm
import Definitions.Def_ErdosProblems_Erdos269_RestrictedFloorSum
import Definitions.Def_ErdosProblems_Erdos269_DyadicBlockMassIdentity
import Definitions.Def_ErdosProblems_Erdos269_DyadicBlockThresholdPartition
import Definitions.Def_ErdosProblems_Erdos269_DyadicOrderedTailRecurrence
import Definitions.Def_ErdosProblems_Erdos269_DyadicShellSummability
import Definitions.Def_ErdosProblems_Erdos269_IntegralBranchExtinction
import Definitions.Def_ErdosProblems_Erdos269_PaperR7ActualOrbit
import Definitions.Def_ErdosProblems_Erdos269_PaperR7SeriesIdentification
import Theorems.Thm_ErdosProblems_Erdos269_summable_dyadicShellMassR235
import Theorems.Thm_ErdosProblems_Erdos269_smoothPrefixLcm_eq_threePrimeHeight
import Theorems.Thm_ErdosProblems_Erdos269_PaperR7_summable_exponentKernel235
import Theorems.Thm_ErdosProblems_Erdos269_PaperR7_actual_orbit_dynamics_and_bounds
import Mathlib.Algebra.BigOperators.Group.Finset.Basic
import Mathlib.Algebra.BigOperators.Group.Finset.Sigma
import Mathlib.Algebra.BigOperators.Group.List.Basic
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Algebra.Ring.Parity
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Data.Finset.Card
import Mathlib.Data.Finset.Prod
import Mathlib.Data.Int.ModEq
import Mathlib.Data.Nat.Factorization.Basic
import Mathlib.Data.Nat.Log
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.Nat.Prime.Int
import Mathlib.Tactic
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.InfiniteSum.Real

/-!
# Round 7: identify the original smooth-number series with the shell tsum

The distinction is material: a theorem about `dyadicShellTsumTailR235 0` is
not an end-to-end theorem about the paper's `S` until reindexing has been
proved. We build the exponent/smooth-number and shell/exponent equivalences,
prove summability, and identify the literal running-LCM series.

No admissions.
-/

namespace ErdosProblems.Erdos269.PaperR7
open scoped BigOperators



















theorem smoothReciprocal235_eq_height (x : Smooth235) :
    smoothReciprocal235 x = (threePrimeHeight 2 3 5 x.val : ℝ)⁻¹ := by
  have hx : x.val ≠ 0 := by
    obtain ⟨e, he⟩ := x.property
    rw [← he]
    exact (exponentValue235_pos e).ne'
  unfold smoothReciprocal235
  rw [smoothPrefixLcm_eq_threePrimeHeight
    (by norm_num : Nat.Prime 2) (by norm_num : Nat.Prime 3)
    (by norm_num : Nat.Prime 5) (by norm_num) (by norm_num) (by norm_num) hx]

theorem smoothReciprocal235_comp_exponent (e : Exponent235) :
    smoothReciprocal235 (exponentSmoothEquiv235 e) = exponentKernel235 e := by
  rw [smoothReciprocal235_eq_height]
  rfl



















/-- Convergence of the paper's original, ungrouped smooth-number series. -/
theorem summable_smoothReciprocal235 : Summable smoothReciprocal235 := by
  apply exponentSmoothEquiv235.summable_iff.mp
  exact summable_exponentKernel235.congr
    fun e => (smoothReciprocal235_comp_exponent e).symm
end ErdosProblems.Erdos269.PaperR7

open scoped BigOperators
open ErdosProblems in
open ErdosProblems.Erdos269 in
open ErdosProblems.Erdos269.PaperR7 in
theorem solution :
    Summable smoothReciprocal235 ∧
    (∀ a : ℕ, Summable (fun n : ℕ => dyadicShellMassR235 (a + n))) ∧
    (∀ a : ℕ,
      trueNormalizedState (a + 1) =
        (dyadicBlockBase235 a : ℝ) * trueNormalizedState a -
          (dyadicOrderedBlockDigit235 a : ℝ)) ∧
    (∀ a : ℕ, 0 < trueNormalizedState a ∧
      trueNormalizedState a ≤ (8640 / 343 : ℝ) * ((a + 1 : ℕ) : ℝ) ^ 2 ∧
      (8640 / 343 : ℝ) * ((a + 1 : ℕ) : ℝ) ^ 2 <
        90 * ((a + 1 : ℕ) : ℝ) ^ 2) ∧
    (∀ B : ℤ,
      (∃ a : ℕ, ∀ n, a ≤ n → ∃ z : ℤ,
        (B : ℝ) * trueNormalizedState n = (z : ℝ)) ∨
      (∀ a₀ : ℕ, ∃ a, a₀ ≤ a ∧
        FarFromIntegers ((B : ℝ) * trueNormalizedState a) ((1 : ℝ) / 31))) := by
  refine ⟨summable_smoothReciprocal235, ?_, actual_orbit_dynamics_and_bounds⟩
  intro a
  exact summable_dyadicShellMassR235.comp_injective fun _ _ h => Nat.add_left_cancel h
