import Definitions.Def_ErdosProblems_Erdos269_ThreePrimeRunningLcm
import Definitions.Def_ErdosProblems_Shared_IrrationalRotationStaircase
import Definitions.Def_ErdosProblems_Erdos269_KernelCarryRank
import Definitions.Def_ErdosProblems_Erdos269_PaperR7AnalyticInterfaces
import Theorems.Thm_ErdosProblems_Erdos269_logCarry_le_one
import Mathlib.Algebra.BigOperators.Group.Finset.Basic
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Algebra.Order.Floor.Ring
import Mathlib.Algebra.Order.Floor.Semiring
import Mathlib.Algebra.Ring.Parity
import Mathlib.Analysis.SpecialFunctions.Log.Base
import Mathlib.Data.Finset.Card
import Mathlib.Data.Finset.Prod
import Mathlib.Data.Fintype.Pigeonhole
import Mathlib.Data.Nat.Log
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.Nat.Prime.Int
import Mathlib.Data.Real.Archimedean
import Mathlib.LinearAlgebra.Matrix.Block
import Mathlib.LinearAlgebra.Matrix.Determinant.Basic
import Mathlib.RingTheory.Algebraic.Basic
import Mathlib.Tactic
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Ring

/-!
# Round 7: proved algebra around explicitly unresolved analytic inputs

This file DOES NOT prove the two-prime transcendence theorem. Its final algebraic
step is separated from THREE hypotheses still requiring analytic proofs:
transcendence of the specified Hecke--Mahler value, and the two identities for
the actual series. The parameters are visible, not axioms or admitted theorems.

It also proves the constant rank-one upper witness for the uniform carry
approximation. The lower bound over every finite separated rank remains open
as a formalisation obligation in this return.

Validation: authored, not compiled. No admissions.
-/

namespace ErdosProblems.Erdos269.PaperR7
open Polynomial
end ErdosProblems.Erdos269.PaperR7

open Polynomial
open ErdosProblems in
open ErdosProblems.Erdos269 in
open ErdosProblems.Erdos269.PaperR7 in
theorem solution {p q r : ℕ}
    (hp : 0 < p) (hq : 0 < q) (hr : 1 < r) :
    (∃ f g : ℕ → ℝ, ∀ i j,
      (1 + (r : ℝ)⁻¹) / 2 = f i * g j) ∧
    (∀ i j,
      |realCarryMatrix p q r i j - (1 + (r : ℝ)⁻¹) / 2| =
        ((r : ℝ) - 1) / (2 * (r : ℝ))) := by
  refine ⟨⟨fun _ => (1 + (r : ℝ)⁻¹) / 2, fun _ => 1, by simp⟩, ?_⟩
  intro i j
  have hbit := logCarry_le_one hr (pow_ne_zero i hp.ne') (pow_ne_zero j hq.ne')
  have hrR : (1 : ℝ) < r := by exact_mod_cast hr
  have hr0 : (0 : ℝ) < r := by linarith
  have hinv : (r : ℝ)⁻¹ ≤ 1 := (inv_le_one₀ hr0).mpr hrR.le
  have hcase : logCarry r (p ^ i) (q ^ j) = 0 ∨
      logCarry r (p ^ i) (q ^ j) = 1 := by omega
  rcases hcase with h | h
  · rw [realCarryMatrix, h, pow_zero, abs_of_nonneg (by linarith)]
    field_simp [ne_of_gt hr0] <;> ring
  · rw [realCarryMatrix, h, pow_one, abs_of_nonpos (by linarith)]
    field_simp [ne_of_gt hr0] <;> ring
