import Definitions.Def_ErdosProblems_Erdos269_ThreePrimeRunningLcm
import Definitions.Def_ErdosProblems_Shared_IrrationalRotationStaircase
import Definitions.Def_ErdosProblems_Erdos269_KernelCarryRank
import Mathlib.Algebra.BigOperators.Group.Finset.Basic
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Algebra.Order.Floor.Ring
import Mathlib.Algebra.Order.Floor.Semiring
import Mathlib.Algebra.Ring.Parity
import Mathlib.Analysis.SpecialFunctions.Log.Base
import Mathlib.Data.Finset.Card
import Mathlib.Data.Finset.Prod
import Mathlib.Data.Fintype.Pigeonhole
import Mathlib.Data.Nat.Log
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.Nat.Prime.Int
import Mathlib.Data.Real.Archimedean
import Mathlib.LinearAlgebra.Matrix.Block
import Mathlib.LinearAlgebra.Matrix.Determinant.Basic
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Ring

namespace ErdosProblems.Erdos269
open ErdosProblems.Shared
/-- `Nat.log` is superadditive across a product. -/
theorem add_log_le_log_mul {b : ℕ} (hb : 1 < b) {x y : ℕ} (hx : x ≠ 0) (hy : y ≠ 0) :
    Nat.log b x + Nat.log b y ≤ Nat.log b (x * y) := by
  apply Nat.le_log_of_pow_le hb
  rw [pow_add]
  exact Nat.mul_le_mul (Nat.pow_log_le_self b hx) (Nat.pow_log_le_self b hy)
/-- `Nat.log` loses at most one unit across a product: the **two-factor
carry law**. -/
theorem log_mul_le_add_log_succ {b : ℕ} (hb : 1 < b) {x y : ℕ} (hx : x ≠ 0) (hy : y ≠ 0) :
    Nat.log b (x * y) ≤ Nat.log b x + Nat.log b y + 1 := by
  have hlt : x * y < b ^ (Nat.log b x + Nat.log b y + 2) := by
    calc x * y < b ^ (Nat.log b x + 1) * b ^ (Nat.log b y + 1) :=
          Nat.mul_lt_mul_of_lt_of_lt (Nat.lt_pow_succ_log_self hb x)
            (Nat.lt_pow_succ_log_self hb y)
      _ = b ^ (Nat.log b x + Nat.log b y + 2) := by rw [← pow_add]; ring_nf
  have := Nat.log_lt_of_lt_pow (Nat.mul_ne_zero hx hy) hlt
  omega
end ErdosProblems.Erdos269

open ErdosProblems
open ErdosProblems.Erdos269
open ErdosProblems.Shared
open ErdosProblems in
open ErdosProblems.Erdos269 in
theorem solution {b : ℕ} (hb : 1 < b) {x y : ℕ} (hx : x ≠ 0) (hy : y ≠ 0) :
    logCarry b x y ≤ 1 := by
  have h1 := add_log_le_log_mul hb hx hy
  have h2 := log_mul_le_add_log_succ hb hx hy
  unfold logCarry
  omega
