import Definitions.Def_ErdosProblems_Erdos269_BoundedRadixTailEscape
import Definitions.Def_ErdosProblems_Erdos269_ThreePrimeRunningLcm
import Theorems.Thm_ErdosProblems_Erdos269_dyadicBlockBase235_mem_interval
import Theorems.Thm_ErdosProblems_Erdos269_boundedRadix_zero_or_cofinal_far
import Mathlib.Algebra.BigOperators.Group.Finset.Basic
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Algebra.Ring.Parity
import Mathlib.Data.Finset.Card
import Mathlib.Data.Finset.Prod
import Mathlib.Data.Nat.Log
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.Nat.Prime.Int
import Mathlib.Tactic
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Ring

/-!
# Erdős #269: actual dyadic-radix tail escape

This module specializes the generic bounded-radix escape mechanism to the
actual dyadic height ratios arising from the primes `2`, `3`, and `5`.

The specialization deliberately remains separate from the generic theorem.
It does not identify the integer block digit of the Erdős #269 tail or prove
the corresponding affine recurrence; those are the remaining arithmetic
inputs.
-/

open ErdosProblems in
open ErdosProblems.Erdos269 in
theorem solution
    (c : ℕ → ℤ) (x : ℕ → ℝ)
    (hrec :
      ∀ a, x (a + 1) =
        (dyadicBlockBase235 a : ℝ) * x a - (c a : ℝ)) :
    (∃ a : ℕ, ∃ z : ℤ, x a = (z : ℝ)) ∨
      ∀ a₀, ∃ a, a₀ ≤ a ∧
        FarFromIntegers (x a) ((1 : ℝ) / 31) := by
  apply boundedRadix_zero_or_cofinal_far dyadicBlockBase235 c x
  · intro a
    exact (dyadicBlockBase235_mem_interval a).1
  · intro a
    exact (dyadicBlockBase235_mem_interval a).2
  · exact hrec
