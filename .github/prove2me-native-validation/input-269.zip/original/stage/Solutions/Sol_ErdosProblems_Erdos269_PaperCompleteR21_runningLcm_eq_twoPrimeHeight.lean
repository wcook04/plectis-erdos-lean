import Definitions.Def_ErdosProblems_Erdos269_ThreePrimeRunningLcm
import Definitions.Def_ErdosProblems_Shared_IrrationalRotationStaircase
import Definitions.Def_ErdosProblems_Erdos269_KernelCarryRank
import Definitions.Def_ErdosProblems_Erdos269_PaperR7AnalyticInterfaces
import Definitions.Def_ErdosProblems_Erdos269_PaperCompleteR21_TwoPrimeSums
import Mathlib.Algebra.BigOperators.Group.Finset.Basic
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Algebra.Order.Floor.Ring
import Mathlib.Algebra.Order.Floor.Semiring
import Mathlib.Algebra.Ring.Parity
import Mathlib.Analysis.Normed.Ring.InfiniteSum
import Mathlib.Analysis.SpecialFunctions.Log.Base
import Mathlib.Analysis.SpecialFunctions.Pow.Real
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.Data.Finset.Card
import Mathlib.Data.Finset.Prod
import Mathlib.Data.Fintype.Pigeonhole
import Mathlib.Data.Nat.Log
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.Nat.Prime.Int
import Mathlib.Data.Real.Archimedean
import Mathlib.LinearAlgebra.Matrix.Block
import Mathlib.LinearAlgebra.Matrix.Determinant.Basic
import Mathlib.NumberTheory.Real.Irrational
import Mathlib.RingTheory.Algebraic.Basic
import Mathlib.Tactic
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Ring

/-!
# Erdős #269: both two-prime running-LCM sums

This file transcribes the two-prime objects of the short paper's
`res:two-prime-transcendence` and of the long paper's `long269:res:lead-two-prime`
and proves everything those statements assert except one external value theorem.

* `runningLcm p q x` is the literal least common multiple of the `{p,q}`-smooth
  numbers not exceeding `x`; `runningLcm_eq_twoPrimeHeight` identifies it with the
  product of the two maximal pure prime powers.
* `repeatedSum p q` is `R_{p,q}`: the reciprocal running LCM summed at every
  positive `{p,q}`-smooth integer.  `distinctSum p q` is `D_{p,q}`: each distinct
  running LCM counted once.
* `two_prime_affine_and_quadratic` proves the paper's displayed identities
  `eq:two-prime-affine`, with `A` the paper's boundary value
  `ErdosProblems.Erdos269.PaperR7.twoPrimeHeckeValue`.
* `two_prime_sums_transcendental` and `two_prime_transcendence` conclude that both
  values are transcendental.

The only undischarged input is `BugeaudLaurentTranscendence`, the theorem of
Bugeaud and Laurent (Theorem 1.1) in the case `ρ = 0` due to Loxton and van der
Poorten (Theorem 8, p. 40), that the Hecke--Mahler series takes transcendental
values.  It is carried as one explicit named hypothesis, stated in the generality
in which the paper cites it; all of its side conditions for the pair `(1/p, 1/q)`,
including irrationality of the slope `θ = log p / log q`, are proved here.
-/

namespace ErdosProblems.Erdos269.PaperCompleteR21
open Polynomial
open scoped BigOperators

noncomputable section

/-! ## The `{p,q}`-smooth numbers and their running least common multiple -/









private theorem pow_le_of_smooth_le {p q : ℕ} (hp : 0 < p) (hq : 0 < q) {i j x : ℕ}
    (h : p ^ i * q ^ j ≤ x) : p ^ i ≤ x ∧ q ^ j ≤ x := by
  have h1 : (1 : ℕ) ≤ p ^ i := Nat.one_le_iff_ne_zero.mpr (pow_ne_zero _ hp.ne')
  have h2 : (1 : ℕ) ≤ q ^ j := Nat.one_le_iff_ne_zero.mpr (pow_ne_zero _ hq.ne')
  constructor
  · calc p ^ i = p ^ i * 1 := (mul_one _).symm
      _ ≤ p ^ i * q ^ j := Nat.mul_le_mul le_rfl h2
      _ ≤ x := h
  · calc q ^ j = 1 * q ^ j := (one_mul _).symm
      _ ≤ p ^ i * q ^ j := Nat.mul_le_mul h1 le_rfl
      _ ≤ x := h

theorem mem_smoothPrefixPairs {p q x : ℕ} (hp : 1 < p) (hq : 1 < q) {e : ℕ × ℕ} :
    e ∈ smoothPrefixPairs p q x ↔ p ^ e.1 * q ^ e.2 ≤ x := by
  constructor
  · intro he
    exact (Finset.mem_filter.mp he).2
  · intro hle
    obtain ⟨h1, h2⟩ := pow_le_of_smooth_le (by omega : 0 < p) (by omega : 0 < q) hle
    refine Finset.mem_filter.mpr ⟨Finset.mem_product.mpr ⟨?_, ?_⟩, hle⟩
    · exact Finset.mem_range.mpr (Nat.lt_succ_of_le (Nat.le_log_of_pow_le hp h1))
    · exact Finset.mem_range.mpr (Nat.lt_succ_of_le (Nat.le_log_of_pow_le hq h2))
end
end ErdosProblems.Erdos269.PaperCompleteR21

open Polynomial
open scoped BigOperators
open ErdosProblems in
open ErdosProblems.Erdos269 in
open ErdosProblems.Erdos269.PaperCompleteR21 in
theorem solution {p q x : ℕ}
    (hp : p.Prime) (hq : q.Prime) (hpq : p ≠ q) (hx : x ≠ 0) :
    runningLcm p q x = twoPrimeHeight p q x := by
  have hp1 : 1 < p := hp.one_lt
  have hq1 : 1 < q := hq.one_lt
  refine Nat.dvd_antisymm ?_ ?_
  · apply Finset.lcm_dvd
    intro e he
    have hle := (mem_smoothPrefixPairs hp1 hq1).mp he
    obtain ⟨h1, h2⟩ := pow_le_of_smooth_le (by omega : 0 < p) (by omega : 0 < q) hle
    exact mul_dvd_mul (pow_dvd_pow p (Nat.le_log_of_pow_le hp1 h1))
      (pow_dvd_pow q (Nat.le_log_of_pow_le hq1 h2))
  · have hpmem : (Nat.log p x, 0) ∈ smoothPrefixPairs p q x := by
      rw [mem_smoothPrefixPairs hp1 hq1]
      simpa using Nat.pow_log_le_self p hx
    have hqmem : (0, Nat.log q x) ∈ smoothPrefixPairs p q x := by
      rw [mem_smoothPrefixPairs hp1 hq1]
      simpa using Nat.pow_log_le_self q hx
    have hpd : p ^ Nat.log p x ∣ runningLcm p q x := by
      simpa [runningLcm] using
        Finset.dvd_lcm (f := fun e : ℕ × ℕ => p ^ e.1 * q ^ e.2) hpmem
    have hqd : q ^ Nat.log q x ∣ runningLcm p q x := by
      simpa [runningLcm] using
        Finset.dvd_lcm (f := fun e : ℕ × ℕ => p ^ e.1 * q ^ e.2) hqmem
    exact (Nat.coprime_pow_primes _ _ hp hq hpq).mul_dvd_of_dvd_of_dvd hpd hqd
