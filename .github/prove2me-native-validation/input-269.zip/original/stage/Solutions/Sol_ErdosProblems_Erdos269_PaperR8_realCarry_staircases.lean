import Definitions.Def_ErdosProblems_Erdos269_ThreePrimeRunningLcm
import Definitions.Def_ErdosProblems_Shared_IrrationalRotationStaircase
import Definitions.Def_ErdosProblems_Erdos269_KernelCarryRank
import Definitions.Def_ErdosProblems_Erdos269_PaperR7AnalyticInterfaces
import Definitions.Def_ErdosProblems_Erdos269_PaperR8UniformRank
import Theorems.Thm_ErdosProblems_Erdos269_logCarry_pow_eq_floor_fract
import Theorems.Thm_ErdosProblems_Shared_exists_staircase_indices
import Mathlib.Algebra.BigOperators.Group.Finset.Basic
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Algebra.Order.Floor.Ring
import Mathlib.Algebra.Order.Floor.Semiring
import Mathlib.Algebra.Ring.Parity
import Mathlib.Analysis.Normed.Module.FiniteDimension
import Mathlib.Analysis.SpecialFunctions.Log.Base
import Mathlib.Data.ENNReal.Real
import Mathlib.Data.Finset.Card
import Mathlib.Data.Finset.Prod
import Mathlib.Data.Fintype.Pigeonhole
import Mathlib.Data.Nat.Log
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.Nat.Prime.Int
import Mathlib.Data.Real.Archimedean
import Mathlib.LinearAlgebra.Matrix.Block
import Mathlib.LinearAlgebra.Matrix.Determinant.Basic
import Mathlib.RingTheory.Algebraic.Basic
import Mathlib.Tactic
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Ring
import Mathlib.Topology.ContinuousMap.Bounded.Normed
import Mathlib.Topology.MetricSpace.Pseudo.Basic

namespace PaperR7
end PaperR7

/-!
# The infinite uniform finite-rank obstruction

The finite staircase minors alone do not prove a uniform lower bound. This
file uses their column separation inside a finite-dimensional bounded column
space, and a finite covering of a compact ball. Row factors in an arbitrary
separated representation need not be bounded; the subspace is formed by
intersecting their algebraic span with the space of bounded functions.

The final infimum ranges over ALL finite-separated-rank matrices. It uses an
extended nonnegative supremum so that unbounded approximants have infinite
uniform error, never the spurious zero returned by an unbounded real iSup.
The resulting finite value is also identified after conversion to the reals.
All proof text is an uncompiled candidate against the packet's pinned Mathlib.
-/

namespace ErdosProblems.Erdos269.PaperR8
open PaperR7 ErdosProblems.Shared Set Metric
open scoped BigOperators Topology BoundedContinuousFunction ENNReal
end ErdosProblems.Erdos269.PaperR8

open PaperR7 ErdosProblems.Shared Set Metric
open scoped BigOperators Topology BoundedContinuousFunction ENNReal
open ErdosProblems in
open ErdosProblems.Erdos269 in
open ErdosProblems.Erdos269.PaperR8 in
open ErdosProblems.Erdos269.PaperR7 in
theorem solution {p q r : ℕ}
    (hp : 0 < p) (hq : 0 < q) (hr : 1 < r)
    (hα : NoIntegerOrbit (Real.logb r p)) (hβ : NoIntegerOrbit (Real.logb r q))
    (n : ℕ) :
    ∃ I J : Fin n → ℕ, ∀ a b,
      realCarryMatrix p q r (I a) (J b) =
        if b ≤ a then (r : ℝ)⁻¹ else 1 := by
  obtain ⟨I, J, _hIpos, _hJpos, _hIinj, _hJinj, hstair⟩ :=
    exists_staircase_indices hα hβ n
  refine ⟨I, J, ?_⟩
  intro a b
  have hc := logCarry_pow_eq_floor_fract (b := r) hr hp hq (I a) (J b)
  rw [hstair a b] at hc
  by_cases hba : b ≤ a
  · have hn : (b : ℕ) ≤ (a : ℕ) := hba
    rw [if_pos hn] at hc
    have hcarry : logCarry r (p ^ I a) (q ^ J b) = 1 := by omega
    simp only [realCarryMatrix, hcarry, pow_one, if_pos hba]
  · have hn : ¬(b : ℕ) ≤ (a : ℕ) := hba
    rw [if_neg hn] at hc
    have hcarry : logCarry r (p ^ I a) (q ^ J b) = 0 := by omega
    simp only [realCarryMatrix, hcarry, pow_zero, if_neg hba]
