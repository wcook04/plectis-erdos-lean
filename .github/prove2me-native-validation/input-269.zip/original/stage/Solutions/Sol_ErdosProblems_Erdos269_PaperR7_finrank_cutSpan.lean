import Definitions.Def_ErdosProblems_Erdos269_PaperR7FiniteCutRank
import Theorems.Thm_ErdosProblems_Erdos269_PaperR7_cutSpan_erase_zero
import Theorems.Thm_ErdosProblems_Erdos269_PaperR7_cutVectors_linearIndependent
import Mathlib.Data.Fintype.BigOperators
import Mathlib.LinearAlgebra.Dimension.Constructions
import Mathlib.LinearAlgebra.LinearIndependent.Basic
import Mathlib.LinearAlgebra.Matrix.Rank
import Mathlib.Tactic

/-!
# Paper-complete campaign, round 7: the complete finite cut-rank formula

Target: short-note `res:finite-cut-rank`.  This file generalises the supplied
rational interval-difference engine to an arbitrary field, proves independence
except for the two extreme columns, removes exactly that redundancy, and states
the result using `Matrix.rank`. Repetitions and permutations of columns are
handled by a column-range equality, not an extra independence assumption.

Authored against Lean 4.29.1 and the packet's Mathlib pin.
No admitted statements or additional axioms are introduced.
-/

namespace ErdosProblems.Erdos269.PaperR7
open scoped BigOperators
open Module Submodule

variable {F : Type*} [Field F]
end ErdosProblems.Erdos269.PaperR7

open scoped BigOperators
open Module Submodule
variable {F : Type*} [Field F]
open ErdosProblems in
open ErdosProblems.Erdos269 in
open ErdosProblems.Erdos269.PaperR7 in
theorem solution (c : F) (hc0 : c ≠ 0) (hc1 : c ≠ 1)
    {m : ℕ} (hm : 0 < m) (E : Finset ℕ)
    (hbound : ∀ k ∈ E, k ≤ m) :
    Module.finrank F (cutSpan c m E) =
      E.card - if 0 ∈ E ∧ m ∈ E then 1 else 0 := by
  classical
  by_cases hext : 0 ∈ E ∧ m ∈ E
  · rw [if_pos hext, cutSpan_erase_zero c hm E hext.2]
    have hb : ∀ k ∈ E.erase 0, k ≤ m :=
      fun k hk => hbound k (Finset.mem_of_mem_erase hk)
    have hi := cutVectors_linearIndependent c hc0 hc1 hm (E.erase 0) hb (by simp)
    change Module.finrank F
      (Submodule.span F (Set.range (fun k : E.erase 0 => cutVector c m k))) = _
    rw [finrank_span_eq_card hi, Fintype.card_coe, Finset.card_erase_of_mem hext.1]
  · rw [if_neg hext, Nat.sub_zero]
    exact (finrank_span_eq_card
      (cutVectors_linearIndependent c hc0 hc1 hm E hbound hext)).trans
        (Fintype.card_coe E)
