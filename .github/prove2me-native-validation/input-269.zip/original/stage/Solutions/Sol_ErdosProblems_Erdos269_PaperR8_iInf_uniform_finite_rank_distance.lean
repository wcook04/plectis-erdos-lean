import Definitions.Def_ErdosProblems_Erdos269_ThreePrimeRunningLcm
import Definitions.Def_ErdosProblems_Shared_IrrationalRotationStaircase
import Definitions.Def_ErdosProblems_Erdos269_KernelCarryRank
import Definitions.Def_ErdosProblems_Erdos269_PaperR7AnalyticInterfaces
import Definitions.Def_ErdosProblems_Erdos269_PaperR8UniformRank
import Theorems.Thm_ErdosProblems_Erdos269_PaperR7_uniform_carry_midpoint_witness
import Theorems.Thm_ErdosProblems_Erdos269_PaperR8_finite_rank_uniform_error_lower
import Mathlib.Algebra.BigOperators.Group.Finset.Basic
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Algebra.Order.Floor.Ring
import Mathlib.Algebra.Order.Floor.Semiring
import Mathlib.Algebra.Ring.Parity
import Mathlib.Analysis.Normed.Module.FiniteDimension
import Mathlib.Analysis.SpecialFunctions.Log.Base
import Mathlib.Data.ENNReal.Real
import Mathlib.Data.Finset.Card
import Mathlib.Data.Finset.Prod
import Mathlib.Data.Fintype.Pigeonhole
import Mathlib.Data.Nat.Log
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.Nat.Prime.Int
import Mathlib.Data.Real.Archimedean
import Mathlib.LinearAlgebra.Matrix.Block
import Mathlib.LinearAlgebra.Matrix.Determinant.Basic
import Mathlib.RingTheory.Algebraic.Basic
import Mathlib.Tactic
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Ring
import Mathlib.Topology.ContinuousMap.Bounded.Normed
import Mathlib.Topology.MetricSpace.Pseudo.Basic

namespace PaperR7
end PaperR7

/-!
# The infinite uniform finite-rank obstruction

The finite staircase minors alone do not prove a uniform lower bound. This
file uses their column separation inside a finite-dimensional bounded column
space, and a finite covering of a compact ball. Row factors in an arbitrary
separated representation need not be bounded; the subspace is formed by
intersecting their algebraic span with the space of bounded functions.

The final infimum ranges over ALL finite-separated-rank matrices. It uses an
extended nonnegative supremum so that unbounded approximants have infinite
uniform error, never the spurious zero returned by an unbounded real iSup.
The resulting finite value is also identified after conversion to the reals.
All proof text is an uncompiled candidate against the packet's pinned Mathlib.
-/

namespace ErdosProblems.Erdos269.PaperR8
open PaperR7 ErdosProblems.Shared Set Metric
open scoped BigOperators Topology BoundedContinuousFunction ENNReal
end ErdosProblems.Erdos269.PaperR8

open PaperR7 ErdosProblems.Shared Set Metric
open scoped BigOperators Topology BoundedContinuousFunction ENNReal
open ErdosProblems in
open ErdosProblems.Erdos269 in
open ErdosProblems.Erdos269.PaperR8 in
open ErdosProblems.Erdos269.PaperR7 in
theorem solution {p q r : ℕ}
    (hp : 0 < p) (hq : 0 < q) (hr : 1 < r)
    (hα : NoIntegerOrbit (Real.logb r p)) (hβ : NoIntegerOrbit (Real.logb r q)) :
    (⨅ A : FiniteRankMatrix, uniformError (realCarryMatrix p q r) A.val) =
      ENNReal.ofReal (((r : ℝ) - 1) / (2 * (r : ℝ))) := by
  classical
  let gap : ℝ := ((r : ℝ) - 1) / (2 * (r : ℝ))
  have hrR : (1 : ℝ) < r := by exact_mod_cast hr
  have hr0 : (0 : ℝ) < r := lt_trans (by norm_num) hrR
  have hgap_eq : gap = (1 - (r : ℝ)⁻¹) / 2 := by
    dsimp [gap]
    field_simp [hr0.ne']
    <;> ring
  let mid : FiniteRankMatrix :=
    ⟨(fun _ _ => (1 + (r : ℝ)⁻¹) / 2),
      ⟨1, (fun _ _ => (1 + (r : ℝ)⁻¹) / 2), (fun _ _ => 1),
        by intro i j; simp⟩⟩
  change (⨅ A : FiniteRankMatrix, uniformError (realCarryMatrix p q r) A.val) =
    ENNReal.ofReal gap
  apply le_antisymm
  · refine (iInf_le _ mid).trans ?_
    apply iSup_le
    intro i
    apply iSup_le
    intro j
    have h := (uniform_carry_midpoint_witness hp hq hr).2 i j
    change ENNReal.ofReal |realCarryMatrix p q r i j - (1 + (r : ℝ)⁻¹) / 2| ≤ _
    rw [h]
  · apply le_iInf
    intro A
    let E := uniformError (realCarryMatrix p q r) A.val
    change ENNReal.ofReal gap ≤ E
    by_cases htop : E = ⊤
    · rw [htop]
      exact le_top
    have herr : ∀ i j, |realCarryMatrix p q r i j - A.val i j| ≤ E.toReal := by
      intro i j
      have he : ENNReal.ofReal |realCarryMatrix p q r i j - A.val i j| ≤ E :=
        (le_iSup_of_le i (le_iSup_of_le j le_rfl))
      -- Mathlib/Data/ENNReal/Real.lean: toReal_mono.
      -- Mathlib/Data/ENNReal/Basic.lean: toReal_ofReal.
      have h := ENNReal.toReal_mono htop he
      simpa only [ENNReal.toReal_ofReal (abs_nonneg _)] using h
    have hlow := finite_rank_uniform_error_lower hp hq hr hα hβ A.val A.property
      E.toReal ENNReal.toReal_nonneg herr
    rw [← hgap_eq] at hlow
    -- Mathlib/Data/ENNReal/Real.lean: ofReal_le_of_le_toReal.
    exact ENNReal.ofReal_le_of_le_toReal hlow
