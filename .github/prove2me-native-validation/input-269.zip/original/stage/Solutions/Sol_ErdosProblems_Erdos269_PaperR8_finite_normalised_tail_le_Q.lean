import Definitions.Def_ErdosProblems_Erdos269_BoundedRadixTailEscape
import Definitions.Def_ErdosProblems_Erdos269_ResidueEscape
import Definitions.Def_ErdosProblems_Erdos269_ThreePrimeRunningLcm
import Definitions.Def_ErdosProblems_Erdos269_RestrictedFloorSum
import Definitions.Def_ErdosProblems_Erdos269_DyadicBlockMassIdentity
import Definitions.Def_ErdosProblems_Erdos269_DyadicBlockThresholdPartition
import Definitions.Def_ErdosProblems_Erdos269_DyadicOrderedTailRecurrence
import Definitions.Def_ErdosProblems_Erdos269_DyadicShellSummability
import Definitions.Def_ErdosProblems_Erdos269_IntegralBranchExtinction
import Definitions.Def_ErdosProblems_Erdos269_JumpConstraintMajorant
import Definitions.Def_ErdosProblems_Shared_IrrationalRotationStaircase
import Definitions.Def_ErdosProblems_Erdos269_KernelCarryRank
import Definitions.Def_ErdosProblems_Erdos269_PaperR7ActualOrbit
import Definitions.Def_ErdosProblems_Erdos269_PaperR7SeriesIdentification
import Definitions.Def_ErdosProblems_Erdos269_RationalLatticeReduction
import Definitions.Def_ErdosProblems_Erdos269_RationalityCarryBridge
import Definitions.Def_ErdosProblems_Erdos269_PaperR7RationalBridge
import Definitions.Def_ErdosProblems_Erdos269_PaperR7WindowResults
import Definitions.Def_ErdosProblems_Erdos269_PaperR8RankMajorant
import Theorems.Thm_ErdosProblems_Erdos269_PaperR8_hasSum_rankMajorant
import Theorems.Thm_ErdosProblems_Erdos269_PaperR8_heightRank235_dyadic
import Theorems.Thm_ErdosProblems_Erdos269_PaperR8_heightRank235_mono
import Theorems.Thm_ErdosProblems_Erdos269_PaperR8_rank_fibre_card_bound
import Theorems.Thm_ErdosProblems_Erdos269_PaperR8_normalised_kernel_le_rank_weight
import Mathlib.Algebra.BigOperators.Group.Finset.Basic
import Mathlib.Algebra.BigOperators.Group.Finset.Sigma
import Mathlib.Algebra.BigOperators.Group.List.Basic
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Algebra.Order.Floor.Ring
import Mathlib.Algebra.Order.Floor.Semiring
import Mathlib.Algebra.Ring.Parity
import Mathlib.Analysis.SpecialFunctions.Log.Base
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Data.Finset.Card
import Mathlib.Data.Finset.Prod
import Mathlib.Data.Fintype.Pigeonhole
import Mathlib.Data.Int.ModEq
import Mathlib.Data.Nat.Factorization.Basic
import Mathlib.Data.Nat.Log
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.Nat.Prime.Int
import Mathlib.Data.Real.Archimedean
import Mathlib.LinearAlgebra.Matrix.Block
import Mathlib.LinearAlgebra.Matrix.Determinant.Basic
import Mathlib.Tactic
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.InfiniteSum.Order
import Mathlib.Topology.Algebra.InfiniteSum.Real

namespace PaperR7
end PaperR7

/-!
# The actual height-rank majorant (round 8)

This file supplies the missing geometric summation over height ranks, not a
comparison of the much larger dyadic-shell bound with `carryMajorantQ`.
It uses the live round-7 definitions without changing any of them.

Proof text: not elaborated in this return. No additional hypotheses are hidden
in the final theorem. Mathlib source checks use commit
`5e932f97dd25535344f80f9dd8da3aab83df0fe6`.
-/

namespace ErdosProblems.Erdos269.PaperR8
open scoped BigOperators
open PaperR7
end ErdosProblems.Erdos269.PaperR8

open scoped BigOperators
open PaperR7
open ErdosProblems in
open ErdosProblems.Erdos269 in
open ErdosProblems.Erdos269.PaperR8 in
open ErdosProblems.Erdos269.PaperR7 in
theorem solution (a : ℕ) (s : Finset Exponent235)
    (hs : ∀ e ∈ s, 2 ^ a ≤ exponentValue235 e) :
    (∑ e ∈ s, (threePrimeHeight 2 3 5 (2 ^ a) : ℝ) / 2 * exponentKernel235 e) ≤
      (carryMajorantQ (paperJumpIndex a) : ℝ) := by
  classical
  let kfun : Exponent235 → ℕ := fun e =>
    heightRank235 (exponentValue235 e) - paperJumpIndex a
  let f : Exponent235 → ℝ := fun e =>
    (threePrimeHeight 2 3 5 (2 ^ a) : ℝ) / 2 * exponentKernel235 e
  have hfib : ∀ k ∈ s.image kfun,
      (∑ e ∈ s with kfun e = k, f e) ≤ rankMajorant (paperJumpIndex a) k := by
    intro k _hk
    let t := s.filter (fun e => kfun e = k)
    have ht : ∀ e ∈ t, heightRank235 (exponentValue235 e) = paperJumpIndex a + k := by
      intro e he
      have he' := Finset.mem_filter.mp he
      have hmono := heightRank235_mono (hs e he'.1)
      rw [heightRank235_dyadic] at hmono
      have hek : heightRank235 (exponentValue235 e) - paperJumpIndex a = k := he'.2
      omega
    have hcardN := rank_fibre_card_bound t (paperJumpIndex a + k) ht
    have hcard : (t.card : ℝ) ≤ ((paperJumpIndex a + k + 3 : ℕ) : ℝ) ^ 2 / 9 := by
      have h : (9 : ℝ) * t.card ≤ ((paperJumpIndex a + k + 3 : ℕ) : ℝ) ^ 2 := by
        exact_mod_cast hcardN
      linarith
    change (∑ e ∈ t, f e) ≤ _
    calc
      (∑ e ∈ t, f e) ≤ ∑ _e ∈ t, 1 / (2 * (2 : ℝ) ^ k) := by
        apply Finset.sum_le_sum
        intro e he
        have he' := Finset.mem_filter.mp he
        have hw := normalised_kernel_le_rank_weight a e (hs e he'.1)
        change f e ≤ 1 / (2 * (2 : ℝ) ^ kfun e) at hw
        rw [he'.2] at hw
        exact hw
      _ = (t.card : ℝ) * (1 / (2 * (2 : ℝ) ^ k)) := by simp
      _ ≤ (((paperJumpIndex a + k + 3 : ℕ) : ℝ) ^ 2 / 9) *
          (1 / (2 * (2 : ℝ) ^ k)) :=
        mul_le_mul_of_nonneg_right hcard (by positivity)
      _ = rankMajorant (paperJumpIndex a) k := by unfold rankMajorant; ring
  have hsum : (∑ e ∈ s, f e) =
      ∑ k ∈ s.image kfun, ∑ e ∈ s with kfun e = k, f e := by
    -- Mathlib/Algebra/BigOperators/Group/Finset/Basic.lean:
    -- Finset.sum_fiberwise_of_maps_to.
    symm
    exact Finset.sum_fiberwise_of_maps_to
      (fun _e he => Finset.mem_image_of_mem kfun he) f
  change (∑ e ∈ s, f e) ≤ _
  rw [hsum]
  have hfinite := Finset.sum_le_sum hfib
  refine hfinite.trans ?_
  -- Mathlib/Topology/Algebra/InfiniteSum/Order.lean: sum_le_hasSum.
  exact sum_le_hasSum (s.image kfun)
    (fun k _ => by unfold rankMajorant; positivity)
    (hasSum_rankMajorant (paperJumpIndex a))
