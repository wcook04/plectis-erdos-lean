import Definitions.Def_ErdosProblems_Erdos269_BoundedRadixTailEscape
import Definitions.Def_ErdosProblems_Erdos269_ResidueEscape
import Definitions.Def_ErdosProblems_Erdos269_ThreePrimeRunningLcm
import Definitions.Def_ErdosProblems_Erdos269_RestrictedFloorSum
import Definitions.Def_ErdosProblems_Erdos269_DyadicBlockMassIdentity
import Definitions.Def_ErdosProblems_Erdos269_DyadicBlockThresholdPartition
import Definitions.Def_ErdosProblems_Erdos269_DyadicOrderedTailRecurrence
import Definitions.Def_ErdosProblems_Erdos269_DyadicShellSummability
import Definitions.Def_ErdosProblems_Erdos269_IntegralBranchExtinction
import Theorems.Thm_ErdosProblems_Erdos269_dyadicSmoothShell235_card_le_square
import Theorems.Thm_ErdosProblems_Erdos269_PaperR7_inverse_height_le_shell_geometric
import Mathlib.Algebra.BigOperators.Group.Finset.Basic
import Mathlib.Algebra.BigOperators.Group.Finset.Sigma
import Mathlib.Algebra.BigOperators.Group.List.Basic
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Algebra.Ring.Parity
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Data.Finset.Card
import Mathlib.Data.Finset.Prod
import Mathlib.Data.Int.ModEq
import Mathlib.Data.Nat.Log
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.Nat.Prime.Int
import Mathlib.Tactic
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Ring

namespace ErdosProblems.Erdos269.PaperR7
end ErdosProblems.Erdos269.PaperR7

/-!
# Round 7: the literal `8640 / 343` shell bound

Target: the bound in short-note `res:actual-orbit`.  The supplied bound `90`
does not prove this sharper displayed constant.  We retain the actual shell
mass, prove its `8^{-a}` estimate, and sum the resulting majorant exactly.
This is NOT a proof of the separate long-record `Q(n_a)` bound.

No admissions.
-/

namespace ErdosProblems.Erdos269.PaperR7
open scoped BigOperators
end ErdosProblems.Erdos269.PaperR7

open scoped BigOperators
open ErdosProblems in
open ErdosProblems.Erdos269 in
open ErdosProblems.Erdos269.PaperR7 in
theorem solution (a : ℕ) :
    dyadicShellMassR235 a ≤ 30 * ((a + 1 : ℕ) : ℝ) ^ 2 / (8 : ℝ) ^ a := by
  have hrepr : dyadicShellMassR235 a =
      ∑ e ∈ dyadicSmoothShell235 a,
        ((threePrimeHeight 2 3 5 (smooth3Val 2 3 5 e.1 e.2.1 e.2.2) : ℕ) : ℝ)⁻¹ := by
    simp [dyadicShellMassR235, dyadicShellMassQ235]
  rw [hrepr]
  calc
    (∑ e ∈ dyadicSmoothShell235 a,
      ((threePrimeHeight 2 3 5 (smooth3Val 2 3 5 e.1 e.2.1 e.2.2) : ℕ) : ℝ)⁻¹)
        ≤ ∑ _e ∈ dyadicSmoothShell235 a, 30 / (8 : ℝ) ^ a := by
          apply Finset.sum_le_sum
          intro e he
          exact inverse_height_le_shell_geometric a _
            (mem_dyadicSmoothShell235_iff.mp he).1
    _ = (dyadicSmoothShell235 a).card * (30 / (8 : ℝ) ^ a) := by simp
    _ ≤ (((a + 1 : ℕ) : ℝ) ^ 2) * (30 / (8 : ℝ) ^ a) := by
      apply mul_le_mul_of_nonneg_right _ (by positivity)
      exact_mod_cast dyadicSmoothShell235_card_le_square a
    _ = 30 * ((a + 1 : ℕ) : ℝ) ^ 2 / (8 : ℝ) ^ a := by ring
