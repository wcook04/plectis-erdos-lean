import Definitions.Def_ErdosProblems_Shared_IrrationalRotationStaircase
import Theorems.Thm_ErdosProblems_Shared_exists_small_step
import Mathlib.Algebra.Order.Floor.Ring
import Mathlib.Algebra.Order.Floor.Semiring
import Mathlib.Analysis.SpecialFunctions.Log.Base
import Mathlib.Data.Fintype.Pigeonhole
import Mathlib.Data.Real.Archimedean
import Mathlib.LinearAlgebra.Matrix.Block
import Mathlib.LinearAlgebra.Matrix.Determinant.Basic
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Ring

/-!
# Irrational-rotation staircases and the carry-staircase determinant

Two independent pieces of reusable machinery.

* `ErdosProblems.Shared.exists_pos_nat_fract_mem_Ioo` : the **forward** orbit
  `n ↦ Int.fract (n * α)`, `n ≥ 1`, is dense in `[0,1]` as soon as no positive
  integer multiple of `α` is an integer.  The hypothesis is packaged as
  `NoIntegerOrbit`; for real `α` it is exactly irrationality, but it is often
  cheaper to verify directly.

* `ErdosProblems.Shared.det_carryStaircase` : the exact determinant
  `det (fun i j => if j ≤ i then t else 1) = t * (t - 1) ^ n`
  of the `(n+1)`-dimensional *carry staircase*.

Combined in `exists_staircase_indices`, they say that a pair of independent
rotations without integer returns realises an arbitrarily large staircase in
the two-dimensional carry `⌊fract (i * α) + fract (j * β)⌋`.  That is the
engine behind the three-prime running-LCM rank phase transition of Erdős #269.

Nothing here mentions a specific Erdős problem; the file is Mathlib-only.
-/

namespace ErdosProblems.Shared
open Set Matrix

/-! ## Forward orbits of a rotation without integer returns -/



/-- Scaling a real by a natural number is transparent to `Int.fract` as long
as the scaled fractional part has not yet wrapped. -/
theorem fract_natCast_mul_of_lt_one {x : ℝ} {m : ℕ}
    (h : (m : ℝ) * Int.fract x < 1) :
    Int.fract ((m : ℝ) * x) = (m : ℝ) * Int.fract x := by
  have h0 : (0 : ℝ) ≤ (m : ℝ) * Int.fract x :=
    mul_nonneg (Nat.cast_nonneg m) (Int.fract_nonneg x)
  have hx : x = (⌊x⌋ : ℝ) + Int.fract x := (Int.floor_add_fract x).symm
  have key : (m : ℝ) * x = ((m * ⌊x⌋ : ℤ) : ℝ) + (m : ℝ) * Int.fract x := by
    calc (m : ℝ) * x = (m : ℝ) * ((⌊x⌋ : ℝ) + Int.fract x) := by rw [← hx]
      _ = ((m * ⌊x⌋ : ℤ) : ℝ) + (m : ℝ) * Int.fract x := by push_cast; ring
  rw [key, Int.fract_intCast_add, Int.fract_eq_self.2 ⟨h0, h⟩]
end ErdosProblems.Shared

open Set Matrix
open ErdosProblems in
open ErdosProblems.Shared in
theorem solution {α : ℝ} (hα : NoIntegerOrbit α)
    {c d : ℝ} (hc : 0 ≤ c) (hcd : c < d) (hd : d ≤ 1) :
    ∃ n : ℕ, 0 < n ∧ c < Int.fract ((n : ℝ) * α) ∧ Int.fract ((n : ℝ) * α) < d := by
  set ε : ℝ := (d - c) / 2 with hεdef
  have hε : 0 < ε := by rw [hεdef]; linarith
  have hε1 : ε ≤ 1 := by rw [hεdef]; linarith
  obtain ⟨k, hk, hstep⟩ := exists_small_step (α := α) hε hε1
  set δ : ℝ := Int.fract ((k : ℝ) * α) with hδdef
  have hδ0 : 0 < δ := lt_of_le_of_ne (Int.fract_nonneg _) (Ne.symm (hα k hk))
  rcases hstep with hsmall | hlarge
  · -- small forward step: climb from `0` past `c` before overshooting `d`
    set m : ℕ := ⌈c / δ⌉₊ + 1 with hm
    have hmpos : 0 < m := by omega
    have hceil_lb : c ≤ (⌈c / δ⌉₊ : ℝ) * δ := by
      have hle := Nat.le_ceil (c / δ)
      calc c = c / δ * δ := by field_simp
        _ ≤ (⌈c / δ⌉₊ : ℝ) * δ := by nlinarith
    have hceil_ub : (⌈c / δ⌉₊ : ℝ) * δ < c + δ := by
      have hnn : (0 : ℝ) ≤ c / δ := by positivity
      have hlt := Nat.ceil_lt_add_one hnn
      calc (⌈c / δ⌉₊ : ℝ) * δ < (c / δ + 1) * δ := by nlinarith
        _ = c + δ := by field_simp
    have hmδ : (m : ℝ) * δ = (⌈c / δ⌉₊ : ℝ) * δ + δ := by rw [hm]; push_cast; ring
    have hlb : c < (m : ℝ) * δ := by rw [hmδ]; linarith
    have hub : (m : ℝ) * δ < d := by
      rw [hmδ]; rw [hεdef] at hsmall; linarith
    have hcast : (((m * k : ℕ)) : ℝ) * α = (m : ℝ) * ((k : ℝ) * α) := by
      push_cast; ring
    have hval : Int.fract (((m * k : ℕ) : ℝ) * α) = (m : ℝ) * δ := by
      rw [hcast, fract_natCast_mul_of_lt_one (by rw [← hδdef]; linarith), ← hδdef]
    exact ⟨m * k, Nat.mul_pos hmpos hk, by rw [hval]; exact hlb, by rw [hval]; exact hub⟩
  · -- large forward step: descend from `1` below `d` before undershooting `c`
    set η : ℝ := 1 - δ with hη
    have hη0 : 0 < η := by rw [hη]; linarith [Int.fract_lt_one ((k : ℝ) * α)]
    have hηε : η < ε := by rw [hη]; linarith
    set m : ℕ := ⌈(1 - d) / η⌉₊ + 1 with hm
    have hmpos : 0 < m := by omega
    have h1d : (0 : ℝ) ≤ 1 - d := by linarith
    have hceil_lb : 1 - d ≤ (⌈(1 - d) / η⌉₊ : ℝ) * η := by
      have hle := Nat.le_ceil ((1 - d) / η)
      calc 1 - d = (1 - d) / η * η := by field_simp
        _ ≤ (⌈(1 - d) / η⌉₊ : ℝ) * η := by nlinarith
    have hceil_ub : (⌈(1 - d) / η⌉₊ : ℝ) * η < (1 - d) + η := by
      have hnn : (0 : ℝ) ≤ (1 - d) / η := by positivity
      have hlt := Nat.ceil_lt_add_one hnn
      calc (⌈(1 - d) / η⌉₊ : ℝ) * η < ((1 - d) / η + 1) * η := by nlinarith
        _ = (1 - d) + η := by field_simp
    have hmη : (m : ℝ) * η = (⌈(1 - d) / η⌉₊ : ℝ) * η + η := by rw [hm]; push_cast; ring
    have hlb : 1 - d < (m : ℝ) * η := by rw [hmη]; linarith
    have hub : (m : ℝ) * η < 1 - c := by rw [hmη]; rw [hεdef] at hηε; linarith
    have hmη0 : 0 < (m : ℝ) * η := by positivity
    have hmη1 : (m : ℝ) * η < 1 := by linarith
    have hfeq : Int.fract ((m : ℝ) * η) = (m : ℝ) * η :=
      Int.fract_eq_self.2 ⟨hmη0.le, hmη1⟩
    have hkey : Int.fract (((m * k : ℕ) : ℝ) * α) = 1 - (m : ℝ) * η := by
      have hcast : (((m * k : ℕ)) : ℝ) * α = (m : ℝ) * ((k : ℝ) * α) := by push_cast; ring
      have hstepd : Int.fract ((m : ℝ) * ((k : ℝ) * α)) = Int.fract ((m : ℝ) * δ) := by
        refine Int.fract_eq_fract.2 ⟨m * ⌊(k : ℝ) * α⌋, ?_⟩
        rw [hδdef, Int.fract]
        push_cast
        ring
      have hsplit : (m : ℝ) * δ = (m : ℝ) + -((m : ℝ) * η) := by rw [hη]; ring
      have hfneg : Int.fract (-((m : ℝ) * η)) = 1 - (m : ℝ) * η := by
        rw [Int.fract_neg (by rw [hfeq]; exact ne_of_gt hmη0), hfeq]
      rw [hcast, hstepd, hsplit, Int.fract_natCast_add, hfneg]
    exact ⟨m * k, Nat.mul_pos hmpos hk, by rw [hkey]; linarith, by rw [hkey]; linarith⟩
