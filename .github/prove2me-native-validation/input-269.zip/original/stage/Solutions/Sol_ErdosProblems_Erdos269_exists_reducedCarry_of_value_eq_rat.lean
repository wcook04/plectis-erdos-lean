import Definitions.Def_ErdosProblems_Erdos269_BoundedRadixTailEscape
import Definitions.Def_ErdosProblems_Erdos269_ResidueEscape
import Definitions.Def_ErdosProblems_Erdos269_ThreePrimeRunningLcm
import Definitions.Def_ErdosProblems_Erdos269_RestrictedFloorSum
import Definitions.Def_ErdosProblems_Erdos269_DyadicBlockMassIdentity
import Definitions.Def_ErdosProblems_Erdos269_DyadicBlockThresholdPartition
import Definitions.Def_ErdosProblems_Erdos269_DyadicOrderedTailRecurrence
import Definitions.Def_ErdosProblems_Erdos269_DyadicShellSummability
import Definitions.Def_ErdosProblems_Erdos269_IntegralBranchExtinction
import Definitions.Def_ErdosProblems_Erdos269_RationalLatticeReduction
import Definitions.Def_ErdosProblems_Erdos269_RationalityCarryBridge
import Theorems.Thm_ErdosProblems_Erdos269_qsmul_trueNormalizedState_eq_height_mul_sub
import Theorems.Thm_ErdosProblems_Erdos269_smooth_dvd_heightNormalizer235
import Theorems.Thm_ErdosProblems_Erdos269_trueNormalizedState_mul_le
import Theorems.Thm_ErdosProblems_Erdos269_trueNormalizedState_pos
import Theorems.Thm_ErdosProblems_Erdos269_exists_smooth_coprime_split
import Theorems.Thm_ErdosProblems_Erdos269_latticeCarry_succ
import Theorems.Thm_ErdosProblems_Erdos269_smooth_dvd_latticeCarry
import Mathlib.Algebra.BigOperators.Group.Finset.Basic
import Mathlib.Algebra.BigOperators.Group.Finset.Sigma
import Mathlib.Algebra.BigOperators.Group.List.Basic
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Algebra.Ring.Parity
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Data.Finset.Card
import Mathlib.Data.Finset.Prod
import Mathlib.Data.Int.ModEq
import Mathlib.Data.Nat.Log
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.Nat.Prime.Int
import Mathlib.Tactic
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Ring

/-!
# Erdős #269: the rationality-to-carry bridge, closed

The paper's Problem `prob:bridge269` ("actual rationality-to-carry
identification") asks: starting from the `{2,3,5}` running-LCM series and a
reduced denominator `D = D_sm · B` with `D_sm` `30`-smooth and `gcd(B,30) = 1`,
prove with a stated onset `a ≥ a_D` that the literal radix word
`β_a = dyadicBlockBase235 a`, the literal digit `m_a = dyadicOrderedBlockDigit235 a`
and the literal normalized tail `T_a = trueNormalizedState a` give positive
integral carries `c_a = D T_a` with `c_(a+1) = β_a c_a - D m_a`, an explicit
bound, and `D_sm ∣ c_a`; and that the reduced carry `d_a = c_a / D_sm` obeys
`d_(a+1) = β_a d_a - B m_a` with `0 < d_a ≤ K(B, a)`.

This module proves exactly that, with `K(B, a) = B · 90 (a+1)^2` (the width of
`NormalizedStateWidth`) and onset `a_D = α + 1 + 2β + 3γ` for
`D_sm = 2^α 3^β 5^γ`.  The pieces:

* `exists_smooth_coprime_split` — every positive integer is `2^α 3^β 5^γ · B`
  with `gcd(B, 30) = 1`;
* `smooth_dvd_heightNormalizer235` — the half height `H(2^a)/2` absorbs
  `2^α 3^β 5^γ` once `a ≥ α + 1 + 2β + 3γ`;
* `qsmul_trueNormalizedState_eq_height_mul_sub` — the all-scale lattice with
  its explicit witness `q X_a = (H(2^a)/2) p - q z_a`, so the carry is
  congruent to `(H(2^a)/2) p` modulo `q` and the smooth part divides it;
* `latticeCarry` and its recurrence, positivity and width, all inherited from
  the true state through the integer cast;
* `reducedLatticeCarry` — the quotient by the smooth part, with the reduced
  recurrence and the bound `0 < d_a ≤ B · 90 (a+1)^2` from the onset on.

The consumer `no_positive_reducedCarry_of_cofinalLocalWindowEscape` of
`RestrictedFloorSum` was stated for carries defined at every index; the
onset-aware form `no_positive_reducedCarry_of_cofinalLocalWindowEscape_onset`
proved here uses the producer's own `∀ lo₀ ∃ lo ≥ lo₀` clause to start the
window past the onset.

## Consequence

`irrational_of_cofinalLocalWindowEscape`: the paper's Problem `prob:producer`
(9.5), i.e. `CofinalLocalWindowEscape` for the actual radix word, the actual
ordered digit and the short bound `B · 90 (n+1)^2`, implies that
`Σ_{h ≥ 2} 1/H(h)` is irrational, hence (`irrational_value_of_cofinalLocalWindowEscape`)
that the Erdős #269 value `Σ_{h ≥ 1} 1/H(h)` is irrational.  The generic
extinction theorem is thereby a theorem about the actual series: the only
unproved input is the cofinal local-window escape itself.

## Claim ceiling

`CofinalLocalWindowEscape` is a named `Prop`, not a theorem.  Nothing here
proves it, and **Erdős #269 remains open**.  What is closed is the bridge: a
rational value forces, from an explicit onset, a positive reduced integral
carry of the exact shape the residue consumer refutes, with every object the
literal one from the series.
-/

namespace ErdosProblems.Erdos269
open scoped BigOperators

/-! ## Onset-aware window identity and consumer -/





/-! ## Splitting a denominator into its `30`-smooth and rough parts -/





/-! ## The lattice witness, made explicit -/



/-! ## The integral lattice carry and its reduction -/



theorem latticeCarry_cast {p q : ℤ} (hq : 0 < q)
    (hval : dyadicShellTsumTailR235 1 = (p : ℝ) / (q : ℝ))
    {a : ℕ} (ha : 1 ≤ a) :
    ((latticeCarry q a : ℤ) : ℝ) = (q : ℝ) * trueNormalizedState a := by
  obtain ⟨z, hz⟩ := qsmul_trueNormalizedState_eq_height_mul_sub hq hval ha
  have hint : (q : ℝ) * trueNormalizedState a
      = (((heightNormalizer235 a : ℕ) : ℤ) * p - q * z : ℤ) := by
    rw [hz]
    push_cast
    ring
  unfold latticeCarry
  rw [hint, Int.floor_intCast]





/-- The carry is positive at every scale `a ≥ 1`. -/
theorem latticeCarry_pos {p q : ℤ} (hq : 0 < q)
    (hval : dyadicShellTsumTailR235 1 = (p : ℝ) / (q : ℝ))
    {a : ℕ} (ha : 1 ≤ a) : 0 < latticeCarry q a := by
  have h := latticeCarry_cast hq hval ha
  have hpos : (0 : ℝ) < (q : ℝ) * trueNormalizedState a :=
    mul_pos (by exact_mod_cast hq) (trueNormalizedState_pos a)
  rw [← h] at hpos
  exact_mod_cast hpos

/-- The carry is bounded by `q · 90 (a+1)^2` at every scale `a ≥ 1`. -/
theorem latticeCarry_le {p q : ℤ} (hq : 0 < q)
    (hval : dyadicShellTsumTailR235 1 = (p : ℝ) / (q : ℝ))
    {a : ℕ} (ha : 1 ≤ a) :
    latticeCarry q a ≤ q * ((90 * (a + 1) ^ 2 : ℕ) : ℤ) := by
  have h := latticeCarry_cast hq hval ha
  have hle : (q : ℝ) * trueNormalizedState a ≤ (q : ℝ) * (90 * ((a + 1 : ℕ) : ℝ) ^ 2) :=
    trueNormalizedState_mul_le a (by exact_mod_cast hq.le)
  rw [← h] at hle
  have hle' : ((latticeCarry q a : ℤ) : ℝ) ≤ ((q * ((90 * (a + 1) ^ 2 : ℕ) : ℤ) : ℤ) : ℝ) := by
    push_cast
    push_cast at hle
    linarith
  exact_mod_cast hle'
end ErdosProblems.Erdos269

open scoped BigOperators
open ErdosProblems in
open ErdosProblems.Erdos269 in
theorem solution
    {p q : ℤ} (hq : 0 < q)
    (hval : dyadicShellTsumTailR235 1 = (p : ℝ) / (q : ℝ)) :
    ∃ (B a₀ : ℕ) (d : ℕ → ℤ), 0 < B ∧ Nat.Coprime B 30 ∧
      (∀ n, a₀ ≤ n →
        d (n + 1) = (dyadicBlockBase235 n : ℤ) * d n
          - (B : ℤ) * (dyadicOrderedBlockDigit235 n : ℤ)) ∧
      (∀ n, a₀ ≤ n → 0 < d n) ∧
      (∀ n, a₀ ≤ n → Int.natAbs (d n) ≤ B * bridgeWidth n) := by
  obtain ⟨α, β, γ, B, hqeq, hBpos, hBcop⟩ :=
    exists_smooth_coprime_split q.toNat (by omega)
  set s : ℕ := 2 ^ α * 3 ^ β * 5 ^ γ with hs
  have hsPos : 0 < s := by positivity
  have hqs : q = ((s : ℕ) : ℤ) * ((B : ℕ) : ℤ) := by
    have hnat : q.toNat = s * B := by rw [hqeq]
    have := Int.toNat_of_nonneg hq.le
    rw [← this, hnat]
    push_cast
    ring
  set a₀ : ℕ := α + 1 + 2 * β + 3 * γ with ha₀
  have ha₀1 : 1 ≤ a₀ := by omega
  have hsdvd : ∀ n, a₀ ≤ n → ((s : ℕ) : ℤ) ∣ latticeCarry q n := by
    intro n hn
    refine smooth_dvd_latticeCarry hq hval ?_ (by omega) ?_
    · rw [hqs]
      exact dvd_mul_right _ _
    · exact_mod_cast smooth_dvd_heightNormalizer235 (a := n) (by omega)
  have hfac : ∀ k, a₀ ≤ k →
      latticeCarry q k = ((s : ℕ) : ℤ) * reducedLatticeCarry q (s : ℤ) k := by
    intro k hk
    unfold reducedLatticeCarry
    exact (Int.mul_ediv_cancel' (hsdvd k hk)).symm
  have hsne : ((s : ℕ) : ℤ) ≠ 0 := by exact_mod_cast hsPos.ne'
  have hsZ : (0 : ℤ) < ((s : ℕ) : ℤ) := by exact_mod_cast hsPos
  -- `set` hides `q` inside the reduced carry, so rewriting `q = s · B` below
  -- cannot accidentally rewrite the carry's own denominator argument.
  set d : ℕ → ℤ := reducedLatticeCarry q (s : ℤ) with hdset
  refine ⟨B, a₀, d, hBpos, hBcop, ?_, ?_, ?_⟩
  · intro n hn
    have hrec := latticeCarry_succ hq hval (a := n) (by omega)
    rw [hfac n hn, hfac (n + 1) (by omega)] at hrec
    apply mul_left_cancel₀ hsne
    rw [hrec]
    linear_combination (-(dyadicOrderedBlockDigit235 n : ℤ)) * hqs
  · intro n hn
    have hpos := latticeCarry_pos hq hval (a := n) (by omega)
    rw [hfac n hn] at hpos
    exact pos_of_mul_pos_right hpos hsZ.le
  · intro n hn
    have hle := latticeCarry_le hq hval (a := n) (by omega)
    have hpos := latticeCarry_pos hq hval (a := n) (by omega)
    rw [hfac n hn] at hle hpos
    have hdpos : 0 < d n := pos_of_mul_pos_right hpos hsZ.le
    have hdle : d n ≤ ((B : ℕ) : ℤ) * ((90 * (n + 1) ^ 2 : ℕ) : ℤ) := by
      have h' : ((s : ℕ) : ℤ) * d n
          ≤ ((s : ℕ) : ℤ) * (((B : ℕ) : ℤ) * ((90 * (n + 1) ^ 2 : ℕ) : ℤ)) := by
        calc ((s : ℕ) : ℤ) * d n
            ≤ q * ((90 * (n + 1) ^ 2 : ℕ) : ℤ) := hle
          _ = ((s : ℕ) : ℤ) * (((B : ℕ) : ℤ) * ((90 * (n + 1) ^ 2 : ℕ) : ℤ)) := by
              rw [hqs]; ring
      exact le_of_mul_le_mul_left h' hsZ
    have hcast : ((B * bridgeWidth n : ℕ) : ℤ)
        = ((B : ℕ) : ℤ) * ((90 * (n + 1) ^ 2 : ℕ) : ℤ) := by
      unfold bridgeWidth
      push_cast
      ring
    rw [← hcast] at hdle
    omega
