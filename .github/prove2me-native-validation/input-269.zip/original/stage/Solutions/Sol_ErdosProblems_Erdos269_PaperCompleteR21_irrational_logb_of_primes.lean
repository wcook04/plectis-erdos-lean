import Definitions.Def_ErdosProblems_Erdos269_ThreePrimeRunningLcm
import Definitions.Def_ErdosProblems_Shared_IrrationalRotationStaircase
import Definitions.Def_ErdosProblems_Erdos269_KernelCarryRank
import Definitions.Def_ErdosProblems_Erdos269_PaperR7AnalyticInterfaces
import Definitions.Def_ErdosProblems_Erdos269_PaperCompleteR21_TwoPrimeSums
import Mathlib.Algebra.BigOperators.Group.Finset.Basic
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Algebra.Order.Floor.Ring
import Mathlib.Algebra.Order.Floor.Semiring
import Mathlib.Algebra.Ring.Parity
import Mathlib.Analysis.Normed.Ring.InfiniteSum
import Mathlib.Analysis.SpecialFunctions.Log.Base
import Mathlib.Analysis.SpecialFunctions.Pow.Real
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.Data.Finset.Card
import Mathlib.Data.Finset.Prod
import Mathlib.Data.Fintype.Pigeonhole
import Mathlib.Data.Nat.Log
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.Nat.Prime.Int
import Mathlib.Data.Real.Archimedean
import Mathlib.LinearAlgebra.Matrix.Block
import Mathlib.LinearAlgebra.Matrix.Determinant.Basic
import Mathlib.NumberTheory.Real.Irrational
import Mathlib.RingTheory.Algebraic.Basic
import Mathlib.Tactic
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Ring

/-!
# Erdős #269: both two-prime running-LCM sums

This file transcribes the two-prime objects of the short paper's
`res:two-prime-transcendence` and of the long paper's `long269:res:lead-two-prime`
and proves everything those statements assert except one external value theorem.

* `runningLcm p q x` is the literal least common multiple of the `{p,q}`-smooth
  numbers not exceeding `x`; `runningLcm_eq_twoPrimeHeight` identifies it with the
  product of the two maximal pure prime powers.
* `repeatedSum p q` is `R_{p,q}`: the reciprocal running LCM summed at every
  positive `{p,q}`-smooth integer.  `distinctSum p q` is `D_{p,q}`: each distinct
  running LCM counted once.
* `two_prime_affine_and_quadratic` proves the paper's displayed identities
  `eq:two-prime-affine`, with `A` the paper's boundary value
  `ErdosProblems.Erdos269.PaperR7.twoPrimeHeckeValue`.
* `two_prime_sums_transcendental` and `two_prime_transcendence` conclude that both
  values are transcendental.

The only undischarged input is `BugeaudLaurentTranscendence`, the theorem of
Bugeaud and Laurent (Theorem 1.1) in the case `ρ = 0` due to Loxton and van der
Poorten (Theorem 8, p. 40), that the Hecke--Mahler series takes transcendental
values.  It is carried as one explicit named hypothesis, stated in the generality
in which the paper cites it; all of its side conditions for the pair `(1/p, 1/q)`,
including irrationality of the slope `θ = log p / log q`, are proved here.
-/

namespace ErdosProblems.Erdos269.PaperCompleteR21
open Polynomial
open scoped BigOperators

noncomputable section

/-! ## The `{p,q}`-smooth numbers and their running least common multiple -/















/-! ## Integer logarithms at smooth points -/

























/-! ## The exact combinatorics of the jump indices -/











/-! ## Unique factorisation of the smooth monoid -/







/-! ## The two sums of the paper -/







/-! ## The two component series -/



























/-! ## `R = A (1 + B)` -/





/-! ## `D = A + B` -/



















/-! ## The telescoping identity `A - 1 - x A = x (y-1) B / y` -/















/-! ## The Hecke--Mahler boundary value -/













/-! ## Irrationality of the slope -/
end
end ErdosProblems.Erdos269.PaperCompleteR21

open Polynomial
open scoped BigOperators
open ErdosProblems in
open ErdosProblems.Erdos269 in
open ErdosProblems.Erdos269.PaperCompleteR21 in
theorem solution {p q : ℕ} (hp : p.Prime) (hq : q.Prime) (hpq : p ≠ q) :
    Irrational (Real.logb q p) := by
  have hp1 : 1 < p := hp.one_lt
  have hq1 : 1 < q := hq.one_lt
  have hpR : (1 : ℝ) < (p : ℝ) := by exact_mod_cast hp1
  have hqR : (1 : ℝ) < (q : ℝ) := by exact_mod_cast hq1
  have hlogp : 0 < Real.log (p : ℝ) := Real.log_pos hpR
  have hlogq : 0 < Real.log (q : ℝ) := Real.log_pos hqR
  rintro ⟨r, hr⟩
  have hrv : Real.log (p : ℝ) = (r : ℝ) * Real.log (q : ℝ) := by
    have hrl : (r : ℝ) = Real.log (p : ℝ) / Real.log (q : ℝ) := by
      rw [hr, Real.logb]
    rw [hrl]
    field_simp
  have hrpos : 0 < r := by
    have h : (0 : ℝ) < (r : ℝ) := by nlinarith
    exact_mod_cast h
  have hnumpos : 0 < r.num := Rat.num_pos.mpr hrpos
  have hane : r.num.toNat ≠ 0 := by omega
  have hbne : r.den ≠ 0 := r.den_nz
  have hrq : (r : ℝ) = ((r.num.toNat : ℕ) : ℝ) / ((r.den : ℕ) : ℝ) := by
    rw [show ((r.num.toNat : ℕ) : ℝ) = ((r.num : ℤ) : ℝ) by
      exact_mod_cast congrArg (fun z : ℤ => (z : ℝ)) (Int.toNat_of_nonneg hnumpos.le)]
    rw [← Rat.cast_def]
  have hbR : (0 : ℝ) < ((r.den : ℕ) : ℝ) := by
    exact_mod_cast Nat.pos_of_ne_zero hbne
  have hlogeq : Real.log ((p : ℝ) ^ r.den) = Real.log ((q : ℝ) ^ r.num.toNat) := by
    rw [Real.log_pow, Real.log_pow, hrv, hrq]
    field_simp
  have hppos : (0 : ℝ) < (p : ℝ) ^ r.den := by positivity
  have hqpos : (0 : ℝ) < (q : ℝ) ^ r.num.toNat := by positivity
  have hpow : ((p : ℝ)) ^ r.den = ((q : ℝ)) ^ r.num.toNat := by
    calc ((p : ℝ)) ^ r.den = Real.exp (Real.log ((p : ℝ) ^ r.den)) := (Real.exp_log hppos).symm
      _ = Real.exp (Real.log ((q : ℝ) ^ r.num.toNat)) := by rw [hlogeq]
      _ = ((q : ℝ)) ^ r.num.toNat := Real.exp_log hqpos
  have hnat : p ^ r.den = q ^ r.num.toNat := by exact_mod_cast hpow
  exact hpq (Nat.Prime.pow_inj' hp hq hbne hane hnat).1
