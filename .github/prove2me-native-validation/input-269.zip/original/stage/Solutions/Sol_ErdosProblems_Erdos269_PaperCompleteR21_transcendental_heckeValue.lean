import Definitions.Def_ErdosProblems_Erdos269_ThreePrimeRunningLcm
import Definitions.Def_ErdosProblems_Shared_IrrationalRotationStaircase
import Definitions.Def_ErdosProblems_Erdos269_KernelCarryRank
import Definitions.Def_ErdosProblems_Erdos269_PaperR7AnalyticInterfaces
import Definitions.Def_ErdosProblems_Erdos269_PaperCompleteR21_TwoPrimeSums
import Theorems.Thm_ErdosProblems_Erdos269_PaperCompleteR21_heckeValue_boundary
import Theorems.Thm_ErdosProblems_Erdos269_PaperCompleteR21_irrational_logb_of_primes
import Mathlib.Algebra.BigOperators.Group.Finset.Basic
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Algebra.Order.Floor.Ring
import Mathlib.Algebra.Order.Floor.Semiring
import Mathlib.Algebra.Ring.Parity
import Mathlib.Analysis.Normed.Ring.InfiniteSum
import Mathlib.Analysis.SpecialFunctions.Log.Base
import Mathlib.Analysis.SpecialFunctions.Pow.Real
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.Data.Finset.Card
import Mathlib.Data.Finset.Prod
import Mathlib.Data.Fintype.Pigeonhole
import Mathlib.Data.Nat.Log
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.Nat.Prime.Int
import Mathlib.Data.Real.Archimedean
import Mathlib.LinearAlgebra.Matrix.Block
import Mathlib.LinearAlgebra.Matrix.Determinant.Basic
import Mathlib.NumberTheory.Real.Irrational
import Mathlib.RingTheory.Algebraic.Basic
import Mathlib.Tactic
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Ring

/-!
# Erdős #269: both two-prime running-LCM sums

This file transcribes the two-prime objects of the short paper's
`res:two-prime-transcendence` and of the long paper's `long269:res:lead-two-prime`
and proves everything those statements assert except one external value theorem.

* `runningLcm p q x` is the literal least common multiple of the `{p,q}`-smooth
  numbers not exceeding `x`; `runningLcm_eq_twoPrimeHeight` identifies it with the
  product of the two maximal pure prime powers.
* `repeatedSum p q` is `R_{p,q}`: the reciprocal running LCM summed at every
  positive `{p,q}`-smooth integer.  `distinctSum p q` is `D_{p,q}`: each distinct
  running LCM counted once.
* `two_prime_affine_and_quadratic` proves the paper's displayed identities
  `eq:two-prime-affine`, with `A` the paper's boundary value
  `ErdosProblems.Erdos269.PaperR7.twoPrimeHeckeValue`.
* `two_prime_sums_transcendental` and `two_prime_transcendence` conclude that both
  values are transcendental.

The only undischarged input is `BugeaudLaurentTranscendence`, the theorem of
Bugeaud and Laurent (Theorem 1.1) in the case `ρ = 0` due to Loxton and van der
Poorten (Theorem 8, p. 40), that the Hecke--Mahler series takes transcendental
values.  It is carried as one explicit named hypothesis, stated in the generality
in which the paper cites it; all of its side conditions for the pair `(1/p, 1/q)`,
including irrationality of the slope `θ = log p / log q`, are proved here.
-/

namespace ErdosProblems.Erdos269.PaperCompleteR21
open Polynomial
open scoped BigOperators

noncomputable section

/-! ## The `{p,q}`-smooth numbers and their running least common multiple -/















/-! ## Integer logarithms at smooth points -/

























/-! ## The exact combinatorics of the jump indices -/











/-! ## Unique factorisation of the smooth monoid -/







/-! ## The two sums of the paper -/







/-! ## The two component series -/

















private theorem inv_lt_one_nat {p : ℕ} (hp : 1 < p) : ((p : ℝ))⁻¹ < 1 := by
  have hp0 : (0 : ℝ) < (p : ℝ) := by exact_mod_cast (by omega : 0 < p)
  have hp1 : (1 : ℝ) < (p : ℝ) := by exact_mod_cast hp
  have h : (1 : ℝ) / (p : ℝ) < 1 := by
    rw [div_lt_one hp0]
    exact hp1
  simpa [one_div] using h









/-! ## `R = A (1 + B)` -/





/-! ## `D = A + B` -/



















/-! ## The telescoping identity `A - 1 - x A = x (y-1) B / y` -/















/-! ## The Hecke--Mahler boundary value -/







theorem qExp_eq_floor {p q : ℕ} (hp : 1 < p) (hq : 1 < q) (n : ℕ) :
    qExp p q n = ⌊(n : ℝ) * Real.logb q p⌋₊ := by
  rw [qExp, ← Real.natFloor_logb_natCast q (p ^ n)]
  congr 1
  rw [Nat.cast_pow, Real.logb_pow]

/-- The paper's `A`: the series over the pure powers of `p` is the boundary value
already recorded in the tree. -/
theorem aSum_eq_heckeValue {p q : ℕ} (hp : 1 < p) (hq : 1 < q) :
    (∑' n : ℕ, aTerm p q n) = PaperR7.twoPrimeHeckeValue p q := by
  refine tsum_congr fun n => ?_
  simp only [aTerm]
  rw [qExp_eq_floor hp hq]



/-! ## Irrationality of the slope -/



/-! ## Transcendence -/

private theorem isAlgebraic_ratCast (r : ℚ) : IsAlgebraic ℚ ((r : ℝ)) := by
  refine ⟨Polynomial.X - Polynomial.C r, Polynomial.X_sub_C_ne_zero r, ?_⟩
  simp

private theorem transcendental_affine {F : ℝ} (hF : Transcendental ℚ F) (c d : ℚ)
    (hd : d ≠ 0) : Transcendental ℚ ((d : ℝ) * F + (c : ℝ)) := by
  have h := hF.aeval (Polynomial.C d * Polynomial.X + Polynomial.C c)
    (by rw [Polynomial.natDegree_linear hd]; omega)
    (by
      rw [Polynomial.leadingCoeff_linear hd]
      exact mem_nonZeroDivisors_of_ne_zero hd)
  simpa using h
end
end ErdosProblems.Erdos269.PaperCompleteR21

open Polynomial
open scoped BigOperators
open ErdosProblems in
open ErdosProblems.Erdos269 in
open ErdosProblems.Erdos269.PaperCompleteR21 in
theorem solution (hBL : BugeaudLaurentTranscendence)
    {p q : ℕ} (hp : p.Prime) (hq : q.Prime) (hpq : p < q) :
    Transcendental ℚ (PaperR7.twoPrimeHeckeValue p q) := by
  have hp1 : 1 < p := hp.one_lt
  have hq1 : 1 < q := hq.one_lt
  have hne : p ≠ q := Nat.ne_of_lt hpq
  have hpR : (1 : ℝ) < (p : ℝ) := by exact_mod_cast hp1
  have hqR : (1 : ℝ) < (q : ℝ) := by exact_mod_cast hq1
  have hpqR : ((p : ℝ)) < (q : ℝ) := by exact_mod_cast hpq
  have hp0 : (0 : ℝ) < (p : ℝ) := by linarith
  have hq0 : (0 : ℝ) < (q : ℝ) := by linarith
  have hirr : Irrational (Real.logb q p) := irrational_logb_of_primes hp hq hne
  have hθpos : 0 < Real.logb q p := by
    rw [Real.logb]
    exact div_pos (Real.log_pos hpR) (Real.log_pos hqR)
  have hθlt : Real.logb q p < 1 := by
    rw [Real.logb, div_lt_one (Real.log_pos hqR)]
    exact Real.log_lt_log hp0 hpqR
  have halgβ : IsAlgebraic ℚ ((p : ℝ))⁻¹ := by
    have h : ((p : ℝ))⁻¹ = (((p : ℚ))⁻¹ : ℚ) := by push_cast; ring
    rw [h]
    exact isAlgebraic_ratCast _
  have halgα : IsAlgebraic ℚ ((q : ℝ))⁻¹ := by
    have h : ((q : ℝ))⁻¹ = (((q : ℚ))⁻¹ : ℚ) := by push_cast; ring
    rw [h]
    exact isAlgebraic_ratCast _
  have hβne : ((p : ℝ))⁻¹ ≠ 0 := by positivity
  have hαne : ((q : ℝ))⁻¹ ≠ 0 := by positivity
  have hβabs : |((p : ℝ))⁻¹| < 1 := by
    rw [abs_of_pos (by positivity)]
    exact inv_lt_one_nat hp1
  have hrpow : |((q : ℝ))⁻¹| ^ (Real.logb q p) = ((p : ℝ))⁻¹ := by
    rw [abs_of_pos (by positivity), Real.inv_rpow (le_of_lt hq0),
      Real.rpow_logb hq0 (by linarith) hp0]
  have hsize : |((p : ℝ))⁻¹| * |((q : ℝ))⁻¹| ^ (Real.logb q p) < 1 := by
    rw [hrpow, abs_of_pos (by positivity)]
    have h2 : (2 : ℝ) ≤ (p : ℝ) := by exact_mod_cast hp.two_le
    have hmul : ((p : ℝ))⁻¹ * ((p : ℝ))⁻¹ = ((p : ℝ) * (p : ℝ))⁻¹ := by
      rw [mul_inv]
    rw [hmul, inv_lt_one_iff₀]
    right
    nlinarith
  have hFtr := hBL (Real.logb q p) ((p : ℝ))⁻¹ ((q : ℝ))⁻¹ hirr hθpos hθlt halgβ halgα
    hβne hαne hβabs hsize
  have hbd := heckeValue_boundary (p := p) (q := q) hp1 hq1
  rw [← aSum_eq_heckeValue hp1 hq1]
  have hkey : (∑' n : ℕ, aTerm p q n)
      = ((-(((q : ℚ)) - 1) : ℚ) : ℝ) *
          heckeMahlerSeries (Real.logb q p) ((p : ℝ))⁻¹ ((q : ℝ))⁻¹
        + ((((p : ℚ)) / (((p : ℚ)) - 1) : ℚ) : ℝ) := by
    rw [hbd]
    push_cast
    ring
  rw [hkey]
  refine transcendental_affine hFtr _ _ ?_
  have hqQ : (1 : ℚ) < (q : ℚ) := by exact_mod_cast hq1
  intro hcon
  have hzero : ((q : ℚ)) - 1 = 0 := by
    have := neg_eq_zero.mp hcon
    linarith
  linarith
