import Definitions.Def_ErdosProblems_Erdos269_BoundedRadixTailEscape
import Definitions.Def_ErdosProblems_Erdos269_ResidueEscape
import Definitions.Def_ErdosProblems_Erdos269_ThreePrimeRunningLcm
import Definitions.Def_ErdosProblems_Erdos269_RestrictedFloorSum
import Definitions.Def_ErdosProblems_Erdos269_DyadicBlockMassIdentity
import Definitions.Def_ErdosProblems_Erdos269_DyadicBlockThresholdPartition
import Definitions.Def_ErdosProblems_Erdos269_DyadicOrderedTailRecurrence
import Definitions.Def_ErdosProblems_Erdos269_DyadicShellSummability
import Definitions.Def_ErdosProblems_Erdos269_IntegralBranchExtinction
import Theorems.Thm_ErdosProblems_Erdos269_threePrimeHeight235_cast_pos
import Theorems.Thm_ErdosProblems_Erdos269_PaperR7_eight_pow_eq_two_pow_cube
import Theorems.Thm_ErdosProblems_Erdos269_PaperR7_cube_lt_thirty_height235
import Mathlib.Algebra.BigOperators.Group.Finset.Basic
import Mathlib.Algebra.BigOperators.Group.Finset.Sigma
import Mathlib.Algebra.BigOperators.Group.List.Basic
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Algebra.Ring.Parity
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Data.Finset.Card
import Mathlib.Data.Finset.Prod
import Mathlib.Data.Int.ModEq
import Mathlib.Data.Nat.Log
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.Nat.Prime.Int
import Mathlib.Tactic
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Ring

namespace ErdosProblems.Erdos269.PaperR7
end ErdosProblems.Erdos269.PaperR7

/-!
# Round 7: the literal `8640 / 343` shell bound

Target: the bound in short-note `res:actual-orbit`.  The supplied bound `90`
does not prove this sharper displayed constant.  We retain the actual shell
mass, prove its `8^{-a}` estimate, and sum the resulting majorant exactly.
This is NOT a proof of the separate long-record `Q(n_a)` bound.

No admissions.
-/

namespace ErdosProblems.Erdos269.PaperR7
open scoped BigOperators
end ErdosProblems.Erdos269.PaperR7

open scoped BigOperators
open ErdosProblems in
open ErdosProblems.Erdos269 in
open ErdosProblems.Erdos269.PaperR7 in
theorem solution (a x : ℕ) (hx : 2 ^ a ≤ x) :
    ((threePrimeHeight 2 3 5 x : ℕ) : ℝ)⁻¹ ≤ 30 / (8 : ℝ) ^ a := by
  have hlow : (8 : ℕ) ^ a ≤ x ^ 3 := by
    rw [eight_pow_eq_two_pow_cube]
    exact Nat.pow_le_pow_left hx 3
  have hnat : (8 : ℕ) ^ a < 30 * threePrimeHeight 2 3 5 x :=
    lt_of_le_of_lt hlow (cube_lt_thirty_height235 x)
  have hreal : (8 : ℝ) ^ a < 30 * (threePrimeHeight 2 3 5 x : ℝ) := by
    exact_mod_cast hnat
  have hH : (0 : ℝ) < (threePrimeHeight 2 3 5 x : ℝ) :=
    threePrimeHeight235_cast_pos x
  have h8 : (0 : ℝ) < (8 : ℝ) ^ a := by positivity
  rw [inv_eq_one_div]
  apply (div_le_div_iff₀ hH h8).mpr
  nlinarith
