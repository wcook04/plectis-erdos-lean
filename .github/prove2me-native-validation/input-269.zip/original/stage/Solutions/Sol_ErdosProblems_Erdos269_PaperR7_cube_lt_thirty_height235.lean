import Definitions.Def_ErdosProblems_Erdos269_BoundedRadixTailEscape
import Definitions.Def_ErdosProblems_Erdos269_ResidueEscape
import Definitions.Def_ErdosProblems_Erdos269_ThreePrimeRunningLcm
import Definitions.Def_ErdosProblems_Erdos269_RestrictedFloorSum
import Definitions.Def_ErdosProblems_Erdos269_DyadicBlockMassIdentity
import Definitions.Def_ErdosProblems_Erdos269_DyadicBlockThresholdPartition
import Definitions.Def_ErdosProblems_Erdos269_DyadicOrderedTailRecurrence
import Definitions.Def_ErdosProblems_Erdos269_DyadicShellSummability
import Definitions.Def_ErdosProblems_Erdos269_IntegralBranchExtinction
import Mathlib.Algebra.BigOperators.Group.Finset.Basic
import Mathlib.Algebra.BigOperators.Group.Finset.Sigma
import Mathlib.Algebra.BigOperators.Group.List.Basic
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Algebra.Ring.Parity
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Data.Finset.Card
import Mathlib.Data.Finset.Prod
import Mathlib.Data.Int.ModEq
import Mathlib.Data.Nat.Log
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.Nat.Prime.Int
import Mathlib.Tactic
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Ring

namespace ErdosProblems.Erdos269.PaperR7
end ErdosProblems.Erdos269.PaperR7

/-!
# Round 7: the literal `8640 / 343` shell bound

Target: the bound in short-note `res:actual-orbit`.  The supplied bound `90`
does not prove this sharper displayed constant.  We retain the actual shell
mass, prove its `8^{-a}` estimate, and sum the resulting majorant exactly.
This is NOT a proof of the separate long-record `Q(n_a)` bound.

No admissions.
-/

namespace ErdosProblems.Erdos269.PaperR7
open scoped BigOperators
end ErdosProblems.Erdos269.PaperR7

open scoped BigOperators
open ErdosProblems in
open ErdosProblems.Erdos269 in
open ErdosProblems.Erdos269.PaperR7 in
theorem solution (x : ℕ) :
    x ^ 3 < 30 * threePrimeHeight 2 3 5 x := by
  have h2 := Nat.lt_pow_succ_log_self (b := 2) (by norm_num) x
  have h3 := Nat.lt_pow_succ_log_self (b := 3) (by norm_num) x
  have h5 := Nat.lt_pow_succ_log_self (b := 5) (by norm_num) x
  have h := Nat.mul_lt_mul_of_lt_of_lt
    (Nat.mul_lt_mul_of_lt_of_lt h2 h3) h5
  calc
    x ^ 3 = (x * x) * x := by ring
    _ < (2 ^ (Nat.log 2 x + 1) * 3 ^ (Nat.log 3 x + 1)) *
        5 ^ (Nat.log 5 x + 1) := h
    _ = 30 * threePrimeHeight 2 3 5 x := by
      simp only [threePrimeHeight, pow_succ]
      ring
