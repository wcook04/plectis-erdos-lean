import Definitions.Def_ErdosProblems_Erdos269_PaperR7FiniteCutRank
import Theorems.Thm_ErdosProblems_Erdos269_PaperR7_cut_relation_interior
import Mathlib.Data.Fintype.BigOperators
import Mathlib.LinearAlgebra.Dimension.Constructions
import Mathlib.LinearAlgebra.LinearIndependent.Basic
import Mathlib.LinearAlgebra.Matrix.Rank
import Mathlib.Tactic

/-!
# Paper-complete campaign, round 7: the complete finite cut-rank formula

Target: short-note `res:finite-cut-rank`.  This file generalises the supplied
rational interval-difference engine to an arbitrary field, proves independence
except for the two extreme columns, removes exactly that redundancy, and states
the result using `Matrix.rank`. Repetitions and permutations of columns are
handled by a column-range equality, not an extra independence assumption.

Authored against Lean 4.29.1 and the packet's Mathlib pin.
No admitted statements or additional axioms are introduced.
-/

namespace ErdosProblems.Erdos269.PaperR7
open scoped BigOperators
open Module Submodule

variable {F : Type*} [Field F]
end ErdosProblems.Erdos269.PaperR7

open scoped BigOperators
open Module Submodule
variable {F : Type*} [Field F]
open ErdosProblems in
open ErdosProblems.Erdos269 in
open ErdosProblems.Erdos269.PaperR7 in
theorem solution (c : F) (hc0 : c ≠ 0) (hc1 : c ≠ 1)
    {m : ℕ} (hm : 0 < m) (E : Finset ℕ)
    (hbound : ∀ k ∈ E, k ≤ m) (hext : ¬ (0 ∈ E ∧ m ∈ E)) :
    LinearIndependent F (fun k : E => cutVector c m k) := by
  classical
  rw [Fintype.linearIndependent_iff]
  intro g hg j
  have hinterior : ∀ k : E, 0 < (k : ℕ) → (k : ℕ) < m → g k = 0 :=
    fun k hk hkm => cut_relation_interior c hc1 E g hg k hk hkm
  by_cases hj0 : (j : ℕ) = 0
  · have h0 : 0 ∈ E := hj0 ▸ j.property
    have hnotm : m ∉ E := fun h => hext ⟨h0, h⟩
    have hother : ∀ k : E, k ≠ j → g k = 0 := by
      intro k hkj
      have hk0 : (k : ℕ) ≠ 0 := by
        intro h
        exact hkj (Subtype.ext (h.trans hj0.symm))
      have hkm : (k : ℕ) ≠ m := fun h => hnotm (h ▸ k.property)
      exact hinterior k (Nat.pos_of_ne_zero hk0) (lt_of_le_of_ne (hbound k k.property) hkm)
    have hrow := congrFun hg (⟨0, hm⟩ : Fin m)
    simp only [Finset.sum_apply, Pi.smul_apply, smul_eq_mul, Pi.zero_apply] at hrow
    have hs : (∑ k : E, g k * cutVector c m k ⟨0, hm⟩) =
        g j * cutVector c m j ⟨0, hm⟩ := by
      apply Finset.sum_eq_single j
      · intro k _ hkj
        rw [hother k hkj, zero_mul]
      · simp
    rw [hs] at hrow
    have hp : g j * c = 0 := by simpa [cutVector, hj0] using hrow
    exact (mul_eq_zero.mp hp).resolve_right hc0
  · by_cases hjm : (j : ℕ) = m
    · have hmE : m ∈ E := hjm ▸ j.property
      have hnot0 : 0 ∉ E := fun h => hext ⟨h, hmE⟩
      have hother : ∀ k : E, k ≠ j → g k = 0 := by
        intro k hkj
        have hk0 : (k : ℕ) ≠ 0 := fun h => hnot0 (h ▸ k.property)
        have hkm : (k : ℕ) ≠ m := by
          intro h
          exact hkj (Subtype.ext (h.trans hjm.symm))
        exact hinterior k (Nat.pos_of_ne_zero hk0)
          (lt_of_le_of_ne (hbound k k.property) hkm)
      have hrow := congrFun hg (⟨0, hm⟩ : Fin m)
      simp only [Finset.sum_apply, Pi.smul_apply, smul_eq_mul, Pi.zero_apply] at hrow
      have hs : (∑ k : E, g k * cutVector c m k ⟨0, hm⟩) =
          g j * cutVector c m j ⟨0, hm⟩ := by
        apply Finset.sum_eq_single j
        · intro k _ hkj
          rw [hother k hkj, zero_mul]
        · simp
      rw [hs] at hrow
      simpa [cutVector, hjm, hm] using hrow
    · exact hinterior j (Nat.pos_of_ne_zero hj0)
        (lt_of_le_of_ne (hbound j j.property) hjm)
