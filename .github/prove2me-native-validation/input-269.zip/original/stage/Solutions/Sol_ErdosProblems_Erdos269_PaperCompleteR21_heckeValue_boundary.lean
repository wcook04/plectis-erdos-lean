import Definitions.Def_ErdosProblems_Erdos269_ThreePrimeRunningLcm
import Definitions.Def_ErdosProblems_Shared_IrrationalRotationStaircase
import Definitions.Def_ErdosProblems_Erdos269_KernelCarryRank
import Definitions.Def_ErdosProblems_Erdos269_PaperR7AnalyticInterfaces
import Definitions.Def_ErdosProblems_Erdos269_PaperCompleteR21_TwoPrimeSums
import Mathlib.Algebra.BigOperators.Group.Finset.Basic
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Algebra.Order.Floor.Ring
import Mathlib.Algebra.Order.Floor.Semiring
import Mathlib.Algebra.Ring.Parity
import Mathlib.Analysis.Normed.Ring.InfiniteSum
import Mathlib.Analysis.SpecialFunctions.Log.Base
import Mathlib.Analysis.SpecialFunctions.Pow.Real
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.Data.Finset.Card
import Mathlib.Data.Finset.Prod
import Mathlib.Data.Fintype.Pigeonhole
import Mathlib.Data.Nat.Log
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.Nat.Prime.Int
import Mathlib.Data.Real.Archimedean
import Mathlib.LinearAlgebra.Matrix.Block
import Mathlib.LinearAlgebra.Matrix.Determinant.Basic
import Mathlib.NumberTheory.Real.Irrational
import Mathlib.RingTheory.Algebraic.Basic
import Mathlib.Tactic
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Ring

/-!
# Erdős #269: both two-prime running-LCM sums

This file transcribes the two-prime objects of the short paper's
`res:two-prime-transcendence` and of the long paper's `long269:res:lead-two-prime`
and proves everything those statements assert except one external value theorem.

* `runningLcm p q x` is the literal least common multiple of the `{p,q}`-smooth
  numbers not exceeding `x`; `runningLcm_eq_twoPrimeHeight` identifies it with the
  product of the two maximal pure prime powers.
* `repeatedSum p q` is `R_{p,q}`: the reciprocal running LCM summed at every
  positive `{p,q}`-smooth integer.  `distinctSum p q` is `D_{p,q}`: each distinct
  running LCM counted once.
* `two_prime_affine_and_quadratic` proves the paper's displayed identities
  `eq:two-prime-affine`, with `A` the paper's boundary value
  `ErdosProblems.Erdos269.PaperR7.twoPrimeHeckeValue`.
* `two_prime_sums_transcendental` and `two_prime_transcendence` conclude that both
  values are transcendental.

The only undischarged input is `BugeaudLaurentTranscendence`, the theorem of
Bugeaud and Laurent (Theorem 1.1) in the case `ρ = 0` due to Loxton and van der
Poorten (Theorem 8, p. 40), that the Hecke--Mahler series takes transcendental
values.  It is carried as one explicit named hypothesis, stated in the generality
in which the paper cites it; all of its side conditions for the pair `(1/p, 1/q)`,
including irrationality of the slope `θ = log p / log q`, are proved here.
-/

namespace ErdosProblems.Erdos269.PaperCompleteR21
open Polynomial
open scoped BigOperators

noncomputable section

/-! ## The `{p,q}`-smooth numbers and their running least common multiple -/















/-! ## Integer logarithms at smooth points -/

























/-! ## The exact combinatorics of the jump indices -/











/-! ## Unique factorisation of the smooth monoid -/







/-! ## The two sums of the paper -/







/-! ## The two component series -/





theorem aTerm_nonneg (p q n : ℕ) : 0 ≤ aTerm p q n := by
  unfold aTerm
  positivity











private theorem inv_lt_one_nat {p : ℕ} (hp : 1 < p) : ((p : ℝ))⁻¹ < 1 := by
  have hp0 : (0 : ℝ) < (p : ℝ) := by exact_mod_cast (by omega : 0 < p)
  have hp1 : (1 : ℝ) < (p : ℝ) := by exact_mod_cast hp
  have h : (1 : ℝ) / (p : ℝ) < 1 := by
    rw [div_lt_one hp0]
    exact hp1
  simpa [one_div] using h

private theorem inv_nonneg_nat (p : ℕ) : (0 : ℝ) ≤ ((p : ℝ))⁻¹ := by positivity

theorem summable_aTerm {p q : ℕ} (hp : 1 < p) (hq : 1 < q) : Summable (aTerm p q) := by
  refine Summable.of_nonneg_of_le (fun n => aTerm_nonneg p q n) (fun n => ?_)
    (summable_geometric_of_lt_one (inv_nonneg_nat p) (inv_lt_one_nat hp))
  have hle : ((q : ℝ)⁻¹) ^ qExp p q n ≤ 1 :=
    pow_le_one₀ (inv_nonneg_nat q) (le_of_lt (inv_lt_one_nat hq))
  calc aTerm p q n = ((p : ℝ)⁻¹) ^ n * ((q : ℝ)⁻¹) ^ qExp p q n := rfl
    _ ≤ ((p : ℝ)⁻¹) ^ n * 1 := mul_le_mul_of_nonneg_left hle (by positivity)
    _ = ((p : ℝ)⁻¹) ^ n := mul_one _





/-! ## `R = A (1 + B)` -/





/-! ## `D = A + B` -/



















/-! ## The telescoping identity `A - 1 - x A = x (y-1) B / y` -/















/-! ## The Hecke--Mahler boundary value -/





theorem sum_Icc_pow {y : ℝ} (hy : y ≠ 1) (m : ℕ) :
    ∑ k ∈ Finset.Icc 1 m, y ^ k = (y - y ^ (m + 1)) / (1 - y) := by
  have h1y : (1 : ℝ) - y ≠ 0 := sub_ne_zero.mpr (Ne.symm hy)
  induction m with
  | zero => simp
  | succ m ih =>
    rw [Finset.sum_Icc_succ_top (by omega : 1 ≤ m + 1), ih]
    field_simp
    ring

theorem qExp_eq_floor {p q : ℕ} (hp : 1 < p) (hq : 1 < q) (n : ℕ) :
    qExp p q n = ⌊(n : ℝ) * Real.logb q p⌋₊ := by
  rw [qExp, ← Real.natFloor_logb_natCast q (p ^ n)]
  congr 1
  rw [Nat.cast_pow, Real.logb_pow]
end
end ErdosProblems.Erdos269.PaperCompleteR21

open Polynomial
open scoped BigOperators
open ErdosProblems in
open ErdosProblems.Erdos269 in
open ErdosProblems.Erdos269.PaperCompleteR21 in
theorem solution {p q : ℕ} (hp : 1 < p) (hq : 1 < q) :
    (∑' n : ℕ, aTerm p q n)
      = (p : ℝ) / ((p : ℝ) - 1)
        - ((q : ℝ) - 1) *
          heckeMahlerSeries (Real.logb q p) ((p : ℝ)⁻¹) ((q : ℝ)⁻¹) := by
  have hpR : (1 : ℝ) < (p : ℝ) := by exact_mod_cast hp
  have hqR : (1 : ℝ) < (q : ℝ) := by exact_mod_cast hq
  have hp0 : ((p : ℝ)) ≠ 0 := by
    intro h
    rw [h] at hpR
    linarith
  have hq0 : ((q : ℝ)) ≠ 0 := by
    intro h
    rw [h] at hqR
    linarith
  have hp1ne : ((p : ℝ) - 1) ≠ 0 := by
    intro h
    have : (p : ℝ) = 1 := by linarith
    linarith [this]
  have hq1ne : ((q : ℝ) - 1) ≠ 0 := by
    intro h
    have : (q : ℝ) = 1 := by linarith
    linarith [this]
  have hxlt : ((p : ℝ))⁻¹ < 1 := inv_lt_one_nat hp
  have hylt : ((q : ℝ))⁻¹ < 1 := inv_lt_one_nat hq
  have hxnn : (0 : ℝ) ≤ ((p : ℝ))⁻¹ := inv_nonneg_nat p
  have hyne : ((q : ℝ))⁻¹ ≠ 1 := ne_of_lt hylt
  have hgeoS : Summable (fun n : ℕ => ((p : ℝ))⁻¹ ^ n) :=
    summable_geometric_of_lt_one hxnn hxlt
  have hgeo : (∑' n : ℕ, ((p : ℝ))⁻¹ ^ n) = (1 - ((p : ℝ))⁻¹)⁻¹ :=
    tsum_geometric_of_lt_one hxnn hxlt
  have hinner : ∀ n : ℕ,
      (∑ k ∈ Finset.Icc 1 ⌊(n : ℝ) * Real.logb q p⌋₊,
        ((p : ℝ))⁻¹ ^ n * ((q : ℝ))⁻¹ ^ k)
        = ((q : ℝ) - 1)⁻¹ * (((p : ℝ))⁻¹ ^ n - aTerm p q n) := by
    intro n
    rw [← Finset.mul_sum, ← qExp_eq_floor hp hq, sum_Icc_pow hyne]
    unfold aTerm
    rw [pow_succ]
    generalize ((q : ℝ))⁻¹ ^ qExp p q n = Y
    generalize ((p : ℝ))⁻¹ ^ n = X
    have h1y : (1 : ℝ) - ((q : ℝ))⁻¹ ≠ 0 := by
      intro h
      have : ((q : ℝ))⁻¹ = 1 := by linarith
      exact hyne this
    field_simp
  have hF : heckeMahlerSeries (Real.logb q p) ((p : ℝ))⁻¹ ((q : ℝ))⁻¹
      = ((q : ℝ) - 1)⁻¹ * ((1 - ((p : ℝ))⁻¹)⁻¹ - ∑' n : ℕ, aTerm p q n) := by
    unfold heckeMahlerSeries
    rw [tsum_congr hinner, tsum_mul_left]
    congr 1
    rw [hgeoS.tsum_sub (summable_aTerm hp hq), hgeo]
  have hxv : (1 - ((p : ℝ))⁻¹)⁻¹ = (p : ℝ) / ((p : ℝ) - 1) := by
    field_simp
  rw [hF, ← mul_assoc, mul_inv_cancel₀ hq1ne, one_mul, hxv]
  ring
