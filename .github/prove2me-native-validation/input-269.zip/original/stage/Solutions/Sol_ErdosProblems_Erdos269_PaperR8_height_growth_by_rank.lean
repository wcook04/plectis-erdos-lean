import Definitions.Def_ErdosProblems_Erdos269_BoundedRadixTailEscape
import Definitions.Def_ErdosProblems_Erdos269_ResidueEscape
import Definitions.Def_ErdosProblems_Erdos269_ThreePrimeRunningLcm
import Definitions.Def_ErdosProblems_Erdos269_RestrictedFloorSum
import Definitions.Def_ErdosProblems_Erdos269_DyadicBlockMassIdentity
import Definitions.Def_ErdosProblems_Erdos269_DyadicBlockThresholdPartition
import Definitions.Def_ErdosProblems_Erdos269_DyadicOrderedTailRecurrence
import Definitions.Def_ErdosProblems_Erdos269_DyadicShellSummability
import Definitions.Def_ErdosProblems_Erdos269_IntegralBranchExtinction
import Definitions.Def_ErdosProblems_Erdos269_JumpConstraintMajorant
import Definitions.Def_ErdosProblems_Shared_IrrationalRotationStaircase
import Definitions.Def_ErdosProblems_Erdos269_KernelCarryRank
import Definitions.Def_ErdosProblems_Erdos269_PaperR7ActualOrbit
import Definitions.Def_ErdosProblems_Erdos269_PaperR7SeriesIdentification
import Definitions.Def_ErdosProblems_Erdos269_RationalLatticeReduction
import Definitions.Def_ErdosProblems_Erdos269_RationalityCarryBridge
import Definitions.Def_ErdosProblems_Erdos269_PaperR7RationalBridge
import Definitions.Def_ErdosProblems_Erdos269_PaperR7WindowResults
import Definitions.Def_ErdosProblems_Erdos269_PaperR8RankMajorant
import Mathlib.Algebra.BigOperators.Group.Finset.Basic
import Mathlib.Algebra.BigOperators.Group.Finset.Sigma
import Mathlib.Algebra.BigOperators.Group.List.Basic
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Algebra.Order.Floor.Ring
import Mathlib.Algebra.Order.Floor.Semiring
import Mathlib.Algebra.Ring.Parity
import Mathlib.Analysis.SpecialFunctions.Log.Base
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Data.Finset.Card
import Mathlib.Data.Finset.Prod
import Mathlib.Data.Fintype.Pigeonhole
import Mathlib.Data.Int.ModEq
import Mathlib.Data.Nat.Factorization.Basic
import Mathlib.Data.Nat.Log
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.Nat.Prime.Int
import Mathlib.Data.Real.Archimedean
import Mathlib.LinearAlgebra.Matrix.Block
import Mathlib.LinearAlgebra.Matrix.Determinant.Basic
import Mathlib.Tactic
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.InfiniteSum.Order
import Mathlib.Topology.Algebra.InfiniteSum.Real

namespace PaperR7
end PaperR7

/-!
# The actual height-rank majorant (round 8)

This file supplies the missing geometric summation over height ranks, not a
comparison of the much larger dyadic-shell bound with `carryMajorantQ`.
It uses the live round-7 definitions without changing any of them.

Proof text: not elaborated in this return. No additional hypotheses are hidden
in the final theorem. Mathlib source checks use commit
`5e932f97dd25535344f80f9dd8da3aab83df0fe6`.
-/

namespace ErdosProblems.Erdos269.PaperR8
open scoped BigOperators
open PaperR7
end ErdosProblems.Erdos269.PaperR8

open scoped BigOperators
open PaperR7
open ErdosProblems in
open ErdosProblems.Erdos269 in
open ErdosProblems.Erdos269.PaperR8 in
open ErdosProblems.Erdos269.PaperR7 in
theorem solution {x y : ℕ} (hxy : x ≤ y) :
    threePrimeHeight 2 3 5 x * 2 ^ (heightRank235 y - heightRank235 x) ≤
      threePrimeHeight 2 3 5 y := by
  let a := Nat.log 2 x
  let b := Nat.log 3 x
  let c := Nat.log 5 x
  let A := Nat.log 2 y
  let B := Nat.log 3 y
  let C := Nat.log 5 y
  have h2 : a ≤ A := Nat.log_mono_right hxy
  have h3 : b ≤ B := Nat.log_mono_right hxy
  have h5 : c ≤ C := Nat.log_mono_right hxy
  have hd : heightRank235 y - heightRank235 x = (A - a) + (B - b) + (C - c) := by
    change (A + B + C) - (a + b + c) = _
    omega
  have ha : a + (A - a) = A := by omega
  have hb : b + (B - b) = B := by omega
  have hc : c + (C - c) = C := by omega
  have hpow3 : 2 ^ (B - b) ≤ 3 ^ (B - b) :=
    Nat.pow_le_pow_left (by decide : 2 ≤ 3) (B - b)
  have hpow5 : 2 ^ (C - c) ≤ 5 ^ (C - c) :=
    Nat.pow_le_pow_left (by decide : 2 ≤ 5) (C - c)
  have hg : 2 ^ (heightRank235 y - heightRank235 x) ≤
      2 ^ (A - a) * 3 ^ (B - b) * 5 ^ (C - c) := by
    rw [hd, pow_add, pow_add]
    exact Nat.mul_le_mul (Nat.mul_le_mul_left _ hpow3) hpow5
  calc
    threePrimeHeight 2 3 5 x * 2 ^ (heightRank235 y - heightRank235 x)
      ≤ threePrimeHeight 2 3 5 x *
          (2 ^ (A - a) * 3 ^ (B - b) * 5 ^ (C - c)) :=
        Nat.mul_le_mul_left _ hg
    _ = threePrimeHeight 2 3 5 y := by
      change (2 ^ a * 3 ^ b * 5 ^ c) *
        (2 ^ (A - a) * 3 ^ (B - b) * 5 ^ (C - c)) = 2 ^ A * 3 ^ B * 5 ^ C
      calc
        _ = (2 ^ a * 2 ^ (A - a)) * (3 ^ b * 3 ^ (B - b)) *
              (5 ^ c * 5 ^ (C - c)) := by ring
        _ = _ := by rw [← pow_add, ← pow_add, ← pow_add, ha, hb, hc]
