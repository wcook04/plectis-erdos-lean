import Definitions.Def_ErdosProblems_Erdos269_ThreePrimeRunningLcm
import Definitions.Def_ErdosProblems_Shared_IrrationalRotationStaircase
import Definitions.Def_ErdosProblems_Erdos269_KernelCarryRank
import Definitions.Def_ErdosProblems_Erdos269_PaperR7AnalyticInterfaces
import Definitions.Def_ErdosProblems_Erdos269_PaperR8UniformRank
import Theorems.Thm_ErdosProblems_Erdos269_logCarry_le_one
import Theorems.Thm_ErdosProblems_Erdos269_PaperR8_bounded_column_space
import Theorems.Thm_ErdosProblems_Erdos269_PaperR8_finite_packing_bound
import Theorems.Thm_ErdosProblems_Erdos269_PaperR8_realCarry_staircases
import Mathlib.Algebra.BigOperators.Group.Finset.Basic
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Algebra.Order.Floor.Ring
import Mathlib.Algebra.Order.Floor.Semiring
import Mathlib.Algebra.Ring.Parity
import Mathlib.Analysis.Normed.Module.FiniteDimension
import Mathlib.Analysis.SpecialFunctions.Log.Base
import Mathlib.Data.ENNReal.Real
import Mathlib.Data.Finset.Card
import Mathlib.Data.Finset.Prod
import Mathlib.Data.Fintype.Pigeonhole
import Mathlib.Data.Nat.Log
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.Nat.Prime.Int
import Mathlib.Data.Real.Archimedean
import Mathlib.LinearAlgebra.Matrix.Block
import Mathlib.LinearAlgebra.Matrix.Determinant.Basic
import Mathlib.RingTheory.Algebraic.Basic
import Mathlib.Tactic
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Ring
import Mathlib.Topology.ContinuousMap.Bounded.Normed
import Mathlib.Topology.MetricSpace.Pseudo.Basic

namespace PaperR7
end PaperR7

/-!
# The infinite uniform finite-rank obstruction

The finite staircase minors alone do not prove a uniform lower bound. This
file uses their column separation inside a finite-dimensional bounded column
space, and a finite covering of a compact ball. Row factors in an arbitrary
separated representation need not be bounded; the subspace is formed by
intersecting their algebraic span with the space of bounded functions.

The final infimum ranges over ALL finite-separated-rank matrices. It uses an
extended nonnegative supremum so that unbounded approximants have infinite
uniform error, never the spurious zero returned by an unbounded real iSup.
The resulting finite value is also identified after conversion to the reals.
All proof text is an uncompiled candidate against the packet's pinned Mathlib.
-/

namespace ErdosProblems.Erdos269.PaperR8
open PaperR7 ErdosProblems.Shared Set Metric
open scoped BigOperators Topology BoundedContinuousFunction ENNReal










/-- The actual carry is bounded by one. -/
theorem realCarryMatrix_abs_le_one {p q r : ℕ}
    (hp : 0 < p) (hq : 0 < q) (hr : 1 < r) (i j : ℕ) :
    |realCarryMatrix p q r i j| ≤ 1 := by
  have hbit := logCarry_le_one hr (pow_ne_zero i hp.ne') (pow_ne_zero j hq.ne')
  have hr0 : (0 : ℝ) < r := by exact_mod_cast (lt_trans (by decide : 0 < 1) hr)
  have hr1 : (1 : ℝ) ≤ r := by exact_mod_cast hr.le
  have hc : (r : ℝ)⁻¹ ≤ 1 := (inv_le_one₀ hr0).mpr hr1
  have hc0 : (0 : ℝ) ≤ (r : ℝ)⁻¹ := inv_nonneg.mpr hr0.le
  have hh : logCarry r (p ^ i) (q ^ j) = 0 ∨ logCarry r (p ^ i) (q ^ j) = 1 := by omega
  rcases hh with hh | hh
  · simp only [realCarryMatrix, hh, pow_zero, abs_one, le_refl]
  · simpa only [realCarryMatrix, hh, pow_one, abs_of_nonneg hc0] using hc
end ErdosProblems.Erdos269.PaperR8

open PaperR7 ErdosProblems.Shared Set Metric
open scoped BigOperators Topology BoundedContinuousFunction ENNReal
open ErdosProblems in
open ErdosProblems.Erdos269 in
open ErdosProblems.Erdos269.PaperR8 in
open ErdosProblems.Erdos269.PaperR7 in
theorem solution {p q r : ℕ}
    (hp : 0 < p) (hq : 0 < q) (hr : 1 < r)
    (hα : NoIntegerOrbit (Real.logb r p)) (hβ : NoIntegerOrbit (Real.logb r q))
    (A : ℕ → ℕ → ℝ) (hA : FiniteSeparatedRank A)
    (E : ℝ) (hE : 0 ≤ E)
    (herr : ∀ i j, |realCarryMatrix p q r i j - A i j| ≤ E) :
    (1 - (r : ℝ)⁻¹) / 2 ≤ E := by
  classical
  by_contra hnot
  have hsmall : E < (1 - (r : ℝ)⁻¹) / 2 := lt_of_not_ge hnot
  let δ : ℝ := 1 - (r : ℝ)⁻¹ - 2 * E
  have hδ : 0 < δ := by dsimp [δ]; linarith
  have hAbound : ∀ i j, |A i j| ≤ 1 + E := by
    intro i j
    calc
      |A i j| = |realCarryMatrix p q r i j -
          (realCarryMatrix p q r i j - A i j)| := by congr 1; ring
      _ ≤ |realCarryMatrix p q r i j| + |realCarryMatrix p q r i j - A i j| :=
        abs_sub _ _
      _ ≤ 1 + E := add_le_add (realCarryMatrix_abs_le_one hp hq hr i j) (herr i j)
  obtain ⟨V, hV, v, hv, hvbound⟩ := bounded_column_space A hA (1 + E) (by linarith) hAbound
  letI : FiniteDimensional ℝ V := hV
  obtain ⟨n, hn⟩ := finite_packing_bound V (1 + E) δ hδ
  obtain ⟨I, J, hIJ⟩ := realCarry_staircases hp hq hr hα hβ n
  obtain ⟨j, k, hjk, hclose⟩ := hn (fun j => v (J j)) (fun j => hvbound (J j))
  have hc1 : (r : ℝ)⁻¹ ≤ 1 := by
    apply (inv_le_one₀ (by exact_mod_cast (lt_trans (by decide : 0 < 1) hr))).mpr
    exact_mod_cast hr.le
  have hsep : ∃ i : ℕ,
      |realCarryMatrix p q r i (J j) - realCarryMatrix p q r i (J k)| =
        1 - (r : ℝ)⁻¹ := by
    rcases lt_or_gt_of_ne hjk with hjk' | hkj'
    · refine ⟨I j, ?_⟩
      rw [hIJ, hIJ, if_pos (le_refl j), if_neg (not_le.mpr hjk')]
      rw [abs_of_nonpos (by linarith)]
      ring
    · refine ⟨I k, ?_⟩
      rw [hIJ, hIJ, if_neg (not_le.mpr hkj'), if_pos (le_refl k)]
      rw [abs_of_nonneg (by linarith)]
  obtain ⟨i, hi⟩ := hsep
  have hpoint : |A i (J j) - A i (J k)| ≤ dist (v (J j)) (v (J k)) := by
    -- Mathlib/Topology/ContinuousMap/Bounded/Basic.lean: dist_coe_le_dist.
    have h := BoundedContinuousFunction.dist_coe_le_dist
      (f := (v (J j) : BoundedColumn)) (g := (v (J k) : BoundedColumn)) i
    simpa only [hv, Real.dist_eq] using h
  have htriangle :
      |realCarryMatrix p q r i (J j) - realCarryMatrix p q r i (J k)| ≤
        |realCarryMatrix p q r i (J j) - A i (J j)| +
        |A i (J j) - A i (J k)| +
        |A i (J k) - realCarryMatrix p q r i (J k)| := by
    calc
      _ = |(realCarryMatrix p q r i (J j) - A i (J j)) +
          (A i (J j) - A i (J k)) +
          (A i (J k) - realCarryMatrix p q r i (J k))| := by congr 1; ring
      _ ≤ |realCarryMatrix p q r i (J j) - A i (J j) +
          (A i (J j) - A i (J k))| +
          |A i (J k) - realCarryMatrix p q r i (J k)| := abs_add_le
          ((realCarryMatrix p q r i (J j) - A i (J j)) + (A i (J j) - A i (J k)))
          (A i (J k) - realCarryMatrix p q r i (J k))
      _ ≤ _ := add_le_add
        (abs_add_le (realCarryMatrix p q r i (J j) - A i (J j))
          (A i (J j) - A i (J k)))
        (le_refl |A i (J k) - realCarryMatrix p q r i (J k)|)
  have he1 := herr i (J j)
  have he2 : |A i (J k) - realCarryMatrix p q r i (J k)| ≤ E := by
    rw [abs_sub_comm]
    exact herr i (J k)
  rw [hi] at htriangle
  dsimp [δ] at hclose
  have hupper := add_le_add (add_le_add he1 hpoint) he2
  have hsep := htriangle.trans hupper
  have impossible (x d e : ℝ) (h₁ : x ≤ e + d + e)
      (h₂ : d < x - 2 * e) : False := by linarith
  exact impossible (1 - (r : ℝ)⁻¹) (dist (v (J j)) (v (J k))) E hsep hclose
