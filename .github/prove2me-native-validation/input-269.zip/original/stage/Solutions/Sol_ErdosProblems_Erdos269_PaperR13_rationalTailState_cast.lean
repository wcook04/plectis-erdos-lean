import Definitions.Def_ErdosProblems_Erdos269_BoundedRadixTailEscape
import Definitions.Def_ErdosProblems_Erdos269_ResidueEscape
import Definitions.Def_ErdosProblems_Erdos269_ThreePrimeRunningLcm
import Definitions.Def_ErdosProblems_Erdos269_RestrictedFloorSum
import Definitions.Def_ErdosProblems_Erdos269_DyadicBlockMassIdentity
import Definitions.Def_ErdosProblems_Erdos269_DyadicBlockThresholdPartition
import Definitions.Def_ErdosProblems_Erdos269_DyadicOrderedTailRecurrence
import Definitions.Def_ErdosProblems_Erdos269_DyadicShellSummability
import Definitions.Def_ErdosProblems_Erdos269_IntegralBranchExtinction
import Definitions.Def_ErdosProblems_Erdos269_PaperR7ActualOrbit
import Definitions.Def_ErdosProblems_Erdos269_PaperR7SeriesIdentification
import Definitions.Def_ErdosProblems_Erdos269_RationalLatticeReduction
import Definitions.Def_ErdosProblems_Erdos269_RationalityCarryBridge
import Definitions.Def_ErdosProblems_Erdos269_PaperR7RationalBridge
import Definitions.Def_ErdosProblems_Erdos269_PaperExactDenominatorR13
import Theorems.Thm_ErdosProblems_Erdos269_two_mul_heightNormalizer235
import Theorems.Thm_ErdosProblems_Erdos269_PaperR7_tail_one_of_paperSeries_eq_rat
import Theorems.Thm_ErdosProblems_Erdos269_dyadicShellTsumTailR235_eq_range_add
import Mathlib.Algebra.BigOperators.Group.Finset.Basic
import Mathlib.Algebra.BigOperators.Group.Finset.Sigma
import Mathlib.Algebra.BigOperators.Group.List.Basic
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Algebra.Ring.Parity
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Data.Finset.Card
import Mathlib.Data.Finset.Prod
import Mathlib.Data.Int.ModEq
import Mathlib.Data.Nat.Factorization.Basic
import Mathlib.Data.Nat.Find
import Mathlib.Data.Nat.Log
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.Nat.Prime.Int
import Mathlib.Data.Rat.Lemmas
import Mathlib.Tactic
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.InfiniteSum.Real

namespace PaperR7
end PaperR7

/-!
# Exact reduced denominators for the paper tail states

This module formalises the exact-denominator calculation in the short and long
papers.  The rational representative below is proved to cast to the literal
real tail state, so its `Rat.den` is the paper's positive reduced denominator.
-/

namespace ErdosProblems.Erdos269.PaperR13
open scoped BigOperators
open PaperR7



/-- At positive scale the half-height definition is literally the normalizer
used in `trueNormalizedState`. -/
theorem trueNormalizedState_eq_heightNormalizer_mul (a : ℕ) (ha : 1 ≤ a) :
    trueNormalizedState a =
      (heightNormalizer235 a : ℝ) * dyadicShellTsumTailR235 a := by
  unfold trueNormalizedState dyadicNormalizedTailStateR235
  have h2 : (threePrimeHeight 2 3 5 (2 ^ a) : ℝ) =
      2 * (heightNormalizer235 a : ℝ) := by
    exact_mod_cast (two_mul_heightNormalizer235 a ha).symm
  rw [h2]
  ring
end ErdosProblems.Erdos269.PaperR13

open scoped BigOperators
open PaperR7
open ErdosProblems in
open ErdosProblems.Erdos269 in
open ErdosProblems.Erdos269.PaperR13 in
open ErdosProblems.Erdos269.PaperR7 in
theorem solution {N : ℤ} {D a : ℕ} (hD : 0 < D) (ha : 1 ≤ a)
    (hval : paperSeries235 = (N : ℝ) / (D : ℝ)) :
    ((rationalTailState N D a : ℚ) : ℝ) = trueNormalizedState a := by
  have haeq : 1 + (a - 1) = a := by omega
  have hsplit := dyadicShellTsumTailR235_eq_range_add 1 (a - 1)
  rw [haeq] at hsplit
  have hpref :
      (∑ i ∈ Finset.range (a - 1), dyadicShellMassR235 (1 + i)) =
        ((dyadicSmoothWindowMassQ235 1 (a - 1) : ℚ) : ℝ) := by
    simp [dyadicSmoothWindowMassQ235, dyadicShellMassR235]
  have htailOne := tail_one_of_paperSeries_eq_rat hD hval
  have htail : dyadicShellTsumTailR235 a =
      (N : ℝ) / (D : ℝ) - 1 -
        ((dyadicSmoothWindowMassQ235 1 (a - 1) : ℚ) : ℝ) := by
    rw [hpref, htailOne] at hsplit
    have hDR : (D : ℝ) ≠ 0 := by exact_mod_cast hD.ne'
    have hquot :
        (((N - (D : ℤ) : ℤ) : ℤ) : ℝ) / (D : ℝ) =
          (N : ℝ) / (D : ℝ) - 1 := by
      push_cast
      field_simp [hDR]
    rw [hquot] at hsplit
    linarith
  rw [trueNormalizedState_eq_heightNormalizer_mul a ha, htail]
  simp only [rationalTailState, Rat.cast_mul, Rat.cast_natCast, Rat.cast_sub,
    Rat.cast_intCast, Rat.cast_div, Rat.cast_one]
