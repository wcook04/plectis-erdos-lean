import Definitions.Def_ErdosProblems_Erdos269_ThreePrimeRunningLcm
import Definitions.Def_ErdosProblems_Shared_IrrationalRotationStaircase
import Definitions.Def_ErdosProblems_Erdos269_KernelCarryRank
import Mathlib.Algebra.BigOperators.Group.Finset.Basic
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Algebra.Order.Floor.Ring
import Mathlib.Algebra.Order.Floor.Semiring
import Mathlib.Algebra.Ring.Parity
import Mathlib.Analysis.SpecialFunctions.Log.Base
import Mathlib.Data.Finset.Card
import Mathlib.Data.Finset.Prod
import Mathlib.Data.Fintype.Pigeonhole
import Mathlib.Data.Nat.Log
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.Nat.Prime.Int
import Mathlib.Data.Real.Archimedean
import Mathlib.LinearAlgebra.Matrix.Block
import Mathlib.LinearAlgebra.Matrix.Determinant.Basic
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Ring

namespace ErdosProblems.Erdos269
open ErdosProblems.Shared
end ErdosProblems.Erdos269

open ErdosProblems
open ErdosProblems.Erdos269
open ErdosProblems.Shared
open ErdosProblems in
open ErdosProblems.Erdos269 in
theorem solution {p r : ℕ} (hp : p.Prime) (hr : r.Prime)
    (hpr : p ≠ r) : NoIntegerOrbit (Real.logb r p) := by
  intro n hn hfract
  have hp1 : (1 : ℝ) < (p : ℝ) := by exact_mod_cast hp.one_lt
  have hr1 : (1 : ℝ) < (r : ℝ) := by exact_mod_cast hr.one_lt
  have hlogp : 0 < Real.log (p : ℝ) := Real.log_pos hp1
  have hlogr : 0 < Real.log (r : ℝ) := Real.log_pos hr1
  set x : ℝ := (n : ℝ) * Real.logb r p with hx
  set z : ℤ := ⌊x⌋ with hz
  have hxz : x = (z : ℝ) := by
    have := Int.floor_add_fract x
    rw [hfract] at this
    rw [hz]; linarith
  have hx0 : (0 : ℝ) ≤ x := by
    rw [hx]
    exact mul_nonneg (Nat.cast_nonneg n) (Real.logb_nonneg hr1 hp1.le)
  have hz0 : 0 ≤ z := by rw [hz]; exact Int.floor_nonneg.2 hx0
  -- `n * log p = z * log r`
  have hkey : (n : ℝ) * Real.log (p : ℝ) = (z : ℝ) * Real.log (r : ℝ) := by
    have hlogb : Real.logb (r : ℝ) (p : ℝ) = Real.log (p : ℝ) / Real.log (r : ℝ) := rfl
    rw [hx, hlogb] at hxz
    field_simp at hxz
    linarith
  -- exponentiate
  have hlogL : Real.log (((p ^ n : ℕ)) : ℝ) = (n : ℝ) * Real.log (p : ℝ) := by
    push_cast; rw [Real.log_pow]
  have hlogR : Real.log (((r ^ z.toNat : ℕ)) : ℝ) = (z : ℝ) * Real.log (r : ℝ) := by
    push_cast
    rw [Real.log_pow]
    congr 1
    exact_mod_cast congrArg (fun m : ℤ => (m : ℝ)) (Int.toNat_of_nonneg hz0)
  have hposL : (0 : ℝ) < ((p ^ n : ℕ) : ℝ) := by
    have hpn : 0 < p ^ n := pow_pos hp.pos n
    exact_mod_cast hpn
  have hposR : (0 : ℝ) < ((r ^ z.toNat : ℕ) : ℝ) := by
    have hrz : 0 < r ^ z.toNat := pow_pos hr.pos _
    exact_mod_cast hrz
  have hlogEq : Real.log (((p ^ n : ℕ)) : ℝ) = Real.log (((r ^ z.toNat : ℕ)) : ℝ) := by
    rw [hlogL, hlogR, hkey]
  have hEqR : ((p ^ n : ℕ) : ℝ) = ((r ^ z.toNat : ℕ) : ℝ) := by
    have h1 := Real.exp_log hposL
    have h2 := Real.exp_log hposR
    rw [← h1, ← h2, hlogEq]
  have hEq : p ^ n = r ^ z.toNat := by exact_mod_cast hEqR
  have hdvd : p ∣ r ^ z.toNat := by
    rw [← hEq]
    exact dvd_pow_self p hn.ne'
  exact hpr (Nat.prime_dvd_prime_iff_eq hp hr |>.1 (hp.dvd_of_dvd_pow hdvd))
