import Definitions.Def_ErdosProblems_Erdos269_BoundedRadixTailEscape
import Definitions.Def_ErdosProblems_Erdos269_ResidueEscape
import Definitions.Def_ErdosProblems_Erdos269_ThreePrimeRunningLcm
import Definitions.Def_ErdosProblems_Erdos269_RestrictedFloorSum
import Definitions.Def_ErdosProblems_Erdos269_DyadicBlockMassIdentity
import Definitions.Def_ErdosProblems_Erdos269_DyadicBlockThresholdPartition
import Definitions.Def_ErdosProblems_Erdos269_DyadicOrderedTailRecurrence
import Definitions.Def_ErdosProblems_Erdos269_DyadicShellSummability
import Definitions.Def_ErdosProblems_Erdos269_IntegralBranchExtinction
import Definitions.Def_ErdosProblems_Erdos269_JumpConstraintMajorant
import Definitions.Def_ErdosProblems_Shared_IrrationalRotationStaircase
import Definitions.Def_ErdosProblems_Erdos269_KernelCarryRank
import Definitions.Def_ErdosProblems_Erdos269_PaperR7ActualOrbit
import Definitions.Def_ErdosProblems_Erdos269_PaperR7SeriesIdentification
import Definitions.Def_ErdosProblems_Erdos269_RationalLatticeReduction
import Definitions.Def_ErdosProblems_Erdos269_RationalityCarryBridge
import Definitions.Def_ErdosProblems_Erdos269_PaperR7RationalBridge
import Definitions.Def_ErdosProblems_Erdos269_PaperR7WindowResults
import Definitions.Def_ErdosProblems_Erdos269_PaperCompleteR20_WeightedShiftArithmetic
import Definitions.Def_ErdosProblems_Erdos269_PaperCompleteR20_WeightedShiftValue
import Theorems.Thm_ErdosProblems_Erdos269_dyadicOrderedBlockDigit235_le_quadratic
import Theorems.Thm_ErdosProblems_Erdos269_half_threePrimeHeight_mul_dyadicShellMassR235
import Theorems.Thm_ErdosProblems_Erdos269_threePrimeHeight235_cast_pos
import Theorems.Thm_ErdosProblems_Erdos269_summable_dyadicShellMassR235
import Theorems.Thm_ErdosProblems_Erdos269_PaperR7_paperSeries235_eq_shellTsum
import Theorems.Thm_ErdosProblems_Erdos269_PaperCompleteR20_shiftGamma_four_values
import Theorems.Thm_ErdosProblems_Erdos269_PaperCompleteR20_shiftGamma_bounds
import Theorems.Thm_ErdosProblems_Erdos269_PaperCompleteR20_shiftedLeading_ne_zero
import Theorems.Thm_ErdosProblems_Erdos269_PaperCompleteR20_shiftedNumerator_integral
import Theorems.Thm_ErdosProblems_Erdos269_PaperCompleteR20_shiftedPrefix_integral
import Mathlib.Algebra.BigOperators.Group.Finset.Basic
import Mathlib.Algebra.BigOperators.Group.Finset.Sigma
import Mathlib.Algebra.BigOperators.Group.List.Basic
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Algebra.Order.Floor.Ring
import Mathlib.Algebra.Order.Floor.Semiring
import Mathlib.Algebra.Ring.Parity
import Mathlib.Analysis.Normed.Module.FiniteDimension
import Mathlib.Analysis.SpecialFunctions.Log.Base
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Data.Finset.Card
import Mathlib.Data.Finset.Prod
import Mathlib.Data.Fintype.Pigeonhole
import Mathlib.Data.Int.ModEq
import Mathlib.Data.Nat.Factorization.Basic
import Mathlib.Data.Nat.Log
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.Nat.Prime.Int
import Mathlib.Data.Real.Archimedean
import Mathlib.LinearAlgebra.Matrix.Block
import Mathlib.LinearAlgebra.Matrix.Determinant.Basic
import Mathlib.Tactic
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.InfiniteSum.Real

-- `Summable.norm` (the alias of `summable_norm_iff`) no longer arrives transitively on Lean 4.30.0
-- / Mathlib c5ea0035, and dot notation no longer resolves it because `Summable` now unfolds to
-- `Exists`. Imported explicitly and applied by name below. Statements are unchanged.
namespace PaperR7
end PaperR7

/-!
# Weighted shifts of the literal series

Finite linear combinations of shifted digits retain the original value
with an integer prefix correction. All sums below converge absolutely.
-/

namespace ErdosProblems.Erdos269.PaperCompleteR20
open PaperR7
open scoped BigOperators



theorem shiftTerm_eq_half_shell (a : ℕ) : shiftTerm a = dyadicShellMassR235 a / 2 := by
  have hp : (shiftHeight (a + 1) : ℝ) ≠ 0 := (threePrimeHeight235_cast_pos _).ne'
  have hd := half_threePrimeHeight_mul_dyadicShellMassR235 a
  unfold shiftTerm
  apply (div_eq_div_iff hp (by norm_num : (2 : ℝ) ≠ 0)).2
  nlinarith only [hd]

theorem hasSum_shiftTerm : HasSum shiftTerm (paperSeries235 / 2) := by
  have hs := summable_dyadicShellMassR235.hasSum.div_const (2 : ℝ)
  have hv : (∑' a : ℕ, dyadicShellMassR235 a) = paperSeries235 := by
    simpa only [dyadicShellTsumTailR235, Nat.zero_add] using paperSeries235_eq_shellTsum.symm
  rw [hv] at hs
  exact hs.congr_fun shiftTerm_eq_half_shell

theorem weighted_shift_term (a t : ℕ) :
    shiftGamma a t * (dyadicOrderedBlockDigit235 (a + t) : ℝ) /
        (shiftHeight (a + 1) : ℝ) = (shiftHeight t : ℝ) * shiftTerm (a + t) := by
  have hp : (shiftHeight (a + 1) : ℝ) ≠ 0 := (threePrimeHeight235_cast_pos _).ne'
  have ht : (shiftHeight (a + t + 1) : ℝ) ≠ 0 := (threePrimeHeight235_cast_pos _).ne'
  unfold shiftGamma shiftTerm
  field_simp

theorem hasSum_one_weighted_shift (t : ℕ) :
    HasSum (fun a : ℕ => shiftGamma a t * (dyadicOrderedBlockDigit235 (a + t) : ℝ) /
      (shiftHeight (a + 1) : ℝ))
      ((shiftHeight t : ℝ) * (paperSeries235 / 2) - shiftedPrefix t) := by
  have hs := ((hasSum_nat_add_iff' t).2 hasSum_shiftTerm).mul_left (shiftHeight t : ℝ)
  have he : (shiftHeight t : ℝ) *
      (paperSeries235 / 2 - ∑ k ∈ Finset.range t, shiftTerm k) =
      (shiftHeight t : ℝ) * (paperSeries235 / 2) - shiftedPrefix t := by
    simp only [shiftedPrefix, shiftTerm, mul_sub]
  rw [he] at hs
  exact hs.congr_fun (fun a => weighted_shift_term a t)





theorem shiftedCorrection_integral (c : ℕ → ℤ) (σ r : ℕ) :
    ∃ z : ℤ, shiftedCorrection c σ r = (z : ℝ) := by
  choose z hz using shiftedPrefix_integral
  refine ⟨15 * ∑ j ∈ Finset.range (σ + 1), c j * z (j * r), ?_⟩
  unfold shiftedCorrection
  push_cast
  simp only [hz]

theorem hasSum_weighted_shift_identity (c : ℕ → ℤ) (σ r : ℕ) :
    HasSum (fun a : ℕ => shiftedNumerator c σ r a / (shiftHeight (a + 1) : ℝ))
      ((shiftedLeading c σ r : ℝ) * (paperSeries235 / 2) - shiftedCorrection c σ r) := by
  have hs := (hasSum_sum (s := Finset.range (σ + 1))
    (fun j _ => (hasSum_one_weighted_shift (j * r)).mul_left (c j : ℝ))).mul_left (15 : ℝ)
  convert hs using 1
  · funext a
    simp only [shiftedNumerator, Finset.sum_div, mul_div_assoc, Finset.mul_sum, mul_assoc]
  · simp only [shiftedLeading, shiftedCorrection, Int.cast_mul, Int.cast_ofNat,
      Int.cast_sum, Int.cast_natCast, mul_sub, Finset.sum_sub_distrib,
      Finset.sum_mul, mul_assoc]

theorem weighted_shift_identity_absolute (c : ℕ → ℤ) (σ r : ℕ) :
    Summable (fun a : ℕ => |shiftedNumerator c σ r a / (shiftHeight (a + 1) : ℝ)|) := by
  simpa only [Real.norm_eq_abs] using Summable.norm (hasSum_weighted_shift_identity c σ r).summable



theorem shifted_index_le (a j r : ℕ) :
    a + j * r + 1 ≤ max 1 j * (a + r + 1) := by
  have h1 : 1 ≤ max 1 j := le_max_left _ _
  have hj : j ≤ max 1 j := le_max_right _ _
  nlinarith

theorem one_shift_quadratic_bound (c : ℤ) (a j r : ℕ) :
    |(c : ℝ) * shiftGamma a (j * r) * (dyadicOrderedBlockDigit235 (a + j * r) : ℝ)| ≤
      15 * |(c : ℝ)| * (max 1 j : ℝ) ^ 2 * ((a + r + 1 : ℕ) : ℝ) ^ 2 := by
  obtain ⟨hg0, hg1⟩ := shiftGamma_bounds a (j * r)
  have hm0 : (0 : ℝ) ≤ dyadicOrderedBlockDigit235 (a + j * r) := Nat.cast_nonneg _
  have hmu : (dyadicOrderedBlockDigit235 (a + j * r) : ℝ) ≤
      15 * ((a + j * r + 1 : ℕ) : ℝ) ^ 2 := by
    exact_mod_cast dyadicOrderedBlockDigit235_le_quadratic (a + j * r)
  have hindex : ((a + j * r + 1 : ℕ) : ℝ) ≤
      (max 1 j : ℝ) * ((a + r + 1 : ℕ) : ℝ) := by
    exact_mod_cast shifted_index_le a j r
  have hsq : (((a + j * r + 1 : ℕ) : ℝ)) ^ 2 ≤
      ((max 1 j : ℝ) * ((a + r + 1 : ℕ) : ℝ)) ^ 2 := by
    exact pow_le_pow_left₀ (Nat.cast_nonneg _) hindex 2
  rw [abs_mul, abs_mul, abs_of_pos hg0, abs_of_nonneg hm0]
  calc
    |(c : ℝ)| * shiftGamma a (j * r) * (dyadicOrderedBlockDigit235 (a + j * r) : ℝ)
        ≤ |(c : ℝ)| * (dyadicOrderedBlockDigit235 (a + j * r) : ℝ) := by
      simpa only [mul_one] using
        mul_le_mul_of_nonneg_right (mul_le_mul_of_nonneg_left hg1 (abs_nonneg _)) hm0
    _ ≤ |(c : ℝ)| * (15 * ((a + j * r + 1 : ℕ) : ℝ) ^ 2) :=
      mul_le_mul_of_nonneg_left hmu (abs_nonneg _)
    _ ≤ |(c : ℝ)| * (15 * ((max 1 j : ℝ) * ((a + r + 1 : ℕ) : ℝ)) ^ 2) :=
      mul_le_mul_of_nonneg_left (mul_le_mul_of_nonneg_left hsq (by norm_num)) (abs_nonneg _)
    _ = _ := by ring

theorem shiftedNumerator_quadratic_bound (c : ℕ → ℤ) (σ r a : ℕ) :
    |shiftedNumerator c σ r a| ≤
      shiftedQuadraticConstant c σ * ((a + r + 1 : ℕ) : ℝ) ^ 2 := by
  unfold shiftedNumerator
  rw [abs_mul, abs_of_pos (by norm_num : (0 : ℝ) < 15)]
  calc
    15 * |∑ j ∈ Finset.range (σ + 1), (c j : ℝ) * shiftGamma a (j * r) *
        (dyadicOrderedBlockDigit235 (a + j * r) : ℝ)|
      ≤ 15 * ∑ j ∈ Finset.range (σ + 1),
        |(c j : ℝ) * shiftGamma a (j * r) * (dyadicOrderedBlockDigit235 (a + j * r) : ℝ)| := by
          gcongr
          exact Finset.abs_sum_le_sum_abs _ _
    _ ≤ 15 * ∑ j ∈ Finset.range (σ + 1),
        15 * |(c j : ℝ)| * (max 1 j : ℝ) ^ 2 * ((a + r + 1 : ℕ) : ℝ) ^ 2 := by
          apply mul_le_mul_of_nonneg_left _ (by norm_num)
          exact Finset.sum_le_sum (fun j _ => one_shift_quadratic_bound (c j) a j r)
    _ = 15 * (15 * (∑ j ∈ Finset.range (σ + 1),
        |(c j : ℝ)| * (max 1 j : ℝ) ^ 2) * ((a + r + 1 : ℕ) : ℝ) ^ 2) := by
      congr 1
      simp only [Finset.sum_mul, Finset.mul_sum]
      apply Finset.sum_congr rfl
      intro j _
      ring
    _ = shiftedQuadraticConstant c σ * ((a + r + 1 : ℕ) : ℝ) ^ 2 := by
      unfold shiftedQuadraticConstant
      ring
end ErdosProblems.Erdos269.PaperCompleteR20

open PaperR7
open scoped BigOperators
open ErdosProblems in
open ErdosProblems.Erdos269 in
open ErdosProblems.Erdos269.PaperCompleteR20 in
open ErdosProblems.Erdos269.PaperR7 in
theorem solution (c : ℕ → ℤ) (σ r : ℕ) :
    (∀ a t, shiftGamma a t = 1 ∨ shiftGamma a t = 1 / 3 ∨
      shiftGamma a t = 1 / 5 ∨ shiftGamma a t = 1 / 15) ∧
    (∀ a, ∃ z : ℤ, shiftedNumerator c σ r a = (z : ℝ)) ∧
    (∃ z : ℤ, shiftedCorrection c σ r = (z : ℝ)) ∧
    HasSum (fun a : ℕ => shiftedNumerator c σ r a / (shiftHeight (a + 1) : ℝ))
      ((shiftedLeading c σ r : ℝ) * (paperSeries235 / 2) - shiftedCorrection c σ r) ∧
    Summable (fun a : ℕ => |shiftedNumerator c σ r a / (shiftHeight (a + 1) : ℝ)|) ∧
    (∀ a, |shiftedNumerator c σ r a| ≤
      shiftedQuadraticConstant c σ * ((a + r + 1 : ℕ) : ℝ) ^ 2) ∧
    (∀ J : ℕ, J ≤ σ → (∀ j, J < j → j ≤ σ → c j = 0) →
      (∑ j ∈ Finset.range J, |(c j : ℝ)| / (2 : ℝ) ^ ((J - j) * r)) < |(c J : ℝ)| →
      shiftedLeading c σ r ≠ 0) := by
  exact ⟨shiftGamma_four_values, shiftedNumerator_integral c σ r,
    shiftedCorrection_integral c σ r, hasSum_weighted_shift_identity c σ r,
    weighted_shift_identity_absolute c σ r, shiftedNumerator_quadratic_bound c σ r,
    shiftedLeading_ne_zero c σ r⟩
