import Definitions.Def_ErdosProblems_Erdos269_ThreePrimeRunningLcm
import Definitions.Def_ErdosProblems_Shared_IrrationalRotationStaircase
import Definitions.Def_ErdosProblems_Erdos269_KernelCarryRank
import Definitions.Def_ErdosProblems_Erdos269_PaperR7AnalyticInterfaces
import Definitions.Def_ErdosProblems_Erdos269_PaperCompleteR21_TwoPrimeSums
import Theorems.Thm_ErdosProblems_Erdos269_PaperCompleteR21_qExp_pExp_succ
import Theorems.Thm_ErdosProblems_Erdos269_PaperCompleteR21_runningLcmValues_eq
import Theorems.Thm_ErdosProblems_Erdos269_PaperCompleteR21_smoothVal_injective
import Mathlib.Algebra.BigOperators.Group.Finset.Basic
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Algebra.Order.Floor.Ring
import Mathlib.Algebra.Order.Floor.Semiring
import Mathlib.Algebra.Ring.Parity
import Mathlib.Analysis.Normed.Ring.InfiniteSum
import Mathlib.Analysis.SpecialFunctions.Log.Base
import Mathlib.Analysis.SpecialFunctions.Pow.Real
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.Data.Finset.Card
import Mathlib.Data.Finset.Prod
import Mathlib.Data.Fintype.Pigeonhole
import Mathlib.Data.Nat.Log
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.Nat.Prime.Int
import Mathlib.Data.Real.Archimedean
import Mathlib.LinearAlgebra.Matrix.Block
import Mathlib.LinearAlgebra.Matrix.Determinant.Basic
import Mathlib.NumberTheory.Real.Irrational
import Mathlib.RingTheory.Algebraic.Basic
import Mathlib.Tactic
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Ring

/-!
# Erdős #269: both two-prime running-LCM sums

This file transcribes the two-prime objects of the short paper's
`res:two-prime-transcendence` and of the long paper's `long269:res:lead-two-prime`
and proves everything those statements assert except one external value theorem.

* `runningLcm p q x` is the literal least common multiple of the `{p,q}`-smooth
  numbers not exceeding `x`; `runningLcm_eq_twoPrimeHeight` identifies it with the
  product of the two maximal pure prime powers.
* `repeatedSum p q` is `R_{p,q}`: the reciprocal running LCM summed at every
  positive `{p,q}`-smooth integer.  `distinctSum p q` is `D_{p,q}`: each distinct
  running LCM counted once.
* `two_prime_affine_and_quadratic` proves the paper's displayed identities
  `eq:two-prime-affine`, with `A` the paper's boundary value
  `ErdosProblems.Erdos269.PaperR7.twoPrimeHeckeValue`.
* `two_prime_sums_transcendental` and `two_prime_transcendence` conclude that both
  values are transcendental.

The only undischarged input is `BugeaudLaurentTranscendence`, the theorem of
Bugeaud and Laurent (Theorem 1.1) in the case `ρ = 0` due to Loxton and van der
Poorten (Theorem 8, p. 40), that the Hecke--Mahler series takes transcendental
values.  It is carried as one explicit named hypothesis, stated in the generality
in which the paper cites it; all of its side conditions for the pair `(1/p, 1/q)`,
including irrationality of the slope `θ = log p / log q`, are proved here.
-/

namespace ErdosProblems.Erdos269.PaperCompleteR21
open Polynomial
open scoped BigOperators

noncomputable section

/-! ## The `{p,q}`-smooth numbers and their running least common multiple -/















/-! ## Integer logarithms at smooth points -/















theorem qExp_mono {p q : ℕ} (hp : 0 < p) {m n : ℕ} (h : m ≤ n) :
    qExp p q m ≤ qExp p q n :=
  Nat.log_mono_right (Nat.pow_le_pow_right hp h)

theorem pExp_mono {q : ℕ} (hq : 0 < q) {p m n : ℕ} (h : m ≤ n) :
    pExp p q m ≤ pExp p q n :=
  Nat.log_mono_right (Nat.pow_le_pow_right hq h)



theorem twoPrimeHeight_pow_left {p q : ℕ} (hp : 1 < p) (a : ℕ) :
    twoPrimeHeight p q (p ^ a) = p ^ a * q ^ qExp p q a := by
  simp [twoPrimeHeight, qExp, Nat.log_pow hp]

theorem twoPrimeHeight_pow_right {p q : ℕ} (hq : 1 < q) (b : ℕ) :
    twoPrimeHeight p q (q ^ b) = p ^ pExp p q b * q ^ b := by
  simp [twoPrimeHeight, pExp, Nat.log_pow hq]

/-! ## The exact combinatorics of the jump indices -/



private theorem mul_lt_mul_nat' {a b c d : ℕ} (h1 : a < c) (h2 : b ≤ d) (hb : 0 < b) :
    a * b < c * d := by
  nlinarith







/-! ## Unique factorisation of the smooth monoid -/







/-! ## The two sums of the paper -/







/-! ## The two component series -/





theorem aTerm_nonneg (p q n : ℕ) : 0 ≤ aTerm p q n := by
  unfold aTerm
  positivity

theorem cTerm_nonneg (p q j : ℕ) : 0 ≤ cTerm p q j := by
  unfold cTerm
  positivity





theorem aTerm_eq_inv {p q : ℕ} (n : ℕ) :
    aTerm p q n = (((p : ℝ) ^ n * (q : ℝ) ^ qExp p q n))⁻¹ := by
  rw [aTerm, mul_inv, inv_pow, inv_pow]

theorem cTerm_eq_inv {p q : ℕ} (j : ℕ) :
    cTerm p q j = (((p : ℝ) ^ pExp p q j * (q : ℝ) ^ j))⁻¹ := by
  rw [cTerm, mul_inv, inv_pow, inv_pow]

private theorem inv_lt_one_nat {p : ℕ} (hp : 1 < p) : ((p : ℝ))⁻¹ < 1 := by
  have hp0 : (0 : ℝ) < (p : ℝ) := by exact_mod_cast (by omega : 0 < p)
  have hp1 : (1 : ℝ) < (p : ℝ) := by exact_mod_cast hp
  have h : (1 : ℝ) / (p : ℝ) < 1 := by
    rw [div_lt_one hp0]
    exact hp1
  simpa [one_div] using h

private theorem inv_nonneg_nat (p : ℕ) : (0 : ℝ) ≤ ((p : ℝ))⁻¹ := by positivity

theorem summable_aTerm {p q : ℕ} (hp : 1 < p) (hq : 1 < q) : Summable (aTerm p q) := by
  refine Summable.of_nonneg_of_le (fun n => aTerm_nonneg p q n) (fun n => ?_)
    (summable_geometric_of_lt_one (inv_nonneg_nat p) (inv_lt_one_nat hp))
  have hle : ((q : ℝ)⁻¹) ^ qExp p q n ≤ 1 :=
    pow_le_one₀ (inv_nonneg_nat q) (le_of_lt (inv_lt_one_nat hq))
  calc aTerm p q n = ((p : ℝ)⁻¹) ^ n * ((q : ℝ)⁻¹) ^ qExp p q n := rfl
    _ ≤ ((p : ℝ)⁻¹) ^ n * 1 := mul_le_mul_of_nonneg_left hle (by positivity)
    _ = ((p : ℝ)⁻¹) ^ n := mul_one _

theorem summable_cTerm {p q : ℕ} (hp : 1 < p) (hq : 1 < q) : Summable (cTerm p q) := by
  refine Summable.of_nonneg_of_le (fun j => cTerm_nonneg p q j) (fun j => ?_)
    (summable_geometric_of_lt_one (inv_nonneg_nat q) (inv_lt_one_nat hq))
  have hle : ((p : ℝ)⁻¹) ^ pExp p q j ≤ 1 :=
    pow_le_one₀ (inv_nonneg_nat p) (le_of_lt (inv_lt_one_nat hp))
  calc cTerm p q j = ((p : ℝ)⁻¹) ^ pExp p q j * ((q : ℝ)⁻¹) ^ j := rfl
    _ ≤ 1 * ((q : ℝ)⁻¹) ^ j := mul_le_mul_of_nonneg_right hle (by positivity)
    _ = ((q : ℝ)⁻¹) ^ j := one_mul _

theorem summable_cTerm_succ {p q : ℕ} (hp : 1 < p) (hq : 1 < q) :
    Summable (fun b : ℕ => cTerm p q (b + 1)) :=
  (summable_nat_add_iff 1).mpr (summable_cTerm hp hq)

/-! ## `R = A (1 + B)` -/





/-! ## `D = A + B` -/





theorem jumpLeft_injective {p q : ℕ} (hp : 1 < p) (hq : 1 < q) :
    Function.Injective (jumpLeft p q) := by
  have hmono : StrictMono (jumpLeft p q) := by
    apply strictMono_nat_of_lt_succ
    intro a
    simp only [jumpLeft, twoPrimeHeight_pow_left hp]
    have h1 : p ^ a < p ^ (a + 1) := Nat.pow_lt_pow_right hp (by omega)
    have h2 : q ^ qExp p q a ≤ q ^ qExp p q (a + 1) :=
      Nat.pow_le_pow_right (by omega) (qExp_mono (by omega) (by omega))
    have h3 : 0 < q ^ qExp p q a := pow_pos (by omega) _
    exact mul_lt_mul_nat' h1 h2 h3
  exact hmono.injective

theorem jumpRight_injective {p q : ℕ} (hp : 1 < p) (hq : 1 < q) :
    Function.Injective (jumpRight p q) := by
  have hmono : StrictMono (jumpRight p q) := by
    apply strictMono_nat_of_lt_succ
    intro b
    simp only [jumpRight, twoPrimeHeight_pow_right hq]
    have h1 : q ^ (b + 1) < q ^ (b + 1 + 1) := Nat.pow_lt_pow_right hq (by omega)
    have h2 : p ^ pExp p q (b + 1) ≤ p ^ pExp p q (b + 1 + 1) :=
      Nat.pow_le_pow_right (by omega) (pExp_mono (by omega) (by omega))
    have h3 : 0 < p ^ pExp p q (b + 1) := pow_pos (by omega) _
    calc p ^ pExp p q (b + 1) * q ^ (b + 1)
        = q ^ (b + 1) * p ^ pExp p q (b + 1) := by ring
      _ < q ^ (b + 1 + 1) * p ^ pExp p q (b + 1 + 1) := mul_lt_mul_nat' h1 h2 h3
      _ = p ^ pExp p q (b + 1 + 1) * q ^ (b + 1 + 1) := by ring
  exact hmono.injective



private theorem summable_on_range {g : ℕ → ℕ} (hg : Function.Injective g)
    (h : Summable fun a : ℕ => ((g a : ℝ))⁻¹) :
    Summable ((fun n : ℕ => ((n : ℝ))⁻¹) ∘ ((↑) : Set.range g → ℕ)) := by
  refine ((Equiv.ofInjective g hg).summable_iff
    (f := (fun n : ℕ => ((n : ℝ))⁻¹) ∘ ((↑) : Set.range g → ℕ))).mp ?_
  simpa [Function.comp_def] using h

theorem jumpLeft_inv {p q : ℕ} (hp : 1 < p) (a : ℕ) :
    ((jumpLeft p q a : ℝ))⁻¹ = aTerm p q a := by
  rw [jumpLeft, twoPrimeHeight_pow_left hp, aTerm_eq_inv]
  push_cast
  ring

theorem jumpRight_inv {p q : ℕ} (hq : 1 < q) (b : ℕ) :
    ((jumpRight p q b : ℝ))⁻¹ = cTerm p q (b + 1) := by
  rw [jumpRight, twoPrimeHeight_pow_right hq, cTerm_eq_inv]
  push_cast
  ring
end
end ErdosProblems.Erdos269.PaperCompleteR21

open Polynomial
open scoped BigOperators
open ErdosProblems in
open ErdosProblems.Erdos269 in
open ErdosProblems.Erdos269.PaperCompleteR21 in
theorem solution {p q : ℕ} (hp : p.Prime) (hq : q.Prime) (hpq : p < q) :
    distinctSum p q = (∑' n : ℕ, aTerm p q n) + ∑' b : ℕ, cTerm p q (b + 1) := by
  have hp1 : 1 < p := hp.one_lt
  have hq1 : 1 < q := hq.one_lt
  have hne : p ≠ q := Nat.ne_of_lt hpq
  have hLinj : Function.Injective (jumpLeft p q) := jumpLeft_injective hp1 hq1
  have hRinj : Function.Injective (jumpRight p q) := jumpRight_injective hp1 hq1
  have hdisj : Disjoint (Set.range (jumpLeft p q)) (Set.range (jumpRight p q)) := by
    rw [Set.disjoint_left]
    rintro H ⟨a, rfl⟩ ⟨b, hb⟩
    rw [jumpLeft, jumpRight, twoPrimeHeight_pow_left hp1,
      twoPrimeHeight_pow_right hq1] at hb
    have hpair := smoothVal_injective hp hq hne (a₁ := (pExp p q (b + 1), b + 1))
      (a₂ := (a, qExp p q a)) (by simpa using hb)
    have h2 : b + 1 = qExp p q a := congrArg Prod.snd hpair
    have h1 : pExp p q (b + 1) = a := congrArg Prod.fst hpair
    have h3 := (qExp_pExp_succ hp hq hpq b).1
    rw [h1] at h3
    omega
  have hsA : Summable ((fun n : ℕ => ((n : ℝ))⁻¹) ∘
      ((↑) : Set.range (jumpLeft p q) → ℕ)) := by
    refine summable_on_range hLinj ?_
    exact (summable_aTerm hp1 hq1).congr fun a => (jumpLeft_inv hp1 a).symm
  have hsB : Summable ((fun n : ℕ => ((n : ℝ))⁻¹) ∘
      ((↑) : Set.range (jumpRight p q) → ℕ)) := by
    refine summable_on_range hRinj ?_
    exact (summable_cTerm_succ hp1 hq1).congr fun b => (jumpRight_inv hq1 b).symm
  unfold distinctSum
  rw [runningLcmValues_eq hp hq hne, Summable.tsum_union_disjoint hdisj hsA hsB,
    tsum_range (fun n : ℕ => ((n : ℝ))⁻¹) hLinj,
    tsum_range (fun n : ℕ => ((n : ℝ))⁻¹) hRinj]
  congr 1
  · exact tsum_congr fun a => jumpLeft_inv hp1 a
  · exact tsum_congr fun b => jumpRight_inv hq1 b
