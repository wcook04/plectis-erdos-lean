import Definitions.Def_ErdosProblems_Erdos269_ThreePrimeRunningLcm
import Definitions.Def_ErdosProblems_Shared_IrrationalRotationStaircase
import Definitions.Def_ErdosProblems_Erdos269_KernelCarryRank
import Definitions.Def_ErdosProblems_Erdos269_PaperR7AnalyticInterfaces
import Definitions.Def_ErdosProblems_Erdos269_PaperCompleteR21_TwoPrimeSums
import Mathlib.Algebra.BigOperators.Group.Finset.Basic
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Algebra.Order.Floor.Ring
import Mathlib.Algebra.Order.Floor.Semiring
import Mathlib.Algebra.Ring.Parity
import Mathlib.Analysis.Normed.Ring.InfiniteSum
import Mathlib.Analysis.SpecialFunctions.Log.Base
import Mathlib.Analysis.SpecialFunctions.Pow.Real
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.Data.Finset.Card
import Mathlib.Data.Finset.Prod
import Mathlib.Data.Fintype.Pigeonhole
import Mathlib.Data.Nat.Log
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.Nat.Prime.Int
import Mathlib.Data.Real.Archimedean
import Mathlib.LinearAlgebra.Matrix.Block
import Mathlib.LinearAlgebra.Matrix.Determinant.Basic
import Mathlib.NumberTheory.Real.Irrational
import Mathlib.RingTheory.Algebraic.Basic
import Mathlib.Tactic
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Ring

/-!
# Erdős #269: both two-prime running-LCM sums

This file transcribes the two-prime objects of the short paper's
`res:two-prime-transcendence` and of the long paper's `long269:res:lead-two-prime`
and proves everything those statements assert except one external value theorem.

* `runningLcm p q x` is the literal least common multiple of the `{p,q}`-smooth
  numbers not exceeding `x`; `runningLcm_eq_twoPrimeHeight` identifies it with the
  product of the two maximal pure prime powers.
* `repeatedSum p q` is `R_{p,q}`: the reciprocal running LCM summed at every
  positive `{p,q}`-smooth integer.  `distinctSum p q` is `D_{p,q}`: each distinct
  running LCM counted once.
* `two_prime_affine_and_quadratic` proves the paper's displayed identities
  `eq:two-prime-affine`, with `A` the paper's boundary value
  `ErdosProblems.Erdos269.PaperR7.twoPrimeHeckeValue`.
* `two_prime_sums_transcendental` and `two_prime_transcendence` conclude that both
  values are transcendental.

The only undischarged input is `BugeaudLaurentTranscendence`, the theorem of
Bugeaud and Laurent (Theorem 1.1) in the case `ρ = 0` due to Loxton and van der
Poorten (Theorem 8, p. 40), that the Hecke--Mahler series takes transcendental
values.  It is carried as one explicit named hypothesis, stated in the generality
in which the paper cites it; all of its side conditions for the pair `(1/p, 1/q)`,
including irrationality of the slope `θ = log p / log q`, are proved here.
-/

namespace ErdosProblems.Erdos269.PaperCompleteR21
open Polynomial
open scoped BigOperators

noncomputable section

/-! ## The `{p,q}`-smooth numbers and their running least common multiple -/















/-! ## Integer logarithms at smooth points -/

theorem log_mul_pow {b : ℕ} (hb : 1 < b) {m : ℕ} (hm : m ≠ 0) (i : ℕ) :
    Nat.log b (m * b ^ i) = Nat.log b m + i := by
  induction i with
  | zero => simp
  | succ i ih =>
    have hmi : m * b ^ i ≠ 0 := Nat.mul_ne_zero hm (pow_ne_zero _ (by omega))
    calc Nat.log b (m * b ^ (i + 1)) = Nat.log b (m * b ^ i * b) := by
          congr 1
          ring
      _ = Nat.log b (m * b ^ i) + 1 := Nat.log_mul_base hb hmi
      _ = Nat.log b m + i + 1 := by rw [ih]
      _ = Nat.log b m + (i + 1) := by omega

theorem log_left_smooth {p q : ℕ} (hp : 1 < p) (hq : 1 < q) (i j : ℕ) :
    Nat.log p (p ^ i * q ^ j) = i + Nat.log p (q ^ j) := by
  have h : p ^ i * q ^ j = q ^ j * p ^ i := by ring
  rw [h, log_mul_pow hp (pow_ne_zero _ (by omega : q ≠ 0)) i]
  omega

theorem log_right_smooth {p q : ℕ} (hp : 1 < p) (hq : 1 < q) (i j : ℕ) :
    Nat.log q (p ^ i * q ^ j) = Nat.log q (p ^ i) + j :=
  log_mul_pow hq (pow_ne_zero _ (by omega : p ≠ 0)) j
end
end ErdosProblems.Erdos269.PaperCompleteR21

open Polynomial
open scoped BigOperators
open ErdosProblems in
open ErdosProblems.Erdos269 in
open ErdosProblems.Erdos269.PaperCompleteR21 in
theorem solution {p q : ℕ} (hp : 1 < p) (hq : 1 < q) (i j : ℕ) :
    twoPrimeHeight p q (p ^ i * q ^ j)
      = (p ^ i * q ^ qExp p q i) * (p ^ pExp p q j * q ^ j) := by
  simp only [twoPrimeHeight, qExp, pExp, log_left_smooth hp hq, log_right_smooth hp hq,
    pow_add]
  ring
