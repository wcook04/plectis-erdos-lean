import Definitions.Def_ErdosProblems_Erdos269_PaperR7FiniteCutRank
import Theorems.Thm_ErdosProblems_Erdos269_PaperR7_finrank_cutSpan
import Mathlib.Data.Fintype.BigOperators
import Mathlib.LinearAlgebra.Dimension.Constructions
import Mathlib.LinearAlgebra.LinearIndependent.Basic
import Mathlib.LinearAlgebra.Matrix.Rank
import Mathlib.Tactic

/-!
# Paper-complete campaign, round 7: the complete finite cut-rank formula

Target: short-note `res:finite-cut-rank`.  This file generalises the supplied
rational interval-difference engine to an arbitrary field, proves independence
except for the two extreme columns, removes exactly that redundancy, and states
the result using `Matrix.rank`. Repetitions and permutations of columns are
handled by a column-range equality, not an extra independence assumption.

Authored against Lean 4.29.1 and the packet's Mathlib pin.
No admitted statements or additional axioms are introduced.
-/

namespace ErdosProblems.Erdos269.PaperR7
open scoped BigOperators
open Module Submodule

variable {F : Type*} [Field F]
end ErdosProblems.Erdos269.PaperR7

open scoped BigOperators
open Module Submodule
variable {F : Type*} [Field F]
open ErdosProblems in
open ErdosProblems.Erdos269 in
open ErdosProblems.Erdos269.PaperR7 in
theorem solution {ι : Type*} [Fintype ι]
    (c : F) (hc0 : c ≠ 0) (hc1 : c ≠ 1) {m : ℕ} (hm : 0 < m)
    (E : Finset ℕ) (hbound : ∀ k ∈ E, k ≤ m)
    (A : Matrix (Fin m) ι F)
    (hcols : Set.range A.col = Set.range (fun k : E => cutVector c m k)) :
    A.rank = E.card - if 0 ∈ E ∧ m ∈ E then 1 else 0 := by
  rw [Matrix.rank_eq_finrank_span_cols, hcols]
  exact finrank_cutSpan c hc0 hc1 hm E hbound
