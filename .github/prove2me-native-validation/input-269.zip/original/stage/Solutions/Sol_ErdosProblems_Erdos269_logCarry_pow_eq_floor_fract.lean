import Definitions.Def_ErdosProblems_Erdos269_ThreePrimeRunningLcm
import Definitions.Def_ErdosProblems_Shared_IrrationalRotationStaircase
import Definitions.Def_ErdosProblems_Erdos269_KernelCarryRank
import Mathlib.Algebra.BigOperators.Group.Finset.Basic
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Algebra.Order.Floor.Ring
import Mathlib.Algebra.Order.Floor.Semiring
import Mathlib.Algebra.Ring.Parity
import Mathlib.Analysis.SpecialFunctions.Log.Base
import Mathlib.Data.Finset.Card
import Mathlib.Data.Finset.Prod
import Mathlib.Data.Fintype.Pigeonhole
import Mathlib.Data.Nat.Log
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.Nat.Prime.Int
import Mathlib.Data.Real.Archimedean
import Mathlib.LinearAlgebra.Matrix.Block
import Mathlib.LinearAlgebra.Matrix.Determinant.Basic
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Ring

namespace ErdosProblems.Erdos269
open ErdosProblems.Shared
/-- `Nat.log` is superadditive across a product. -/
theorem add_log_le_log_mul {b : ℕ} (hb : 1 < b) {x y : ℕ} (hx : x ≠ 0) (hy : y ≠ 0) :
    Nat.log b x + Nat.log b y ≤ Nat.log b (x * y) := by
  apply Nat.le_log_of_pow_le hb
  rw [pow_add]
  exact Nat.mul_le_mul (Nat.pow_log_le_self b hx) (Nat.pow_log_le_self b hy)
/-- The exact carry decomposition of `Nat.log` across a product. -/
theorem log_mul_eq_add_log_add_logCarry {b : ℕ} (hb : 1 < b) {x y : ℕ}
    (hx : x ≠ 0) (hy : y ≠ 0) :
    Nat.log b (x * y) = Nat.log b x + Nat.log b y + logCarry b x y := by
  have h1 := add_log_le_log_mul hb hx hy
  unfold logCarry
  omega
/-- `Nat.log` of a pure power, read as a floor of a real logarithm. -/
private theorem natLog_pow_eq_floor {b x : ℕ} (hb : 1 < b) (hx : 0 < x) (i : ℕ) :
    Nat.log b (x ^ i) = ⌊(i : ℝ) * Real.logb b x⌋₊ := by
  have hxR : (0 : ℝ) < (x : ℝ) := by exact_mod_cast hx
  have hcast : (((x ^ i : ℕ)) : ℝ) = (x : ℝ) ^ i := by push_cast; ring
  rw [← Real.natFloor_logb_natCast b (x ^ i), hcast, Real.logb_pow]
end ErdosProblems.Erdos269

open ErdosProblems
open ErdosProblems.Erdos269
open ErdosProblems.Shared
open ErdosProblems in
open ErdosProblems.Erdos269 in
theorem solution {p q b : ℕ} (hb : 1 < b) (hp : 0 < p) (hq : 0 < q)
    (i j : ℕ) :
    (logCarry b (p ^ i) (q ^ j) : ℤ)
      = ⌊Int.fract ((i : ℝ) * Real.logb b p) + Int.fract ((j : ℝ) * Real.logb b q)⌋ := by
  have hpR : (0 : ℝ) < (p : ℝ) := by exact_mod_cast hp
  have hqR : (0 : ℝ) < (q : ℝ) := by exact_mod_cast hq
  set x : ℝ := (i : ℝ) * Real.logb b p with hx
  set y : ℝ := (j : ℝ) * Real.logb b q with hy
  have hpi : (p ^ i : ℕ) ≠ 0 := pow_ne_zero _ hp.ne'
  have hqj : (q ^ j : ℕ) ≠ 0 := pow_ne_zero _ hq.ne'
  have hbR : (1 : ℝ) < (b : ℝ) := by exact_mod_cast hb
  have hp1R : (1 : ℝ) ≤ (p : ℝ) := by
    have h1 : 1 ≤ p := hp
    exact_mod_cast h1
  have hq1R : (1 : ℝ) ≤ (q : ℝ) := by
    have h1 : 1 ≤ q := hq
    exact_mod_cast h1
  have hx0 : (0 : ℝ) ≤ x := by
    rw [hx]
    exact mul_nonneg (Nat.cast_nonneg i) (Real.logb_nonneg hbR hp1R)
  have hy0 : (0 : ℝ) ≤ y := by
    rw [hy]
    exact mul_nonneg (Nat.cast_nonneg j) (Real.logb_nonneg hbR hq1R)
  -- the three `Nat.log` values as floors
  have hLp : Nat.log b (p ^ i) = ⌊x⌋₊ := natLog_pow_eq_floor hb hp i
  have hLq : Nat.log b (q ^ j) = ⌊y⌋₊ := natLog_pow_eq_floor hb hq j
  have hprodR : (((p ^ i * q ^ j : ℕ)) : ℝ) = (p : ℝ) ^ i * (q : ℝ) ^ j := by push_cast; ring
  have hLpq : Nat.log b (p ^ i * q ^ j) = ⌊x + y⌋₊ := by
    rw [← Real.natFloor_logb_natCast b (p ^ i * q ^ j), hprodR,
      Real.logb_mul (by positivity) (by positivity), Real.logb_pow, Real.logb_pow]
  -- the exact `ℤ`-floor split
  have hsplit : ⌊x + y⌋ = ⌊x⌋ + ⌊y⌋ + ⌊Int.fract x + Int.fract y⌋ := by
    have hxy : x + y = ((⌊x⌋ + ⌊y⌋ : ℤ) : ℝ) + (Int.fract x + Int.fract y) := by
      have hx' := Int.floor_add_fract x
      have hy' := Int.floor_add_fract y
      push_cast
      linarith
    rw [hxy, Int.floor_intCast_add]
  have hsuper := add_log_le_log_mul hb hpi hqj
  have hcarry := log_mul_eq_add_log_add_logCarry hb hpi hqj
  have hzx : ((⌊x⌋₊ : ℕ) : ℤ) = ⌊x⌋ := Int.natCast_floor_eq_floor hx0
  have hzy : ((⌊y⌋₊ : ℕ) : ℤ) = ⌊y⌋ := Int.natCast_floor_eq_floor hy0
  have hzxy : ((⌊x + y⌋₊ : ℕ) : ℤ) = ⌊x + y⌋ :=
    Int.natCast_floor_eq_floor (by linarith)
  have hZ : ((Nat.log b (p ^ i * q ^ j) : ℕ) : ℤ)
      = ((Nat.log b (p ^ i) : ℕ) : ℤ) + ((Nat.log b (q ^ j) : ℕ) : ℤ)
        + (logCarry b (p ^ i) (q ^ j) : ℤ) := by
    rw [hcarry]; push_cast; ring
  rw [hLp, hLq, hLpq] at hZ
  rw [hzx, hzy, hzxy, hsplit] at hZ
  omega
