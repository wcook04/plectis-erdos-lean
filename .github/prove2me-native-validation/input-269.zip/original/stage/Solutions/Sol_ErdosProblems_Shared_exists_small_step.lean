import Definitions.Def_ErdosProblems_Shared_IrrationalRotationStaircase
import Mathlib.Algebra.Order.Floor.Ring
import Mathlib.Algebra.Order.Floor.Semiring
import Mathlib.Analysis.SpecialFunctions.Log.Base
import Mathlib.Data.Fintype.Pigeonhole
import Mathlib.Data.Real.Archimedean
import Mathlib.LinearAlgebra.Matrix.Block
import Mathlib.LinearAlgebra.Matrix.Determinant.Basic
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Ring

/-!
# Irrational-rotation staircases and the carry-staircase determinant

Two independent pieces of reusable machinery.

* `ErdosProblems.Shared.exists_pos_nat_fract_mem_Ioo` : the **forward** orbit
  `n ↦ Int.fract (n * α)`, `n ≥ 1`, is dense in `[0,1]` as soon as no positive
  integer multiple of `α` is an integer.  The hypothesis is packaged as
  `NoIntegerOrbit`; for real `α` it is exactly irrationality, but it is often
  cheaper to verify directly.

* `ErdosProblems.Shared.det_carryStaircase` : the exact determinant
  `det (fun i j => if j ≤ i then t else 1) = t * (t - 1) ^ n`
  of the `(n+1)`-dimensional *carry staircase*.

Combined in `exists_staircase_indices`, they say that a pair of independent
rotations without integer returns realises an arbitrarily large staircase in
the two-dimensional carry `⌊fract (i * α) + fract (j * β)⌋`.  That is the
engine behind the three-prime running-LCM rank phase transition of Erdős #269.

Nothing here mentions a specific Erdős problem; the file is Mathlib-only.
-/

namespace ErdosProblems.Shared
open Set Matrix

/-! ## Forward orbits of a rotation without integer returns -/





/-- From two orbit points landing in the same `ε`-bin, extract a positive
index whose orbit point is within `ε` of `0` or of `1`. -/
private theorem step_of_close {α : ℝ} {ε : ℝ} {a b : ℕ}
    (hab : a < b) (hε1 : ε ≤ 1)
    (h : |Int.fract ((b : ℝ) * α) - Int.fract ((a : ℝ) * α)| < ε) :
    ∃ k : ℕ, 0 < k ∧
      (Int.fract ((k : ℝ) * α) < ε ∨ 1 - ε < Int.fract ((k : ℝ) * α)) := by
  refine ⟨b - a, by omega, ?_⟩
  set s : ℝ := Int.fract ((b : ℝ) * α) - Int.fract ((a : ℝ) * α) with hs
  have habs := abs_lt.1 h
  have hcast : ((b - a : ℕ) : ℝ) = (b : ℝ) - (a : ℝ) := by
    rw [Nat.cast_sub hab.le]
  have hfr : Int.fract (((b - a : ℕ) : ℝ) * α) = Int.fract s := by
    refine Int.fract_eq_fract.2 ⟨⌊(b : ℝ) * α⌋ - ⌊(a : ℝ) * α⌋, ?_⟩
    rw [hcast, hs, Int.fract, Int.fract]
    push_cast
    ring
  rcases le_or_gt 0 s with hs0 | hs0
  · left
    have hs1 : s < 1 := lt_of_lt_of_le habs.2 hε1
    rw [hfr, Int.fract_eq_self.2 ⟨hs0, hs1⟩]
    exact habs.2
  · right
    have hlow : (0 : ℝ) ≤ s + 1 := by linarith [habs.1, hε1]
    have hhigh : s + 1 < 1 := by linarith
    have hshift : Int.fract s = s + 1 := by
      have hrw : Int.fract s = Int.fract (s + 1) :=
        Int.fract_eq_fract.2 ⟨-1, by push_cast; ring⟩
      rw [hrw, Int.fract_eq_self.2 ⟨hlow, hhigh⟩]
    rw [hfr, hshift]
    linarith [habs.1]
end ErdosProblems.Shared

open Set Matrix
open ErdosProblems in
open ErdosProblems.Shared in
theorem solution {α : ℝ} {ε : ℝ} (hε : 0 < ε) (hε1 : ε ≤ 1) :
    ∃ k : ℕ, 0 < k ∧
      (Int.fract ((k : ℝ) * α) < ε ∨ 1 - ε < Int.fract ((k : ℝ) * α)) := by
  obtain ⟨N, hN⟩ := exists_nat_gt (1 / ε)
  have hNR : (0 : ℝ) < (N : ℝ) := lt_of_le_of_lt (by positivity) hN
  have hNpos : 0 < N := by exact_mod_cast hNR
  have hinv : 1 / (N : ℝ) < ε := by
    rw [div_lt_iff₀ hNR]
    rw [div_lt_iff₀ hε] at hN
    linarith
  have hbin : ∀ i : Fin (N + 1),
      ⌊(N : ℝ) * Int.fract (((i : ℕ) : ℝ) * α)⌋₊ < N := by
    intro i
    have h0 : (0 : ℝ) ≤ (N : ℝ) * Int.fract (((i : ℕ) : ℝ) * α) :=
      mul_nonneg hNR.le (Int.fract_nonneg _)
    have h1 : (N : ℝ) * Int.fract (((i : ℕ) : ℝ) * α) < (N : ℝ) := by
      nlinarith [Int.fract_lt_one (((i : ℕ) : ℝ) * α)]
    exact (Nat.floor_lt h0).2 (by exact_mod_cast h1)
  set f : Fin (N + 1) → Fin N := fun i =>
    ⟨⌊(N : ℝ) * Int.fract (((i : ℕ) : ℝ) * α)⌋₊, hbin i⟩ with hf
  have hcard : Fintype.card (Fin N) < Fintype.card (Fin (N + 1)) := by simp
  obtain ⟨i, j, hij, hfij⟩ := Fintype.exists_ne_map_eq_of_card_lt f hcard
  have hbins : ⌊(N : ℝ) * Int.fract (((i : ℕ) : ℝ) * α)⌋₊
      = ⌊(N : ℝ) * Int.fract (((j : ℕ) : ℝ) * α)⌋₊ := by
    simpa [hf] using congrArg Fin.val hfij
  have habs : |Int.fract (((j : ℕ) : ℝ) * α) - Int.fract (((i : ℕ) : ℝ) * α)| < ε := by
    set u := Int.fract (((i : ℕ) : ℝ) * α) with hu
    set v := Int.fract (((j : ℕ) : ℝ) * α) with hv
    have hu0 : (0 : ℝ) ≤ (N : ℝ) * u := mul_nonneg hNR.le (Int.fract_nonneg _)
    have hv0 : (0 : ℝ) ≤ (N : ℝ) * v := mul_nonneg hNR.le (Int.fract_nonneg _)
    have hul := Nat.floor_le hu0
    have huu := Nat.lt_floor_add_one ((N : ℝ) * u)
    have hvl := Nat.floor_le hv0
    have hvu := Nat.lt_floor_add_one ((N : ℝ) * v)
    rw [hbins] at hul huu
    have hup : v - u < 1 / (N : ℝ) := by
      rw [lt_div_iff₀ hNR]; linarith
    have hdn : u - v < 1 / (N : ℝ) := by
      rw [lt_div_iff₀ hNR]; linarith
    rw [abs_lt]
    exact ⟨by linarith, by linarith⟩
  have hne : (i : ℕ) ≠ (j : ℕ) := fun hval => hij (Fin.val_injective hval)
  rcases Nat.lt_or_ge (i : ℕ) (j : ℕ) with hlt | hge
  · exact step_of_close hlt hε1 habs
  · refine step_of_close (a := (j : ℕ)) (b := (i : ℕ)) (by omega) hε1 ?_
    rw [abs_sub_comm]
    exact habs
