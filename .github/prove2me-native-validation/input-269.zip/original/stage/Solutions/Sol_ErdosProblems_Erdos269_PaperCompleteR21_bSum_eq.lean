import Definitions.Def_ErdosProblems_Erdos269_ThreePrimeRunningLcm
import Definitions.Def_ErdosProblems_Shared_IrrationalRotationStaircase
import Definitions.Def_ErdosProblems_Erdos269_KernelCarryRank
import Definitions.Def_ErdosProblems_Erdos269_PaperR7AnalyticInterfaces
import Definitions.Def_ErdosProblems_Erdos269_PaperCompleteR21_TwoPrimeSums
import Theorems.Thm_ErdosProblems_Erdos269_PaperCompleteR21_pExp_qExp_succ
import Theorems.Thm_ErdosProblems_Erdos269_PaperCompleteR21_qExp_pExp_succ
import Mathlib.Algebra.BigOperators.Group.Finset.Basic
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Algebra.Order.Floor.Ring
import Mathlib.Algebra.Order.Floor.Semiring
import Mathlib.Algebra.Ring.Parity
import Mathlib.Analysis.Normed.Ring.InfiniteSum
import Mathlib.Analysis.SpecialFunctions.Log.Base
import Mathlib.Analysis.SpecialFunctions.Pow.Real
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.Data.Finset.Card
import Mathlib.Data.Finset.Prod
import Mathlib.Data.Fintype.Pigeonhole
import Mathlib.Data.Nat.Log
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.Nat.Prime.Int
import Mathlib.Data.Real.Archimedean
import Mathlib.LinearAlgebra.Matrix.Block
import Mathlib.LinearAlgebra.Matrix.Determinant.Basic
import Mathlib.NumberTheory.Real.Irrational
import Mathlib.RingTheory.Algebraic.Basic
import Mathlib.Tactic
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Ring

/-!
# Erdős #269: both two-prime running-LCM sums

This file transcribes the two-prime objects of the short paper's
`res:two-prime-transcendence` and of the long paper's `long269:res:lead-two-prime`
and proves everything those statements assert except one external value theorem.

* `runningLcm p q x` is the literal least common multiple of the `{p,q}`-smooth
  numbers not exceeding `x`; `runningLcm_eq_twoPrimeHeight` identifies it with the
  product of the two maximal pure prime powers.
* `repeatedSum p q` is `R_{p,q}`: the reciprocal running LCM summed at every
  positive `{p,q}`-smooth integer.  `distinctSum p q` is `D_{p,q}`: each distinct
  running LCM counted once.
* `two_prime_affine_and_quadratic` proves the paper's displayed identities
  `eq:two-prime-affine`, with `A` the paper's boundary value
  `ErdosProblems.Erdos269.PaperR7.twoPrimeHeckeValue`.
* `two_prime_sums_transcendental` and `two_prime_transcendence` conclude that both
  values are transcendental.

The only undischarged input is `BugeaudLaurentTranscendence`, the theorem of
Bugeaud and Laurent (Theorem 1.1) in the case `ρ = 0` due to Loxton and van der
Poorten (Theorem 8, p. 40), that the Hecke--Mahler series takes transcendental
values.  It is carried as one explicit named hypothesis, stated in the generality
in which the paper cites it; all of its side conditions for the pair `(1/p, 1/q)`,
including irrationality of the slope `θ = log p / log q`, are proved here.
-/

namespace ErdosProblems.Erdos269.PaperCompleteR21
open Polynomial
open scoped BigOperators

noncomputable section

/-! ## The `{p,q}`-smooth numbers and their running least common multiple -/















/-! ## Integer logarithms at smooth points -/











@[simp] theorem qExp_zero (p q : ℕ) : qExp p q 0 = 0 := by simp [qExp]













/-! ## The exact combinatorics of the jump indices -/











/-! ## Unique factorisation of the smooth monoid -/







/-! ## The two sums of the paper -/







/-! ## The two component series -/





theorem aTerm_nonneg (p q n : ℕ) : 0 ≤ aTerm p q n := by
  unfold aTerm
  positivity



@[simp] theorem aTerm_zero (p q : ℕ) : aTerm p q 0 = 1 := by simp [aTerm]







private theorem inv_lt_one_nat {p : ℕ} (hp : 1 < p) : ((p : ℝ))⁻¹ < 1 := by
  have hp0 : (0 : ℝ) < (p : ℝ) := by exact_mod_cast (by omega : 0 < p)
  have hp1 : (1 : ℝ) < (p : ℝ) := by exact_mod_cast hp
  have h : (1 : ℝ) / (p : ℝ) < 1 := by
    rw [div_lt_one hp0]
    exact hp1
  simpa [one_div] using h

private theorem inv_nonneg_nat (p : ℕ) : (0 : ℝ) ≤ ((p : ℝ))⁻¹ := by positivity

theorem summable_aTerm {p q : ℕ} (hp : 1 < p) (hq : 1 < q) : Summable (aTerm p q) := by
  refine Summable.of_nonneg_of_le (fun n => aTerm_nonneg p q n) (fun n => ?_)
    (summable_geometric_of_lt_one (inv_nonneg_nat p) (inv_lt_one_nat hp))
  have hle : ((q : ℝ)⁻¹) ^ qExp p q n ≤ 1 :=
    pow_le_one₀ (inv_nonneg_nat q) (le_of_lt (inv_lt_one_nat hq))
  calc aTerm p q n = ((p : ℝ)⁻¹) ^ n * ((q : ℝ)⁻¹) ^ qExp p q n := rfl
    _ ≤ ((p : ℝ)⁻¹) ^ n * 1 := mul_le_mul_of_nonneg_left hle (by positivity)
    _ = ((p : ℝ)⁻¹) ^ n := mul_one _





/-! ## `R = A (1 + B)` -/





/-! ## `D = A + B` -/



















/-! ## The telescoping identity `A - 1 - x A = x (y-1) B / y` -/





theorem summable_sTerm {p q : ℕ} (hp : 1 < p) (hq : 1 < q) : Summable (sTerm p q) := by
  refine Summable.of_nonneg_of_le (fun n => by unfold sTerm; positivity) (fun n => ?_)
    (summable_geometric_of_lt_one (inv_nonneg_nat p) (inv_lt_one_nat hp))
  have hle : ((q : ℝ)⁻¹) ^ qExp p q (n + 1) ≤ 1 :=
    pow_le_one₀ (inv_nonneg_nat q) (le_of_lt (inv_lt_one_nat hq))
  calc sTerm p q n = ((p : ℝ)⁻¹) ^ n * ((q : ℝ)⁻¹) ^ qExp p q (n + 1) := rfl
    _ ≤ ((p : ℝ)⁻¹) ^ n * 1 := mul_le_mul_of_nonneg_left hle (by positivity)
    _ = ((p : ℝ)⁻¹) ^ n := mul_one _

theorem sSum_eq {p q : ℕ} (hp : 1 < p) (hq : 1 < q) :
    (∑' n : ℕ, sTerm p q n) = (p : ℝ) * ((∑' n : ℕ, aTerm p q n) - 1) := by
  have hp0 : ((p : ℝ)) ≠ 0 := by
    have h : (0 : ℝ) < (p : ℝ) := by exact_mod_cast (by omega : 0 < p)
    exact ne_of_gt h
  have hshift : (∑' n : ℕ, aTerm p q (n + 1))
      = ((p : ℝ)⁻¹) * ∑' n : ℕ, sTerm p q n := by
    rw [← tsum_mul_left]
    refine tsum_congr fun n => ?_
    unfold aTerm sTerm
    ring
  have hsplit : (∑' n : ℕ, aTerm p q n)
      = 1 + ((p : ℝ)⁻¹) * ∑' n : ℕ, sTerm p q n := by
    rw [(summable_aTerm hp hq).tsum_eq_zero_add, aTerm_zero, hshift]
  rw [hsplit, add_sub_cancel_left, ← mul_assoc, mul_inv_cancel₀ hp0, one_mul]

theorem dTerm_support {p q : ℕ} (hp : p.Prime) (hq : q.Prime) (hpq : p < q) :
    Function.support (dTerm p q) ⊆ Set.range (fun b : ℕ => pExp p q (b + 1)) := by
  intro n hn
  simp only [Function.mem_support] at hn
  have hjump : qExp p q (n + 1) ≠ qExp p q n := by
    intro heq
    apply hn
    unfold dTerm aTerm sTerm
    rw [heq]
    ring
  exact ⟨qExp p q n, pExp_qExp_succ hp hq hpq hjump⟩

theorem dSum_eq {p q : ℕ} (hp : p.Prime) (hq : q.Prime) (hpq : p < q) :
    (∑' n : ℕ, dTerm p q n) = ((q : ℝ) - 1) * ∑' b : ℕ, cTerm p q (b + 1) := by
  have hp1 : 1 < p := hp.one_lt
  have hq1 : 1 < q := hq.one_lt
  have hq0 : ((q : ℝ)) ≠ 0 := by
    have h : (0 : ℝ) < (q : ℝ) := by exact_mod_cast (by omega : 0 < q)
    exact ne_of_gt h
  have hginj : Function.Injective (fun b : ℕ => pExp p q (b + 1)) := by
    intro a b hab
    have ha := (qExp_pExp_succ hp hq hpq a).1
    have hb := (qExp_pExp_succ hp hq hpq b).1
    simp only at hab
    rw [hab] at ha
    omega
  have hreindex := hginj.tsum_eq (f := dTerm p q) (dTerm_support hp hq hpq)
  rw [← hreindex, ← tsum_mul_left]
  refine tsum_congr fun b => ?_
  have h1 := (qExp_pExp_succ hp hq hpq b).1
  have h2 := (qExp_pExp_succ hp hq hpq b).2
  show dTerm p q (pExp p q (b + 1)) = ((q : ℝ) - 1) * cTerm p q (b + 1)
  unfold dTerm aTerm sTerm cTerm
  rw [h1, h2, pow_succ]
  generalize ((q : ℝ))⁻¹ ^ b = Y
  generalize ((p : ℝ))⁻¹ ^ pExp p q (b + 1) = X
  field_simp
end
end ErdosProblems.Erdos269.PaperCompleteR21

open Polynomial
open scoped BigOperators
open ErdosProblems in
open ErdosProblems.Erdos269 in
open ErdosProblems.Erdos269.PaperCompleteR21 in
theorem solution {p q : ℕ} (hp : p.Prime) (hq : q.Prime) (hpq : p < q) :
    (∑' b : ℕ, cTerm p q (b + 1))
      = ((p : ℝ) - ((p : ℝ) - 1) * (∑' n : ℕ, aTerm p q n)) / ((q : ℝ) - 1) := by
  have hp1 : 1 < p := hp.one_lt
  have hq1 : 1 < q := hq.one_lt
  have hqR : (1 : ℝ) < (q : ℝ) := by exact_mod_cast hq1
  have hq1' : ((q : ℝ) - 1) ≠ 0 := by linarith
  have hsub : (∑' n : ℕ, dTerm p q n)
      = (∑' n : ℕ, aTerm p q n) - ∑' n : ℕ, sTerm p q n := by
    have h := (summable_aTerm hp1 hq1).tsum_sub (summable_sTerm hp1 hq1)
    simpa [dTerm] using h
  have hd := dSum_eq hp hq hpq
  rw [hsub, sSum_eq hp1 hq1] at hd
  field_simp
  linarith
