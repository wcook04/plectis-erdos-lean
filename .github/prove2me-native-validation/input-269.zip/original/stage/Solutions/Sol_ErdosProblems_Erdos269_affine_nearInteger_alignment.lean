import Definitions.Def_ErdosProblems_Erdos269_BoundedRadixTailEscape
import Mathlib.Tactic

/-!
# Erdős #269: bounded-radix tail escape

Consider an affine orbit
`x (n + 1) = P n * x n - c n` with integral `c n` and radices
`2 ≤ P n ≤ 30`.  If the orbit is eventually always within `1/31` of an
integer, the corresponding errors grow by at least a factor of two at every
step; hence one of the states is itself integral.  Otherwise the orbit is at
least `1/31` from every integer at arbitrarily late indices.

The integral state in the first alternative need not be zero.  The theorem
also makes no assertion that the separated indices are eventually all
indices, have positive density, or have unbounded distance from the integers.
-/

open ErdosProblems in
open ErdosProblems.Erdos269 in
theorem solution
    {P : ℕ} {x y : ℝ} {c m n : ℤ}
    (hP : P ≤ 30)
    (hrec : y = (P : ℝ) * x - (c : ℝ))
    (hx : |x - (m : ℝ)| < (1 : ℝ) / 31)
    (hy : |y - (n : ℝ)| < (1 : ℝ) / 31) :
    n = (P : ℤ) * m - c := by
  let k : ℤ := (P : ℤ) * m - c - n
  have hk_cast :
      (k : ℝ) = (y - (n : ℝ)) - (P : ℝ) * (x - (m : ℝ)) := by
    dsimp [k]
    rw [hrec]
    push_cast
    ring
  have hmul :
      |(P : ℝ) * (x - (m : ℝ))| ≤
        (P : ℝ) * ((1 : ℝ) / 31) := by
    rw [abs_mul, abs_of_nonneg (Nat.cast_nonneg P)]
    exact mul_le_mul_of_nonneg_left (le_of_lt hx) (Nat.cast_nonneg P)
  have hk_lt : |(k : ℝ)| < 1 := by
    rw [hk_cast]
    calc
      |(y - (n : ℝ)) - (P : ℝ) * (x - (m : ℝ))| ≤
          |y - (n : ℝ)| + |(P : ℝ) * (x - (m : ℝ))| :=
        abs_sub _ _
      _ < (1 : ℝ) / 31 + (P : ℝ) * ((1 : ℝ) / 31) :=
        add_lt_add_of_lt_of_le hy hmul
      _ ≤ 1 := by
        have hP' : (P : ℝ) ≤ 30 := by exact_mod_cast hP
        have hadd : (P : ℝ) + 1 ≤ 30 + 1 := by linarith
        calc
          (1 : ℝ) / 31 + (P : ℝ) * ((1 : ℝ) / 31) =
              ((P : ℝ) + 1) / 31 := by ring
          _ ≤ (30 + 1 : ℝ) / 31 :=
            div_le_div_of_nonneg_right hadd (by norm_num)
          _ = 1 := by norm_num
  have hk_zero : k = 0 := by
    have hlo : (-1 : ℝ) < (k : ℝ) := (abs_lt.mp hk_lt).1
    have hhi : (k : ℝ) < 1 := (abs_lt.mp hk_lt).2
    have hlo' : (-1 : ℤ) < k := by exact_mod_cast hlo
    have hhi' : k < (1 : ℤ) := by exact_mod_cast hhi
    omega
  dsimp [k] at hk_zero
  omega
