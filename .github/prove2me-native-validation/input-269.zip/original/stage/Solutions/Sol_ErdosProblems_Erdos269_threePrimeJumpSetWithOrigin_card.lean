import Definitions.Def_ErdosProblems_Erdos269_ThreePrimeRunningLcm
import Theorems.Thm_ErdosProblems_Erdos269_threePrimePositiveJumpSet_card
import Mathlib.Algebra.BigOperators.Group.Finset.Basic
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Algebra.Ring.Parity
import Mathlib.Data.Finset.Card
import Mathlib.Data.Finset.Prod
import Mathlib.Data.Nat.Log
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.Nat.Prime.Int
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Ring

/-!
# Erdős #269: the three-prime running-LCM coordinate

This module starts the problem-owned formalization of the first unresolved
three-prime case.  It records the exact computational height used by the
running-LCM representation, its cubic majorant, the smallest non-separation
fixture for `{2,3,5}`, the variable-base tail-state update, and the uniform
quadratic bound for actual filtered smooth-number shells.

No declaration here asserts irrationality or transcendence of a three-prime
value.  The missing producer is still an infinite residue-escape or genuinely
higher-dimensional analytic theorem.
-/

namespace ErdosProblems.Erdos269
open scoped BigOperators































/-! ## Finite pure-power jump enumeration -/





/-- The common origin `1` is absent from every positive prime-power channel. -/
theorem one_not_mem_positivePrimePowers
    {p count : ℕ} (hp : p.Prime) :
    1 ∉ positivePrimePowers p count := by
  intro hone
  change 1 ∈ (Finset.range count).image (fun e => p ^ (e + 1)) at hone
  rcases Finset.mem_image.mp hone with ⟨e, _he, hpow⟩
  have hlt : 1 < p ^ (e + 1) := one_lt_pow₀ hp.one_lt (by omega)
  exact (Nat.ne_of_gt hlt) hpow
end ErdosProblems.Erdos269

open scoped BigOperators
open ErdosProblems in
open ErdosProblems.Erdos269 in
theorem solution
    {p q r count : ℕ} (hp : p.Prime) (hq : q.Prime) (hr : r.Prime)
    (hpq : p ≠ q) (hpr : p ≠ r) (hqr : q ≠ r) :
    (threePrimeJumpSetWithOrigin p q r count).card = 3 * count + 1 := by
  have hone : 1 ∉ threePrimePositiveJumpSet p q r count := by
    simp [threePrimePositiveJumpSet,
      one_not_mem_positivePrimePowers hp,
      one_not_mem_positivePrimePowers hq,
      one_not_mem_positivePrimePowers hr]
  rw [threePrimeJumpSetWithOrigin, Finset.card_insert_of_notMem hone,
    threePrimePositiveJumpSet_card hp hq hr hpq hpr hqr]
