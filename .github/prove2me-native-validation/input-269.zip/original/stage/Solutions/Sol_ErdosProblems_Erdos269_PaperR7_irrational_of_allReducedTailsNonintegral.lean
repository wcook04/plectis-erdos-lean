import Definitions.Def_ErdosProblems_Erdos269_BoundedRadixTailEscape
import Definitions.Def_ErdosProblems_Erdos269_ResidueEscape
import Definitions.Def_ErdosProblems_Erdos269_ThreePrimeRunningLcm
import Definitions.Def_ErdosProblems_Erdos269_RestrictedFloorSum
import Definitions.Def_ErdosProblems_Erdos269_DyadicBlockMassIdentity
import Definitions.Def_ErdosProblems_Erdos269_DyadicBlockThresholdPartition
import Definitions.Def_ErdosProblems_Erdos269_DyadicOrderedTailRecurrence
import Definitions.Def_ErdosProblems_Erdos269_DyadicShellSummability
import Definitions.Def_ErdosProblems_Erdos269_IntegralBranchExtinction
import Definitions.Def_ErdosProblems_Erdos269_PaperR7ActualOrbit
import Definitions.Def_ErdosProblems_Erdos269_PaperR7SeriesIdentification
import Definitions.Def_ErdosProblems_Erdos269_RationalLatticeReduction
import Definitions.Def_ErdosProblems_Erdos269_RationalityCarryBridge
import Definitions.Def_ErdosProblems_Erdos269_PaperR7RationalBridge
import Theorems.Thm_ErdosProblems_Erdos269_PaperR7_fixed_split_scaled_state_is_integer
import Theorems.Thm_ErdosProblems_Erdos269_exists_smooth_coprime_split
import Mathlib.Algebra.BigOperators.Group.Finset.Basic
import Mathlib.Algebra.BigOperators.Group.Finset.Sigma
import Mathlib.Algebra.BigOperators.Group.List.Basic
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Algebra.Ring.Parity
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Data.Finset.Card
import Mathlib.Data.Finset.Prod
import Mathlib.Data.Int.ModEq
import Mathlib.Data.Nat.Factorization.Basic
import Mathlib.Data.Nat.Log
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.Nat.Prime.Int
import Mathlib.Tactic
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.InfiniteSum.Real

/-!
# Round 7: the fixed denominator split and the literal original value

The existing bridge existentially chooses a split and a carry. The paper fixes
`D = 2^u 3^v 5^w B`, fixes the onset, and identifies that carry with `B X_a`.
This file proves those equality data rather than citing a nearby existential.
The long-record sharper `Q`-cap remains a separate obligation.

No admissions.
-/

namespace ErdosProblems.Erdos269.PaperR7
open scoped BigOperators
end ErdosProblems.Erdos269.PaperR7

open scoped BigOperators
open ErdosProblems in
open ErdosProblems.Erdos269 in
open ErdosProblems.Erdos269.PaperR7 in
theorem solution (h : AllReducedTailsNonintegral) :
    Irrational paperSeries235 := by
  have hposden : ∀ N : ℤ, ∀ D : ℕ, 0 < D →
      paperSeries235 ≠ (N : ℝ) / (D : ℝ) := by
    intro N D hD hv
    obtain ⟨u, v, w, B, hsplit, hB, hcop⟩ := exists_smooth_coprime_split D hD
    obtain ⟨z, hz⟩ := fixed_split_scaled_state_is_integer hB hsplit hv
      (a := u + 1 + 2 * v + 3 * w) (le_refl _)
    exact h B hB hcop _ (by omega) z hz
  rw [irrational_iff_ne_rational]
  intro a b hb
  rcases lt_or_gt_of_ne hb with hbneg | hbpos
  · have hbn : 0 < (-b).toNat := by omega
    have hcast : (((-b).toNat : ℕ) : ℤ) = -b := Int.toNat_of_nonneg (by omega)
    intro hv
    apply hposden (-a) (-b).toNat hbn
    rw [hv]
    have hR : (((-b).toNat : ℕ) : ℝ) = -(b : ℝ) := by exact_mod_cast hcast
    rw [hR]
    push_cast
    rw [neg_div_neg_eq]
  · have hbn : 0 < b.toNat := by omega
    have hcast : ((b.toNat : ℕ) : ℤ) = b := Int.toNat_of_nonneg hbpos.le
    intro hv
    apply hposden a b.toNat hbn
    have hR : ((b.toNat : ℕ) : ℝ) = (b : ℝ) := by exact_mod_cast hcast
    simpa [hR] using hv
