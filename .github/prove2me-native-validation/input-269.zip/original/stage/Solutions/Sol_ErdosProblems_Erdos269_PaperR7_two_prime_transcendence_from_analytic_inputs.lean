import Definitions.Def_ErdosProblems_Erdos269_ThreePrimeRunningLcm
import Definitions.Def_ErdosProblems_Shared_IrrationalRotationStaircase
import Definitions.Def_ErdosProblems_Erdos269_KernelCarryRank
import Definitions.Def_ErdosProblems_Erdos269_PaperR7AnalyticInterfaces
import Mathlib.Algebra.BigOperators.Group.Finset.Basic
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Algebra.Order.Floor.Ring
import Mathlib.Algebra.Order.Floor.Semiring
import Mathlib.Algebra.Ring.Parity
import Mathlib.Analysis.SpecialFunctions.Log.Base
import Mathlib.Data.Finset.Card
import Mathlib.Data.Finset.Prod
import Mathlib.Data.Fintype.Pigeonhole
import Mathlib.Data.Nat.Log
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.Nat.Prime.Int
import Mathlib.Data.Real.Archimedean
import Mathlib.LinearAlgebra.Matrix.Block
import Mathlib.LinearAlgebra.Matrix.Determinant.Basic
import Mathlib.RingTheory.Algebraic.Basic
import Mathlib.Tactic
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Ring

/-!
# Round 7: proved algebra around explicitly unresolved analytic inputs

This file DOES NOT prove the two-prime transcendence theorem. Its final algebraic
step is separated from THREE hypotheses still requiring analytic proofs:
transcendence of the specified Hecke--Mahler value, and the two identities for
the actual series. The parameters are visible, not axioms or admitted theorems.

It also proves the constant rank-one upper witness for the uniform carry
approximation. The lower bound over every finite separated rank remains open
as a formalisation obligation in this return.

Validation: authored, not compiled. No admissions.
-/

namespace ErdosProblems.Erdos269.PaperR7
open Polynomial



private theorem transcendental_polynomial_image_of_coeff
    {A : ℝ} (hA : Transcendental ℚ A) (f : ℚ[X])
    (n : ℕ) (hn : 0 < n) (hcoeff : f.coeff n ≠ 0) :
    Transcendental ℚ (Polynomial.aeval A f) := by
  have hf : f ≠ 0 := by
    intro h
    apply hcoeff
    simp [h]
  have hdeg : f.natDegree ≠ 0 := by
    intro h
    apply hcoeff
    exact Polynomial.coeff_eq_zero_of_natDegree_lt (by omega)
  exact hA.aeval f hdeg
    (mem_nonZeroDivisors_of_ne_zero (Polynomial.leadingCoeff_ne_zero.mpr hf))
end ErdosProblems.Erdos269.PaperR7

open Polynomial
open ErdosProblems in
open ErdosProblems.Erdos269 in
open ErdosProblems.Erdos269.PaperR7 in
theorem solution
    (p q : ℚ) (hp : 1 < p) (hq : 1 < q) (hpq : p ≠ q)
    (A D R : ℝ) (hA : Transcendental ℚ A)
    (hD : D = (((q : ℝ) - p) * A + p) / ((q : ℝ) - 1))
    (hR : R = (((p : ℝ) + q - 1) * A - ((p : ℝ) - 1) * A ^ 2) /
      ((q : ℝ) - 1)) :
    Transcendental ℚ D ∧ Transcendental ℚ R := by
  have hp1 : p - 1 ≠ 0 := sub_ne_zero.mpr (ne_of_gt hp)
  have hq1 : q - 1 ≠ 0 := sub_ne_zero.mpr (ne_of_gt hq)
  have hqp : q - p ≠ 0 := sub_ne_zero.mpr hpq.symm
  have hDc : (distinctValuePolynomial p q).coeff 1 ≠ 0 := by
    simpa [distinctValuePolynomial] using div_ne_zero hqp hq1
  have hRc : (repeatedValuePolynomial p q).coeff 2 ≠ 0 := by
    simpa [repeatedValuePolynomial] using neg_ne_zero.mpr (div_ne_zero hp1 hq1)
  have hDt := transcendental_polynomial_image_of_coeff hA
    (distinctValuePolynomial p q) 1 (by norm_num) hDc
  have hRt := transcendental_polynomial_image_of_coeff hA
    (repeatedValuePolynomial p q) 2 (by norm_num) hRc
  have heD : Polynomial.aeval A (distinctValuePolynomial p q) = D := by
    rw [hD]
    simp [distinctValuePolynomial]
    push_cast
    ring
  have heR : Polynomial.aeval A (repeatedValuePolynomial p q) = R := by
    rw [hR]
    simp [repeatedValuePolynomial]
    push_cast
    ring
  exact ⟨heD ▸ hDt, heR ▸ hRt⟩
