import Definitions.Def_ErdosProblems_Erdos269_BoundedRadixTailEscape
import Definitions.Def_ErdosProblems_Erdos269_ResidueEscape
import Definitions.Def_ErdosProblems_Erdos269_ThreePrimeRunningLcm
import Definitions.Def_ErdosProblems_Erdos269_RestrictedFloorSum
import Definitions.Def_ErdosProblems_Erdos269_DyadicBlockMassIdentity
import Definitions.Def_ErdosProblems_Erdos269_DyadicBlockThresholdPartition
import Definitions.Def_ErdosProblems_Erdos269_DyadicOrderedTailRecurrence
import Definitions.Def_ErdosProblems_Erdos269_DyadicShellSummability
import Definitions.Def_ErdosProblems_Erdos269_IntegralBranchExtinction
import Theorems.Thm_ErdosProblems_Erdos269_summable_dyadicShellMassR235
import Theorems.Thm_ErdosProblems_Erdos269_hasSum_succ_sq_mul_geometric
import Theorems.Thm_ErdosProblems_Erdos269_PaperR7_normalised_shell_le_eighth_majorant
import Mathlib.Algebra.BigOperators.Group.Finset.Basic
import Mathlib.Algebra.BigOperators.Group.Finset.Sigma
import Mathlib.Algebra.BigOperators.Group.List.Basic
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Algebra.Ring.Parity
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Data.Finset.Card
import Mathlib.Data.Finset.Prod
import Mathlib.Data.Int.ModEq
import Mathlib.Data.Nat.Log
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.Nat.Prime.Int
import Mathlib.Tactic
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Ring

namespace ErdosProblems.Erdos269.PaperR7
end ErdosProblems.Erdos269.PaperR7

/-!
# Round 7: the literal `8640 / 343` shell bound

Target: the bound in short-note `res:actual-orbit`.  The supplied bound `90`
does not prove this sharper displayed constant.  We retain the actual shell
mass, prove its `8^{-a}` estimate, and sum the resulting majorant exactly.
This is NOT a proof of the separate long-record `Q(n_a)` bound.

No admissions.
-/

namespace ErdosProblems.Erdos269.PaperR7
open scoped BigOperators













/-- Exact value of the geometric moment used on the page. -/
theorem hasSum_succ_square_eighth :
    HasSum (fun n : ℕ => ((n + 1 : ℕ) : ℝ) ^ 2 * (1 / 8 : ℝ) ^ n)
      (576 / 343 : ℝ) := by
  have h := hasSum_succ_sq_mul_geometric (r := (1 / 8 : ℝ)) (by norm_num)
  convert h using 1 <;> norm_num
end ErdosProblems.Erdos269.PaperR7

open scoped BigOperators
open ErdosProblems in
open ErdosProblems.Erdos269 in
open ErdosProblems.Erdos269.PaperR7 in
theorem solution (a : ℕ) :
    trueNormalizedState a ≤ (8640 / 343 : ℝ) * ((a + 1 : ℕ) : ℝ) ^ 2 := by
  have hs : Summable (fun n : ℕ => dyadicShellMassR235 (a + n)) :=
    summable_dyadicShellMassR235.comp_injective fun _ _ h => Nat.add_left_cancel h
  have hl := hs.mul_left ((threePrimeHeight 2 3 5 (2 ^ a) : ℝ) / 2)
  have hr := hasSum_succ_square_eighth.mul_left (15 * ((a + 1 : ℕ) : ℝ) ^ 2)
  have hstate : trueNormalizedState a =
      ∑' n : ℕ, (threePrimeHeight 2 3 5 (2 ^ a) : ℝ) / 2 *
        dyadicShellMassR235 (a + n) := by
    unfold trueNormalizedState dyadicNormalizedTailStateR235 dyadicShellTsumTailR235
    rw [tsum_mul_left]
  rw [hstate]
  calc
    (∑' n : ℕ, (threePrimeHeight 2 3 5 (2 ^ a) : ℝ) / 2 *
      dyadicShellMassR235 (a + n))
      ≤ ∑' n : ℕ, 15 * ((a + 1 : ℕ) : ℝ) ^ 2 *
          (((n + 1 : ℕ) : ℝ) ^ 2 * (1 / 8 : ℝ) ^ n) :=
        hl.tsum_le_tsum (normalised_shell_le_eighth_majorant a) hr.summable
    _ = 15 * ((a + 1 : ℕ) : ℝ) ^ 2 * (576 / 343 : ℝ) := hr.tsum_eq
    _ = (8640 / 343 : ℝ) * ((a + 1 : ℕ) : ℝ) ^ 2 := by ring
