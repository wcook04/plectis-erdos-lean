import Definitions.Def_ErdosProblems_Erdos269_ResidueEscape
import Definitions.Def_ErdosProblems_Erdos269_ThreePrimeRunningLcm
import Definitions.Def_ErdosProblems_Erdos269_RestrictedFloorSum
import Theorems.Thm_ErdosProblems_Erdos269_integralCarry_window
import Theorems.Thm_ErdosProblems_Erdos269_no_bounded_positive_int_state_of_leastPositiveResidue
import Mathlib.Algebra.BigOperators.Group.Finset.Basic
import Mathlib.Algebra.BigOperators.Group.Finset.Sigma
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Algebra.Ring.Parity
import Mathlib.Data.Finset.Card
import Mathlib.Data.Finset.Prod
import Mathlib.Data.Int.ModEq
import Mathlib.Data.Nat.Log
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.Nat.Prime.Int
import Mathlib.Tactic
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Ring

/-!
# Erdős #269: restricted floor sums and local windows

Problem-owned landing surface for the exact true-shell floor sums and the
local-window residue reduction.  No declaration here asserts the open
cofinal anti-concentration theorem.
-/

namespace ErdosProblems.Erdos269
open scoped BigOperators

/-! ## Exact finite strict counts -/

















/-! ## Exact two-dimensional fiber formula -/







































/-! ## Generic logarithmic-window algebra -/



















/-! ## Exact denominator-factor cancellation -/
end ErdosProblems.Erdos269

open scoped BigOperators
open ErdosProblems in
open ErdosProblems.Erdos269 in
theorem solution
    (b m : ℕ → ℕ) (shortBound : ℕ → ℕ → ℕ)
    (hescape : CofinalLocalWindowEscape b m shortBound)
    (B : ℕ) (hBpos : 0 < B) (hBcoprime : Nat.Coprime B 30)
    (d : ℕ → ℤ)
    (hrec : ∀ n,
      d (n + 1) = (b n : ℤ) * d n - (B : ℤ) * (m n : ℤ))
    (hpos : ∀ n, 0 < d n)
    (hbound : ∀ n, Int.natAbs (d n) ≤ shortBound B n) :
    False := by
  rcases hescape B hBpos hBcoprime 0 with
    ⟨lo, len, _hlo, _hlen, hbasePos, hresidueEscape⟩
  let W : ℤ := windowBase (fun n => (b n : ℤ)) lo len
  let F : ℤ := windowForcing
    (fun n => (b n : ℤ)) (fun n => (m n : ℤ)) lo len
  have hwindow :
      d (lo + len) = W * d lo - (B : ℤ) * F := by
    simpa [W, F] using
      integralCarry_window d
        (fun n => (b n : ℤ)) (fun n => (m n : ℤ))
        (B : ℤ) lo len hrec
  have hmodW :
      Int.ModEq W (d (lo + len)) (-((B : ℤ) * F)) := by
    rw [Int.modEq_iff_dvd]
    refine ⟨-d lo, ?_⟩
    rw [hwindow]
    ring
  have hmod :
      Int.ModEq (Int.natAbs W)
        (d (lo + len)) (-((B : ℤ) * F)) :=
    (Int.modEq_natAbs).2 hmodW
  exact no_bounded_positive_int_state_of_leastPositiveResidue
    (by simpa [W] using hbasePos)
    (hpos (lo + len))
    (hbound (lo + len))
    (by simpa [W, F] using hresidueEscape)
    hmod
