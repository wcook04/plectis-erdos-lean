import Definitions.Def_ErdosProblems_Erdos269_BoundedRadixTailEscape
import Definitions.Def_ErdosProblems_Erdos269_ResidueEscape
import Definitions.Def_ErdosProblems_Erdos269_ThreePrimeRunningLcm
import Definitions.Def_ErdosProblems_Erdos269_RestrictedFloorSum
import Definitions.Def_ErdosProblems_Erdos269_DyadicBlockMassIdentity
import Definitions.Def_ErdosProblems_Erdos269_DyadicBlockThresholdPartition
import Definitions.Def_ErdosProblems_Erdos269_DyadicOrderedTailRecurrence
import Definitions.Def_ErdosProblems_Erdos269_DyadicShellSummability
import Definitions.Def_ErdosProblems_Erdos269_IntegralBranchExtinction
import Definitions.Def_ErdosProblems_Erdos269_JumpConstraintMajorant
import Definitions.Def_ErdosProblems_Shared_IrrationalRotationStaircase
import Definitions.Def_ErdosProblems_Erdos269_KernelCarryRank
import Definitions.Def_ErdosProblems_Erdos269_PaperR7ActualOrbit
import Definitions.Def_ErdosProblems_Erdos269_PaperR7SeriesIdentification
import Definitions.Def_ErdosProblems_Erdos269_RationalLatticeReduction
import Definitions.Def_ErdosProblems_Erdos269_RationalityCarryBridge
import Definitions.Def_ErdosProblems_Erdos269_PaperR7RationalBridge
import Definitions.Def_ErdosProblems_Erdos269_PaperR7WindowResults
import Theorems.Thm_ErdosProblems_Erdos269_trueNormalizedState_le_quadratic
import Theorems.Thm_ErdosProblems_Erdos269_trueNormalizedState_pos
import Theorems.Thm_ErdosProblems_Erdos269_PaperR7_actualWindowProduct_pos
import Theorems.Thm_ErdosProblems_Erdos269_PaperR7_actualWindowProduct_geometric_bounds
import Mathlib.Algebra.BigOperators.Group.Finset.Basic
import Mathlib.Algebra.BigOperators.Group.Finset.Sigma
import Mathlib.Algebra.BigOperators.Group.List.Basic
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Algebra.Order.Floor.Ring
import Mathlib.Algebra.Order.Floor.Semiring
import Mathlib.Algebra.Ring.Parity
import Mathlib.Analysis.SpecialFunctions.Log.Base
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Data.Finset.Card
import Mathlib.Data.Finset.Prod
import Mathlib.Data.Fintype.Pigeonhole
import Mathlib.Data.Int.ModEq
import Mathlib.Data.Nat.Factorization.Basic
import Mathlib.Data.Nat.Log
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.Nat.Prime.Int
import Mathlib.Data.Real.Archimedean
import Mathlib.LinearAlgebra.Matrix.Block
import Mathlib.LinearAlgebra.Matrix.Determinant.Basic
import Mathlib.Tactic
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.InfiniteSum.Real

namespace ErdosProblems.Erdos269.PaperR14
end ErdosProblems.Erdos269.PaperR14

namespace PaperR7
end PaperR7

/-!
# The fixed-start residue limit from the long paper

For a fixed multiplier `B` and starting scale `lo`, the paper studies the
least positive residue of the actual window forcing modulo the actual window
product.  This file proves its eventual exact formula and limiting proportion.
The proof includes the delicate integral case: the finite quotients approach
`B X_lo` strictly from below, so their floors stabilise at `ceil (B X_lo) - 1`.
-/

namespace ErdosProblems.Erdos269.PaperR14
open Filter
open scoped Topology
open PaperR7
end ErdosProblems.Erdos269.PaperR14

open Filter
open scoped Topology
open PaperR7
open ErdosProblems in
open ErdosProblems.Erdos269 in
open ErdosProblems.Erdos269.PaperR14 in
open ErdosProblems.Erdos269.PaperR7 in
theorem solution (B lo : ℕ) :
    Tendsto
      (fun h : ℕ =>
        (B : ℝ) * trueNormalizedState (lo + h) /
          (actualWindowProduct lo h : ℝ))
      atTop (nhds 0) := by
  let majorant : ℕ → ℝ := fun h =>
    1350 * B * ((lo + h + 1 : ℕ) : ℝ) ^ 2 / (8 : ℝ) ^ h
  have hbase : Tendsto (fun n : ℕ => (n : ℝ) ^ 2 / (8 : ℝ) ^ n)
      atTop (nhds 0) :=
    tendsto_pow_const_div_const_pow_of_one_lt 2 (by norm_num)
  have hshift := hbase.comp (tendsto_add_atTop_nat (lo + 1))
  have hmaj : Tendsto majorant atTop (nhds 0) := by
    have hmul := hshift.const_mul
      (1350 * (B : ℝ) * (8 : ℝ) ^ (lo + 1))
    convert hmul using 1
    · funext h
      dsimp [majorant]
      rw [pow_add]
      push_cast
      field_simp
      ring
    · simp
  refine tendsto_of_tendsto_of_tendsto_of_le_of_le' tendsto_const_nhds hmaj
    (Eventually.of_forall fun h => ?_) (Eventually.of_forall fun h => ?_)
  · exact div_nonneg
      (mul_nonneg (by positivity) (trueNormalizedState_pos _).le)
      (by positivity)
  · have hW := (actualWindowProduct_geometric_bounds lo h).1
    have hWpos : (0 : ℝ) < actualWindowProduct lo h := by
      exact_mod_cast actualWindowProduct_pos lo h
    have hX := trueNormalizedState_le_quadratic (lo + h)
    have hBnonneg : (0 : ℝ) ≤ B := by positivity
    have hXnonneg : (0 : ℝ) ≤ trueNormalizedState (lo + h) :=
      (trueNormalizedState_pos _).le
    dsimp [majorant]
    have hrecip : (actualWindowProduct lo h : ℝ)⁻¹ <
        15 / (8 : ℝ) ^ h := by
      rw [inv_eq_one_div]
      have hp : (0 : ℝ) < (8 : ℝ) ^ h := by positivity
      calc
        1 / (actualWindowProduct lo h : ℝ) <
            1 / ((8 : ℝ) ^ h / 15) :=
          one_div_lt_one_div_of_lt (div_pos hp (by norm_num)) hW
        _ = 15 / (8 : ℝ) ^ h := by field_simp
    calc
      (B : ℝ) * trueNormalizedState (lo + h) /
          (actualWindowProduct lo h : ℝ)
          = (B : ℝ) * trueNormalizedState (lo + h) *
              (actualWindowProduct lo h : ℝ)⁻¹ := by rw [div_eq_mul_inv]
      _ ≤ (B : ℝ) * (90 * ((lo + h + 1 : ℕ) : ℝ) ^ 2) *
              (actualWindowProduct lo h : ℝ)⁻¹ := by
            gcongr
      _ ≤ (B : ℝ) * (90 * ((lo + h + 1 : ℕ) : ℝ) ^ 2) *
              (15 / (8 : ℝ) ^ h) := by
            gcongr
      _ = 1350 * B * ((lo + h + 1 : ℕ) : ℝ) ^ 2 / (8 : ℝ) ^ h := by ring
