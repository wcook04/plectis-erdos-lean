import Definitions.Def_ErdosProblems_Erdos269_ThreePrimeRunningLcm
import Definitions.Def_ErdosProblems_Shared_IrrationalRotationStaircase
import Definitions.Def_ErdosProblems_Erdos269_KernelCarryRank
import Definitions.Def_ErdosProblems_Erdos269_PaperR7AnalyticInterfaces
import Definitions.Def_ErdosProblems_Erdos269_PaperCompleteR21_TwoPrimeSums
import Theorems.Thm_ErdosProblems_Erdos269_PaperCompleteR21_runningLcm_eq_twoPrimeHeight
import Mathlib.Algebra.BigOperators.Group.Finset.Basic
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Algebra.Order.Floor.Ring
import Mathlib.Algebra.Order.Floor.Semiring
import Mathlib.Algebra.Ring.Parity
import Mathlib.Analysis.Normed.Ring.InfiniteSum
import Mathlib.Analysis.SpecialFunctions.Log.Base
import Mathlib.Analysis.SpecialFunctions.Pow.Real
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.Data.Finset.Card
import Mathlib.Data.Finset.Prod
import Mathlib.Data.Fintype.Pigeonhole
import Mathlib.Data.Nat.Log
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.Nat.Prime.Int
import Mathlib.Data.Real.Archimedean
import Mathlib.LinearAlgebra.Matrix.Block
import Mathlib.LinearAlgebra.Matrix.Determinant.Basic
import Mathlib.NumberTheory.Real.Irrational
import Mathlib.RingTheory.Algebraic.Basic
import Mathlib.Tactic
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Ring

/-!
# Erdős #269: both two-prime running-LCM sums

This file transcribes the two-prime objects of the short paper's
`res:two-prime-transcendence` and of the long paper's `long269:res:lead-two-prime`
and proves everything those statements assert except one external value theorem.

* `runningLcm p q x` is the literal least common multiple of the `{p,q}`-smooth
  numbers not exceeding `x`; `runningLcm_eq_twoPrimeHeight` identifies it with the
  product of the two maximal pure prime powers.
* `repeatedSum p q` is `R_{p,q}`: the reciprocal running LCM summed at every
  positive `{p,q}`-smooth integer.  `distinctSum p q` is `D_{p,q}`: each distinct
  running LCM counted once.
* `two_prime_affine_and_quadratic` proves the paper's displayed identities
  `eq:two-prime-affine`, with `A` the paper's boundary value
  `ErdosProblems.Erdos269.PaperR7.twoPrimeHeckeValue`.
* `two_prime_sums_transcendental` and `two_prime_transcendence` conclude that both
  values are transcendental.

The only undischarged input is `BugeaudLaurentTranscendence`, the theorem of
Bugeaud and Laurent (Theorem 1.1) in the case `ρ = 0` due to Loxton and van der
Poorten (Theorem 8, p. 40), that the Hecke--Mahler series takes transcendental
values.  It is carried as one explicit named hypothesis, stated in the generality
in which the paper cites it; all of its side conditions for the pair `(1/p, 1/q)`,
including irrationality of the slope `θ = log p / log q`, are proved here.
-/

namespace ErdosProblems.Erdos269.PaperCompleteR21
open Polynomial
open scoped BigOperators

noncomputable section

/-! ## The `{p,q}`-smooth numbers and their running least common multiple -/















/-! ## Integer logarithms at smooth points -/

























/-! ## The exact combinatorics of the jump indices -/











/-! ## Unique factorisation of the smooth monoid -/







/-! ## The two sums of the paper -/







/-! ## The two component series -/



























/-! ## `R = A (1 + B)` -/





/-! ## `D = A + B` -/
end
end ErdosProblems.Erdos269.PaperCompleteR21

open Polynomial
open scoped BigOperators
open ErdosProblems in
open ErdosProblems.Erdos269 in
open ErdosProblems.Erdos269.PaperCompleteR21 in
theorem solution {p q : ℕ} (hp : p.Prime) (hq : q.Prime) (hpq : p ≠ q) :
    runningLcmValues p q =
      Set.range (jumpLeft p q) ∪ Set.range (jumpRight p q) := by
  have hp1 : 1 < p := hp.one_lt
  have hq1 : 1 < q := hq.one_lt
  ext H
  constructor
  · rintro ⟨n, hn, rfl⟩
    have hnpos : 0 < n := hn.1
    have hne : n ≠ 0 := by omega
    rw [runningLcm_eq_twoPrimeHeight hp hq hpq hne]
    have hpa : p ^ Nat.log p n ≤ n := Nat.pow_log_le_self p hne
    have hqb : q ^ Nat.log q n ≤ n := Nat.pow_log_le_self q hne
    rcases Nat.lt_or_ge (p ^ Nat.log p n) (q ^ Nat.log q n) with hcase | hcase
    · right
      have hbpos : 0 < Nat.log q n := by
        by_contra hb0
        have hb : Nat.log q n = 0 := by omega
        rw [hb, pow_zero] at hcase
        have h1 : (1 : ℕ) ≤ p ^ Nat.log p n :=
          Nat.one_le_iff_ne_zero.mpr (pow_ne_zero _ (by omega))
        omega
      refine ⟨Nat.log q n - 1, ?_⟩
      have hbb : Nat.log q n - 1 + 1 = Nat.log q n := by omega
      have hlog : Nat.log p (q ^ Nat.log q n) = Nat.log p n :=
        le_antisymm (Nat.log_mono_right hqb) (Nat.le_log_of_pow_le hp1 (le_of_lt hcase))
      simp only [jumpRight, hbb, twoPrimeHeight, Nat.log_pow hq1, hlog]
    · left
      refine ⟨Nat.log p n, ?_⟩
      have hlog : Nat.log q (p ^ Nat.log p n) = Nat.log q n :=
        le_antisymm (Nat.log_mono_right hpa) (Nat.le_log_of_pow_le hq1 hcase)
      simp only [jumpLeft, twoPrimeHeight, Nat.log_pow hp1, hlog]
  · rintro (⟨a, rfl⟩ | ⟨b, rfl⟩)
    · exact ⟨p ^ a, ⟨pow_pos (by omega) a, a, 0, by ring⟩,
        runningLcm_eq_twoPrimeHeight hp hq hpq (pow_ne_zero _ (by omega))⟩
    · exact ⟨q ^ (b + 1), ⟨pow_pos (by omega) _, 0, b + 1, by ring⟩,
        runningLcm_eq_twoPrimeHeight hp hq hpq (pow_ne_zero _ (by omega))⟩
