import Definitions.Def_ErdosProblems_Erdos269_ThreePrimeRunningLcm
import Mathlib.Algebra.BigOperators.Group.Finset.Basic
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Algebra.Ring.Parity
import Mathlib.Data.Finset.Card
import Mathlib.Data.Finset.Prod
import Mathlib.Data.Nat.Log
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.Nat.Prime.Int
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Ring

/-!
# Erdős #269: the three-prime running-LCM coordinate

This module starts the problem-owned formalization of the first unresolved
three-prime case.  It records the exact computational height used by the
running-LCM representation, its cubic majorant, the smallest non-separation
fixture for `{2,3,5}`, the variable-base tail-state update, and the uniform
quadratic bound for actual filtered smooth-number shells.

No declaration here asserts irrationality or transcendence of a three-prime
value.  The missing producer is still an infinite residue-escape or genuinely
higher-dimensional analytic theorem.
-/

namespace ErdosProblems.Erdos269
open scoped BigOperators































/-! ## Finite pure-power jump enumeration -/



/-- A prime base has no repeated positive powers. -/
theorem positivePrimePowers_card
    {p count : ℕ} (hp : p.Prime) :
    (positivePrimePowers p count).card = count := by
  calc
    (positivePrimePowers p count).card = (Finset.range count).card := by
      rw [positivePrimePowers, Finset.card_image_iff]
      intro a _ha b _hb hab
      exact Nat.add_right_cancel (Nat.pow_right_injective hp.two_le hab)
    _ = count := Finset.card_range count



/-- Positive power channels of two distinct primes are disjoint. -/
theorem positivePrimePowers_disjoint
    {p q pcount qcount : ℕ} (hp : p.Prime) (hq : q.Prime) (hpq : p ≠ q) :
    Disjoint (positivePrimePowers p pcount) (positivePrimePowers q qcount) := by
  rw [Finset.disjoint_left]
  intro x hpx hqx
  change x ∈ (Finset.range pcount).image (fun e => p ^ (e + 1)) at hpx
  change x ∈ (Finset.range qcount).image (fun e => q ^ (e + 1)) at hqx
  rcases Finset.mem_image.mp hpx with ⟨a, _ha, hpa⟩
  rcases Finset.mem_image.mp hqx with ⟨b, _hb, hqb⟩
  have hpow : p ^ (a + 1) = q ^ (b + 1) := hpa.trans hqb.symm
  exact hpq (hp.pow_inj hq hpow).1
end ErdosProblems.Erdos269

open scoped BigOperators
open ErdosProblems in
open ErdosProblems.Erdos269 in
theorem solution
    {p q r count : ℕ} (hp : p.Prime) (hq : q.Prime) (hr : r.Prime)
    (hpq : p ≠ q) (hpr : p ≠ r) (hqr : q ≠ r) :
    (threePrimePositiveJumpSet p q r count).card = 3 * count := by
  have hpqDisjoint :=
    positivePrimePowers_disjoint (pcount := count) (qcount := count) hp hq hpq
  have hprDisjoint :=
    positivePrimePowers_disjoint (pcount := count) (qcount := count) hp hr hpr
  have hqrDisjoint :=
    positivePrimePowers_disjoint (pcount := count) (qcount := count) hq hr hqr
  have hpqrDisjoint :
      Disjoint
        (positivePrimePowers p count ∪ positivePrimePowers q count)
        (positivePrimePowers r count) :=
    Finset.disjoint_union_left.mpr ⟨hprDisjoint, hqrDisjoint⟩
  rw [threePrimePositiveJumpSet,
    Finset.card_union_of_disjoint hpqrDisjoint,
    Finset.card_union_of_disjoint hpqDisjoint,
    positivePrimePowers_card hp,
    positivePrimePowers_card hq,
    positivePrimePowers_card hr]
  omega
