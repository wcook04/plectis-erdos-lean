import Definitions.Def_ErdosProblems_Erdos269_ThreePrimeRunningLcm
import Definitions.Def_ErdosProblems_Shared_IrrationalRotationStaircase
import Definitions.Def_ErdosProblems_Erdos269_KernelCarryRank
import Definitions.Def_ErdosProblems_Erdos269_PaperR7AnalyticInterfaces
import Definitions.Def_ErdosProblems_Erdos269_PaperCompleteR21_TwoPrimeSums
import Mathlib.Algebra.BigOperators.Group.Finset.Basic
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Algebra.Order.Floor.Ring
import Mathlib.Algebra.Order.Floor.Semiring
import Mathlib.Algebra.Ring.Parity
import Mathlib.Analysis.Normed.Ring.InfiniteSum
import Mathlib.Analysis.SpecialFunctions.Log.Base
import Mathlib.Analysis.SpecialFunctions.Pow.Real
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.Data.Finset.Card
import Mathlib.Data.Finset.Prod
import Mathlib.Data.Fintype.Pigeonhole
import Mathlib.Data.Nat.Log
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.Nat.Prime.Int
import Mathlib.Data.Real.Archimedean
import Mathlib.LinearAlgebra.Matrix.Block
import Mathlib.LinearAlgebra.Matrix.Determinant.Basic
import Mathlib.NumberTheory.Real.Irrational
import Mathlib.RingTheory.Algebraic.Basic
import Mathlib.Tactic
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Ring

/-!
# Erdős #269: both two-prime running-LCM sums

This file transcribes the two-prime objects of the short paper's
`res:two-prime-transcendence` and of the long paper's `long269:res:lead-two-prime`
and proves everything those statements assert except one external value theorem.

* `runningLcm p q x` is the literal least common multiple of the `{p,q}`-smooth
  numbers not exceeding `x`; `runningLcm_eq_twoPrimeHeight` identifies it with the
  product of the two maximal pure prime powers.
* `repeatedSum p q` is `R_{p,q}`: the reciprocal running LCM summed at every
  positive `{p,q}`-smooth integer.  `distinctSum p q` is `D_{p,q}`: each distinct
  running LCM counted once.
* `two_prime_affine_and_quadratic` proves the paper's displayed identities
  `eq:two-prime-affine`, with `A` the paper's boundary value
  `ErdosProblems.Erdos269.PaperR7.twoPrimeHeckeValue`.
* `two_prime_sums_transcendental` and `two_prime_transcendence` conclude that both
  values are transcendental.

The only undischarged input is `BugeaudLaurentTranscendence`, the theorem of
Bugeaud and Laurent (Theorem 1.1) in the case `ρ = 0` due to Loxton and van der
Poorten (Theorem 8, p. 40), that the Hecke--Mahler series takes transcendental
values.  It is carried as one explicit named hypothesis, stated in the generality
in which the paper cites it; all of its side conditions for the pair `(1/p, 1/q)`,
including irrationality of the slope `θ = log p / log q`, are proved here.
-/

namespace ErdosProblems.Erdos269.PaperCompleteR21
open Polynomial
open scoped BigOperators

noncomputable section

/-! ## The `{p,q}`-smooth numbers and their running least common multiple -/















/-! ## Integer logarithms at smooth points -/

























/-! ## The exact combinatorics of the jump indices -/

private theorem mul_lt_mul_nat {a b c d : ℕ} (h1 : a < c) (h2 : b < d) : a * b < c * d := by
  nlinarith

private theorem mul_lt_mul_nat' {a b c d : ℕ} (h1 : a < c) (h2 : b ≤ d) (hb : 0 < b) :
    a * b < c * d := by
  nlinarith

theorem pow_ne_pow_of_ne {p q : ℕ} (hp : p.Prime) (hq : q.Prime) (hpq : p ≠ q) {a b : ℕ}
    (ha : a ≠ 0) (hb : b ≠ 0) : p ^ a ≠ q ^ b := fun h =>
  hpq (Nat.Prime.pow_inj' hp hq ha hb h).1
end
end ErdosProblems.Erdos269.PaperCompleteR21

open Polynomial
open scoped BigOperators
open ErdosProblems in
open ErdosProblems.Erdos269 in
open ErdosProblems.Erdos269.PaperCompleteR21 in
theorem solution {p q : ℕ} (hp : p.Prime) (hq : q.Prime) (hpq : p < q) (b : ℕ) :
    qExp p q (pExp p q (b + 1)) = b ∧ qExp p q (pExp p q (b + 1) + 1) = b + 1 := by
  have hp1 : 1 < p := hp.one_lt
  have hq1 : 1 < q := hq.one_lt
  have hne : p ≠ q := Nat.ne_of_lt hpq
  simp only [qExp, pExp]
  set n := Nat.log p (q ^ (b + 1)) with hn
  have hqpow : q ^ (b + 1) ≠ 0 := pow_ne_zero _ (by omega)
  have hle : p ^ n ≤ q ^ (b + 1) := by
    rw [hn]
    exact Nat.pow_log_le_self p hqpow
  have hlt : q ^ (b + 1) < p ^ (n + 1) := by
    rw [hn]
    exact Nat.lt_pow_succ_log_self hp1 _
  have hppos : 0 < p ^ n := pow_pos (by omega) _
  have hstrict : p ^ n < q ^ (b + 1) := by
    rcases Nat.eq_zero_or_pos n with h0 | hpos
    · rw [h0, pow_zero]
      calc (1 : ℕ) < q := hq1
        _ = q ^ 1 := (pow_one q).symm
        _ ≤ q ^ (b + 1) := Nat.pow_le_pow_right (by omega) (by omega)
    · exact lt_of_le_of_ne hle (pow_ne_pow_of_ne hp hq hne (by omega) (by omega))
  have hlow : q ^ b ≤ p ^ n := by
    by_contra hcon
    push_neg at hcon
    have hkey : p ^ (n + 1) < q ^ (b + 1) := by
      calc p ^ (n + 1) = p * p ^ n := by ring
        _ < q * q ^ b := mul_lt_mul_nat hpq hcon
        _ = q ^ (b + 1) := by ring
    omega
  refine ⟨Nat.log_eq_of_pow_le_of_lt_pow hlow hstrict, ?_⟩
  refine Nat.log_eq_of_pow_le_of_lt_pow (le_of_lt hlt) ?_
  calc p ^ (n + 1) = p * p ^ n := by ring
    _ < q * q ^ (b + 1) := mul_lt_mul_nat' hpq (le_of_lt hstrict) hppos
    _ = q ^ (b + 1 + 1) := by ring
