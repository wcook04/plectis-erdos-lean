import Definitions.Def_ErdosProblems_Erdos269_BoundedRadixTailEscape
import Definitions.Def_ErdosProblems_Erdos269_ResidueEscape
import Definitions.Def_ErdosProblems_Erdos269_ThreePrimeRunningLcm
import Definitions.Def_ErdosProblems_Erdos269_RestrictedFloorSum
import Definitions.Def_ErdosProblems_Erdos269_DyadicBlockMassIdentity
import Definitions.Def_ErdosProblems_Erdos269_DyadicBlockThresholdPartition
import Definitions.Def_ErdosProblems_Erdos269_DyadicOrderedTailRecurrence
import Definitions.Def_ErdosProblems_Erdos269_DyadicShellSummability
import Definitions.Def_ErdosProblems_Erdos269_IntegralBranchExtinction
import Definitions.Def_ErdosProblems_Erdos269_PaperR7ActualOrbit
import Definitions.Def_ErdosProblems_Erdos269_PaperR7SeriesIdentification
import Definitions.Def_ErdosProblems_Erdos269_RationalLatticeReduction
import Definitions.Def_ErdosProblems_Erdos269_RationalityCarryBridge
import Definitions.Def_ErdosProblems_Erdos269_PaperR7RationalBridge
import Definitions.Def_ErdosProblems_Erdos269_PaperExactDenominatorR13
import Theorems.Thm_ErdosProblems_Erdos269_monomial235_dvd
import Theorems.Thm_ErdosProblems_Erdos269_two_mul_heightNormalizer235
import Mathlib.Algebra.BigOperators.Group.Finset.Basic
import Mathlib.Algebra.BigOperators.Group.Finset.Sigma
import Mathlib.Algebra.BigOperators.Group.List.Basic
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Algebra.Ring.Parity
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Data.Finset.Card
import Mathlib.Data.Finset.Prod
import Mathlib.Data.Int.ModEq
import Mathlib.Data.Nat.Factorization.Basic
import Mathlib.Data.Nat.Find
import Mathlib.Data.Nat.Log
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.Nat.Prime.Int
import Mathlib.Data.Rat.Lemmas
import Mathlib.Tactic
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.InfiniteSum.Real

namespace PaperR7
end PaperR7

/-!
# Exact reduced denominators for the paper tail states

This module formalises the exact-denominator calculation in the short and long
papers.  The rational representative below is proved to cast to the literal
real tail state, so its `Rat.den` is the paper's positive reduced denominator.
-/

namespace ErdosProblems.Erdos269.PaperR13
open scoped BigOperators
open PaperR7
end ErdosProblems.Erdos269.PaperR13

open scoped BigOperators
open PaperR7
open ErdosProblems in
open ErdosProblems.Erdos269 in
open ErdosProblems.Erdos269.PaperR13 in
open ErdosProblems.Erdos269.PaperR7 in
theorem solution (a : ℕ) (ha : 1 ≤ a) :
    heightNormalizer235 a ∣ 30 ^ a := by
  have h2 : Nat.log 2 (2 ^ a) = a := Nat.log_pow (by norm_num) a
  have h3 : Nat.log 3 (2 ^ a) ≤ a := by
    have h := Nat.log_mono_right (b := 3)
      (Nat.pow_le_pow_left (by norm_num : 2 ≤ 3) a)
    simpa [Nat.log_pow (by norm_num : 1 < (3 : ℕ))] using h
  have h5 : Nat.log 5 (2 ^ a) ≤ a := by
    have h := Nat.log_mono_right (b := 5)
      (Nat.pow_le_pow_left (by norm_num : 2 ≤ 5) a)
    simpa [Nat.log_pow (by norm_num : 1 < (5 : ℕ))] using h
  have hH : threePrimeHeight 2 3 5 (2 ^ a) ∣ 30 ^ a := by
    unfold threePrimeHeight
    rw [h2]
    have hm := monomial235_dvd (le_refl a) h3 h5
    have h30 : 30 ^ a = 2 ^ a * 3 ^ a * 5 ^ a := by
      rw [show (30 : ℕ) = 2 * 3 * 5 by norm_num, mul_pow, mul_pow]
    rw [h30]
    exact hm
  have hh : heightNormalizer235 a ∣ threePrimeHeight 2 3 5 (2 ^ a) := by
    refine ⟨2, ?_⟩
    simpa [mul_comm] using (two_mul_heightNormalizer235 a ha).symm
  exact hh.trans hH
