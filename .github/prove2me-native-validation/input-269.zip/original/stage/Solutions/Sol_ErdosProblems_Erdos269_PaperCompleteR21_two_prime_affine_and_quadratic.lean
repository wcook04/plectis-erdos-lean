import Definitions.Def_ErdosProblems_Erdos269_ThreePrimeRunningLcm
import Definitions.Def_ErdosProblems_Shared_IrrationalRotationStaircase
import Definitions.Def_ErdosProblems_Erdos269_KernelCarryRank
import Definitions.Def_ErdosProblems_Erdos269_PaperR7AnalyticInterfaces
import Definitions.Def_ErdosProblems_Erdos269_PaperCompleteR21_TwoPrimeSums
import Theorems.Thm_ErdosProblems_Erdos269_PaperCompleteR21_bSum_eq
import Theorems.Thm_ErdosProblems_Erdos269_PaperCompleteR21_distinctSum_eq
import Theorems.Thm_ErdosProblems_Erdos269_PaperCompleteR21_repeatedSum_eq
import Mathlib.Algebra.BigOperators.Group.Finset.Basic
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Algebra.Order.Floor.Ring
import Mathlib.Algebra.Order.Floor.Semiring
import Mathlib.Algebra.Ring.Parity
import Mathlib.Analysis.Normed.Ring.InfiniteSum
import Mathlib.Analysis.SpecialFunctions.Log.Base
import Mathlib.Analysis.SpecialFunctions.Pow.Real
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.Data.Finset.Card
import Mathlib.Data.Finset.Prod
import Mathlib.Data.Fintype.Pigeonhole
import Mathlib.Data.Nat.Log
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.Nat.Prime.Int
import Mathlib.Data.Real.Archimedean
import Mathlib.LinearAlgebra.Matrix.Block
import Mathlib.LinearAlgebra.Matrix.Determinant.Basic
import Mathlib.NumberTheory.Real.Irrational
import Mathlib.RingTheory.Algebraic.Basic
import Mathlib.Tactic
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Ring

/-!
# Erdős #269: both two-prime running-LCM sums

This file transcribes the two-prime objects of the short paper's
`res:two-prime-transcendence` and of the long paper's `long269:res:lead-two-prime`
and proves everything those statements assert except one external value theorem.

* `runningLcm p q x` is the literal least common multiple of the `{p,q}`-smooth
  numbers not exceeding `x`; `runningLcm_eq_twoPrimeHeight` identifies it with the
  product of the two maximal pure prime powers.
* `repeatedSum p q` is `R_{p,q}`: the reciprocal running LCM summed at every
  positive `{p,q}`-smooth integer.  `distinctSum p q` is `D_{p,q}`: each distinct
  running LCM counted once.
* `two_prime_affine_and_quadratic` proves the paper's displayed identities
  `eq:two-prime-affine`, with `A` the paper's boundary value
  `ErdosProblems.Erdos269.PaperR7.twoPrimeHeckeValue`.
* `two_prime_sums_transcendental` and `two_prime_transcendence` conclude that both
  values are transcendental.

The only undischarged input is `BugeaudLaurentTranscendence`, the theorem of
Bugeaud and Laurent (Theorem 1.1) in the case `ρ = 0` due to Loxton and van der
Poorten (Theorem 8, p. 40), that the Hecke--Mahler series takes transcendental
values.  It is carried as one explicit named hypothesis, stated in the generality
in which the paper cites it; all of its side conditions for the pair `(1/p, 1/q)`,
including irrationality of the slope `θ = log p / log q`, are proved here.
-/

namespace ErdosProblems.Erdos269.PaperCompleteR21
open Polynomial
open scoped BigOperators

noncomputable section

/-! ## The `{p,q}`-smooth numbers and their running least common multiple -/















/-! ## Integer logarithms at smooth points -/













@[simp] theorem pExp_zero (p q : ℕ) : pExp p q 0 = 0 := by simp [pExp]











/-! ## The exact combinatorics of the jump indices -/











/-! ## Unique factorisation of the smooth monoid -/







/-! ## The two sums of the paper -/







/-! ## The two component series -/







theorem cTerm_nonneg (p q j : ℕ) : 0 ≤ cTerm p q j := by
  unfold cTerm
  positivity



@[simp] theorem cTerm_zero (p q : ℕ) : cTerm p q 0 = 1 := by simp [cTerm]





private theorem inv_lt_one_nat {p : ℕ} (hp : 1 < p) : ((p : ℝ))⁻¹ < 1 := by
  have hp0 : (0 : ℝ) < (p : ℝ) := by exact_mod_cast (by omega : 0 < p)
  have hp1 : (1 : ℝ) < (p : ℝ) := by exact_mod_cast hp
  have h : (1 : ℝ) / (p : ℝ) < 1 := by
    rw [div_lt_one hp0]
    exact hp1
  simpa [one_div] using h

private theorem inv_nonneg_nat (p : ℕ) : (0 : ℝ) ≤ ((p : ℝ))⁻¹ := by positivity



theorem summable_cTerm {p q : ℕ} (hp : 1 < p) (hq : 1 < q) : Summable (cTerm p q) := by
  refine Summable.of_nonneg_of_le (fun j => cTerm_nonneg p q j) (fun j => ?_)
    (summable_geometric_of_lt_one (inv_nonneg_nat q) (inv_lt_one_nat hq))
  have hle : ((p : ℝ)⁻¹) ^ pExp p q j ≤ 1 :=
    pow_le_one₀ (inv_nonneg_nat p) (le_of_lt (inv_lt_one_nat hp))
  calc cTerm p q j = ((p : ℝ)⁻¹) ^ pExp p q j * ((q : ℝ)⁻¹) ^ j := rfl
    _ ≤ 1 * ((q : ℝ)⁻¹) ^ j := mul_le_mul_of_nonneg_right hle (by positivity)
    _ = ((q : ℝ)⁻¹) ^ j := one_mul _



/-! ## `R = A (1 + B)` -/



theorem cSum_eq_one_add {p q : ℕ} (hp : 1 < p) (hq : 1 < q) :
    (∑' j : ℕ, cTerm p q j) = 1 + ∑' b : ℕ, cTerm p q (b + 1) := by
  rw [(summable_cTerm hp hq).tsum_eq_zero_add, cTerm_zero]

/-! ## `D = A + B` -/



















/-! ## The telescoping identity `A - 1 - x A = x (y-1) B / y` -/















/-! ## The Hecke--Mahler boundary value -/







theorem qExp_eq_floor {p q : ℕ} (hp : 1 < p) (hq : 1 < q) (n : ℕ) :
    qExp p q n = ⌊(n : ℝ) * Real.logb q p⌋₊ := by
  rw [qExp, ← Real.natFloor_logb_natCast q (p ^ n)]
  congr 1
  rw [Nat.cast_pow, Real.logb_pow]

/-- The paper's `A`: the series over the pure powers of `p` is the boundary value
already recorded in the tree. -/
theorem aSum_eq_heckeValue {p q : ℕ} (hp : 1 < p) (hq : 1 < q) :
    (∑' n : ℕ, aTerm p q n) = PaperR7.twoPrimeHeckeValue p q := by
  refine tsum_congr fun n => ?_
  simp only [aTerm]
  rw [qExp_eq_floor hp hq]



/-! ## Irrationality of the slope -/



/-! ## Transcendence -/







/-! ## The paper's theorems -/
end
end ErdosProblems.Erdos269.PaperCompleteR21

open Polynomial
open scoped BigOperators
open ErdosProblems in
open ErdosProblems.Erdos269 in
open ErdosProblems.Erdos269.PaperCompleteR21 in
theorem solution {p q : ℕ}
    (hp : p.Prime) (hq : q.Prime) (hpq : p < q) :
    distinctSum p q
        = (((q : ℝ) - (p : ℝ)) * PaperR7.twoPrimeHeckeValue p q + (p : ℝ))
          / ((q : ℝ) - 1) ∧
      repeatedSum p q
        = (((p : ℝ) + (q : ℝ) - 1) * PaperR7.twoPrimeHeckeValue p q
            - ((p : ℝ) - 1) * (PaperR7.twoPrimeHeckeValue p q) ^ 2)
          / ((q : ℝ) - 1) := by
  have hp1 : 1 < p := hp.one_lt
  have hq1 : 1 < q := hq.one_lt
  have hne : p ≠ q := Nat.ne_of_lt hpq
  have hqR : (1 : ℝ) < (q : ℝ) := by exact_mod_cast hq1
  have hq1' : ((q : ℝ) - 1) ≠ 0 := by linarith
  have hA := aSum_eq_heckeValue (p := p) (q := q) hp1 hq1
  have hB := bSum_eq hp hq hpq
  have hD := distinctSum_eq hp hq hpq
  have hR := repeatedSum_eq hp hq hne
  rw [cSum_eq_one_add hp1 hq1] at hR
  rw [hB] at hD hR
  rw [hA] at hD hR
  constructor
  · rw [hD]
    field_simp
    ring
  · rw [hR]
    field_simp
    ring
