import Definitions.Def_ErdosProblems_Erdos269_BoundedRadixTailEscape
import Theorems.Thm_ErdosProblems_Erdos269_affine_nearInteger_alignment
import Mathlib.Tactic

/-!
# Erdős #269: bounded-radix tail escape

Consider an affine orbit
`x (n + 1) = P n * x n - c n` with integral `c n` and radices
`2 ≤ P n ≤ 30`.  If the orbit is eventually always within `1/31` of an
integer, the corresponding errors grow by at least a factor of two at every
step; hence one of the states is itself integral.  Otherwise the orbit is at
least `1/31` from every integer at arbitrarily late indices.

The integral state in the first alternative need not be zero.  The theorem
also makes no assertion that the separated indices are eventually all
indices, have positive density, or have unbounded distance from the integers.
-/

namespace ErdosProblems.Erdos269
/-- Once the integer witnesses align, the signed errors multiply exactly by
the radix. -/
theorem affine_nearInteger_error_mul
    {P : ℕ} {x y : ℝ} {c m n : ℤ}
    (hrec : y = (P : ℝ) * x - (c : ℝ))
    (halign : n = (P : ℤ) * m - c) :
    y - (n : ℝ) = (P : ℝ) * (x - (m : ℝ)) := by
  rw [hrec, halign]
  push_cast
  ring
end ErdosProblems.Erdos269

open ErdosProblems in
open ErdosProblems.Erdos269 in
theorem solution
    (P : ℕ → ℕ) (c : ℕ → ℤ) (x : ℕ → ℝ)
    (hPlo : ∀ a, 2 ≤ P a)
    (hPhi : ∀ a, P a ≤ 30)
    (hrec :
      ∀ a, x (a + 1) =
        (P a : ℝ) * x a - (c a : ℝ)) :
    (∃ a : ℕ, ∃ z : ℤ, x a = (z : ℝ)) ∨
      ∀ a₀, ∃ a, a₀ ≤ a ∧
        FarFromIntegers (x a) ((1 : ℝ) / 31) := by
  classical
  by_cases hescape :
      ∀ a₀, ∃ a, a₀ ≤ a ∧
        FarFromIntegers (x a) ((1 : ℝ) / 31)
  · exact Or.inr hescape
  · left
    push Not at hescape
    rcases hescape with ⟨a₀, hclose⟩
    have hnear : ∀ k : ℕ,
        NearInteger (x (a₀ + k)) ((1 : ℝ) / 31) := by
      intro k
      have hnfar := hclose (a₀ + k) (Nat.le_add_right a₀ k)
      unfold FarFromIntegers at hnfar
      simp only [not_forall] at hnfar
      rcases hnfar with ⟨z, hz⟩
      exact ⟨z, lt_of_not_ge hz⟩
    let m : ℕ → ℤ := fun k => Classical.choose (hnear k)
    have hm (k : ℕ) :
        |x (a₀ + k) - (m k : ℝ)| < (1 : ℝ) / 31 :=
      Classical.choose_spec (hnear k)
    have herr (k : ℕ) :
        x (a₀ + (k + 1)) - (m (k + 1) : ℝ) =
          (P (a₀ + k) : ℝ) *
            (x (a₀ + k) - (m k : ℝ)) := by
      have hindex : a₀ + (k + 1) = (a₀ + k) + 1 := by omega
      have halign : m (k + 1) =
          (P (a₀ + k) : ℤ) * m k - c (a₀ + k) := by
        apply affine_nearInteger_alignment (hPhi (a₀ + k))
          (hrec (a₀ + k))
        · exact hm k
        · rw [← hindex]
          exact hm (k + 1)
      rw [hindex]
      exact affine_nearInteger_error_mul (hrec (a₀ + k)) halign
    have hgrow (k : ℕ) :
        (2 : ℝ) ^ k * |x a₀ - (m 0 : ℝ)| ≤
          |x (a₀ + k) - (m k : ℝ)| := by
      induction k with
      | zero => simp
      | succ k ih =>
          have htwoP : (2 : ℝ) ≤ P (a₀ + k) := by
            exact_mod_cast hPlo (a₀ + k)
          calc
            (2 : ℝ) ^ (k + 1) * |x a₀ - (m 0 : ℝ)| =
                2 * ((2 : ℝ) ^ k * |x a₀ - (m 0 : ℝ)|) := by
                  rw [pow_succ]
                  ring
            _ ≤ 2 * |x (a₀ + k) - (m k : ℝ)| :=
              mul_le_mul_of_nonneg_left ih (by norm_num)
            _ ≤ (P (a₀ + k) : ℝ) *
                |x (a₀ + k) - (m k : ℝ)| :=
              mul_le_mul_of_nonneg_right htwoP (abs_nonneg _)
            _ = |x (a₀ + (k + 1)) - (m (k + 1) : ℝ)| := by
              have habsP :
                  |(P (a₀ + k) : ℝ)| = (P (a₀ + k) : ℝ) :=
                abs_of_nonneg (Nat.cast_nonneg (P (a₀ + k)))
              calc
                (P (a₀ + k) : ℝ) *
                    |x (a₀ + k) - (m k : ℝ)| =
                    |(P (a₀ + k) : ℝ)| *
                      |x (a₀ + k) - (m k : ℝ)| := by
                        rw [habsP]
                _ = |(P (a₀ + k) : ℝ) *
                    (x (a₀ + k) - (m k : ℝ))| := (abs_mul _ _).symm
                _ = |x (a₀ + (k + 1)) - (m (k + 1) : ℝ)| := by
                  rw [herr k]
    have hzero : x a₀ - (m 0 : ℝ) = 0 := by
      by_contra hne
      have habs : 0 < |x a₀ - (m 0 : ℝ)| := abs_pos.mpr hne
      obtain ⟨k, hk⟩ :=
        pow_unbounded_of_one_lt
          (((1 : ℝ) / 31) / |x a₀ - (m 0 : ℝ)|)
          (by norm_num : (1 : ℝ) < 2)
      have hlarge :
          (1 : ℝ) / 31 <
            (2 : ℝ) ^ k * |x a₀ - (m 0 : ℝ)| := by
        exact (div_lt_iff₀ habs).mp hk
      have := hgrow k
      have := hm k
      nlinarith
    exact ⟨a₀, m 0, by linarith⟩
