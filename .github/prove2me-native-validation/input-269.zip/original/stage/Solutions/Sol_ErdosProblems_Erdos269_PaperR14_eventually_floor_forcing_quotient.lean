import Definitions.Def_ErdosProblems_Erdos269_BoundedRadixTailEscape
import Definitions.Def_ErdosProblems_Erdos269_ResidueEscape
import Definitions.Def_ErdosProblems_Erdos269_ThreePrimeRunningLcm
import Definitions.Def_ErdosProblems_Erdos269_RestrictedFloorSum
import Definitions.Def_ErdosProblems_Erdos269_DyadicBlockMassIdentity
import Definitions.Def_ErdosProblems_Erdos269_DyadicBlockThresholdPartition
import Definitions.Def_ErdosProblems_Erdos269_DyadicOrderedTailRecurrence
import Definitions.Def_ErdosProblems_Erdos269_DyadicShellSummability
import Definitions.Def_ErdosProblems_Erdos269_IntegralBranchExtinction
import Definitions.Def_ErdosProblems_Erdos269_JumpConstraintMajorant
import Definitions.Def_ErdosProblems_Shared_IrrationalRotationStaircase
import Definitions.Def_ErdosProblems_Erdos269_KernelCarryRank
import Definitions.Def_ErdosProblems_Erdos269_PaperR7ActualOrbit
import Definitions.Def_ErdosProblems_Erdos269_PaperR7SeriesIdentification
import Definitions.Def_ErdosProblems_Erdos269_RationalLatticeReduction
import Definitions.Def_ErdosProblems_Erdos269_RationalityCarryBridge
import Definitions.Def_ErdosProblems_Erdos269_PaperR7RationalBridge
import Definitions.Def_ErdosProblems_Erdos269_PaperR7WindowResults
import Theorems.Thm_ErdosProblems_Erdos269_trueNormalizedState_pos
import Theorems.Thm_ErdosProblems_Erdos269_trueNormalizedState_window
import Theorems.Thm_ErdosProblems_Erdos269_PaperR7_actualWindowBase_eq_product
import Theorems.Thm_ErdosProblems_Erdos269_PaperR7_actualWindowProduct_pos
import Theorems.Thm_ErdosProblems_Erdos269_PaperR14_scaled_tail_div_window_tendsto_zero
import Mathlib.Algebra.BigOperators.Group.Finset.Basic
import Mathlib.Algebra.BigOperators.Group.Finset.Sigma
import Mathlib.Algebra.BigOperators.Group.List.Basic
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Algebra.Order.Floor.Ring
import Mathlib.Algebra.Order.Floor.Semiring
import Mathlib.Algebra.Ring.Parity
import Mathlib.Analysis.SpecialFunctions.Log.Base
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Data.Finset.Card
import Mathlib.Data.Finset.Prod
import Mathlib.Data.Fintype.Pigeonhole
import Mathlib.Data.Int.ModEq
import Mathlib.Data.Nat.Factorization.Basic
import Mathlib.Data.Nat.Log
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.Nat.Prime.Int
import Mathlib.Data.Real.Archimedean
import Mathlib.LinearAlgebra.Matrix.Block
import Mathlib.LinearAlgebra.Matrix.Determinant.Basic
import Mathlib.Tactic
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.InfiniteSum.Real

namespace ErdosProblems.Erdos269.PaperR14
end ErdosProblems.Erdos269.PaperR14

namespace PaperR7
end PaperR7

/-!
# The fixed-start residue limit from the long paper

For a fixed multiplier `B` and starting scale `lo`, the paper studies the
least positive residue of the actual window forcing modulo the actual window
product.  This file proves its eventual exact formula and limiting proportion.
The proof includes the delicate integral case: the finite quotients approach
`B X_lo` strictly from below, so their floors stabilise at `ceil (B X_lo) - 1`.
-/

namespace ErdosProblems.Erdos269.PaperR14
open Filter
open scoped Topology
open PaperR7





/-- The quotient appearing in Euclidean division approaches the fixed state
strictly from below. -/
theorem forcing_quotient_eq (B lo h : ℕ) :
    (((B : ℤ) * actualWindowForcing lo h : ℤ) : ℝ) /
        (actualWindowProduct lo h : ℝ) =
      (B : ℝ) * trueNormalizedState lo -
        (B : ℝ) * trueNormalizedState (lo + h) /
          (actualWindowProduct lo h : ℝ) := by
  have hwindow := trueNormalizedState_window lo h
  change trueNormalizedState (lo + h) =
    (actualWindowBase lo h : ℝ) * trueNormalizedState lo -
      (actualWindowForcing lo h : ℝ) at hwindow
  rw [actualWindowBase_eq_product] at hwindow
  have hW : (actualWindowProduct lo h : ℝ) ≠ 0 := by
    exact_mod_cast (actualWindowProduct_pos lo h).ne'
  push_cast at hwindow ⊢
  field_simp [hW]
  nlinarith
end ErdosProblems.Erdos269.PaperR14

open Filter
open scoped Topology
open PaperR7
open ErdosProblems in
open ErdosProblems.Erdos269 in
open ErdosProblems.Erdos269.PaperR14 in
open ErdosProblems.Erdos269.PaperR7 in
theorem solution (B lo : ℕ) (hB : 0 < B) :
    ∀ᶠ h in atTop,
      ⌊(((B : ℤ) * actualWindowForcing lo h : ℤ) : ℝ) /
          (actualWindowProduct lo h : ℝ)⌋ =
        ⌈(B : ℝ) * trueNormalizedState lo⌉ - 1 := by
  let y : ℝ := (B : ℝ) * trueNormalizedState lo
  let gap : ℝ := y - ((⌈y⌉ - 1 : ℤ) : ℝ)
  have hgap : 0 < gap := by
    dsimp [gap]
    have := Int.ceil_lt_add_one y
    push_cast at this ⊢
    linarith
  have heps := (scaled_tail_div_window_tendsto_zero B lo).eventually
    (eventually_lt_nhds hgap)
  filter_upwards [heps] with h hepslt
  rw [forcing_quotient_eq]
  apply Int.floor_eq_iff.mpr
  constructor
  · dsimp [gap, y] at hepslt ⊢
    linarith
  · have htailpos : 0 <
        (B : ℝ) * trueNormalizedState (lo + h) /
          (actualWindowProduct lo h : ℝ) := by
      exact div_pos (mul_pos (by exact_mod_cast hB) (trueNormalizedState_pos _))
        (by exact_mod_cast actualWindowProduct_pos lo h)
    have hyceil : y ≤ (⌈y⌉ : ℤ) := Int.le_ceil y
    dsimp [y] at hyceil ⊢
    push_cast at hyceil ⊢
    linarith
