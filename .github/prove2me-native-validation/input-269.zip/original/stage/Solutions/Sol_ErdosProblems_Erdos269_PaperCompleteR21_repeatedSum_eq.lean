import Definitions.Def_ErdosProblems_Erdos269_ThreePrimeRunningLcm
import Definitions.Def_ErdosProblems_Shared_IrrationalRotationStaircase
import Definitions.Def_ErdosProblems_Erdos269_KernelCarryRank
import Definitions.Def_ErdosProblems_Erdos269_PaperR7AnalyticInterfaces
import Definitions.Def_ErdosProblems_Erdos269_PaperCompleteR21_TwoPrimeSums
import Theorems.Thm_ErdosProblems_Erdos269_PaperCompleteR21_runningLcm_eq_twoPrimeHeight
import Theorems.Thm_ErdosProblems_Erdos269_PaperCompleteR21_smoothVal_injective
import Theorems.Thm_ErdosProblems_Erdos269_PaperCompleteR21_twoPrimeHeight_smooth
import Mathlib.Algebra.BigOperators.Group.Finset.Basic
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Algebra.Order.Floor.Ring
import Mathlib.Algebra.Order.Floor.Semiring
import Mathlib.Algebra.Ring.Parity
import Mathlib.Analysis.Normed.Ring.InfiniteSum
import Mathlib.Analysis.SpecialFunctions.Log.Base
import Mathlib.Analysis.SpecialFunctions.Pow.Real
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.Data.Finset.Card
import Mathlib.Data.Finset.Prod
import Mathlib.Data.Fintype.Pigeonhole
import Mathlib.Data.Nat.Log
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.Nat.Prime.Int
import Mathlib.Data.Real.Archimedean
import Mathlib.LinearAlgebra.Matrix.Block
import Mathlib.LinearAlgebra.Matrix.Determinant.Basic
import Mathlib.NumberTheory.Real.Irrational
import Mathlib.RingTheory.Algebraic.Basic
import Mathlib.Tactic
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Ring

/-!
# Erdős #269: both two-prime running-LCM sums

This file transcribes the two-prime objects of the short paper's
`res:two-prime-transcendence` and of the long paper's `long269:res:lead-two-prime`
and proves everything those statements assert except one external value theorem.

* `runningLcm p q x` is the literal least common multiple of the `{p,q}`-smooth
  numbers not exceeding `x`; `runningLcm_eq_twoPrimeHeight` identifies it with the
  product of the two maximal pure prime powers.
* `repeatedSum p q` is `R_{p,q}`: the reciprocal running LCM summed at every
  positive `{p,q}`-smooth integer.  `distinctSum p q` is `D_{p,q}`: each distinct
  running LCM counted once.
* `two_prime_affine_and_quadratic` proves the paper's displayed identities
  `eq:two-prime-affine`, with `A` the paper's boundary value
  `ErdosProblems.Erdos269.PaperR7.twoPrimeHeckeValue`.
* `two_prime_sums_transcendental` and `two_prime_transcendence` conclude that both
  values are transcendental.

The only undischarged input is `BugeaudLaurentTranscendence`, the theorem of
Bugeaud and Laurent (Theorem 1.1) in the case `ρ = 0` due to Loxton and van der
Poorten (Theorem 8, p. 40), that the Hecke--Mahler series takes transcendental
values.  It is carried as one explicit named hypothesis, stated in the generality
in which the paper cites it; all of its side conditions for the pair `(1/p, 1/q)`,
including irrationality of the slope `θ = log p / log q`, are proved here.
-/

namespace ErdosProblems.Erdos269.PaperCompleteR21
open Polynomial
open scoped BigOperators

noncomputable section

/-! ## The `{p,q}`-smooth numbers and their running least common multiple -/















/-! ## Integer logarithms at smooth points -/

























/-! ## The exact combinatorics of the jump indices -/











/-! ## Unique factorisation of the smooth monoid -/



theorem smoothSet_eq_range {p q : ℕ} (hp : 0 < p) (hq : 0 < q) :
    SmoothSet p q = Set.range (fun e : ℕ × ℕ => p ^ e.1 * q ^ e.2) := by
  ext n
  constructor
  · rintro ⟨-, i, j, rfl⟩
    exact ⟨(i, j), rfl⟩
  · rintro ⟨⟨i, j⟩, rfl⟩
    exact ⟨Nat.mul_pos (pow_pos hp i) (pow_pos hq j), i, j, rfl⟩



/-! ## The two sums of the paper -/







/-! ## The two component series -/





theorem aTerm_nonneg (p q n : ℕ) : 0 ≤ aTerm p q n := by
  unfold aTerm
  positivity

theorem cTerm_nonneg (p q j : ℕ) : 0 ≤ cTerm p q j := by
  unfold cTerm
  positivity





theorem aTerm_eq_inv {p q : ℕ} (n : ℕ) :
    aTerm p q n = (((p : ℝ) ^ n * (q : ℝ) ^ qExp p q n))⁻¹ := by
  rw [aTerm, mul_inv, inv_pow, inv_pow]

theorem cTerm_eq_inv {p q : ℕ} (j : ℕ) :
    cTerm p q j = (((p : ℝ) ^ pExp p q j * (q : ℝ) ^ j))⁻¹ := by
  rw [cTerm, mul_inv, inv_pow, inv_pow]

private theorem inv_lt_one_nat {p : ℕ} (hp : 1 < p) : ((p : ℝ))⁻¹ < 1 := by
  have hp0 : (0 : ℝ) < (p : ℝ) := by exact_mod_cast (by omega : 0 < p)
  have hp1 : (1 : ℝ) < (p : ℝ) := by exact_mod_cast hp
  have h : (1 : ℝ) / (p : ℝ) < 1 := by
    rw [div_lt_one hp0]
    exact hp1
  simpa [one_div] using h

private theorem inv_nonneg_nat (p : ℕ) : (0 : ℝ) ≤ ((p : ℝ))⁻¹ := by positivity

theorem summable_aTerm {p q : ℕ} (hp : 1 < p) (hq : 1 < q) : Summable (aTerm p q) := by
  refine Summable.of_nonneg_of_le (fun n => aTerm_nonneg p q n) (fun n => ?_)
    (summable_geometric_of_lt_one (inv_nonneg_nat p) (inv_lt_one_nat hp))
  have hle : ((q : ℝ)⁻¹) ^ qExp p q n ≤ 1 :=
    pow_le_one₀ (inv_nonneg_nat q) (le_of_lt (inv_lt_one_nat hq))
  calc aTerm p q n = ((p : ℝ)⁻¹) ^ n * ((q : ℝ)⁻¹) ^ qExp p q n := rfl
    _ ≤ ((p : ℝ)⁻¹) ^ n * 1 := mul_le_mul_of_nonneg_left hle (by positivity)
    _ = ((p : ℝ)⁻¹) ^ n := mul_one _

theorem summable_cTerm {p q : ℕ} (hp : 1 < p) (hq : 1 < q) : Summable (cTerm p q) := by
  refine Summable.of_nonneg_of_le (fun j => cTerm_nonneg p q j) (fun j => ?_)
    (summable_geometric_of_lt_one (inv_nonneg_nat q) (inv_lt_one_nat hq))
  have hle : ((p : ℝ)⁻¹) ^ pExp p q j ≤ 1 :=
    pow_le_one₀ (inv_nonneg_nat p) (le_of_lt (inv_lt_one_nat hp))
  calc cTerm p q j = ((p : ℝ)⁻¹) ^ pExp p q j * ((q : ℝ)⁻¹) ^ j := rfl
    _ ≤ 1 * ((q : ℝ)⁻¹) ^ j := mul_le_mul_of_nonneg_right hle (by positivity)
    _ = ((q : ℝ)⁻¹) ^ j := one_mul _



/-! ## `R = A (1 + B)` -/
end
end ErdosProblems.Erdos269.PaperCompleteR21

open Polynomial
open scoped BigOperators
open ErdosProblems in
open ErdosProblems.Erdos269 in
open ErdosProblems.Erdos269.PaperCompleteR21 in
theorem solution {p q : ℕ} (hp : p.Prime) (hq : q.Prime) (hpq : p ≠ q) :
    repeatedSum p q = (∑' n : ℕ, aTerm p q n) * (∑' j : ℕ, cTerm p q j) := by
  have hp1 : 1 < p := hp.one_lt
  have hq1 : 1 < q := hq.one_lt
  have hset := smoothSet_eq_range (p := p) (q := q) (by omega) (by omega)
  have hinj := smoothVal_injective hp hq hpq
  have hstep : repeatedSum p q = ∑' e : ℕ × ℕ, aTerm p q e.1 * cTerm p q e.2 := by
    unfold repeatedSum
    rw [hset, tsum_range (fun n : ℕ => ((runningLcm p q n : ℝ))⁻¹) hinj]
    refine tsum_congr fun e => ?_
    show ((runningLcm p q (p ^ e.1 * q ^ e.2) : ℝ))⁻¹ = aTerm p q e.1 * cTerm p q e.2
    have hne : p ^ e.1 * q ^ e.2 ≠ 0 :=
      (Nat.mul_pos (pow_pos (by omega) _) (pow_pos (by omega) _)).ne'
    rw [runningLcm_eq_twoPrimeHeight hp hq hpq hne, twoPrimeHeight_smooth hp1 hq1,
      aTerm_eq_inv, cTerm_eq_inv]
    push_cast
    rw [← mul_inv]
  rw [hstep]
  exact (Summable.tsum_mul_tsum (summable_aTerm hp1 hq1) (summable_cTerm hp1 hq1)
    (Summable.mul_of_nonneg (summable_aTerm hp1 hq1) (summable_cTerm hp1 hq1)
      (fun n => aTerm_nonneg p q n) (fun j => cTerm_nonneg p q j))).symm
