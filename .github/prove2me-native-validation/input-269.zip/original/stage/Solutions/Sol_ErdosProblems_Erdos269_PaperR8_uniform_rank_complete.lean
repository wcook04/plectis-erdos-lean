import Definitions.Def_ErdosProblems_Erdos269_ThreePrimeRunningLcm
import Definitions.Def_ErdosProblems_Shared_IrrationalRotationStaircase
import Definitions.Def_ErdosProblems_Erdos269_KernelCarryRank
import Definitions.Def_ErdosProblems_Erdos269_PaperR7AnalyticInterfaces
import Definitions.Def_ErdosProblems_Erdos269_PaperR8UniformRank
import Theorems.Thm_ErdosProblems_Erdos269_PaperR7_uniform_carry_midpoint_witness
import Theorems.Thm_ErdosProblems_Erdos269_PaperR8_iInf_uniform_finite_rank_distance
import Theorems.Thm_ErdosProblems_Erdos269_noIntegerOrbit_logb_of_prime
import Mathlib.Algebra.BigOperators.Group.Finset.Basic
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Algebra.Order.Floor.Ring
import Mathlib.Algebra.Order.Floor.Semiring
import Mathlib.Algebra.Ring.Parity
import Mathlib.Analysis.Normed.Module.FiniteDimension
import Mathlib.Analysis.SpecialFunctions.Log.Base
import Mathlib.Data.ENNReal.Real
import Mathlib.Data.Finset.Card
import Mathlib.Data.Finset.Prod
import Mathlib.Data.Fintype.Pigeonhole
import Mathlib.Data.Nat.Log
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.Nat.Prime.Int
import Mathlib.Data.Real.Archimedean
import Mathlib.LinearAlgebra.Matrix.Block
import Mathlib.LinearAlgebra.Matrix.Determinant.Basic
import Mathlib.RingTheory.Algebraic.Basic
import Mathlib.Tactic
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Ring
import Mathlib.Topology.ContinuousMap.Bounded.Normed
import Mathlib.Topology.MetricSpace.Pseudo.Basic

namespace PaperR7
end PaperR7

/-!
# The infinite uniform finite-rank obstruction

The finite staircase minors alone do not prove a uniform lower bound. This
file uses their column separation inside a finite-dimensional bounded column
space, and a finite covering of a compact ball. Row factors in an arbitrary
separated representation need not be bounded; the subspace is formed by
intersecting their algebraic span with the space of bounded functions.

The final infimum ranges over ALL finite-separated-rank matrices. It uses an
extended nonnegative supremum so that unbounded approximants have infinite
uniform error, never the spurious zero returned by an unbounded real iSup.
The resulting finite value is also identified after conversion to the reals.
All proof text is an uncompiled candidate against the packet's pinned Mathlib.
-/

namespace ErdosProblems.Erdos269.PaperR8
open PaperR7 ErdosProblems.Shared Set Metric
open scoped BigOperators Topology BoundedContinuousFunction ENNReal























/-- The displayed prime-specialised equality, including the real-valued form. -/
theorem uniform_rank_prime_equality {p q r : ℕ}
    (hp : p.Prime) (hq : q.Prime) (hr : r.Prime)
    (hpr : p ≠ r) (hqr : q ≠ r) :
    (⨅ A : FiniteRankMatrix, uniformError (realCarryMatrix p q r) A.val) =
        ENNReal.ofReal (((r : ℝ) - 1) / (2 * (r : ℝ))) ∧
    (⨅ A : FiniteRankMatrix, uniformError (realCarryMatrix p q r) A.val).toReal =
        ((r : ℝ) - 1) / (2 * (r : ℝ)) := by
  have h := iInf_uniform_finite_rank_distance hp.pos hq.pos hr.one_lt
    (noIntegerOrbit_logb_of_prime hp hr hpr)
    (noIntegerOrbit_logb_of_prime hq hr hqr)
  refine ⟨h, ?_⟩
  rw [h]
  have hrR : (1 : ℝ) < r := by exact_mod_cast hr.one_lt
  exact ENNReal.toReal_ofReal
    (div_nonneg (sub_nonneg.mpr hrR.le) (mul_nonneg (by norm_num) (by positivity)))
end ErdosProblems.Erdos269.PaperR8

open PaperR7 ErdosProblems.Shared Set Metric
open scoped BigOperators Topology BoundedContinuousFunction ENNReal
open ErdosProblems in
open ErdosProblems.Erdos269 in
open ErdosProblems.Erdos269.PaperR8 in
open ErdosProblems.Erdos269.PaperR7 in
theorem solution {p q r : ℕ}
    (hp : p.Prime) (hq : q.Prime) (hr : r.Prime)
    (hpr : p ≠ r) (hqr : q ≠ r) :
    (⨅ A : FiniteRankMatrix, uniformError (realCarryMatrix p q r) A.val) =
        ENNReal.ofReal ((1 - (r : ℝ)⁻¹) / 2) ∧
    (⨅ A : FiniteRankMatrix, uniformError (realCarryMatrix p q r) A.val) =
        ENNReal.ofReal (((r : ℝ) - 1) / (2 * (r : ℝ))) ∧
    ∃ A : FiniteRankMatrix,
      (∀ i j, A.val i j = (1 + (r : ℝ)⁻¹) / 2) ∧
      uniformError (realCarryMatrix p q r) A.val =
        (⨅ F : FiniteRankMatrix, uniformError (realCarryMatrix p q r) F.val) := by
  classical
  have heq := (uniform_rank_prime_equality hp hq hr hpr hqr).1
  have hr0 : (r : ℝ) ≠ 0 := by exact_mod_cast hr.ne_zero
  have hgap : ((r : ℝ) - 1) / (2 * (r : ℝ)) = (1 - (r : ℝ)⁻¹) / 2 := by
    field_simp [hr0]
    <;> ring
  refine ⟨heq.trans (congrArg ENNReal.ofReal hgap), heq, ?_⟩
  let A : FiniteRankMatrix :=
    ⟨(fun _ _ => (1 + (r : ℝ)⁻¹) / 2),
      ⟨1, (fun _ _ => (1 + (r : ℝ)⁻¹) / 2), (fun _ _ => 1),
        by intro i j; simp⟩⟩
  refine ⟨A, fun _ _ => rfl, ?_⟩
  apply le_antisymm
  · rw [heq]
    apply iSup_le
    intro i
    apply iSup_le
    intro j
    change ENNReal.ofReal
      |realCarryMatrix p q r i j - (1 + (r : ℝ)⁻¹) / 2| ≤ _
    rw [(uniform_carry_midpoint_witness hp.pos hq.pos hr.one_lt).2 i j]
  · exact iInf_le _ A
