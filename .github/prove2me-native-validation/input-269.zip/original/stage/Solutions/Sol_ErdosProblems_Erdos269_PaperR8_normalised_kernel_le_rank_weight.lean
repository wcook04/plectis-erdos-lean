import Definitions.Def_ErdosProblems_Erdos269_BoundedRadixTailEscape
import Definitions.Def_ErdosProblems_Erdos269_ResidueEscape
import Definitions.Def_ErdosProblems_Erdos269_ThreePrimeRunningLcm
import Definitions.Def_ErdosProblems_Erdos269_RestrictedFloorSum
import Definitions.Def_ErdosProblems_Erdos269_DyadicBlockMassIdentity
import Definitions.Def_ErdosProblems_Erdos269_DyadicBlockThresholdPartition
import Definitions.Def_ErdosProblems_Erdos269_DyadicOrderedTailRecurrence
import Definitions.Def_ErdosProblems_Erdos269_DyadicShellSummability
import Definitions.Def_ErdosProblems_Erdos269_IntegralBranchExtinction
import Definitions.Def_ErdosProblems_Erdos269_JumpConstraintMajorant
import Definitions.Def_ErdosProblems_Shared_IrrationalRotationStaircase
import Definitions.Def_ErdosProblems_Erdos269_KernelCarryRank
import Definitions.Def_ErdosProblems_Erdos269_PaperR7ActualOrbit
import Definitions.Def_ErdosProblems_Erdos269_PaperR7SeriesIdentification
import Definitions.Def_ErdosProblems_Erdos269_RationalLatticeReduction
import Definitions.Def_ErdosProblems_Erdos269_RationalityCarryBridge
import Definitions.Def_ErdosProblems_Erdos269_PaperR7RationalBridge
import Definitions.Def_ErdosProblems_Erdos269_PaperR7WindowResults
import Definitions.Def_ErdosProblems_Erdos269_PaperR8RankMajorant
import Theorems.Thm_ErdosProblems_Erdos269_threePrimeHeight235_cast_pos
import Theorems.Thm_ErdosProblems_Erdos269_PaperR8_heightRank235_dyadic
import Theorems.Thm_ErdosProblems_Erdos269_PaperR8_height_growth_by_rank
import Mathlib.Algebra.BigOperators.Group.Finset.Basic
import Mathlib.Algebra.BigOperators.Group.Finset.Sigma
import Mathlib.Algebra.BigOperators.Group.List.Basic
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Algebra.Order.Floor.Ring
import Mathlib.Algebra.Order.Floor.Semiring
import Mathlib.Algebra.Ring.Parity
import Mathlib.Analysis.SpecialFunctions.Log.Base
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Data.Finset.Card
import Mathlib.Data.Finset.Prod
import Mathlib.Data.Fintype.Pigeonhole
import Mathlib.Data.Int.ModEq
import Mathlib.Data.Nat.Factorization.Basic
import Mathlib.Data.Nat.Log
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.Nat.Prime.Int
import Mathlib.Data.Real.Archimedean
import Mathlib.LinearAlgebra.Matrix.Block
import Mathlib.LinearAlgebra.Matrix.Determinant.Basic
import Mathlib.Tactic
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.InfiniteSum.Order
import Mathlib.Topology.Algebra.InfiniteSum.Real

namespace PaperR7
end PaperR7

/-!
# The actual height-rank majorant (round 8)

This file supplies the missing geometric summation over height ranks, not a
comparison of the much larger dyadic-shell bound with `carryMajorantQ`.
It uses the live round-7 definitions without changing any of them.

Proof text: not elaborated in this return. No additional hypotheses are hidden
in the final theorem. Mathlib source checks use commit
`5e932f97dd25535344f80f9dd8da3aab83df0fe6`.
-/

namespace ErdosProblems.Erdos269.PaperR8
open scoped BigOperators
open PaperR7
end ErdosProblems.Erdos269.PaperR8

open scoped BigOperators
open PaperR7
open ErdosProblems in
open ErdosProblems.Erdos269 in
open ErdosProblems.Erdos269.PaperR8 in
open ErdosProblems.Erdos269.PaperR7 in
theorem solution (a : ℕ) (e : Exponent235)
    (he : 2 ^ a ≤ exponentValue235 e) :
    (threePrimeHeight 2 3 5 (2 ^ a) : ℝ) / 2 * exponentKernel235 e ≤
      1 / (2 * (2 : ℝ) ^ (heightRank235 (exponentValue235 e) - paperJumpIndex a)) := by
  have hh := height_growth_by_rank he
  rw [heightRank235_dyadic] at hh
  have hhR : (threePrimeHeight 2 3 5 (2 ^ a) : ℝ) *
      (2 : ℝ) ^ (heightRank235 (exponentValue235 e) - paperJumpIndex a) ≤
      (threePrimeHeight 2 3 5 (exponentValue235 e) : ℝ) := by exact_mod_cast hh
  have hH : (0 : ℝ) < (threePrimeHeight 2 3 5 (exponentValue235 e) : ℝ) :=
    threePrimeHeight235_cast_pos _
  have hP : (0 : ℝ) < (2 : ℝ) ^
      (heightRank235 (exponentValue235 e) - paperJumpIndex a) := by positivity
  unfold exponentKernel235
  rw [inv_eq_one_div]
  apply (le_div_iff₀ (mul_pos (by norm_num : (0 : ℝ) < 2) hP)).mpr
  apply (mul_le_mul_iff_left₀ hH).mp
  calc
    ((threePrimeHeight 2 3 5 (2 ^ a) : ℝ) / 2 *
        (1 / (threePrimeHeight 2 3 5 (exponentValue235 e) : ℝ)) *
        (2 * (2 : ℝ) ^ (heightRank235 (exponentValue235 e) - paperJumpIndex a))) *
        (threePrimeHeight 2 3 5 (exponentValue235 e) : ℝ)
      = (threePrimeHeight 2 3 5 (2 ^ a) : ℝ) *
          (2 : ℝ) ^ (heightRank235 (exponentValue235 e) - paperJumpIndex a) := by
            field_simp [ne_of_gt hH]
            <;> ring
    _ ≤ (threePrimeHeight 2 3 5 (exponentValue235 e) : ℝ) := hhR
    _ = 1 * (threePrimeHeight 2 3 5 (exponentValue235 e) : ℝ) := by ring
