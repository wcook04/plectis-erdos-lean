import Definitions.Def_ErdosProblems_Erdos269_BoundedRadixTailEscape
import Definitions.Def_ErdosProblems_Erdos269_ResidueEscape
import Definitions.Def_ErdosProblems_Erdos269_ThreePrimeRunningLcm
import Definitions.Def_ErdosProblems_Erdos269_RestrictedFloorSum
import Definitions.Def_ErdosProblems_Erdos269_DyadicBlockMassIdentity
import Definitions.Def_ErdosProblems_Erdos269_DyadicBlockThresholdPartition
import Definitions.Def_ErdosProblems_Erdos269_DyadicOrderedTailRecurrence
import Definitions.Def_ErdosProblems_Erdos269_DyadicShellSummability
import Definitions.Def_ErdosProblems_Erdos269_IntegralBranchExtinction
import Theorems.Thm_ErdosProblems_Erdos269_dyadicShellMassR235_nonneg
import Theorems.Thm_ErdosProblems_Erdos269_PaperR7_dyadic_height_le_eight_pow
import Theorems.Thm_ErdosProblems_Erdos269_PaperR7_shellMass_le_thirty_square_div_eight_pow
import Mathlib.Algebra.BigOperators.Group.Finset.Basic
import Mathlib.Algebra.BigOperators.Group.Finset.Sigma
import Mathlib.Algebra.BigOperators.Group.List.Basic
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Algebra.Ring.Parity
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Data.Finset.Card
import Mathlib.Data.Finset.Prod
import Mathlib.Data.Int.ModEq
import Mathlib.Data.Nat.Log
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.Nat.Prime.Int
import Mathlib.Tactic
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Ring

namespace ErdosProblems.Erdos269.PaperR7
end ErdosProblems.Erdos269.PaperR7

/-!
# Round 7: the literal `8640 / 343` shell bound

Target: the bound in short-note `res:actual-orbit`.  The supplied bound `90`
does not prove this sharper displayed constant.  We retain the actual shell
mass, prove its `8^{-a}` estimate, and sum the resulting majorant exactly.
This is NOT a proof of the separate long-record `Q(n_a)` bound.

No admissions.
-/

namespace ErdosProblems.Erdos269.PaperR7
open scoped BigOperators
end ErdosProblems.Erdos269.PaperR7

open scoped BigOperators
open ErdosProblems in
open ErdosProblems.Erdos269 in
open ErdosProblems.Erdos269.PaperR7 in
theorem solution (a n : ℕ) :
    (threePrimeHeight 2 3 5 (2 ^ a) : ℝ) / 2 * dyadicShellMassR235 (a + n) ≤
      15 * ((a + 1 : ℕ) : ℝ) ^ 2 *
        (((n + 1 : ℕ) : ℝ) ^ 2 * (1 / 8 : ℝ) ^ n) := by
  have hsplit : ((a + n + 1 : ℕ) : ℝ) ≤
      ((a + 1 : ℕ) : ℝ) * ((n + 1 : ℕ) : ℝ) := by
    push_cast
    nlinarith [(Nat.cast_nonneg a : (0 : ℝ) ≤ a),
      (Nat.cast_nonneg n : (0 : ℝ) ≤ n)]
  have hsq : ((a + n + 1 : ℕ) : ℝ) ^ 2 ≤
      (((a + 1 : ℕ) : ℝ) * ((n + 1 : ℕ) : ℝ)) ^ 2 :=
    pow_le_pow_left₀ (Nat.cast_nonneg _) hsplit 2
  calc
    (threePrimeHeight 2 3 5 (2 ^ a) : ℝ) / 2 * dyadicShellMassR235 (a + n)
      ≤ ((8 : ℝ) ^ a / 2) *
          (30 * ((a + n + 1 : ℕ) : ℝ) ^ 2 / (8 : ℝ) ^ (a + n)) := by
        apply mul_le_mul
        · exact div_le_div_of_nonneg_right (dyadic_height_le_eight_pow a) (by norm_num)
        · exact shellMass_le_thirty_square_div_eight_pow (a + n)
        · exact dyadicShellMassR235_nonneg _
        · positivity
    _ = 15 * ((a + n + 1 : ℕ) : ℝ) ^ 2 * (1 / 8 : ℝ) ^ n := by
      rw [pow_add, one_div_pow]
      field_simp <;> ring
    _ ≤ 15 * (((a + 1 : ℕ) : ℝ) * ((n + 1 : ℕ) : ℝ)) ^ 2 *
        (1 / 8 : ℝ) ^ n := by
      apply mul_le_mul_of_nonneg_right _ (by positivity)
      exact mul_le_mul_of_nonneg_left hsq (by norm_num)
    _ = 15 * ((a + 1 : ℕ) : ℝ) ^ 2 *
        (((n + 1 : ℕ) : ℝ) ^ 2 * (1 / 8 : ℝ) ^ n) := by ring
