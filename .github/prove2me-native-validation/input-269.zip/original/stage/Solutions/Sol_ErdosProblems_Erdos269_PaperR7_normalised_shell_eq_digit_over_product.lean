import Definitions.Def_ErdosProblems_Erdos269_BoundedRadixTailEscape
import Definitions.Def_ErdosProblems_Erdos269_ResidueEscape
import Definitions.Def_ErdosProblems_Erdos269_ThreePrimeRunningLcm
import Definitions.Def_ErdosProblems_Erdos269_RestrictedFloorSum
import Definitions.Def_ErdosProblems_Erdos269_DyadicBlockMassIdentity
import Definitions.Def_ErdosProblems_Erdos269_DyadicBlockThresholdPartition
import Definitions.Def_ErdosProblems_Erdos269_DyadicOrderedTailRecurrence
import Definitions.Def_ErdosProblems_Erdos269_DyadicShellSummability
import Definitions.Def_ErdosProblems_Erdos269_IntegralBranchExtinction
import Definitions.Def_ErdosProblems_Erdos269_PaperR7ActualOrbit
import Theorems.Thm_ErdosProblems_Erdos269_half_threePrimeHeight_mul_dyadicShellMassR235
import Theorems.Thm_ErdosProblems_Erdos269_prod_dyadicBlockBase235_ge_two_pow
import Theorems.Thm_ErdosProblems_Erdos269_threePrimeHeight235_pow_add_eq_mul_prod
import Mathlib.Algebra.BigOperators.Group.Finset.Basic
import Mathlib.Algebra.BigOperators.Group.Finset.Sigma
import Mathlib.Algebra.BigOperators.Group.List.Basic
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Algebra.Ring.Parity
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Data.Finset.Card
import Mathlib.Data.Finset.Prod
import Mathlib.Data.Int.ModEq
import Mathlib.Data.Nat.Log
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.Nat.Prime.Int
import Mathlib.Tactic
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Ring

/-!
# Round 7: literal forcing, infinite digit expansion and scaled dichotomy

Targets: short-note `res:dyadic-alphabet`, the dynamical clauses of
`res:actual-orbit`, and long-record `res:actual-orbit`.
The total smooth-series reindexing is supplied separately in
`PaperR7SeriesIdentification`; nothing here silently identifies a formal tsum
with the smooth-number series without that bridge.

No admissions.
-/

namespace ErdosProblems.Erdos269.PaperR7
open scoped BigOperators
end ErdosProblems.Erdos269.PaperR7

open scoped BigOperators
open ErdosProblems in
open ErdosProblems.Erdos269 in
open ErdosProblems.Erdos269.PaperR7 in
theorem solution (a n : ℕ) :
    (threePrimeHeight 2 3 5 (2 ^ a) : ℝ) / 2 * dyadicShellMassR235 (a + n) =
      (dyadicOrderedBlockDigit235 (a + n) : ℝ) /
        ∏ j ∈ Finset.range (n + 1), (dyadicBlockBase235 (a + j) : ℝ) := by
  have hprodpos : (0 : ℝ) <
      ∏ j ∈ Finset.range (n + 1), (dyadicBlockBase235 (a + j) : ℝ) :=
    lt_of_lt_of_le (by positivity) (prod_dyadicBlockBase235_ge_two_pow a (n + 1))
  have hd := half_threePrimeHeight_mul_dyadicShellMassR235 (a + n)
  have hH := threePrimeHeight235_pow_add_eq_mul_prod a (n + 1)
  rw [eq_div_iff hprodpos.ne', ← hd]
  rw [show a + n + 1 = a + (n + 1) by omega, hH]
  ring
