import Definitions.Def_ErdosProblems_Erdos269_BoundedRadixTailEscape
import Definitions.Def_ErdosProblems_Erdos269_ResidueEscape
import Definitions.Def_ErdosProblems_Erdos269_ThreePrimeRunningLcm
import Definitions.Def_ErdosProblems_Erdos269_RestrictedFloorSum
import Definitions.Def_ErdosProblems_Erdos269_DyadicBlockMassIdentity
import Definitions.Def_ErdosProblems_Erdos269_DyadicBlockThresholdPartition
import Definitions.Def_ErdosProblems_Erdos269_DyadicOrderedTailRecurrence
import Definitions.Def_ErdosProblems_Erdos269_DyadicShellSummability
import Definitions.Def_ErdosProblems_Erdos269_IntegralBranchExtinction
import Definitions.Def_ErdosProblems_Erdos269_JumpConstraintMajorant
import Definitions.Def_ErdosProblems_Shared_IrrationalRotationStaircase
import Definitions.Def_ErdosProblems_Erdos269_KernelCarryRank
import Definitions.Def_ErdosProblems_Erdos269_PaperR7ActualOrbit
import Definitions.Def_ErdosProblems_Erdos269_PaperR7SeriesIdentification
import Definitions.Def_ErdosProblems_Erdos269_RationalLatticeReduction
import Definitions.Def_ErdosProblems_Erdos269_RationalityCarryBridge
import Definitions.Def_ErdosProblems_Erdos269_PaperR7RationalBridge
import Definitions.Def_ErdosProblems_Erdos269_PaperR7WindowResults
import Theorems.Thm_ErdosProblems_Erdos269_dyadicBlockBase235_mem_interval
import Theorems.Thm_ErdosProblems_Erdos269_leastPositiveResidue_pos_le
import Theorems.Thm_ErdosProblems_Erdos269_windowBase235_pos
import Theorems.Thm_ErdosProblems_Erdos269_PaperR7_actualWindowBase_eq_product
import Theorems.Thm_ErdosProblems_Erdos269_PaperR7_start_le_longPaperCap
import Mathlib.Algebra.BigOperators.Group.Finset.Basic
import Mathlib.Algebra.BigOperators.Group.Finset.Sigma
import Mathlib.Algebra.BigOperators.Group.List.Basic
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Algebra.Order.Floor.Ring
import Mathlib.Algebra.Order.Floor.Semiring
import Mathlib.Algebra.Ring.Parity
import Mathlib.Analysis.SpecialFunctions.Log.Base
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Data.Finset.Card
import Mathlib.Data.Finset.Prod
import Mathlib.Data.Fintype.Pigeonhole
import Mathlib.Data.Int.ModEq
import Mathlib.Data.Nat.Factorization.Basic
import Mathlib.Data.Nat.Log
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.Nat.Prime.Int
import Mathlib.Data.Real.Archimedean
import Mathlib.LinearAlgebra.Matrix.Block
import Mathlib.LinearAlgebra.Matrix.Determinant.Basic
import Mathlib.Tactic
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.InfiniteSum.Real

/-!
# Round 7: exact window statements at the correct bounds

The short cap is `90 B (a+1)^2`. The long cap is `floor(B Q(n_a))`.
They are separately named. No validity claim about the latter is inferred from
the former. The bounded-length obstruction needs only growth of the long cap,
so it can be proved without assuming the unresolved `X_a <= Q(n_a)` bridge.

No admissions.
-/

namespace ErdosProblems.Erdos269.PaperR7
open scoped BigOperators





































/-- Crude but sufficient upper bound on a fixed-length window modulus. -/
theorem actualWindowProduct_le_thirty_pow (lo len : ℕ) :
    actualWindowProduct lo len ≤ 30 ^ len := by
  induction len with
  | zero => simp [actualWindowProduct]
  | succ len ih =>
    simp only [actualWindowProduct, Finset.prod_range_succ] at ih ⊢
    rw [pow_succ]
    exact Nat.mul_le_mul ih (dyadicBlockBase235_mem_interval (lo + len)).2

/-- An explicit finite box for every bounded-length escape against the exact long cap. -/
theorem escaping_start_lt_thirty_pow {B H lo len : ℕ}
    (hB : 0 < B) (hlen : len ≤ H)
    (hesc : longPaperCap B (lo + len) <
      leastPositiveResidue (Int.natAbs (actualWindowBase lo len))
        (-((B : ℤ) * actualWindowForcing lo len))) : lo < 30 ^ H := by
  have hp : 0 < Int.natAbs (actualWindowBase lo len) :=
    Int.natAbs_pos.mpr (windowBase235_pos lo len).ne'
  have hres := (leastPositiveResidue_pos_le hp
    (-((B : ℤ) * actualWindowForcing lo len))).2
  have hcap := start_le_longPaperCap (a := lo + len) hB
  have hnat : Int.natAbs (actualWindowBase lo len) ≤ 30 ^ H := by
    rw [actualWindowBase_eq_product, Int.natAbs_natCast]
    exact (actualWindowProduct_le_thirty_pow lo len).trans
      (Nat.pow_le_pow_right (by norm_num) hlen)
  omega
end ErdosProblems.Erdos269.PaperR7

open scoped BigOperators
open ErdosProblems in
open ErdosProblems.Erdos269 in
open ErdosProblems.Erdos269.PaperR7 in
theorem solution {B H : ℕ} (hB : 0 < B)
    (_hcop : Nat.Coprime B 30) (_hH : 1 ≤ H) :
    Set.Finite {lo : ℕ | ∃ len : ℕ, 1 ≤ len ∧ len ≤ H ∧
      longPaperCap B (lo + len) <
        leastPositiveResidue (Int.natAbs (actualWindowBase lo len))
          (-((B : ℤ) * actualWindowForcing lo len))} := by
  apply (Finset.finite_toSet (Finset.range (30 ^ H))).subset
  intro lo hlo
  obtain ⟨len, _, hlen, hesc⟩ := hlo
  exact Finset.mem_range.mpr (escaping_start_lt_thirty_pow hB hlen hesc)
