import Definitions.Def_ErdosProblems_Erdos269_BoundedRadixTailEscape
import Definitions.Def_ErdosProblems_Erdos269_ResidueEscape
import Definitions.Def_ErdosProblems_Erdos269_ThreePrimeRunningLcm
import Definitions.Def_ErdosProblems_Erdos269_RestrictedFloorSum
import Definitions.Def_ErdosProblems_Erdos269_DyadicBlockMassIdentity
import Definitions.Def_ErdosProblems_Erdos269_DyadicBlockThresholdPartition
import Definitions.Def_ErdosProblems_Erdos269_DyadicOrderedTailRecurrence
import Definitions.Def_ErdosProblems_Erdos269_DyadicShellSummability
import Definitions.Def_ErdosProblems_Erdos269_IntegralBranchExtinction
import Definitions.Def_ErdosProblems_Erdos269_PaperR7ActualOrbit
import Definitions.Def_ErdosProblems_Erdos269_PaperR7SeriesIdentification
import Definitions.Def_ErdosProblems_Erdos269_RationalLatticeReduction
import Definitions.Def_ErdosProblems_Erdos269_RationalityCarryBridge
import Definitions.Def_ErdosProblems_Erdos269_PaperR7RationalBridge
import Definitions.Def_ErdosProblems_Erdos269_PaperExactDenominatorR13
import Theorems.Thm_ErdosProblems_Erdos269_two_mul_heightNormalizer235
import Theorems.Thm_ErdosProblems_Erdos269_PaperR13_exact_denominators
import Theorems.Thm_ErdosProblems_Erdos269_PaperR13_firstClearingIndex_minimal
import Theorems.Thm_ErdosProblems_Erdos269_PaperR13_firstClearingIndex_spec
import Theorems.Thm_ErdosProblems_Erdos269_PaperR13_monomial235_dvd_iff
import Theorems.Thm_ErdosProblems_Erdos269_PaperR13_rationalTailState_cast
import Mathlib.Algebra.BigOperators.Group.Finset.Basic
import Mathlib.Algebra.BigOperators.Group.Finset.Sigma
import Mathlib.Algebra.BigOperators.Group.List.Basic
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Algebra.Ring.Parity
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Data.Finset.Card
import Mathlib.Data.Finset.Prod
import Mathlib.Data.Int.ModEq
import Mathlib.Data.Nat.Factorization.Basic
import Mathlib.Data.Nat.Find
import Mathlib.Data.Nat.Log
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.Nat.Prime.Int
import Mathlib.Data.Rat.Lemmas
import Mathlib.Tactic
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.InfiniteSum.Real

namespace PaperR7
end PaperR7

/-!
# Exact reduced denominators for the paper tail states

This module formalises the exact-denominator calculation in the short and long
papers.  The rational representative below is proved to cast to the literal
real tail state, so its `Rat.den` is the paper's positive reduced denominator.
-/

namespace ErdosProblems.Erdos269.PaperR13
open scoped BigOperators
open PaperR7













/-- At a positive scale, the half-height removes exactly one factor of two
from the boundary height. -/
theorem heightNormalizer235_eq_monomial (a : ℕ) (ha : 1 ≤ a) :
    heightNormalizer235 a =
      2 ^ (a - 1) * 3 ^ Nat.log 3 (2 ^ a) * 5 ^ Nat.log 5 (2 ^ a) := by
  apply Nat.mul_left_cancel (n := 2) (by norm_num)
  rw [two_mul_heightNormalizer235 a ha]
  unfold threePrimeHeight
  rw [Nat.log_pow (by norm_num : 1 < (2 : ℕ))]
  have hpow : 2 ^ a = 2 * 2 ^ (a - 1) := by
    calc
      2 ^ a = 2 ^ ((a - 1) + 1) := by congr 1 <;> omega
      _ = 2 * 2 ^ (a - 1) := by rw [pow_succ]; ring
  rw [hpow]
  ring



/-- The paper's smooth denominator divides the normalizer precisely at the
three integer-power thresholds. -/
theorem smoothPart_dvd_heightNormalizer235_iff {u v w a : ℕ} (ha : 1 ≤ a) :
    2 ^ u * 3 ^ v * 5 ^ w ∣ heightNormalizer235 a ↔
      2 ^ (u + 1) ≤ 2 ^ a ∧ 3 ^ v ≤ 2 ^ a ∧ 5 ^ w ≤ 2 ^ a := by
  rw [heightNormalizer235_eq_monomial a ha, monomial235_dvd_iff]
  rw [Nat.pow_le_pow_iff_right (by norm_num : 1 < (2 : ℕ))]
  rw [Nat.le_log_iff_pow_le (by norm_num : 1 < (3 : ℕ)) (by positivity)]
  rw [Nat.le_log_iff_pow_le (by norm_num : 1 < (5 : ℕ)) (by positivity)]
  omega





theorem clearingCondition_mono {u v w a b : ℕ} (hab : a ≤ b)
    (ha : ClearingCondition u v w a) : ClearingCondition u v w b := by
  rcases ha with ⟨ha1, h2, h3, h5⟩
  have hp : 2 ^ a ≤ 2 ^ b := Nat.pow_le_pow_right (by norm_num) hab
  exact ⟨ha1.trans hab, h2.trans hp, h3.trans hp, h5.trans hp⟩











/-- Because the three comparisons persist with the scale, their first valid
index characterises every later valid index. -/
theorem clearingCondition_iff_firstClearingIndex_le {u v w a : ℕ} :
    ClearingCondition u v w a ↔ firstClearingIndex u v w ≤ a := by
  constructor
  · exact firstClearingIndex_minimal
  · intro h
    exact clearingCondition_mono h (firstClearingIndex_spec u v w)





/-- The scaled state is integral exactly when the smooth denominator divides
its half-height normalizer. -/
theorem scaled_state_den_eq_one_iff {N : ℤ} {M B a : ℕ}
    (hM : 0 < M) (hB : 0 < B) (hB30 : Nat.Coprime B 30)
    (hcop : Nat.Coprime N.natAbs (M * B)) (ha : 1 ≤ a) :
    ((B : ℚ) * rationalTailState N (M * B) a).den = 1 ↔
      M ∣ heightNormalizer235 a := by
  rw [(exact_denominators hM hB hB30 hcop ha).2]
  constructor
  · intro h
    have hgcdDvd : Nat.gcd M (heightNormalizer235 a) ∣ M :=
      Nat.gcd_dvd_left _ _
    have hgcd : Nat.gcd M (heightNormalizer235 a) = M :=
      Nat.eq_of_dvd_of_div_eq_one hgcdDvd h
    exact Nat.gcd_eq_left_iff_dvd.mp hgcd
  · intro h
    rw [Nat.gcd_eq_left h, Nat.div_self hM]

/-- Literal first-clearing statement from the short paper and the long-paper
proposition.  The reduced state has denominator one exactly from the first
integer-power threshold onward. -/
theorem scaled_state_den_eq_one_iff_firstClearingIndex_le
    {N : ℤ} {u v w B a : ℕ}
    (hB : 0 < B) (hB30 : Nat.Coprime B 30)
    (hcop : Nat.Coprime N.natAbs (2 ^ u * 3 ^ v * 5 ^ w * B))
    (ha : 1 ≤ a) :
    ((B : ℚ) * rationalTailState N (2 ^ u * 3 ^ v * 5 ^ w * B) a).den = 1 ↔
      firstClearingIndex u v w ≤ a := by
  rw [scaled_state_den_eq_one_iff (by positivity) hB hB30 hcop ha]
  rw [smoothPart_dvd_heightNormalizer235_iff ha]
  rw [← clearingCondition_iff_firstClearingIndex_le]
  simp only [ClearingCondition, ha, true_and]
end ErdosProblems.Erdos269.PaperR13

open scoped BigOperators
open PaperR7
open ErdosProblems in
open ErdosProblems.Erdos269 in
open ErdosProblems.Erdos269.PaperR13 in
open ErdosProblems.Erdos269.PaperR7 in
theorem solution
    {N : ℤ} {u v w B a : ℕ}
    (hB : 0 < B) (hB30 : Nat.Coprime B 30)
    (hcop : Nat.Coprime N.natAbs (2 ^ u * 3 ^ v * 5 ^ w * B))
    (ha : 1 ≤ a)
    (hval : paperSeries235 =
      (N : ℝ) / ((2 ^ u * 3 ^ v * 5 ^ w * B : ℕ) : ℝ)) :
    ((rationalTailState N (2 ^ u * 3 ^ v * 5 ^ w * B) a : ℚ) : ℝ) =
        trueNormalizedState a ∧
      (rationalTailState N (2 ^ u * 3 ^ v * 5 ^ w * B) a).den =
        (2 ^ u * 3 ^ v * 5 ^ w * B) /
          Nat.gcd (2 ^ u * 3 ^ v * 5 ^ w) (heightNormalizer235 a) ∧
      ((B : ℚ) * rationalTailState N (2 ^ u * 3 ^ v * 5 ^ w * B) a).den =
        (2 ^ u * 3 ^ v * 5 ^ w) /
          Nat.gcd (2 ^ u * 3 ^ v * 5 ^ w) (heightNormalizer235 a) ∧
      (((B : ℚ) * rationalTailState N (2 ^ u * 3 ^ v * 5 ^ w * B) a).den = 1 ↔
        firstClearingIndex u v w ≤ a) := by
  have hcast := rationalTailState_cast (N := N)
    (D := 2 ^ u * 3 ^ v * 5 ^ w * B) (a := a) (by positivity) ha hval
  have hdens := exact_denominators (N := N)
    (M := 2 ^ u * 3 ^ v * 5 ^ w) (B := B) (a := a)
    (by positivity) hB hB30 hcop ha
  exact ⟨hcast, hdens.1, hdens.2,
    scaled_state_den_eq_one_iff_firstClearingIndex_le hB hB30 hcop ha⟩
