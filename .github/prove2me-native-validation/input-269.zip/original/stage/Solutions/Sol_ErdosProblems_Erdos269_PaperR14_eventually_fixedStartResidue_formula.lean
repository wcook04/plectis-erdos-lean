import Definitions.Def_ErdosProblems_Erdos269_BoundedRadixTailEscape
import Definitions.Def_ErdosProblems_Erdos269_ResidueEscape
import Definitions.Def_ErdosProblems_Erdos269_ThreePrimeRunningLcm
import Definitions.Def_ErdosProblems_Erdos269_RestrictedFloorSum
import Definitions.Def_ErdosProblems_Erdos269_DyadicBlockMassIdentity
import Definitions.Def_ErdosProblems_Erdos269_DyadicBlockThresholdPartition
import Definitions.Def_ErdosProblems_Erdos269_DyadicOrderedTailRecurrence
import Definitions.Def_ErdosProblems_Erdos269_DyadicShellSummability
import Definitions.Def_ErdosProblems_Erdos269_IntegralBranchExtinction
import Definitions.Def_ErdosProblems_Erdos269_JumpConstraintMajorant
import Definitions.Def_ErdosProblems_Shared_IrrationalRotationStaircase
import Definitions.Def_ErdosProblems_Erdos269_KernelCarryRank
import Definitions.Def_ErdosProblems_Erdos269_PaperR7ActualOrbit
import Definitions.Def_ErdosProblems_Erdos269_PaperR7SeriesIdentification
import Definitions.Def_ErdosProblems_Erdos269_RationalLatticeReduction
import Definitions.Def_ErdosProblems_Erdos269_RationalityCarryBridge
import Definitions.Def_ErdosProblems_Erdos269_PaperR7RationalBridge
import Definitions.Def_ErdosProblems_Erdos269_PaperR7WindowResults
import Theorems.Thm_ErdosProblems_Erdos269_trueNormalizedState_window
import Theorems.Thm_ErdosProblems_Erdos269_PaperR7_actualWindowBase_eq_product
import Theorems.Thm_ErdosProblems_Erdos269_PaperR7_actualWindowProduct_pos
import Theorems.Thm_ErdosProblems_Erdos269_PaperR14_eventually_floor_forcing_quotient
import Theorems.Thm_ErdosProblems_Erdos269_PaperR14_leastPositiveResidue_neg_eq_floor
import Mathlib.Algebra.BigOperators.Group.Finset.Basic
import Mathlib.Algebra.BigOperators.Group.Finset.Sigma
import Mathlib.Algebra.BigOperators.Group.List.Basic
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Algebra.Order.Floor.Ring
import Mathlib.Algebra.Order.Floor.Semiring
import Mathlib.Algebra.Ring.Parity
import Mathlib.Analysis.SpecialFunctions.Log.Base
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Data.Finset.Card
import Mathlib.Data.Finset.Prod
import Mathlib.Data.Fintype.Pigeonhole
import Mathlib.Data.Int.ModEq
import Mathlib.Data.Nat.Factorization.Basic
import Mathlib.Data.Nat.Log
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.Nat.Prime.Int
import Mathlib.Data.Real.Archimedean
import Mathlib.LinearAlgebra.Matrix.Block
import Mathlib.LinearAlgebra.Matrix.Determinant.Basic
import Mathlib.Tactic
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.InfiniteSum.Real

namespace ErdosProblems.Erdos269.PaperR14
end ErdosProblems.Erdos269.PaperR14

namespace PaperR7
end PaperR7

/-!
# The fixed-start residue limit from the long paper

For a fixed multiplier `B` and starting scale `lo`, the paper studies the
least positive residue of the actual window forcing modulo the actual window
product.  This file proves its eventual exact formula and limiting proportion.
The proof includes the delicate integral case: the finite quotients approach
`B X_lo` strictly from below, so their floors stabilise at `ceil (B X_lo) - 1`.
-/

namespace ErdosProblems.Erdos269.PaperR14
open Filter
open scoped Topology
open PaperR7
end ErdosProblems.Erdos269.PaperR14

open Filter
open scoped Topology
open PaperR7
open ErdosProblems in
open ErdosProblems.Erdos269 in
open ErdosProblems.Erdos269.PaperR14 in
open ErdosProblems.Erdos269.PaperR7 in
theorem solution (B lo : ℕ) (hB : 0 < B) :
    ∀ᶠ h in atTop,
      (leastPositiveResidue (actualWindowProduct lo h)
          (-((B : ℤ) * actualWindowForcing lo h)) : ℝ) =
        ((⌈(B : ℝ) * trueNormalizedState lo⌉ : ℤ) : ℝ) *
            (actualWindowProduct lo h : ℝ) -
          (B : ℝ) * trueNormalizedState lo *
            (actualWindowProduct lo h : ℝ) +
          (B : ℝ) * trueNormalizedState (lo + h) := by
  filter_upwards [eventually_floor_forcing_quotient B lo hB] with h hfloor
  have hC := actualWindowProduct_pos lo h
  have hlpr := leastPositiveResidue_neg_eq_floor
    (actualWindowProduct lo h) hC ((B : ℤ) * actualWindowForcing lo h)
  rw [hfloor] at hlpr
  have hwindow := trueNormalizedState_window lo h
  change trueNormalizedState (lo + h) =
    (actualWindowBase lo h : ℝ) * trueNormalizedState lo -
      (actualWindowForcing lo h : ℝ) at hwindow
  rw [actualWindowBase_eq_product] at hwindow
  have hlprR :
      (leastPositiveResidue (actualWindowProduct lo h)
          (-((B : ℤ) * actualWindowForcing lo h)) : ℝ) =
        (((actualWindowProduct lo h : ℕ) : ℤ) *
          (⌈(B : ℝ) * trueNormalizedState lo⌉ - 1 + 1) -
          (B : ℤ) * actualWindowForcing lo h : ℤ) := by
    exact_mod_cast hlpr
  rw [hlprR]
  push_cast at hwindow ⊢
  rw [hwindow]
  ring
