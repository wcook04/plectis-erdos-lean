import Definitions.Def_ErdosProblems_Erdos269_BoundedRadixTailEscape
import Definitions.Def_ErdosProblems_Erdos269_ResidueEscape
import Definitions.Def_ErdosProblems_Erdos269_ThreePrimeRunningLcm
import Definitions.Def_ErdosProblems_Erdos269_RestrictedFloorSum
import Definitions.Def_ErdosProblems_Erdos269_DyadicBlockMassIdentity
import Definitions.Def_ErdosProblems_Erdos269_DyadicBlockThresholdPartition
import Definitions.Def_ErdosProblems_Erdos269_DyadicOrderedTailRecurrence
import Definitions.Def_ErdosProblems_Erdos269_DyadicShellSummability
import Definitions.Def_ErdosProblems_Erdos269_IntegralBranchExtinction
import Definitions.Def_ErdosProblems_Erdos269_JumpConstraintMajorant
import Definitions.Def_ErdosProblems_Shared_IrrationalRotationStaircase
import Definitions.Def_ErdosProblems_Erdos269_KernelCarryRank
import Definitions.Def_ErdosProblems_Erdos269_PaperR7ActualOrbit
import Definitions.Def_ErdosProblems_Erdos269_PaperR7SeriesIdentification
import Definitions.Def_ErdosProblems_Erdos269_RationalLatticeReduction
import Definitions.Def_ErdosProblems_Erdos269_RationalityCarryBridge
import Definitions.Def_ErdosProblems_Erdos269_PaperR7RationalBridge
import Definitions.Def_ErdosProblems_Erdos269_PaperR7WindowResults
import Theorems.Thm_ErdosProblems_Erdos269_leastPositiveResidue_eq_natAbs_of_pos_le_modEq
import Mathlib.Algebra.BigOperators.Group.Finset.Basic
import Mathlib.Algebra.BigOperators.Group.Finset.Sigma
import Mathlib.Algebra.BigOperators.Group.List.Basic
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Algebra.Order.Floor.Ring
import Mathlib.Algebra.Order.Floor.Semiring
import Mathlib.Algebra.Ring.Parity
import Mathlib.Analysis.SpecialFunctions.Log.Base
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Data.Finset.Card
import Mathlib.Data.Finset.Prod
import Mathlib.Data.Fintype.Pigeonhole
import Mathlib.Data.Int.ModEq
import Mathlib.Data.Nat.Factorization.Basic
import Mathlib.Data.Nat.Log
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.Nat.Prime.Int
import Mathlib.Data.Real.Archimedean
import Mathlib.LinearAlgebra.Matrix.Block
import Mathlib.LinearAlgebra.Matrix.Determinant.Basic
import Mathlib.Tactic
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.InfiniteSum.Real

namespace ErdosProblems.Erdos269.PaperR14
end ErdosProblems.Erdos269.PaperR14

namespace PaperR7
end PaperR7

/-!
# The fixed-start residue limit from the long paper

For a fixed multiplier `B` and starting scale `lo`, the paper studies the
least positive residue of the actual window forcing modulo the actual window
product.  This file proves its eventual exact formula and limiting proportion.
The proof includes the delicate integral case: the finite quotients approach
`B X_lo` strictly from below, so their floors stabilise at `ceil (B X_lo) - 1`.
-/

namespace ErdosProblems.Erdos269.PaperR14
open Filter
open scoped Topology
open PaperR7
end ErdosProblems.Erdos269.PaperR14

open Filter
open scoped Topology
open PaperR7
open ErdosProblems in
open ErdosProblems.Erdos269 in
open ErdosProblems.Erdos269.PaperR14 in
open ErdosProblems.Erdos269.PaperR7 in
theorem solution (C : ℕ) (hC : 0 < C) (x : ℤ) :
    (leastPositiveResidue C (-x) : ℤ) =
      (C : ℤ) * (⌊(x : ℝ) / (C : ℝ)⌋ + 1) - x := by
  let q : ℤ := ⌊(x : ℝ) / (C : ℝ)⌋
  let c : ℤ := (C : ℤ) * (q + 1) - x
  have hCR : (0 : ℝ) < C := by exact_mod_cast hC
  have hfloor := Int.floor_le ((x : ℝ) / (C : ℝ))
  have hlt := Int.lt_floor_add_one ((x : ℝ) / (C : ℝ))
  have hxlt : (x : ℝ) < (q : ℝ) * (C : ℝ) + C := by
    have := (div_lt_iff₀ hCR).mp hlt
    dsimp [q] at this ⊢
    push_cast at this ⊢
    nlinarith
  have hqle : (q : ℝ) * (C : ℝ) ≤ x := by
    exact (le_div_iff₀ hCR).mp hfloor
  have hcposR : (0 : ℝ) < (c : ℝ) := by
    dsimp [c]
    push_cast
    linarith
  have hcleR : (c : ℝ) ≤ C := by
    dsimp [c]
    push_cast
    linarith
  have hcpos : 0 < c := by exact_mod_cast hcposR
  have hcle : Int.natAbs c ≤ C := by
    have hcleZ : c ≤ (C : ℤ) := by exact_mod_cast hcleR
    exact_mod_cast (show (Int.natAbs c : ℤ) ≤ (C : ℤ) by
      simpa [Int.natAbs_of_nonneg hcpos.le] using hcleZ)
  have hmod : Int.ModEq C c (-x) := by
    dsimp [c]
    convert Int.modEq_add_fac_self (a := -x) (t := q + 1) (n := (C : ℤ)) using 1 <;> ring
  have hres := leastPositiveResidue_eq_natAbs_of_pos_le_modEq hC hcpos hcle hmod
  have hcast : ((Int.natAbs c : ℕ) : ℤ) = c := by
    simp [Int.natAbs_of_nonneg hcpos.le]
  calc
    (leastPositiveResidue C (-x) : ℤ) = (Int.natAbs c : ℕ) := by exact_mod_cast hres
    _ = c := hcast
    _ = (C : ℤ) * (⌊(x : ℝ) / (C : ℝ)⌋ + 1) - x := by rfl
