import Definitions.Def_ErdosProblems_Erdos269_BoundedRadixTailEscape
import Definitions.Def_ErdosProblems_Erdos269_ResidueEscape
import Definitions.Def_ErdosProblems_Erdos269_ThreePrimeRunningLcm
import Definitions.Def_ErdosProblems_Erdos269_RestrictedFloorSum
import Definitions.Def_ErdosProblems_Erdos269_DyadicBlockMassIdentity
import Definitions.Def_ErdosProblems_Erdos269_DyadicBlockThresholdPartition
import Definitions.Def_ErdosProblems_Erdos269_DyadicOrderedTailRecurrence
import Definitions.Def_ErdosProblems_Erdos269_DyadicShellSummability
import Definitions.Def_ErdosProblems_Erdos269_IntegralBranchExtinction
import Definitions.Def_ErdosProblems_Erdos269_PaperR7ActualOrbit
import Definitions.Def_ErdosProblems_Erdos269_PaperR7SeriesIdentification
import Definitions.Def_ErdosProblems_Erdos269_RationalLatticeReduction
import Definitions.Def_ErdosProblems_Erdos269_RationalityCarryBridge
import Definitions.Def_ErdosProblems_Erdos269_PaperR7RationalBridge
import Definitions.Def_ErdosProblems_Erdos269_PaperExactDenominatorR13
import Theorems.Thm_ErdosProblems_Erdos269_heightNormalizer235_mul_windowMass_eq_int
import Theorems.Thm_ErdosProblems_Erdos269_PaperR13_heightNormalizer235_dvd_thirty_pow
import Theorems.Thm_ErdosProblems_Erdos269_PaperR13_rationalTailState_den
import Mathlib.Algebra.BigOperators.Group.Finset.Basic
import Mathlib.Algebra.BigOperators.Group.Finset.Sigma
import Mathlib.Algebra.BigOperators.Group.List.Basic
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Algebra.Ring.Parity
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Data.Finset.Card
import Mathlib.Data.Finset.Prod
import Mathlib.Data.Int.ModEq
import Mathlib.Data.Nat.Factorization.Basic
import Mathlib.Data.Nat.Find
import Mathlib.Data.Nat.Log
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.Nat.Prime.Int
import Mathlib.Data.Rat.Lemmas
import Mathlib.Tactic
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.InfiniteSum.Real

namespace PaperR7
end PaperR7

/-!
# Exact reduced denominators for the paper tail states

This module formalises the exact-denominator calculation in the short and long
papers.  The rational representative below is proved to cast to the literal
real tail state, so its `Rat.den` is the paper's positive reduced denominator.
-/

namespace ErdosProblems.Erdos269.PaperR13
open scoped BigOperators
open PaperR7







/-- Multiplying a reduced rational numerator by a natural number cancels
exactly the gcd with the denominator. -/
theorem den_nat_mul_int_div_nat {h M : ℕ} {N : ℤ} (hM : 0 < M)
    (hcop : Nat.Coprime N.natAbs M) :
    (((h : ℚ) * (N : ℚ) / (M : ℚ)).den) = M / Nat.gcd M h := by
  have hMZ : (M : ℤ) ≠ 0 := by exact_mod_cast hM.ne'
  have heq : (h : ℚ) * (N : ℚ) / (M : ℚ) =
      Rat.divInt ((h : ℤ) * N) (M : ℤ) := by
    rw [Rat.divInt_eq_div]
    push_cast
    rfl
  rw [heq, Rat.den_mk, if_neg hMZ, Int.gcd_def]
  simp only [Int.natAbs_natCast, Int.natAbs_mul]
  rw [hcop.gcd_mul_right_cancel h, Nat.gcd_comm]



/-- A rough denominator coprime to `30` is coprime to every paper
half-height normalizer. -/
theorem coprime_heightNormalizer235 {B a : ℕ} (hB : Nat.Coprime B 30)
    (ha : 1 ≤ a) : Nat.Coprime B (heightNormalizer235 a) := by
  exact Nat.Coprime.of_dvd_right (heightNormalizer235_dvd_thirty_pow a ha)
    (hB.pow_right a)
end ErdosProblems.Erdos269.PaperR13

open scoped BigOperators
open PaperR7
open ErdosProblems in
open ErdosProblems.Erdos269 in
open ErdosProblems.Erdos269.PaperR13 in
open ErdosProblems.Erdos269.PaperR7 in
theorem solution {N : ℤ} {M B a : ℕ}
    (hM : 0 < M) (hB : 0 < B) (hB30 : Nat.Coprime B 30)
    (hcop : Nat.Coprime N.natAbs (M * B)) (ha : 1 ≤ a) :
    (rationalTailState N (M * B) a).den =
        M * B / Nat.gcd M (heightNormalizer235 a) ∧
      ((B : ℚ) * rationalTailState N (M * B) a).den =
        M / Nat.gcd M (heightNormalizer235 a) := by
  have hD : 0 < M * B := Nat.mul_pos hM hB
  have hBh : Nat.Coprime B (heightNormalizer235 a) :=
    coprime_heightNormalizer235 hB30 ha
  have hgcd : Nat.gcd (M * B) (heightNormalizer235 a) =
      Nat.gcd M (heightNormalizer235 a) := by
    exact hBh.gcd_mul_right_cancel M
  constructor
  · rw [rationalTailState_den hD hcop ha, hgcd]
  · obtain ⟨z, hz⟩ := heightNormalizer235_mul_windowMass_eq_int 1 (a - 1)
    have haeq : 1 + (a - 1) = a := by omega
    rw [haeq] at hz
    have hMne : (M : ℚ) ≠ 0 := by exact_mod_cast hM.ne'
    have hBne : (B : ℚ) ≠ 0 := by exact_mod_cast hB.ne'
    have heq : (B : ℚ) * rationalTailState N (M * B) a =
        (heightNormalizer235 a : ℚ) * (N : ℚ) / (M : ℚ) -
          ((B * heightNormalizer235 a : ℕ) : ℤ) - ((B * z : ℕ) : ℤ) := by
      rw [rationalTailState, mul_sub, mul_sub, hz]
      push_cast
      field_simp [hMne, hBne]
    have hcopM : Nat.Coprime N.natAbs M :=
      Nat.Coprime.of_dvd_right (dvd_mul_right M B) hcop
    rw [heq, Rat.sub_intCast_den, Rat.sub_intCast_den]
    exact den_nat_mul_int_div_nat hM hcopM
