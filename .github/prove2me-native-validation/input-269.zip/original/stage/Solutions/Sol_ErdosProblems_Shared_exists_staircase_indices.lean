import Definitions.Def_ErdosProblems_Shared_IrrationalRotationStaircase
import Theorems.Thm_ErdosProblems_Shared_exists_pos_nat_fract_mem_Ioo
import Mathlib.Algebra.Order.Floor.Ring
import Mathlib.Algebra.Order.Floor.Semiring
import Mathlib.Analysis.SpecialFunctions.Log.Base
import Mathlib.Data.Fintype.Pigeonhole
import Mathlib.Data.Real.Archimedean
import Mathlib.LinearAlgebra.Matrix.Block
import Mathlib.LinearAlgebra.Matrix.Determinant.Basic
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Ring

/-!
# Irrational-rotation staircases and the carry-staircase determinant

Two independent pieces of reusable machinery.

* `ErdosProblems.Shared.exists_pos_nat_fract_mem_Ioo` : the **forward** orbit
  `n ↦ Int.fract (n * α)`, `n ≥ 1`, is dense in `[0,1]` as soon as no positive
  integer multiple of `α` is an integer.  The hypothesis is packaged as
  `NoIntegerOrbit`; for real `α` it is exactly irrationality, but it is often
  cheaper to verify directly.

* `ErdosProblems.Shared.det_carryStaircase` : the exact determinant
  `det (fun i j => if j ≤ i then t else 1) = t * (t - 1) ^ n`
  of the `(n+1)`-dimensional *carry staircase*.

Combined in `exists_staircase_indices`, they say that a pair of independent
rotations without integer returns realises an arbitrarily large staircase in
the two-dimensional carry `⌊fract (i * α) + fract (j * β)⌋`.  That is the
engine behind the three-prime running-LCM rank phase transition of Erdős #269.

Nothing here mentions a specific Erdős problem; the file is Mathlib-only.
-/

namespace ErdosProblems.Shared
open Set Matrix

/-! ## Forward orbits of a rotation without integer returns -/











/-! ## The carry staircase and its determinant -/

variable {R : Type*} [CommRing R]









/-! ## Realising an arbitrary staircase from two independent rotations -/
end ErdosProblems.Shared

open Set Matrix
variable {R : Type*} [CommRing R]
open ErdosProblems in
open ErdosProblems.Shared in
theorem solution {α β : ℝ}
    (hα : NoIntegerOrbit α) (hβ : NoIntegerOrbit β) (n : ℕ) :
    ∃ I J : Fin n → ℕ,
      (∀ a, 0 < I a) ∧ (∀ b, 0 < J b) ∧
      Function.Injective I ∧ Function.Injective J ∧
      ∀ a b : Fin n,
        ⌊Int.fract ((I a : ℝ) * α) + Int.fract ((J b : ℝ) * β)⌋
          = if (b : ℕ) ≤ (a : ℕ) then 1 else 0 := by
  obtain ⟨D, hD0, hD⟩ : ∃ D : ℝ, 0 < D ∧ D = 8 * (n : ℝ) + 4 :=
    ⟨8 * (n : ℝ) + 4, by positivity, rfl⟩
  have hrow : ∀ a : Fin n, ∃ i : ℕ, 0 < i ∧
      8 * ((a : ℕ) : ℝ) + 7 < Int.fract ((i : ℝ) * α) * D ∧
      Int.fract ((i : ℝ) * α) * D < 8 * ((a : ℕ) : ℝ) + 9 := by
    intro a
    have haR : ((a : ℕ) : ℝ) + 1 ≤ (n : ℝ) := by exact_mod_cast a.2
    have ha0 : (0 : ℝ) ≤ ((a : ℕ) : ℝ) := Nat.cast_nonneg _
    have hsplit : (8 * ((a : ℕ) : ℝ) + 9) / D
        = (8 * ((a : ℕ) : ℝ) + 7) / D + 2 / D := by ring
    have hlt : (8 * ((a : ℕ) : ℝ) + 7) / D < (8 * ((a : ℕ) : ℝ) + 9) / D := by
      rw [hsplit]
      have h2D : (0 : ℝ) < 2 / D := by positivity
      linarith
    have hlo : (0 : ℝ) ≤ (8 * ((a : ℕ) : ℝ) + 7) / D := by positivity
    have hhi : (8 * ((a : ℕ) : ℝ) + 9) / D ≤ 1 := by
      rw [div_le_one hD0, hD]; linarith
    obtain ⟨i, hi, h1, h2⟩ := exists_pos_nat_fract_mem_Ioo hα hlo hlt hhi
    rw [div_lt_iff₀ hD0] at h1
    rw [lt_div_iff₀ hD0] at h2
    exact ⟨i, hi, h1, h2⟩
  have hcol : ∀ b : Fin n, ∃ j : ℕ, 0 < j ∧
      8 * (n : ℝ) - 8 * ((b : ℕ) : ℝ) - 1 < Int.fract ((j : ℝ) * β) * D ∧
      Int.fract ((j : ℝ) * β) * D < 8 * (n : ℝ) - 8 * ((b : ℕ) : ℝ) + 1 := by
    intro b
    have hbR : ((b : ℕ) : ℝ) + 1 ≤ (n : ℝ) := by exact_mod_cast b.2
    have hb0 : (0 : ℝ) ≤ ((b : ℕ) : ℝ) := Nat.cast_nonneg _
    have hsplit : (8 * (n : ℝ) - 8 * ((b : ℕ) : ℝ) + 1) / D
        = (8 * (n : ℝ) - 8 * ((b : ℕ) : ℝ) - 1) / D + 2 / D := by ring
    have hlt : (8 * (n : ℝ) - 8 * ((b : ℕ) : ℝ) - 1) / D
        < (8 * (n : ℝ) - 8 * ((b : ℕ) : ℝ) + 1) / D := by
      rw [hsplit]
      have h2D : (0 : ℝ) < 2 / D := by positivity
      linarith
    have hlo : (0 : ℝ) ≤ (8 * (n : ℝ) - 8 * ((b : ℕ) : ℝ) - 1) / D := by
      apply div_nonneg _ hD0.le; linarith
    have hhi : (8 * (n : ℝ) - 8 * ((b : ℕ) : ℝ) + 1) / D ≤ 1 := by
      rw [div_le_one hD0, hD]; linarith
    obtain ⟨j, hj, h1, h2⟩ := exists_pos_nat_fract_mem_Ioo hβ hlo hlt hhi
    rw [div_lt_iff₀ hD0] at h1
    rw [lt_div_iff₀ hD0] at h2
    exact ⟨j, hj, h1, h2⟩
  choose I hIpos hIlo hIhi using hrow
  choose J hJpos hJlo hJhi using hcol
  have hIinj : Function.Injective I := by
    intro a a' heq
    by_contra hne
    have hlo1 := hIlo a; have hhi1 := hIhi a
    have hlo2 := hIlo a'; have hhi2 := hIhi a'
    rw [heq] at hhi1 hlo1
    rcases Nat.lt_trichotomy ((a : ℕ)) ((a' : ℕ)) with h | h | h
    · have : ((a : ℕ) : ℝ) + 1 ≤ ((a' : ℕ) : ℝ) := by exact_mod_cast h
      linarith
    · exact hne (Fin.val_injective h)
    · have : ((a' : ℕ) : ℝ) + 1 ≤ ((a : ℕ) : ℝ) := by exact_mod_cast h
      linarith
  have hJinj : Function.Injective J := by
    intro b b' heq
    by_contra hne
    have hlo1 := hJlo b; have hhi1 := hJhi b
    have hlo2 := hJlo b'; have hhi2 := hJhi b'
    rw [heq] at hhi1 hlo1
    rcases Nat.lt_trichotomy ((b : ℕ)) ((b' : ℕ)) with h | h | h
    · have : ((b : ℕ) : ℝ) + 1 ≤ ((b' : ℕ) : ℝ) := by exact_mod_cast h
      linarith
    · exact hne (Fin.val_injective h)
    · have : ((b' : ℕ) : ℝ) + 1 ≤ ((b : ℕ) : ℝ) := by exact_mod_cast h
      linarith
  refine ⟨I, J, hIpos, hJpos, hIinj, hJinj, ?_⟩
  intro a b
  have hIl := hIlo a; have hIh := hIhi a
  have hJl := hJlo b; have hJh := hJhi b
  have haR : ((a : ℕ) : ℝ) + 1 ≤ (n : ℝ) := by exact_mod_cast a.2
  have hbR : ((b : ℕ) : ℝ) + 1 ≤ (n : ℝ) := by exact_mod_cast b.2
  have ha0 : (0 : ℝ) ≤ ((a : ℕ) : ℝ) := Nat.cast_nonneg _
  have hb0 : (0 : ℝ) ≤ ((b : ℕ) : ℝ) := Nat.cast_nonneg _
  have hu0 := Int.fract_nonneg ((I a : ℝ) * α)
  have hv0 := Int.fract_nonneg ((J b : ℝ) * β)
  set u := Int.fract ((I a : ℝ) * α) with hu
  set v := Int.fract ((J b : ℝ) * β) with hv
  by_cases hba : (b : ℕ) ≤ (a : ℕ)
  · have hcmp : ((b : ℕ) : ℝ) ≤ ((a : ℕ) : ℝ) := by exact_mod_cast hba
    rw [if_pos hba, Int.floor_eq_iff]
    constructor
    · have key : (1 : ℝ) * D ≤ (u + v) * D := by
        have expand : (u + v) * D = u * D + v * D := by ring
        rw [expand, one_mul]
        linarith
      have h1 := le_of_mul_le_mul_right key hD0
      push_cast
      linarith
    · have key : (u + v) * D < 2 * D := by
        have expand : (u + v) * D = u * D + v * D := by ring
        rw [expand]
        linarith
      have h1 := lt_of_mul_lt_mul_right key hD0.le
      push_cast
      linarith
  · have hcmp : ((a : ℕ) : ℝ) + 1 ≤ ((b : ℕ) : ℝ) := by
      have hab : (a : ℕ) + 1 ≤ (b : ℕ) := by omega
      exact_mod_cast hab
    rw [if_neg hba, Int.floor_eq_iff]
    refine ⟨by push_cast; linarith, ?_⟩
    have key : (u + v) * D < 1 * D := by
      have expand : (u + v) * D = u * D + v * D := by ring
      rw [expand, one_mul]
      linarith
    have h1 := lt_of_mul_lt_mul_right key hD0.le
    push_cast
    linarith
