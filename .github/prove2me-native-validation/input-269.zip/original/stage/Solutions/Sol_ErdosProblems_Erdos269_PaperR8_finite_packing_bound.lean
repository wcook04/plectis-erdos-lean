import Definitions.Def_ErdosProblems_Erdos269_ThreePrimeRunningLcm
import Definitions.Def_ErdosProblems_Shared_IrrationalRotationStaircase
import Definitions.Def_ErdosProblems_Erdos269_KernelCarryRank
import Definitions.Def_ErdosProblems_Erdos269_PaperR7AnalyticInterfaces
import Definitions.Def_ErdosProblems_Erdos269_PaperR8UniformRank
import Mathlib.Algebra.BigOperators.Group.Finset.Basic
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Algebra.Order.Floor.Ring
import Mathlib.Algebra.Order.Floor.Semiring
import Mathlib.Algebra.Ring.Parity
import Mathlib.Analysis.Normed.Module.FiniteDimension
import Mathlib.Analysis.SpecialFunctions.Log.Base
import Mathlib.Data.ENNReal.Real
import Mathlib.Data.Finset.Card
import Mathlib.Data.Finset.Prod
import Mathlib.Data.Fintype.Pigeonhole
import Mathlib.Data.Nat.Log
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.Nat.Prime.Int
import Mathlib.Data.Real.Archimedean
import Mathlib.LinearAlgebra.Matrix.Block
import Mathlib.LinearAlgebra.Matrix.Determinant.Basic
import Mathlib.RingTheory.Algebraic.Basic
import Mathlib.Tactic
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Ring
import Mathlib.Topology.ContinuousMap.Bounded.Normed
import Mathlib.Topology.MetricSpace.Pseudo.Basic

namespace PaperR7
end PaperR7

/-!
# The infinite uniform finite-rank obstruction

The finite staircase minors alone do not prove a uniform lower bound. This
file uses their column separation inside a finite-dimensional bounded column
space, and a finite covering of a compact ball. Row factors in an arbitrary
separated representation need not be bounded; the subspace is formed by
intersecting their algebraic span with the space of bounded functions.

The final infimum ranges over ALL finite-separated-rank matrices. It uses an
extended nonnegative supremum so that unbounded approximants have infinite
uniform error, never the spurious zero returned by an unbounded real iSup.
The resulting finite value is also identified after conversion to the reals.
All proof text is an uncompiled candidate against the packet's pinned Mathlib.
-/

namespace ErdosProblems.Erdos269.PaperR8
open PaperR7 ErdosProblems.Shared Set Metric
open scoped BigOperators Topology BoundedContinuousFunction ENNReal
end ErdosProblems.Erdos269.PaperR8

open PaperR7 ErdosProblems.Shared Set Metric
open scoped BigOperators Topology BoundedContinuousFunction ENNReal
open ErdosProblems in
open ErdosProblems.Erdos269 in
open ErdosProblems.Erdos269.PaperR8 in
open ErdosProblems.Erdos269.PaperR7 in
theorem solution
    (V : Type*) [NormedAddCommGroup V] [NormedSpace ℝ V] [FiniteDimensional ℝ V]
    (M δ : ℝ) (hδ : 0 < δ) :
    ∃ n : ℕ, ∀ v : Fin n → V, (∀ i, ‖v i‖ ≤ M) →
      ∃ i j, i ≠ j ∧ dist (v i) (v j) < δ := by
  classical
  -- Mathlib/Analysis/Normed/Module/FiniteDimension.lean: real proper-space instance.
  -- Mathlib/Topology/MetricSpace/Pseudo/Basic.lean: Metric.totallyBounded_iff.
  have hcompact : IsCompact (closedBall (0 : V) M) := isCompact_closedBall _ _
  obtain ⟨s, hs, hcover⟩ := Metric.totallyBounded_iff.mp hcompact.totallyBounded
    (δ / 3) (by linarith)
  letI : Fintype s := hs.fintype
  refine ⟨Fintype.card s + 1, ?_⟩
  intro v hv
  have hc : ∀ i : Fin (Fintype.card s + 1),
      ∃ x : s, dist (v i) (x : V) < δ / 3 := by
    intro i
    have hi : v i ∈ closedBall (0 : V) M := by
      simpa only [mem_closedBall, dist_zero_right] using hv i
    have h := hcover hi
    rcases Set.mem_iUnion.mp h with ⟨x, hx⟩
    rcases Set.mem_iUnion.mp hx with ⟨hxs, hball⟩
    exact ⟨⟨x, hxs⟩, hball⟩
  choose centre hcentre using hc
  by_contra hno
  have hinj : Function.Injective centre := by
    intro i j hij
    by_contra hne
    have hge : δ ≤ dist (v i) (v j) := by
      by_contra hlt
      exact hno ⟨i, j, hne, lt_of_not_ge hlt⟩
    have hi := hcentre i
    have hj : dist (centre i : V) (v j) < δ / 3 := by
      rw [hij, dist_comm]
      exact hcentre j
    have htriangle := dist_triangle (v i) (centre i : V) (v j)
    linarith
  -- Mathlib/Data/Fintype/Card.lean: Fintype.card_le_of_injective.
  have hcard := Fintype.card_le_of_injective centre hinj
  simp only [Fintype.card_fin] at hcard
  omega
