import Definitions.Def_ErdosProblems_Erdos269_PaperR7FiniteCutRank
import Mathlib.Data.Fintype.BigOperators
import Mathlib.LinearAlgebra.Dimension.Constructions
import Mathlib.LinearAlgebra.LinearIndependent.Basic
import Mathlib.LinearAlgebra.Matrix.Rank
import Mathlib.Tactic

/-!
# Paper-complete campaign, round 7: the complete finite cut-rank formula

Target: short-note `res:finite-cut-rank`.  This file generalises the supplied
rational interval-difference engine to an arbitrary field, proves independence
except for the two extreme columns, removes exactly that redundancy, and states
the result using `Matrix.rank`. Repetitions and permutations of columns are
handled by a column-range equality, not an extra independence assumption.

Authored against Lean 4.29.1 and the packet's Mathlib pin.
No admitted statements or additional axioms are introduced.
-/

namespace ErdosProblems.Erdos269.PaperR7
open scoped BigOperators
open Module Submodule

variable {F : Type*} [Field F]
end ErdosProblems.Erdos269.PaperR7

open scoped BigOperators
open Module Submodule
variable {F : Type*} [Field F]
open ErdosProblems in
open ErdosProblems.Erdos269 in
open ErdosProblems.Erdos269.PaperR7 in
theorem solution (c : F) {m : ℕ} (hm : 0 < m)
    (E : Finset ℕ) (hmE : m ∈ E) :
    cutSpan c m E = cutSpan c m (E.erase 0) := by
  classical
  apply le_antisymm
  · apply Submodule.span_le.mpr
    rintro _ ⟨k, rfl⟩
    by_cases hk0 : (k : ℕ) = 0
    · have hmerase : m ∈ E.erase 0 := Finset.mem_erase.mpr ⟨Nat.ne_of_gt hm, hmE⟩
      have hmem : cutVector c m m ∈ cutSpan c m (E.erase 0) :=
        Submodule.subset_span ⟨⟨m, hmerase⟩, rfl⟩
      have heq : cutVector c m (k : ℕ) = c • cutVector c m m := by
        ext i
        simp [cutVector, hk0, i.isLt]
      show cutVector c m (k : ℕ) ∈ (cutSpan c m (E.erase 0) : Set (Fin m → F))
      rw [SetLike.mem_coe, heq]
      exact Submodule.smul_mem _ _ hmem
    · exact Submodule.subset_span ⟨⟨k, Finset.mem_erase.mpr ⟨hk0, k.property⟩⟩, rfl⟩
  · apply Submodule.span_mono
    rintro _ ⟨k, rfl⟩
    exact ⟨⟨k, Finset.mem_of_mem_erase k.property⟩, rfl⟩
