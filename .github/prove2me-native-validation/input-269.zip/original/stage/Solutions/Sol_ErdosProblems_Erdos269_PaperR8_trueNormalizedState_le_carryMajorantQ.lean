import Definitions.Def_ErdosProblems_Erdos269_BoundedRadixTailEscape
import Definitions.Def_ErdosProblems_Erdos269_ResidueEscape
import Definitions.Def_ErdosProblems_Erdos269_ThreePrimeRunningLcm
import Definitions.Def_ErdosProblems_Erdos269_RestrictedFloorSum
import Definitions.Def_ErdosProblems_Erdos269_DyadicBlockMassIdentity
import Definitions.Def_ErdosProblems_Erdos269_DyadicBlockThresholdPartition
import Definitions.Def_ErdosProblems_Erdos269_DyadicOrderedTailRecurrence
import Definitions.Def_ErdosProblems_Erdos269_DyadicShellSummability
import Definitions.Def_ErdosProblems_Erdos269_IntegralBranchExtinction
import Definitions.Def_ErdosProblems_Erdos269_JumpConstraintMajorant
import Definitions.Def_ErdosProblems_Shared_IrrationalRotationStaircase
import Definitions.Def_ErdosProblems_Erdos269_KernelCarryRank
import Definitions.Def_ErdosProblems_Erdos269_PaperR7ActualOrbit
import Definitions.Def_ErdosProblems_Erdos269_PaperR7SeriesIdentification
import Definitions.Def_ErdosProblems_Erdos269_RationalLatticeReduction
import Definitions.Def_ErdosProblems_Erdos269_RationalityCarryBridge
import Definitions.Def_ErdosProblems_Erdos269_PaperR7RationalBridge
import Definitions.Def_ErdosProblems_Erdos269_PaperR7WindowResults
import Definitions.Def_ErdosProblems_Erdos269_PaperR8RankMajorant
import Theorems.Thm_ErdosProblems_Erdos269_PaperR7_tsum_exponentKernel235_shell
import Theorems.Thm_ErdosProblems_Erdos269_PaperR7_summable_exponentKernel235
import Theorems.Thm_ErdosProblems_Erdos269_PaperR8_tailShellExponent_injective
import Theorems.Thm_ErdosProblems_Erdos269_PaperR8_tailShellExponent_lower
import Theorems.Thm_ErdosProblems_Erdos269_PaperR8_finite_normalised_tail_le_Q
import Mathlib.Algebra.BigOperators.Group.Finset.Basic
import Mathlib.Algebra.BigOperators.Group.Finset.Sigma
import Mathlib.Algebra.BigOperators.Group.List.Basic
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Algebra.Order.Floor.Ring
import Mathlib.Algebra.Order.Floor.Semiring
import Mathlib.Algebra.Ring.Parity
import Mathlib.Analysis.SpecialFunctions.Log.Base
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Data.Finset.Card
import Mathlib.Data.Finset.Prod
import Mathlib.Data.Fintype.Pigeonhole
import Mathlib.Data.Int.ModEq
import Mathlib.Data.Nat.Factorization.Basic
import Mathlib.Data.Nat.Log
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.Nat.Prime.Int
import Mathlib.Data.Real.Archimedean
import Mathlib.LinearAlgebra.Matrix.Block
import Mathlib.LinearAlgebra.Matrix.Determinant.Basic
import Mathlib.Tactic
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.InfiniteSum.Order
import Mathlib.Topology.Algebra.InfiniteSum.Real

namespace PaperR7
end PaperR7

/-!
# The actual height-rank majorant (round 8)

This file supplies the missing geometric summation over height ranks, not a
comparison of the much larger dyadic-shell bound with `carryMajorantQ`.
It uses the live round-7 definitions without changing any of them.

Proof text: not elaborated in this return. No additional hypotheses are hidden
in the final theorem. Mathlib source checks use commit
`5e932f97dd25535344f80f9dd8da3aab83df0fe6`.
-/

namespace ErdosProblems.Erdos269.PaperR8
open scoped BigOperators
open PaperR7
end ErdosProblems.Erdos269.PaperR8

open scoped BigOperators
open PaperR7
open ErdosProblems in
open ErdosProblems.Erdos269 in
open ErdosProblems.Erdos269.PaperR8 in
open ErdosProblems.Erdos269.PaperR7 in
theorem solution (a : ℕ) :
    trueNormalizedState a ≤ (carryMajorantQ (paperJumpIndex a) : ℝ) := by
  classical
  let f : TailShellIndex a → ℝ := fun z =>
    (threePrimeHeight 2 3 5 (2 ^ a) : ℝ) / 2 *
      exponentKernel235 (tailShellExponent a z)
  have hs0 : Summable (fun z : TailShellIndex a =>
      exponentKernel235 (tailShellExponent a z)) :=
    summable_exponentKernel235.comp_injective (tailShellExponent_injective a)
  have hs : Summable f := hs0.mul_left _
  have htsum : (∑' z : TailShellIndex a, f z) = trueNormalizedState a := by
    -- Mathlib/Topology/Algebra/InfiniteSum/Constructions.lean: Summable.tsum_sigma.
    rw [hs.tsum_sigma]
    change (∑' n : ℕ, ∑' e : {e : Exponent235 // e ∈ dyadicSmoothShell235 (a + n)},
      (threePrimeHeight 2 3 5 (2 ^ a) : ℝ) / 2 * exponentKernel235 e.val) = _
    simp_rw [tsum_mul_left, tsum_exponentKernel235_shell]
    rfl
  rw [← htsum]
  -- Mathlib/Topology/Algebra/InfiniteSum/Order.lean:
  -- Summable.tsum_le_of_sum_le.
  apply hs.tsum_le_of_sum_le
  intro t
  let s := t.image (tailShellExponent a)
  have heq : (∑ z ∈ t, f z) =
      ∑ e ∈ s, (threePrimeHeight 2 3 5 (2 ^ a) : ℝ) / 2 * exponentKernel235 e := by
    symm
    apply Finset.sum_image
    intro z _ w _ h
    exact tailShellExponent_injective a h
  rw [heq]
  apply finite_normalised_tail_le_Q a s
  intro e he
  obtain ⟨z, _hz, rfl⟩ := Finset.mem_image.mp he
  exact tailShellExponent_lower a z
