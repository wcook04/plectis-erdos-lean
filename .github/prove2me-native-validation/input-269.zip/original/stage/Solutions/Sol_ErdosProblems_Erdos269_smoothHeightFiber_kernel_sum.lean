import Definitions.Def_ErdosProblems_Erdos269_ThreePrimeRunningLcm
import Mathlib.Algebra.BigOperators.Group.Finset.Basic
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Algebra.Ring.Parity
import Mathlib.Data.Finset.Card
import Mathlib.Data.Finset.Prod
import Mathlib.Data.Nat.Log
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.Nat.Prime.Int
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Ring

/-!
# Erdős #269: the three-prime running-LCM coordinate

This module starts the problem-owned formalization of the first unresolved
three-prime case.  It records the exact computational height used by the
running-LCM representation, its cubic majorant, the smallest non-separation
fixture for `{2,3,5}`, the variable-base tail-state update, and the uniform
quadratic bound for actual filtered smooth-number shells.

No declaration here asserts irrationality or transcendence of a three-prime
value.  The missing producer is still an infinite residue-escape or genuinely
higher-dimensional analytic theorem.
-/

namespace ErdosProblems.Erdos269
open scoped BigOperators































/-! ## Finite pure-power jump enumeration -/

















/-! ## Single-coordinate jump ratios -/













/-! ## Finite jump grouping -/
end ErdosProblems.Erdos269

open scoped BigOperators
open ErdosProblems in
open ErdosProblems.Erdos269 in
theorem solution
    (p q r hp hq hr H : ℕ) :
    (∑ e ∈ smoothHeightFiber p q r hp hq hr H,
      threePrimeKernelQ p q r e.1 e.2.1 e.2.2) =
      (smoothHeightFiber p q r hp hq hr H).card • ((H : ℚ)⁻¹) := by
  classical
  calc
    (∑ e ∈ smoothHeightFiber p q r hp hq hr H,
        threePrimeKernelQ p q r e.1 e.2.1 e.2.2) =
        ∑ _e ∈ smoothHeightFiber p q r hp hq hr H, ((H : ℚ)⁻¹) := by
      apply Finset.sum_congr rfl
      intro e he
      have hheight : smoothPointHeight p q r e = H :=
        (Finset.mem_filter.mp he).2
      simpa [threePrimeKernelQ, smoothPointHeight, hheight]
    _ = (smoothHeightFiber p q r hp hq hr H).card • ((H : ℚ)⁻¹) := by
      simp
