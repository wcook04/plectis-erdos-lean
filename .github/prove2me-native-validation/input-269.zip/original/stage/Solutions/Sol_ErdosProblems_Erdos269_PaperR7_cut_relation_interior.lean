import Definitions.Def_ErdosProblems_Erdos269_PaperR7FiniteCutRank
import Mathlib.Data.Fintype.BigOperators
import Mathlib.LinearAlgebra.Dimension.Constructions
import Mathlib.LinearAlgebra.LinearIndependent.Basic
import Mathlib.LinearAlgebra.Matrix.Rank
import Mathlib.Tactic

/-!
# Paper-complete campaign, round 7: the complete finite cut-rank formula

Target: short-note `res:finite-cut-rank`.  This file generalises the supplied
rational interval-difference engine to an arbitrary field, proves independence
except for the two extreme columns, removes exactly that redundancy, and states
the result using `Matrix.rank`. Repetitions and permutations of columns are
handled by a column-range equality, not an extra independence assumption.

Authored against Lean 4.29.1 and the packet's Mathlib pin.
No admitted statements or additional axioms are introduced.
-/

namespace ErdosProblems.Erdos269.PaperR7
open scoped BigOperators
open Module Submodule

variable {F : Type*} [Field F]





/-- The discrete derivative detects exactly the interior cut at that row. -/
theorem cutVector_adjacent (c : F) {m j : ℕ} (hj : 0 < j) (hjm : j < m)
    (k : ℕ) :
    cutVector c m k ⟨j - 1, by omega⟩ - cutVector c m k ⟨j, hjm⟩ =
      if k = j then 1 - c else 0 := by
  unfold cutVector
  by_cases hkj : k = j
  · subst k
    simp [show j - 1 < j by omega]
  · by_cases hk : j < k
    · simp [hk, show j - 1 < k by omega, hkj]
    · simp [hk, show ¬ j - 1 < k by omega, hkj]
end ErdosProblems.Erdos269.PaperR7

open scoped BigOperators
open Module Submodule
variable {F : Type*} [Field F]
open ErdosProblems in
open ErdosProblems.Erdos269 in
open ErdosProblems.Erdos269.PaperR7 in
theorem solution (c : F) (hc : c ≠ 1) {m : ℕ}
    (E : Finset ℕ) (g : E → F)
    (hg : (∑ k : E, g k • cutVector c m k) = 0)
    (j : E) (hj : 0 < (j : ℕ)) (hjm : (j : ℕ) < m) : g j = 0 := by
  classical
  have hleft := congrFun hg (⟨(j : ℕ) - 1, by omega⟩ : Fin m)
  have hright := congrFun hg (⟨(j : ℕ), hjm⟩ : Fin m)
  have hdiff :
      (∑ k : E, g k *
        (cutVector c m k ⟨(j : ℕ) - 1, by omega⟩ -
         cutVector c m k ⟨(j : ℕ), hjm⟩)) = 0 := by
    simp only [Finset.sum_apply, Pi.smul_apply, smul_eq_mul, Pi.zero_apply] at hleft hright
    simp only [mul_sub, Finset.sum_sub_distrib]
    rw [hleft, hright, sub_self]
  have hterm : ∀ k : E,
      g k *
        (cutVector c m k ⟨(j : ℕ) - 1, by omega⟩ -
         cutVector c m k ⟨(j : ℕ), hjm⟩) =
          if k = j then g j * (1 - c) else 0 := by
    intro k
    rw [cutVector_adjacent c hj hjm]
    by_cases hkj : k = j
    · subst k
      simp
    · have hval : (k : ℕ) ≠ (j : ℕ) := fun h => hkj (Subtype.ext h)
      simp [hkj, hval]
  simp_rw [hterm] at hdiff
  have hprod : g j * (1 - c) = 0 := by simpa using hdiff
  exact (mul_eq_zero.mp hprod).resolve_right (sub_ne_zero.mpr (Ne.symm hc))
