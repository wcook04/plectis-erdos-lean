import Definitions.Def_ErdosProblems_Erdos269_ThreePrimeRunningLcm
import Definitions.Def_ErdosProblems_Shared_IrrationalRotationStaircase
import Definitions.Def_ErdosProblems_Erdos269_KernelCarryRank
import Definitions.Def_ErdosProblems_Erdos269_PaperR7AnalyticInterfaces
import Definitions.Def_ErdosProblems_Erdos269_PaperR8UniformRank
import Mathlib.Algebra.BigOperators.Group.Finset.Basic
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Algebra.Order.Floor.Ring
import Mathlib.Algebra.Order.Floor.Semiring
import Mathlib.Algebra.Ring.Parity
import Mathlib.Analysis.Normed.Module.FiniteDimension
import Mathlib.Analysis.SpecialFunctions.Log.Base
import Mathlib.Data.ENNReal.Real
import Mathlib.Data.Finset.Card
import Mathlib.Data.Finset.Prod
import Mathlib.Data.Fintype.Pigeonhole
import Mathlib.Data.Nat.Log
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.Nat.Prime.Int
import Mathlib.Data.Real.Archimedean
import Mathlib.LinearAlgebra.Matrix.Block
import Mathlib.LinearAlgebra.Matrix.Determinant.Basic
import Mathlib.RingTheory.Algebraic.Basic
import Mathlib.Tactic
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Ring
import Mathlib.Topology.ContinuousMap.Bounded.Normed
import Mathlib.Topology.MetricSpace.Pseudo.Basic

namespace PaperR7
end PaperR7

/-!
# The infinite uniform finite-rank obstruction

The finite staircase minors alone do not prove a uniform lower bound. This
file uses their column separation inside a finite-dimensional bounded column
space, and a finite covering of a compact ball. Row factors in an arbitrary
separated representation need not be bounded; the subspace is formed by
intersecting their algebraic span with the space of bounded functions.

The final infimum ranges over ALL finite-separated-rank matrices. It uses an
extended nonnegative supremum so that unbounded approximants have infinite
uniform error, never the spurious zero returned by an unbounded real iSup.
The resulting finite value is also identified after conversion to the reals.
All proof text is an uncompiled candidate against the packet's pinned Mathlib.
-/

namespace ErdosProblems.Erdos269.PaperR8
open PaperR7 ErdosProblems.Shared Set Metric
open scoped BigOperators Topology BoundedContinuousFunction ENNReal
end ErdosProblems.Erdos269.PaperR8

open PaperR7 ErdosProblems.Shared Set Metric
open scoped BigOperators Topology BoundedContinuousFunction ENNReal
open ErdosProblems in
open ErdosProblems.Erdos269 in
open ErdosProblems.Erdos269.PaperR8 in
open ErdosProblems.Erdos269.PaperR7 in
theorem solution (A : ℕ → ℕ → ℝ) (hA : FiniteSeparatedRank A)
    (M : ℝ) (hM : 0 ≤ M) (hbound : ∀ i j, |A i j| ≤ M) :
    ∃ V : Submodule ℝ BoundedColumn, FiniteDimensional ℝ V ∧
      ∃ v : ℕ → V, (∀ i j, ((v j : BoundedColumn) i) = A i j) ∧
        ∀ j, ‖v j‖ ≤ M := by
  classical
  obtain ⟨d, f, g, hrep⟩ := hA
  let W : Submodule ℝ (ℕ → ℝ) := Submodule.span ℝ (Set.range f)
  -- Mathlib/LinearAlgebra/FiniteDimensional/Defs.lean: span_of_finite, of_injective.
  letI : FiniteDimensional ℝ W := FiniteDimensional.span_of_finite ℝ (Set.finite_range f)
  let V : Submodule ℝ BoundedColumn :=
    { carrier := {u | (u : ℕ → ℝ) ∈ W}
      zero_mem' := W.zero_mem
      add_mem' := fun hu hv => W.add_mem hu hv
      smul_mem' := fun c u hu => W.smul_mem c hu }
  let F : V →ₗ[ℝ] W :=
    { toFun := fun u => ⟨(u.val : ℕ → ℝ), u.property⟩
      map_add' := fun _ _ => rfl
      map_smul' := fun _ _ => rfl }
  have hF : Function.Injective F := by
    intro u v huv
    apply Subtype.ext
    apply BoundedContinuousFunction.ext
    intro i
    exact congrFun (congrArg Subtype.val huv) i
  letI : FiniteDimensional ℝ V := FiniteDimensional.of_injective F hF
  -- Mathlib/Topology/ContinuousMap/Bounded/Normed.lean: ofNormedAddCommGroupDiscrete.
  let col : ℕ → BoundedColumn := fun j =>
    BoundedContinuousFunction.ofNormedAddCommGroupDiscrete (fun i => A i j) M
      (fun i => by simpa only [Real.norm_eq_abs] using hbound i j)
  have hcol : ∀ j, col j ∈ V := by
    intro j
    change (fun i => A i j) ∈ W
    have heq : (fun i => A i j) = ∑ k : Fin d, (g k j) • f k := by
      funext i
      simpa only [Finset.sum_apply, Pi.smul_apply, smul_eq_mul, mul_comm] using hrep i j
    rw [heq]
    exact W.sum_mem (fun k _ => W.smul_mem (g k j) (Submodule.subset_span ⟨k, rfl⟩))
  refine ⟨V, inferInstance, fun j => ⟨col j, hcol j⟩, ?_, ?_⟩
  · intro i j
    rfl
  · intro j
    change ‖col j‖ ≤ M
    -- Mathlib/Topology/ContinuousMap/Bounded/Normed.lean: norm_le.
    exact (BoundedContinuousFunction.norm_le hM).mpr
      (fun i => by simpa only [Real.norm_eq_abs] using hbound i j)
