import Definitions.Def_ErdosProblems_Erdos269_PaperCompleteR20_StripDecomposition
import Mathlib.Algebra.BigOperators.Intervals
import Mathlib.Data.Real.Basic
import Mathlib.Tactic

/-!
# First-entry strips in a nested finite family

A point contributes to every later set after its first appearance. This
finite identity separates cancellation in the common interior from the
three moving boundary strips of a cubic difference.
-/


open scoped BigOperators

open ErdosProblems.Erdos269.PaperCompleteR20

theorem ErdosProblems.Erdos269.PaperCompleteR20.nested_finite_strip_decomposition {α : Type*} [DecidableEq α]
    (T : ℕ → Finset α) (hT : Monotone T) (F : ℕ → α → ℝ) (σ : ℕ) :
    (∑ ν ∈ Finset.range (σ + 1), ∑ x ∈ T ν, F ν x) =
      ∑ s ∈ Finset.range (σ + 1), ∑ x ∈ entryStrip T s,
        ∑ ν ∈ Finset.Icc s σ, F ν x := by sorry
