import Definitions.Def_ErdosProblems_Erdos269_PaperCompleteR20_StripDecomposition
import Mathlib.Algebra.BigOperators.Intervals
import Mathlib.Data.Real.Basic
import Mathlib.Tactic

/-!
# First-entry strips in a nested finite family

A point contributes to every later set after its first appearance. This
finite identity separates cancellation in the common interior from the
three moving boundary strips of a cubic difference.
-/


open scoped BigOperators

open ErdosProblems.Erdos269.PaperCompleteR20

theorem ErdosProblems.Erdos269.PaperCompleteR20.cubic_difference_boundary_strips {α : Type*} [DecidableEq α]
    (T : ℕ → Finset α) (hT : Monotone T) (w : α → ℝ) :
    (∑ x ∈ T 0, w x) - 3 * (∑ x ∈ T 1, w x) +
        3 * (∑ x ∈ T 2, w x) - (∑ x ∈ T 3, w x) =
      -(∑ x ∈ T 1 \ T 0, w x) + 2 * (∑ x ∈ T 2 \ T 1, w x) -
        (∑ x ∈ T 3 \ T 2, w x) := by sorry
