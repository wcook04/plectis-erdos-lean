import Mathlib.Tactic

/-!
# Erdős #269: bounded-radix tail escape

Consider an affine orbit
`x (n + 1) = P n * x n - c n` with integral `c n` and radices
`2 ≤ P n ≤ 30`.  If the orbit is eventually always within `1/31` of an
integer, the corresponding errors grow by at least a factor of two at every
step; hence one of the states is itself integral.  Otherwise the orbit is at
least `1/31` from every integer at arbitrarily late indices.

The integral state in the first alternative need not be zero.  The theorem
also makes no assertion that the separated indices are eventually all
indices, have positive density, or have unbounded distance from the integers.
-/

namespace ErdosProblems.Erdos269

/-- A real number lies strictly within `δ` of an integer. -/
def NearInteger (x δ : ℝ) : Prop :=
  ∃ z : ℤ, |x - (z : ℝ)| < δ

/-- A real number is at least `δ` from every integer. -/
def FarFromIntegers (x δ : ℝ) : Prop :=
  ∀ z : ℤ, δ ≤ |x - (z : ℝ)|









end ErdosProblems.Erdos269
