import Definitions.Def_ErdosProblems_Erdos269_ThreePrimeRunningLcm
import Definitions.Def_ErdosProblems_Shared_IrrationalRotationStaircase
import Definitions.Def_ErdosProblems_Erdos269_KernelCarryRank
import Mathlib.Algebra.BigOperators.Group.Finset.Basic
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Algebra.Order.Floor.Ring
import Mathlib.Algebra.Order.Floor.Semiring
import Mathlib.Algebra.Ring.Parity
import Mathlib.Analysis.SpecialFunctions.Log.Base
import Mathlib.Data.Finset.Card
import Mathlib.Data.Finset.Prod
import Mathlib.Data.Fintype.Pigeonhole
import Mathlib.Data.Nat.Log
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.Nat.Prime.Int
import Mathlib.Data.Real.Archimedean
import Mathlib.LinearAlgebra.Matrix.Block
import Mathlib.LinearAlgebra.Matrix.Determinant.Basic
import Mathlib.RingTheory.Algebraic.Basic
import Mathlib.Tactic
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Ring

/-!
# Round 7: proved algebra around explicitly unresolved analytic inputs

This file DOES NOT prove the two-prime transcendence theorem. Its final algebraic
step is separated from THREE hypotheses still requiring analytic proofs:
transcendence of the specified Hecke--Mahler value, and the two identities for
the actual series. The parameters are visible, not axioms or admitted theorems.

It also proves the constant rank-one upper witness for the uniform carry
approximation. The lower bound over every finite separated rank remains open
as a formalisation obligation in this return.

Validation: authored, not compiled. No admissions.
-/

namespace ErdosProblems.Erdos269.PaperR7

open Polynomial

/-- Exact value named `A` on the page; this definition makes no arithmetic assertion. -/
noncomputable def twoPrimeHeckeValue (p q : ℕ) : ℝ :=
  ∑' n : ℕ, ((p : ℝ)⁻¹) ^ n *
    ((q : ℝ)⁻¹) ^ ⌊(n : ℝ) * Real.logb q p⌋₊



noncomputable def distinctValuePolynomial (p q : ℚ) : ℚ[X] :=
  C ((q - p) / (q - 1)) * X + C (p / (q - 1))

noncomputable def repeatedValuePolynomial (p q : ℚ) : ℚ[X] :=
  C ((p + q - 1) / (q - 1)) * X - C ((p - 1) / (q - 1)) * X ^ 2



/-- The normalised real-valued carry matrix, using the actual integer-log carry. -/
noncomputable def realCarryMatrix (p q r i j : ℕ) : ℝ :=
  ((r : ℝ)⁻¹) ^ logCarry r (p ^ i) (q ^ j)



end ErdosProblems.Erdos269.PaperR7
