import Mathlib.Data.Fintype.BigOperators
import Mathlib.LinearAlgebra.Dimension.Constructions
import Mathlib.LinearAlgebra.LinearIndependent.Basic
import Mathlib.LinearAlgebra.Matrix.Rank
import Mathlib.Tactic

/-!
# Paper-complete campaign, round 7: the complete finite cut-rank formula

Target: short-note `res:finite-cut-rank`.  This file generalises the supplied
rational interval-difference engine to an arbitrary field, proves independence
except for the two extreme columns, removes exactly that redundancy, and states
the result using `Matrix.rank`. Repetitions and permutations of columns are
handled by a column-range equality, not an extra independence assumption.

Authored against Lean 4.29.1 and the packet's Mathlib pin.
No admitted statements or additional axioms are introduced.
-/

namespace ErdosProblems.Erdos269.PaperR7

open scoped BigOperators
open Module Submodule

variable {F : Type*} [Field F]

/-- A cut at `k`, with `m` rows. -/
def cutVector (c : F) (m k : ℕ) : Fin m → F :=
  fun i => if (i : ℕ) < k then 1 else c









/-- Column-space description, independent of column ordering or repetitions. -/
noncomputable def cutSpan (c : F) (m : ℕ) (E : Finset ℕ) :
    Submodule F (Fin m → F) :=
  Submodule.span F (Set.range (fun k : E => cutVector c m k))







end ErdosProblems.Erdos269.PaperR7
