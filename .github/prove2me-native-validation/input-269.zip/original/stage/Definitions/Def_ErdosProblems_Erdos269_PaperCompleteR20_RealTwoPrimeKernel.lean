import Mathlib.Algebra.Order.Floor.Ring
import Mathlib.Analysis.SpecialFunctions.Log.Base
import Mathlib.Tactic

/-!
# Two-generator separation for arbitrary real bases

The long paper allows real generators greater than one. Integer floors and
integer powers retain that literal domain, including nonintegral bases.
-/

namespace ErdosProblems.Erdos269.PaperCompleteR20

noncomputable section

def realTwoPrimeHeight (p q t : ℝ) : ℝ :=
  p ^ ⌊Real.logb p t⌋ * q ^ ⌊Real.logb q t⌋

def realTwoPrimeKernel (p q : ℝ) (i j : ℕ) : ℝ :=
  (realTwoPrimeHeight p q (p ^ i * q ^ j))⁻¹












end

end ErdosProblems.Erdos269.PaperCompleteR20
