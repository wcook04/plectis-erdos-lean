import Definitions.Def_P2M_Erdos257_20260927_Erdos249257_TotientTailPeriodKiller
import Definitions.Def_P2M_Erdos257_20260927_Erdos249257_CarrySurvivorExtinction
import Definitions.Def_P2M_Erdos257_20260927_Erdos249257_LcmConeFlatness
import Definitions.Def_P2M_Erdos257_20260927_Erdos249257_LcmConeNonflat
import Definitions.Def_P2M_Erdos257_20260927_Erdos249257_MersenneLambertLadder
import Definitions.Def_P2M_Erdos257_20260927_Erdos249257_SternBrocotRunGeometry
import Definitions.Def_P2M_Erdos257_20260927_Erdos249257_CertificateKernel
import Definitions.Def_P2M_Erdos257_20260927_Erdos249257_GenericTailOrbitRigidity
import Definitions.Def_P2M_Erdos257_20260927_Erdos249257_GreedyAchievementSet
import Definitions.Def_P2M_Erdos257_20260927_Erdos249257_BooleanMobiusCarry
import Definitions.Def_P2M_Erdos257_20260927_Erdos249257_RationalSupportCarrySkeleton
import Definitions.Def_P2M_Erdos257_20260927_Erdos249257_ReciprocalSupportIrrationality
import Definitions.Def_P2M_Erdos257_20260927_Erdos249257_AllBaseReciprocalSupportIrrationality
import Definitions.Def_P2M_Erdos257_20260927_ErdosProblems_Erdos257_PaperCompleteR7_Displacement
import Definitions.Def_P2M_Erdos257_20260927_ErdosProblems_Erdos257_PaperCompleteR7_AnalyticTargets
import Definitions.Def_P2M_Erdos257_20260927_ErdosProblems_Erdos257_PaperCompleteR8_FiniteMeans
import Definitions.Def_P2M_Erdos257_20260927_ErdosProblems_Erdos257_PaperCompleteR8_KernelRecurrence
import Definitions.Def_P2M_Erdos257_20260927_ErdosProblems_Erdos257_PaperCompleteR8_CoverPotentialBounds
import Definitions.Def_P2M_Erdos257_20260927_ErdosProblems_Erdos257_PaperCompleteR8_PositiveCoverReturn
import Theorems.Thm_P2M_Erdos257_20260927_ErdosProblems_Erdos257_PaperCompleteR7_displacement_union_le
import Theorems.Thm_P2M_Erdos257_20260927_ErdosProblems_Erdos257_PaperCompleteR8_displacement_finset_le_framePotential
import Mathlib
import Mathlib.Algebra.BigOperators.Field
import Mathlib.Algebra.BigOperators.Intervals
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Algebra.Order.Antidiag.Prod
import Mathlib.Algebra.Order.Ring.Pow
import Mathlib.Algebra.Ring.GeomSum
import Mathlib.Analysis.Asymptotics.SpecificAsymptotics
import Mathlib.Analysis.Convex.SpecificFunctions.Basic
import Mathlib.Analysis.MeanInequalitiesPow
import Mathlib.Analysis.Normed.Group.FunctionSeries
import Mathlib.Analysis.Normed.Group.Tannery
import Mathlib.Analysis.Normed.Ring.InfiniteSum
import Mathlib.Analysis.RCLike.Basic
import Mathlib.Analysis.SpecialFunctions.Pow.Continuity
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Data.Finset.NatAntidiagonal
import Mathlib.Data.Nat.Choose.Dvd
import Mathlib.Data.Nat.Factorization.Basic
import Mathlib.Data.Nat.Fib.Basic
import Mathlib.Data.Nat.Find
import Mathlib.Data.Nat.ModEq
import Mathlib.Data.Nat.Totient
import Mathlib.Data.ZMod.Basic
import Mathlib.FieldTheory.Finite.Basic
import Mathlib.LinearAlgebra.Matrix.Determinant.Basic
import Mathlib.MeasureTheory.Group.Measure
import Mathlib.MeasureTheory.Measure.Lebesgue.Basic
import Mathlib.MeasureTheory.Measure.MeasureSpace
import Mathlib.NumberTheory.ArithmeticFunction.Misc
import Mathlib.NumberTheory.ArithmeticFunction.Moebius
import Mathlib.NumberTheory.Bertrand
import Mathlib.NumberTheory.Multiplicity
import Mathlib.NumberTheory.Real.Irrational
import Mathlib.NumberTheory.TsumDivisorsAntidiagonal
import Mathlib.Order.Filter.AtTopBot.Basic
import Mathlib.RingTheory.Polynomial.Cyclotomic.Eval
import Mathlib.RingTheory.Polynomial.Cyclotomic.Expand
import Mathlib.RingTheory.Polynomial.Cyclotomic.Roots
import Mathlib.Tactic
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.GCongr
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.LinearCombination
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.Set
import Mathlib.Topology.Algebra.InfiniteSum.NatInt
import Mathlib.Topology.Algebra.InfiniteSum.Order
import Mathlib.Topology.Algebra.InfiniteSum.Ring
import Mathlib.Topology.GDelta.Basic
import Mathlib.Topology.Order.IntermediateValue
import Mathlib.Topology.Perfect

namespace ErdosProblems.Erdos257.PaperCompleteR7
end ErdosProblems.Erdos257.PaperCompleteR7

namespace P2M_Erdos257_20260927.Erdos257PeriodNoncollapse
end P2M_Erdos257_20260927.Erdos257PeriodNoncollapse

noncomputable section

namespace P2M_Erdos257_20260927.ErdosProblems.Erdos257.PaperCompleteR8
open Finset Filter Set
open Erdos257PeriodNoncollapse
open ErdosProblems.Erdos257.PaperCompleteR7
end P2M_Erdos257_20260927.ErdosProblems.Erdos257.PaperCompleteR8

open P2M_Erdos257_20260927
open P2M_Erdos257_20260927.ErdosProblems
open P2M_Erdos257_20260927.ErdosProblems.Erdos257
open P2M_Erdos257_20260927.ErdosProblems.Erdos257.PaperCompleteR8
open Finset Filter Set
open Erdos257PeriodNoncollapse
open ErdosProblems.Erdos257.PaperCompleteR7
open P2M_Erdos257_20260927 in
open P2M_Erdos257_20260927.ErdosProblems in
open P2M_Erdos257_20260927.ErdosProblems.Erdos257 in
open P2M_Erdos257_20260927.ErdosProblems.Erdos257.PaperCompleteR8 in
open P2M_Erdos257_20260927.ErdosProblems.Erdos257.PaperCompleteR7 in
theorem solution (C : PositiveCoverData) (J N : ℕ)
    (hzero : displacement 2 (coverPrefix C J : Set ℕ) N = 0) (k : ℕ) :
    displacement 2 (coverPrefix C (J + k) : Set ℕ) N ≤
      ∑ i ∈ Finset.range k, framePotential (C.frame (i + J)) N := by
  induction k with
  | zero => simp only [Nat.add_zero, Finset.range_zero, Finset.sum_empty, hzero, le_refl]
  | succ k ih =>
    have hp : coverPrefix C (J + (k + 1)) =
        coverPrefix C (J + k) ∪ C.frame (k + J) := by
      rw [show J + (k + 1) = (J + k) + 1 by omega, coverPrefix]
      rw [show C.frame (J + k) = C.frame (k + J) from
        congrArg C.frame (Nat.add_comm J k)]
    rw [hp, Finset.coe_union, Finset.sum_range_succ]
    have hu := displacement_union_le 2 (coverPrefix C (J + k) : Set ℕ)
      (C.frame (k + J) : Set ℕ) N (by norm_num)
    have hf := displacement_finset_le_framePotential (C.frame (k + J)) N
    linarith only [hu, hf, ih]
