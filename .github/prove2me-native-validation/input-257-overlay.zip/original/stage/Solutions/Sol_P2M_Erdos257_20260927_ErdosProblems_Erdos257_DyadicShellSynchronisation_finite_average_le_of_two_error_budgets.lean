import Mathlib

namespace P2M_Erdos257_20260927
end P2M_Erdos257_20260927

namespace P2M_Erdos257_20260927.ErdosProblems.Erdos257.DyadicShellSynchronisation
end P2M_Erdos257_20260927.ErdosProblems.Erdos257.DyadicShellSynchronisation



open P2M_Erdos257_20260927
open P2M_Erdos257_20260927.ErdosProblems
open P2M_Erdos257_20260927.ErdosProblems.Erdos257
open P2M_Erdos257_20260927.ErdosProblems.Erdos257.DyadicShellSynchronisation
open P2M_Erdos257_20260927 in
open P2M_Erdos257_20260927.ErdosProblems in
open P2M_Erdos257_20260927.ErdosProblems.Erdos257 in
open P2M_Erdos257_20260927.ErdosProblems.Erdos257.DyadicShellSynchronisation in
theorem solution
    {ι : Type*} (s : Finset ι) (m : ℕ) (hm : 0 < m)
    (hcard : s.card = m) (L a : ℝ) (u near transition : ι → ℝ)
    (hpoint : ∀ i ∈ s, u i ≤ a + near i + transition i)
    (hnear : ∑ i ∈ s, near i ≤ 2 * L * a)
    (htransition : ∑ i ∈ s, transition i ≤ 2 * L * a) :
    (∑ i ∈ s, u i) / (m : ℝ) ≤ (1 + 4 * L / m) * a := by
  have hmR : 0 < (m : ℝ) := by exact_mod_cast hm
  have hsum : (∑ i ∈ s, u i) ≤ (m : ℝ) * a + 4 * L * a := by
    calc
      (∑ i ∈ s, u i) ≤ ∑ i ∈ s, (a + near i + transition i) :=
        Finset.sum_le_sum hpoint
      _ = (m : ℝ) * a + (∑ i ∈ s, near i) +
          (∑ i ∈ s, transition i) := by
        simp only [Finset.sum_add_distrib, Finset.sum_const,
          nsmul_eq_mul, hcard]
      _ ≤ (m : ℝ) * a + 4 * L * a := by linarith
  apply (div_le_iff₀ hmR).2
  calc
    (∑ i ∈ s, u i) ≤ (m : ℝ) * a + 4 * L * a := hsum
    _ = ((1 + 4 * L / (m : ℝ)) * a) * m := by
      field_simp [ne_of_gt hmR]
      <;> ring
