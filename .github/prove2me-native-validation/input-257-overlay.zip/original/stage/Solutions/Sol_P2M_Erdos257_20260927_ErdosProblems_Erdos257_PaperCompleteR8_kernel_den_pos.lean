import Definitions.Def_P2M_Erdos257_20260927_ErdosProblems_Erdos257_PaperCompleteR8_FiniteMeans
import Mathlib.Algebra.BigOperators.Intervals
import Mathlib.Algebra.Order.Ring.Pow
import Mathlib.Analysis.Convex.SpecificFunctions.Basic
import Mathlib.Analysis.MeanInequalitiesPow
import Mathlib.Analysis.SpecialFunctions.Pow.Continuity
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.Tactic

namespace ErdosProblems.Erdos257.PaperCompleteR7
end ErdosProblems.Erdos257.PaperCompleteR7

noncomputable section

namespace P2M_Erdos257_20260927.ErdosProblems.Erdos257.PaperCompleteR8
open Finset
open ErdosProblems.Erdos257.PaperCompleteR7
end P2M_Erdos257_20260927.ErdosProblems.Erdos257.PaperCompleteR8

open P2M_Erdos257_20260927
open P2M_Erdos257_20260927.ErdosProblems
open P2M_Erdos257_20260927.ErdosProblems.Erdos257
open P2M_Erdos257_20260927.ErdosProblems.Erdos257.PaperCompleteR8
open Finset
open ErdosProblems.Erdos257.PaperCompleteR7
open P2M_Erdos257_20260927 in
open P2M_Erdos257_20260927.ErdosProblems in
open P2M_Erdos257_20260927.ErdosProblems.Erdos257 in
open P2M_Erdos257_20260927.ErdosProblems.Erdos257.PaperCompleteR8 in
open P2M_Erdos257_20260927.ErdosProblems.Erdos257.PaperCompleteR7 in
theorem solution {B : ℝ} (hB : 1 < B) {d : ℕ} (hd : 0 < d) :
    0 < B ^ d - 1 := by
  -- Mathlib/Algebra/Order/GroupWithZero/Unbundled/Basic.lean: one_lt_pow₀,
  -- pow_nonneg, pow_pos and the power-order lemmas (opened at the pin).
  have hp : 1 < B ^ d := one_lt_pow₀ hB hd.ne'
  exact sub_pos.mpr hp
