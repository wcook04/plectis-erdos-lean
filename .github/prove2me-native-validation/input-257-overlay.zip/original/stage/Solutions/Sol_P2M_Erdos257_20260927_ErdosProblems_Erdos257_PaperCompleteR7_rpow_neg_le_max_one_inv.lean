import Mathlib.Algebra.Order.Ring.Pow
import Mathlib.Analysis.Convex.SpecificFunctions.Basic
import Mathlib.Analysis.MeanInequalitiesPow
import Mathlib.Analysis.SpecialFunctions.Pow.Continuity
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.Tactic

namespace P2M_Erdos257_20260927
end P2M_Erdos257_20260927

namespace P2M_Erdos257_20260927.ErdosProblems.Erdos257.PaperCompleteR7
end P2M_Erdos257_20260927.ErdosProblems.Erdos257.PaperCompleteR7

noncomputable section

namespace P2M_Erdos257_20260927.ErdosProblems.Erdos257.PaperCompleteR7
open Finset Filter
end P2M_Erdos257_20260927.ErdosProblems.Erdos257.PaperCompleteR7

open P2M_Erdos257_20260927
open P2M_Erdos257_20260927.ErdosProblems
open P2M_Erdos257_20260927.ErdosProblems.Erdos257
open P2M_Erdos257_20260927.ErdosProblems.Erdos257.PaperCompleteR7
open Finset Filter
open P2M_Erdos257_20260927 in
open P2M_Erdos257_20260927.ErdosProblems in
open P2M_Erdos257_20260927.ErdosProblems.Erdos257 in
open P2M_Erdos257_20260927.ErdosProblems.Erdos257.PaperCompleteR7 in
theorem solution {t α : ℝ} (ht : 0 < t) (hα : 0 < α) (hα1 : α ≤ 1) :
    t ^ (-α) ≤ max 1 t⁻¹ := by
  rcases le_total t 1 with h | h
  · have hmono : t ^ (-α) ≤ t ^ (-1 : ℝ) :=
      Real.rpow_le_rpow_of_exponent_ge ht h (by linarith)
    rw [Real.rpow_neg_one] at hmono
    exact hmono.trans (le_max_right _ _)
  · have hone : t ^ (-α) ≤ t ^ (0 : ℝ) :=
      Real.rpow_le_rpow_of_exponent_le h (by linarith)
    rw [Real.rpow_zero] at hone
    exact hone.trans (le_max_left _ _)
