import Definitions.Def_P2M_Erdos257_20260927_ErdosProblems_Erdos257_PaperCompleteR8_FiniteMeans
import Theorems.Thm_P2M_Erdos257_20260927_ErdosProblems_Erdos257_PaperCompleteR8_progressionMean_mono
import Mathlib.Algebra.BigOperators.Intervals
import Mathlib.Algebra.Order.Ring.Pow
import Mathlib.Analysis.Convex.SpecificFunctions.Basic
import Mathlib.Analysis.MeanInequalitiesPow
import Mathlib.Analysis.SpecialFunctions.Pow.Continuity
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.Tactic

namespace ErdosProblems.Erdos257.PaperCompleteR7
end ErdosProblems.Erdos257.PaperCompleteR7

noncomputable section

namespace P2M_Erdos257_20260927.ErdosProblems.Erdos257.PaperCompleteR8
open Finset
open ErdosProblems.Erdos257.PaperCompleteR7
end P2M_Erdos257_20260927.ErdosProblems.Erdos257.PaperCompleteR8

open P2M_Erdos257_20260927
open P2M_Erdos257_20260927.ErdosProblems
open P2M_Erdos257_20260927.ErdosProblems.Erdos257
open P2M_Erdos257_20260927.ErdosProblems.Erdos257.PaperCompleteR8
open Finset
open ErdosProblems.Erdos257.PaperCompleteR7
open P2M_Erdos257_20260927 in
open P2M_Erdos257_20260927.ErdosProblems in
open P2M_Erdos257_20260927.ErdosProblems.Erdos257 in
open P2M_Erdos257_20260927.ErdosProblems.Erdos257.PaperCompleteR8 in
open P2M_Erdos257_20260927.ErdosProblems.Erdos257.PaperCompleteR7 in
theorem solution (L R M : ℕ) (f g : ℕ → ℝ)
    (hfg : ∀ n, f n ≤ g n) : dyadicMean L R M f ≤ dyadicMean L R M g := by
  unfold dyadicMean
  exact div_le_div_of_nonneg_right
    (Finset.sum_le_sum (fun j _ => progressionMean_mono L _ f g hfg))
    (Nat.cast_nonneg M)
