import Mathlib.Algebra.Order.Ring.Pow
import Mathlib.Analysis.Convex.SpecificFunctions.Basic
import Mathlib.Analysis.MeanInequalitiesPow
import Mathlib.Analysis.SpecialFunctions.Pow.Continuity
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.Tactic

namespace P2M_Erdos257_20260927
end P2M_Erdos257_20260927

namespace P2M_Erdos257_20260927.ErdosProblems.Erdos257.PaperCompleteR7
end P2M_Erdos257_20260927.ErdosProblems.Erdos257.PaperCompleteR7

noncomputable section

namespace P2M_Erdos257_20260927.ErdosProblems.Erdos257.PaperCompleteR7
open Finset Filter
end P2M_Erdos257_20260927.ErdosProblems.Erdos257.PaperCompleteR7

open P2M_Erdos257_20260927
open P2M_Erdos257_20260927.ErdosProblems
open P2M_Erdos257_20260927.ErdosProblems.Erdos257
open P2M_Erdos257_20260927.ErdosProblems.Erdos257.PaperCompleteR7
open Finset Filter
open P2M_Erdos257_20260927 in
open P2M_Erdos257_20260927.ErdosProblems in
open P2M_Erdos257_20260927.ErdosProblems.Erdos257 in
open P2M_Erdos257_20260927.ErdosProblems.Erdos257.PaperCompleteR7 in
theorem solution {ι : Type*} (s : Finset ι) (hs : s.Nonempty)
    (f : ι → ℝ) {c : ℝ} (hmean : (∑ i ∈ s, f i) / (s.card : ℝ) < c) :
    ∃ i ∈ s, f i < c := by
  classical
  by_contra hcon
  push_neg at hcon
  have hcard : (0 : ℝ) < (s.card : ℝ) := by
    exact_mod_cast Finset.card_pos.mpr hs
  have hsum : c * (s.card : ℝ) ≤ ∑ i ∈ s, f i := by
    calc c * (s.card : ℝ) = ∑ _i ∈ s, c := by
          rw [Finset.sum_const, nsmul_eq_mul]
          ring
      _ ≤ ∑ i ∈ s, f i := Finset.sum_le_sum fun i hi => hcon i hi
  rw [div_lt_iff₀ hcard] at hmean
  linarith
