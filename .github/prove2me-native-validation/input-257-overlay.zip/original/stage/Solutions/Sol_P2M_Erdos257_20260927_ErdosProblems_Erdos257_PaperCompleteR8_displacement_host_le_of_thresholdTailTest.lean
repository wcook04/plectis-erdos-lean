import Definitions.Def_P2M_Erdos257_20260927_Erdos249257_TotientTailPeriodKiller
import Definitions.Def_P2M_Erdos257_20260927_Erdos249257_CarrySurvivorExtinction
import Definitions.Def_P2M_Erdos257_20260927_Erdos249257_LcmConeFlatness
import Definitions.Def_P2M_Erdos257_20260927_Erdos249257_LcmConeNonflat
import Definitions.Def_P2M_Erdos257_20260927_Erdos249257_MersenneLambertLadder
import Definitions.Def_P2M_Erdos257_20260927_Erdos249257_SternBrocotRunGeometry
import Definitions.Def_P2M_Erdos257_20260927_Erdos249257_CertificateKernel
import Definitions.Def_P2M_Erdos257_20260927_Erdos249257_GenericTailOrbitRigidity
import Definitions.Def_P2M_Erdos257_20260927_Erdos249257_GreedyAchievementSet
import Definitions.Def_P2M_Erdos257_20260927_Erdos249257_BooleanMobiusCarry
import Definitions.Def_P2M_Erdos257_20260927_Erdos249257_RationalSupportCarrySkeleton
import Definitions.Def_P2M_Erdos257_20260927_Erdos249257_ReciprocalSupportIrrationality
import Definitions.Def_P2M_Erdos257_20260927_Erdos249257_AllBaseReciprocalSupportIrrationality
import Definitions.Def_P2M_Erdos257_20260927_ErdosProblems_Erdos257_PaperCompleteR7_Displacement
import Definitions.Def_P2M_Erdos257_20260927_ErdosProblems_Erdos257_PaperCompleteR7_AnalyticTargets
import Definitions.Def_P2M_Erdos257_20260927_ErdosProblems_Erdos257_PaperCompleteR8_FiniteMeans
import Definitions.Def_P2M_Erdos257_20260927_ErdosProblems_Erdos257_PaperCompleteR8_KernelRecurrence
import Definitions.Def_P2M_Erdos257_20260927_ErdosProblems_Erdos257_PaperCompleteR8_CoverPotentialBounds
import Definitions.Def_P2M_Erdos257_20260927_ErdosProblems_Erdos257_PaperCompleteR8_OptimizedCoverBudget
import Definitions.Def_P2M_Erdos257_20260927_ErdosProblems_Erdos257_PaperCompleteR8_PositiveCoverReturn
import Definitions.Def_P2M_Erdos257_20260927_ErdosProblems_Erdos257_PaperCompleteR8_ArbitraryWeightReturns
import Theorems.Thm_P2M_Erdos257_20260927_ErdosProblems_Erdos257_PaperCompleteR7_displacement_finset_eq_zero
import Theorems.Thm_P2M_Erdos257_20260927_ErdosProblems_Erdos257_PaperCompleteR8_coverPotential_nonneg
import Theorems.Thm_P2M_Erdos257_20260927_ErdosProblems_Erdos257_PaperCompleteR8_coverPotential_le_cost
import Theorems.Thm_P2M_Erdos257_20260927_ErdosProblems_Erdos257_PaperCompleteR8_framePotential_nonneg
import Theorems.Thm_P2M_Erdos257_20260927_ErdosProblems_Erdos257_PaperCompleteR8_displacement_host_le_tsum_tail
import Theorems.Thm_P2M_Erdos257_20260927_ErdosProblems_Erdos257_PaperCompleteR8_positiveCover_frame_bridge
import Theorems.Thm_P2M_Erdos257_20260927_ErdosProblems_Erdos257_PaperCompleteR8_thresholdScale_pos
import Mathlib
import Mathlib.Algebra.BigOperators.Field
import Mathlib.Algebra.BigOperators.Intervals
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Algebra.Order.Antidiag.Prod
import Mathlib.Algebra.Order.Ring.Pow
import Mathlib.Algebra.Ring.GeomSum
import Mathlib.Analysis.Asymptotics.SpecificAsymptotics
import Mathlib.Analysis.Convex.SpecificFunctions.Basic
import Mathlib.Analysis.MeanInequalitiesPow
import Mathlib.Analysis.Normed.Group.FunctionSeries
import Mathlib.Analysis.Normed.Group.Tannery
import Mathlib.Analysis.Normed.Ring.InfiniteSum
import Mathlib.Analysis.RCLike.Basic
import Mathlib.Analysis.SpecialFunctions.Pow.Continuity
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Data.Finset.NatAntidiagonal
import Mathlib.Data.Nat.Choose.Dvd
import Mathlib.Data.Nat.Factorization.Basic
import Mathlib.Data.Nat.Fib.Basic
import Mathlib.Data.Nat.Find
import Mathlib.Data.Nat.ModEq
import Mathlib.Data.Nat.Totient
import Mathlib.Data.ZMod.Basic
import Mathlib.FieldTheory.Finite.Basic
import Mathlib.LinearAlgebra.Matrix.Determinant.Basic
import Mathlib.MeasureTheory.Group.Measure
import Mathlib.MeasureTheory.Measure.Lebesgue.Basic
import Mathlib.MeasureTheory.Measure.MeasureSpace
import Mathlib.NumberTheory.ArithmeticFunction.Misc
import Mathlib.NumberTheory.ArithmeticFunction.Moebius
import Mathlib.NumberTheory.Bertrand
import Mathlib.NumberTheory.Multiplicity
import Mathlib.NumberTheory.Real.Irrational
import Mathlib.NumberTheory.TsumDivisorsAntidiagonal
import Mathlib.Order.Filter.AtTopBot.Basic
import Mathlib.RingTheory.Polynomial.Cyclotomic.Eval
import Mathlib.RingTheory.Polynomial.Cyclotomic.Expand
import Mathlib.RingTheory.Polynomial.Cyclotomic.Roots
import Mathlib.Tactic
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.GCongr
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.LinearCombination
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.Set
import Mathlib.Topology.Algebra.InfiniteSum.NatInt
import Mathlib.Topology.Algebra.InfiniteSum.Order
import Mathlib.Topology.Algebra.InfiniteSum.Ring
import Mathlib.Topology.GDelta.Basic
import Mathlib.Topology.Order.IntermediateValue
import Mathlib.Topology.Perfect

namespace Erdos249257
end Erdos249257

namespace ErdosProblems.Erdos257.PaperCompleteR7
end ErdosProblems.Erdos257.PaperCompleteR7

namespace P2M_Erdos257_20260927.Erdos257PeriodNoncollapse
end P2M_Erdos257_20260927.Erdos257PeriodNoncollapse

noncomputable section

namespace P2M_Erdos257_20260927.ErdosProblems.Erdos257.PaperCompleteR8
open Finset Filter
open Erdos249257
open ErdosProblems.Erdos257.PaperCompleteR7
theorem summable_thresholdTailTest_terms (C : PositiveCoverData) (t : ℕ → ℝ)
    (ht : ∀ j, 0 < t j) (hs : Summable (thresholdCost C t)) (J N : ℕ) :
    Summable (fun k => thresholdScale C t (k + J) * coverPotential C (k + J) N) := by
  have htail : Summable (fun k => thresholdCost C t (k + J)) :=
    (summable_nat_add_iff J).mpr hs
  apply Summable.of_nonneg_of_le _ _ (htail.mul_left (2 * (N : ℝ) + 1))
  · intro k
    exact mul_nonneg (thresholdScale_pos C t ht (k + J)).le (coverPotential_nonneg C (k + J) N)
  · intro k
    have h := mul_le_mul_of_nonneg_left (coverPotential_le_cost C (k + J) N)
      (thresholdScale_pos C t ht (k + J)).le
    convert h using 1 <;> unfold thresholdCost <;> ring
theorem framePotential_lt_of_thresholdTailTest (C : PositiveCoverData) (t : ℕ → ℝ)
    (ht : ∀ j, 0 < t j) (hs : Summable (thresholdCost C t)) (J N : ℕ)
    (hsmall : thresholdTailTest C t J N < 1) (k : ℕ) :
    framePotential (C.frame (k + J)) N < t (k + J) := by
  have hsum := summable_thresholdTailTest_terms C t ht hs J N
  have hterm : thresholdScale C t (k + J) * coverPotential C (k + J) N ≤ thresholdTailTest C t J N :=
    hsum.le_tsum k (fun i _ => mul_nonneg (thresholdScale_pos C t ht (i + J)).le
      (coverPotential_nonneg C (i + J) N))
  have hbridge := positiveCover_frame_bridge C (k + J) N
  have hscale := thresholdScale_pos C t ht (k + J)
  have hp : thresholdScale C t (k + J) * framePotential (C.frame (k + J)) N ^ C.exponent (k + J) < 1 :=
    (mul_le_mul_of_nonneg_left hbridge hscale.le).trans_lt (hterm.trans_lt hsmall)
  have hone : thresholdScale C t (k + J) * t (k + J) ^ C.exponent (k + J) = 1 := by
    unfold thresholdScale
    rw [Real.rpow_neg (ht (k + J)).le]
    exact inv_mul_cancel₀ (Real.rpow_pos_of_pos (ht (k + J)) _).ne'
  by_contra hbad
  have hge : t (k + J) ≤ framePotential (C.frame (k + J)) N := le_of_not_gt hbad
  have hpow := Real.rpow_le_rpow (ht (k + J)).le hge (C.exponent_bounds (k + J)).1.le
  have hmult := mul_le_mul_of_nonneg_left hpow hscale.le
  rw [hone] at hmult
  exact (not_lt_of_ge hmult) hp
end P2M_Erdos257_20260927.ErdosProblems.Erdos257.PaperCompleteR8

open P2M_Erdos257_20260927
open P2M_Erdos257_20260927.ErdosProblems
open P2M_Erdos257_20260927.ErdosProblems.Erdos257
open P2M_Erdos257_20260927.ErdosProblems.Erdos257.PaperCompleteR8
open Finset Filter
open Erdos249257
open ErdosProblems.Erdos257.PaperCompleteR7
open P2M_Erdos257_20260927 in
open P2M_Erdos257_20260927.ErdosProblems in
open P2M_Erdos257_20260927.ErdosProblems.Erdos257 in
open P2M_Erdos257_20260927.ErdosProblems.Erdos257.PaperCompleteR8 in
open P2M_Erdos257_20260927.Erdos249257 in
open P2M_Erdos257_20260927.ErdosProblems.Erdos257.PaperCompleteR7 in
theorem solution (C : PositiveCoverData) (t : ℕ → ℝ)
    (ht : ∀ j, 0 < t j) (hs : Summable (thresholdCost C t)) (ρ : ℝ)
    (htsum : HasSum t ρ) (J N : ℕ) (hdiv : ∀ d ∈ coverPrefix C J, d ∣ N)
    (hsmall : thresholdTailTest C t J N < 1) : displacement 2 C.host N ≤ ρ := by
  have hbound := framePotential_lt_of_thresholdTailTest C t ht hs J N hsmall
  have ht' : Summable (fun k => t (k + J)) := (summable_nat_add_iff J).mpr htsum.summable
  have hu : Summable (fun k => framePotential (C.frame (k + J)) N) :=
    Summable.of_nonneg_of_le (fun k => framePotential_nonneg (C.frame (k + J)) N)
      (fun k => (hbound k).le) ht'
  have hzero := displacement_finset_eq_zero 2 (coverPrefix C J) N (by norm_num) hdiv
  have hsum := Summable.tsum_le_tsum (fun k => (hbound k).le) hu ht'
  have hsplit := htsum.summable.sum_add_tsum_nat_add J
  rw [htsum.tsum_eq] at hsplit
  have hpre : 0 ≤ ∑ k ∈ range J, t k := Finset.sum_nonneg (fun k _ => (ht k).le)
  have htail : (∑' k, t (k + J)) ≤ ρ := by linarith only [hsplit, hpre]
  exact (displacement_host_le_tsum_tail C J N hzero hu).trans (hsum.trans htail)
