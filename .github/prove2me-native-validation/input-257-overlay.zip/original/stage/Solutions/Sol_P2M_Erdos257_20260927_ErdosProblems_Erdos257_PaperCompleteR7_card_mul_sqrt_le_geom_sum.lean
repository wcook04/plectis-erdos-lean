import Mathlib.Algebra.Order.Ring.Pow
import Mathlib.Analysis.Convex.SpecificFunctions.Basic
import Mathlib.Analysis.MeanInequalitiesPow
import Mathlib.Analysis.SpecialFunctions.Pow.Continuity
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.Tactic

namespace P2M_Erdos257_20260927
end P2M_Erdos257_20260927

namespace P2M_Erdos257_20260927.ErdosProblems.Erdos257.PaperCompleteR7
end P2M_Erdos257_20260927.ErdosProblems.Erdos257.PaperCompleteR7

noncomputable section

namespace P2M_Erdos257_20260927.ErdosProblems.Erdos257.PaperCompleteR7
open Finset Filter
/-- Two-term AM-GM in the form the pairing uses. -/
theorem two_mul_sqrt_mul_le_add {x y : ℝ} (hx : 0 ≤ x) (hy : 0 ≤ y) :
    2 * Real.sqrt (x * y) ≤ x + y := by
  have h := two_mul_le_add_sq (Real.sqrt x) (Real.sqrt y)
  rw [Real.sq_sqrt hx, Real.sq_sqrt hy] at h
  rw [Real.sqrt_mul hx]
  linarith
end P2M_Erdos257_20260927.ErdosProblems.Erdos257.PaperCompleteR7

open P2M_Erdos257_20260927
open P2M_Erdos257_20260927.ErdosProblems
open P2M_Erdos257_20260927.ErdosProblems.Erdos257
open P2M_Erdos257_20260927.ErdosProblems.Erdos257.PaperCompleteR7
open Finset Filter
open P2M_Erdos257_20260927 in
open P2M_Erdos257_20260927.ErdosProblems in
open P2M_Erdos257_20260927.ErdosProblems.Erdos257 in
open P2M_Erdos257_20260927.ErdosProblems.Erdos257.PaperCompleteR7 in
theorem solution {B : ℝ} (hB : 0 ≤ B) (d : ℕ) :
    (d : ℝ) * Real.sqrt (B ^ (d - 1)) ≤ ∑ i ∈ Finset.range d, B ^ i := by
  classical
  have hpow : ∀ i : ℕ, (0 : ℝ) ≤ B ^ i := fun i => pow_nonneg hB i
  have hpair : ∀ i ∈ Finset.range d,
      2 * Real.sqrt (B ^ (d - 1)) ≤ B ^ i + B ^ (d - 1 - i) := by
    intro i hi
    have hid : i < d := Finset.mem_range.mp hi
    have hsplit : B ^ i * B ^ (d - 1 - i) = B ^ (d - 1) := by
      rw [← pow_add]
      congr 1
      omega
    have h := two_mul_sqrt_mul_le_add (hpow i) (hpow (d - 1 - i))
    rwa [hsplit] at h
  have hsum : ∑ i ∈ Finset.range d, (2 * Real.sqrt (B ^ (d - 1)))
      ≤ ∑ i ∈ Finset.range d, (B ^ i + B ^ (d - 1 - i)) :=
    Finset.sum_le_sum hpair
  have hrefl : ∑ i ∈ Finset.range d, B ^ (d - 1 - i) = ∑ i ∈ Finset.range d, B ^ i := by
    rw [← Finset.sum_range_reflect (fun i => B ^ (d - 1 - i)) d]
    apply Finset.sum_congr rfl
    intro i hi
    have hid : i < d := Finset.mem_range.mp hi
    congr 1
    omega
  rw [Finset.sum_add_distrib, hrefl, Finset.sum_const, Finset.card_range,
    nsmul_eq_mul] at hsum
  linarith
