import Definitions.Def_P2M_Erdos257_20260927_Erdos249257_TotientTailPeriodKiller
import Definitions.Def_P2M_Erdos257_20260927_Erdos249257_CarrySurvivorExtinction
import Definitions.Def_P2M_Erdos257_20260927_Erdos249257_LcmConeFlatness
import Definitions.Def_P2M_Erdos257_20260927_Erdos249257_LcmConeNonflat
import Definitions.Def_P2M_Erdos257_20260927_Erdos249257_MersenneLambertLadder
import Definitions.Def_P2M_Erdos257_20260927_Erdos249257_SternBrocotRunGeometry
import Definitions.Def_P2M_Erdos257_20260927_Erdos249257_CertificateKernel
import Definitions.Def_P2M_Erdos257_20260927_Erdos249257_GenericTailOrbitRigidity
import Definitions.Def_P2M_Erdos257_20260927_Erdos249257_GreedyAchievementSet
import Definitions.Def_P2M_Erdos257_20260927_Erdos249257_BooleanMobiusCarry
import Definitions.Def_P2M_Erdos257_20260927_Erdos249257_RationalSupportCarrySkeleton
import Definitions.Def_P2M_Erdos257_20260927_Erdos249257_ReciprocalSupportIrrationality
import Definitions.Def_P2M_Erdos257_20260927_Erdos249257_AllBaseReciprocalSupportIrrationality
import Definitions.Def_P2M_Erdos257_20260927_ErdosProblems_Erdos257_PaperCompleteR7_Displacement
import Definitions.Def_P2M_Erdos257_20260927_ErdosProblems_Erdos257_PaperCompleteR7_AnalyticTargets
import Definitions.Def_P2M_Erdos257_20260927_ErdosProblems_Erdos257_PaperCompleteR8_FiniteMeans
import Definitions.Def_P2M_Erdos257_20260927_ErdosProblems_Erdos257_PaperCompleteR8_KernelRecurrence
import Definitions.Def_P2M_Erdos257_20260927_ErdosProblems_Erdos257_PaperCompleteR8_WeightedPrimeProfile
import Theorems.Thm_P2M_Erdos257_20260927_ErdosProblems_Erdos257_PaperCompleteR8_kernel_den_pos
import Theorems.Thm_P2M_Erdos257_20260927_ErdosProblems_Erdos257_PaperCompleteR8_pow_sub_one_ratio_le
import Mathlib
import Mathlib.Algebra.BigOperators.Field
import Mathlib.Algebra.BigOperators.Intervals
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Algebra.Order.Antidiag.Prod
import Mathlib.Algebra.Order.Ring.Pow
import Mathlib.Algebra.Ring.GeomSum
import Mathlib.Analysis.Asymptotics.SpecificAsymptotics
import Mathlib.Analysis.Convex.SpecificFunctions.Basic
import Mathlib.Analysis.MeanInequalitiesPow
import Mathlib.Analysis.Normed.Group.FunctionSeries
import Mathlib.Analysis.Normed.Group.Tannery
import Mathlib.Analysis.Normed.Ring.InfiniteSum
import Mathlib.Analysis.RCLike.Basic
import Mathlib.Analysis.SpecialFunctions.Pow.Continuity
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Data.Finset.NatAntidiagonal
import Mathlib.Data.Nat.Choose.Dvd
import Mathlib.Data.Nat.Factorization.Basic
import Mathlib.Data.Nat.Fib.Basic
import Mathlib.Data.Nat.Find
import Mathlib.Data.Nat.ModEq
import Mathlib.Data.Nat.Totient
import Mathlib.Data.ZMod.Basic
import Mathlib.FieldTheory.Finite.Basic
import Mathlib.LinearAlgebra.Matrix.Determinant.Basic
import Mathlib.MeasureTheory.Group.Measure
import Mathlib.MeasureTheory.Measure.Lebesgue.Basic
import Mathlib.MeasureTheory.Measure.MeasureSpace
import Mathlib.NumberTheory.ArithmeticFunction.Misc
import Mathlib.NumberTheory.ArithmeticFunction.Moebius
import Mathlib.NumberTheory.Bertrand
import Mathlib.NumberTheory.Multiplicity
import Mathlib.NumberTheory.Real.Irrational
import Mathlib.NumberTheory.TsumDivisorsAntidiagonal
import Mathlib.Order.Filter.AtTopBot.Basic
import Mathlib.RingTheory.Polynomial.Cyclotomic.Eval
import Mathlib.RingTheory.Polynomial.Cyclotomic.Expand
import Mathlib.RingTheory.Polynomial.Cyclotomic.Roots
import Mathlib.Tactic
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.GCongr
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.LinearCombination
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.Set
import Mathlib.Topology.Algebra.InfiniteSum.NatInt
import Mathlib.Topology.Algebra.InfiniteSum.Order
import Mathlib.Topology.Algebra.InfiniteSum.Ring
import Mathlib.Topology.GDelta.Basic
import Mathlib.Topology.Order.IntermediateValue
import Mathlib.Topology.Perfect

namespace ErdosProblems.Erdos257.PaperCompleteR7
end ErdosProblems.Erdos257.PaperCompleteR7

namespace P2M_Erdos257_20260927.Erdos257PeriodNoncollapse
end P2M_Erdos257_20260927.Erdos257PeriodNoncollapse

noncomputable section

namespace P2M_Erdos257_20260927.ErdosProblems.Erdos257.PaperCompleteR8
open Finset
open ErdosProblems.Erdos257.PaperCompleteR7
end P2M_Erdos257_20260927.ErdosProblems.Erdos257.PaperCompleteR8

open P2M_Erdos257_20260927
open P2M_Erdos257_20260927.ErdosProblems
open P2M_Erdos257_20260927.ErdosProblems.Erdos257
open P2M_Erdos257_20260927.ErdosProblems.Erdos257.PaperCompleteR8
open Finset
open ErdosProblems.Erdos257.PaperCompleteR7
open P2M_Erdos257_20260927 in
open P2M_Erdos257_20260927.ErdosProblems in
open P2M_Erdos257_20260927.ErdosProblems.Erdos257 in
open P2M_Erdos257_20260927.ErdosProblems.Erdos257.PaperCompleteR8 in
open P2M_Erdos257_20260927.ErdosProblems.Erdos257.PaperCompleteR7 in
theorem solution (B : ℝ) (hB : 1 < B) (u v : ℕ)
    (hu : 0 < u) (huv : u ≤ v) :
    (v : ℝ) / (B ^ v - 1) ≤ (u : ℝ) / (B ^ u - 1) := by
  have hv : 0 < v := lt_of_lt_of_le hu huv
  have hr := pow_sub_one_ratio_le hB u v hv huv
  have hvR : (0 : ℝ) < v := by exact_mod_cast hv
  have huDen : 0 < B ^ u - 1 := kernel_den_pos hB hu
  have hvDen : 0 < B ^ v - 1 := kernel_den_pos hB hv
  have hc := (div_le_div_iff₀ hvDen hvR).mp hr
  apply (div_le_div_iff₀ hvDen huDen).mpr
  simpa only [mul_comm] using hc
