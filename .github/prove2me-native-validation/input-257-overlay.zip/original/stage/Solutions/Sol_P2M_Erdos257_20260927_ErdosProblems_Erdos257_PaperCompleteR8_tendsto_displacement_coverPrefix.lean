import Definitions.Def_P2M_Erdos257_20260927_Erdos249257_TotientTailPeriodKiller
import Definitions.Def_P2M_Erdos257_20260927_Erdos249257_CarrySurvivorExtinction
import Definitions.Def_P2M_Erdos257_20260927_Erdos249257_LcmConeFlatness
import Definitions.Def_P2M_Erdos257_20260927_Erdos249257_LcmConeNonflat
import Definitions.Def_P2M_Erdos257_20260927_Erdos249257_MersenneLambertLadder
import Definitions.Def_P2M_Erdos257_20260927_Erdos249257_SternBrocotRunGeometry
import Definitions.Def_P2M_Erdos257_20260927_Erdos249257_CertificateKernel
import Definitions.Def_P2M_Erdos257_20260927_Erdos249257_GenericTailOrbitRigidity
import Definitions.Def_P2M_Erdos257_20260927_Erdos249257_GreedyAchievementSet
import Definitions.Def_P2M_Erdos257_20260927_Erdos249257_BooleanMobiusCarry
import Definitions.Def_P2M_Erdos257_20260927_Erdos249257_RationalSupportCarrySkeleton
import Definitions.Def_P2M_Erdos257_20260927_Erdos249257_ReciprocalSupportIrrationality
import Definitions.Def_P2M_Erdos257_20260927_Erdos249257_AllBaseReciprocalSupportIrrationality
import Definitions.Def_P2M_Erdos257_20260927_ErdosProblems_Erdos257_PaperCompleteR7_Displacement
import Definitions.Def_P2M_Erdos257_20260927_ErdosProblems_Erdos257_PaperCompleteR7_AnalyticTargets
import Definitions.Def_P2M_Erdos257_20260927_ErdosProblems_Erdos257_PaperCompleteR8_FiniteMeans
import Definitions.Def_P2M_Erdos257_20260927_ErdosProblems_Erdos257_PaperCompleteR8_KernelRecurrence
import Definitions.Def_P2M_Erdos257_20260927_ErdosProblems_Erdos257_PaperCompleteR8_CoverPotentialBounds
import Definitions.Def_P2M_Erdos257_20260927_ErdosProblems_Erdos257_PaperCompleteR8_PositiveCoverReturn
import Theorems.Thm_P2M_Erdos257_20260927_Erdos249257_positiveSupportBitAF_apply
import Theorems.Thm_P2M_Erdos257_20260927_Erdos249257_supportCoeffAF_apply
import Theorems.Thm_P2M_Erdos257_20260927_Erdos249257_twentyOneGreedyCarry_zero
import Theorems.Thm_P2M_Erdos257_20260927_ErdosProblems_Erdos257_PaperCompleteR7_displacementAtom_nonneg
import Theorems.Thm_P2M_Erdos257_20260927_ErdosProblems_Erdos257_PaperCompleteR7_displacement_eq_tsum
import Theorems.Thm_P2M_Erdos257_20260927_ErdosProblems_Erdos257_PaperCompleteR7_summable_displacementAtom
import Theorems.Thm_P2M_Erdos257_20260927_ErdosProblems_Erdos257_PaperCompleteR8_mem_coverPrefix_iff
import Mathlib
import Mathlib.Algebra.BigOperators.Field
import Mathlib.Algebra.BigOperators.Intervals
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Algebra.Order.Antidiag.Prod
import Mathlib.Algebra.Order.Ring.Pow
import Mathlib.Algebra.Ring.GeomSum
import Mathlib.Analysis.Asymptotics.SpecificAsymptotics
import Mathlib.Analysis.Convex.SpecificFunctions.Basic
import Mathlib.Analysis.MeanInequalitiesPow
import Mathlib.Analysis.Normed.Group.FunctionSeries
import Mathlib.Analysis.Normed.Group.Tannery
import Mathlib.Analysis.Normed.Ring.InfiniteSum
import Mathlib.Analysis.RCLike.Basic
import Mathlib.Analysis.SpecialFunctions.Pow.Continuity
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Data.Finset.NatAntidiagonal
import Mathlib.Data.Nat.Choose.Dvd
import Mathlib.Data.Nat.Factorization.Basic
import Mathlib.Data.Nat.Fib.Basic
import Mathlib.Data.Nat.Find
import Mathlib.Data.Nat.ModEq
import Mathlib.Data.Nat.Totient
import Mathlib.Data.ZMod.Basic
import Mathlib.FieldTheory.Finite.Basic
import Mathlib.LinearAlgebra.Matrix.Determinant.Basic
import Mathlib.MeasureTheory.Group.Measure
import Mathlib.MeasureTheory.Measure.Lebesgue.Basic
import Mathlib.MeasureTheory.Measure.MeasureSpace
import Mathlib.NumberTheory.ArithmeticFunction.Misc
import Mathlib.NumberTheory.ArithmeticFunction.Moebius
import Mathlib.NumberTheory.Bertrand
import Mathlib.NumberTheory.Multiplicity
import Mathlib.NumberTheory.Real.Irrational
import Mathlib.NumberTheory.TsumDivisorsAntidiagonal
import Mathlib.Order.Filter.AtTopBot.Basic
import Mathlib.RingTheory.Polynomial.Cyclotomic.Eval
import Mathlib.RingTheory.Polynomial.Cyclotomic.Expand
import Mathlib.RingTheory.Polynomial.Cyclotomic.Roots
import Mathlib.Tactic
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.GCongr
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.LinearCombination
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.Set
import Mathlib.Topology.Algebra.InfiniteSum.NatInt
import Mathlib.Topology.Algebra.InfiniteSum.Order
import Mathlib.Topology.Algebra.InfiniteSum.Ring
import Mathlib.Topology.GDelta.Basic
import Mathlib.Topology.Order.IntermediateValue
import Mathlib.Topology.Perfect

namespace ErdosProblems.Erdos257.PaperCompleteR7
end ErdosProblems.Erdos257.PaperCompleteR7

namespace P2M_Erdos257_20260927.Erdos257PeriodNoncollapse
end P2M_Erdos257_20260927.Erdos257PeriodNoncollapse

noncomputable section

namespace P2M_Erdos257_20260927.ErdosProblems.Erdos257.PaperCompleteR8
open Finset Filter Set
open Erdos257PeriodNoncollapse
open ErdosProblems.Erdos257.PaperCompleteR7
theorem coverPrefix_subset_host (C : PositiveCoverData) (J : ℕ) :
    (coverPrefix C J : Set ℕ) ⊆ C.host := by
  intro d hd
  obtain ⟨j, _, hj⟩ := (mem_coverPrefix_iff C J d).mp hd
  exact ⟨j, hj⟩
end P2M_Erdos257_20260927.ErdosProblems.Erdos257.PaperCompleteR8

open P2M_Erdos257_20260927
open P2M_Erdos257_20260927.ErdosProblems
open P2M_Erdos257_20260927.ErdosProblems.Erdos257
open P2M_Erdos257_20260927.ErdosProblems.Erdos257.PaperCompleteR8
open Finset Filter Set
open Erdos257PeriodNoncollapse
open ErdosProblems.Erdos257.PaperCompleteR7
open P2M_Erdos257_20260927 in
open P2M_Erdos257_20260927.ErdosProblems in
open P2M_Erdos257_20260927.ErdosProblems.Erdos257 in
open P2M_Erdos257_20260927.ErdosProblems.Erdos257.PaperCompleteR8 in
open P2M_Erdos257_20260927.ErdosProblems.Erdos257.PaperCompleteR7 in
theorem solution (C : PositiveCoverData) (N : ℕ) :
    Tendsto (fun J => displacement 2 (coverPrefix C J : Set ℕ) N)
      atTop (nhds (displacement 2 C.host N)) := by
  classical
  let v : ℕ → ℕ → ℝ := fun J d =>
    Set.indicator (coverPrefix C J : Set ℕ) (displacementAtom 2 N) d
  let a : ℕ → ℝ := Set.indicator C.host (displacementAtom 2 N)
  have ha : Summable a := summable_displacementAtom 2 C.host N (by norm_num)
  have ht : ∀ d, Tendsto (fun J => v J d) atTop (nhds (a d)) := by
    intro d
    by_cases hd : d ∈ C.host
    · obtain ⟨j, hj⟩ := hd
      apply tendsto_const_nhds.congr'
      filter_upwards [eventually_gt_atTop j] with J hJ
      have hp : d ∈ (coverPrefix C J : Set ℕ) :=
        (mem_coverPrefix_iff C J d).mpr ⟨j, hJ, hj⟩
      have hh : d ∈ C.host := ⟨j, hj⟩
      simp only [v, a, Set.indicator_of_mem hp, Set.indicator_of_mem hh]
    · have hv : ∀ J, v J d = 0 := by
        intro J
        have hp : d ∉ (coverPrefix C J : Set ℕ) :=
          fun h => hd (coverPrefix_subset_host C J h)
        simp [v, hp]
      have ha0 : a d = 0 := by simp [a, hd]
      simp only [hv, ha0]
      exact tendsto_const_nhds
  have hb : ∀ J d, ‖v J d‖ ≤ a d := by
    intro J d
    have hnn := displacementAtom_nonneg 2 N d (by norm_num)
    by_cases hp : d ∈ (coverPrefix C J : Set ℕ)
    · have hh := coverPrefix_subset_host C J hp
      simp only [v, a, Set.indicator_of_mem hp, Set.indicator_of_mem hh,
        Real.norm_eq_abs, abs_of_nonneg hnn, le_refl]
    · have ha0 : 0 ≤ a d := Set.indicator_nonneg (fun d _ =>
        displacementAtom_nonneg 2 N d (by norm_num)) d
      simpa [v, hp] using ha0
  -- Mathlib/Analysis/Normed/Group/Tannery.lean:
  -- tendsto_tsum_of_dominated_convergence (also used in the desk library).
  have hlim := tendsto_tsum_of_dominated_convergence ha ht
    (Filter.Eventually.of_forall hb)
  have hl : (fun J => ∑' d, v J d) =
      (fun J => displacement 2 (coverPrefix C J : Set ℕ) N) := by
    funext J
    exact (displacement_eq_tsum 2 (coverPrefix C J : Set ℕ) N (by norm_num)).symm
  have hr : (∑' d, a d) = displacement 2 C.host N :=
    (displacement_eq_tsum 2 C.host N (by norm_num)).symm
  rw [hl, hr] at hlim
  exact hlim
