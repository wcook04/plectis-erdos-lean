import Definitions.Def_P2M_Erdos257_20260927_Erdos249257_TotientTailPeriodKiller
import Definitions.Def_P2M_Erdos257_20260927_Erdos249257_CarrySurvivorExtinction
import Definitions.Def_P2M_Erdos257_20260927_Erdos249257_LcmConeFlatness
import Definitions.Def_P2M_Erdos257_20260927_Erdos249257_LcmConeNonflat
import Definitions.Def_P2M_Erdos257_20260927_Erdos249257_MersenneLambertLadder
import Definitions.Def_P2M_Erdos257_20260927_Erdos249257_SternBrocotRunGeometry
import Definitions.Def_P2M_Erdos257_20260927_Erdos249257_CertificateKernel
import Mathlib.Algebra.BigOperators.Field
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Algebra.Order.Antidiag.Prod
import Mathlib.Algebra.Ring.GeomSum
import Mathlib.Analysis.Normed.Ring.InfiniteSum
import Mathlib.Analysis.RCLike.Basic
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Data.Finset.NatAntidiagonal
import Mathlib.Data.Nat.Choose.Dvd
import Mathlib.Data.Nat.Factorization.Basic
import Mathlib.Data.Nat.Fib.Basic
import Mathlib.Data.Nat.Find
import Mathlib.Data.Nat.ModEq
import Mathlib.Data.Nat.Totient
import Mathlib.Data.ZMod.Basic
import Mathlib.FieldTheory.Finite.Basic
import Mathlib.NumberTheory.ArithmeticFunction.Misc
import Mathlib.NumberTheory.ArithmeticFunction.Moebius
import Mathlib.NumberTheory.Bertrand
import Mathlib.NumberTheory.Multiplicity
import Mathlib.NumberTheory.Real.Irrational
import Mathlib.NumberTheory.TsumDivisorsAntidiagonal
import Mathlib.RingTheory.Polynomial.Cyclotomic.Eval
import Mathlib.RingTheory.Polynomial.Cyclotomic.Expand
import Mathlib.RingTheory.Polynomial.Cyclotomic.Roots
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.GCongr
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.LinearCombination
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.Set
import Mathlib.Topology.Algebra.InfiniteSum.NatInt
import Mathlib.Topology.Algebra.InfiniteSum.Order
import Mathlib.Topology.Algebra.InfiniteSum.Ring

namespace P2M_Erdos257_20260927.Erdos249257
set_option linter.unusedTactic false
set_option linter.unreachableTactic false
open Filter Topology
end P2M_Erdos257_20260927.Erdos249257

open P2M_Erdos257_20260927
open P2M_Erdos257_20260927.Erdos249257
set_option linter.unusedTactic false
set_option linter.unreachableTactic false
open Filter Topology
open P2M_Erdos257_20260927 in
open P2M_Erdos257_20260927.Erdos249257 in
theorem solution (b : ℕ) (A : Set ℕ) (hb : 2 ≤ b) :
    Summable (fun a : ℕ =>
      Set.indicator A (fun a => (1 : ℝ) / ((b : ℝ) ^ a - 1)) a) := by
  have hb2 : (2 : ℝ) ≤ (b : ℝ) := by exact_mod_cast hb
  have hb_pos : (0 : ℝ) < (b : ℝ) := by linarith
  have hb1 : (1 : ℝ) < (b : ℝ) := by linarith
  have hgeo : Summable (fun a : ℕ => 2 * ((1 : ℝ) / b) ^ a) :=
    (summable_geometric_of_lt_one (by positivity)
      (by rw [div_lt_one hb_pos]; linarith)).mul_left 2
  refine Summable.of_nonneg_of_le (fun a => ?_) (fun a => ?_) hgeo
  · refine Set.indicator_nonneg (fun a _ => ?_) a
    rcases Nat.eq_zero_or_pos a with h0 | hpos
    · subst h0
      simp
    · have h1 : (1 : ℝ) < (b : ℝ) ^ a := one_lt_pow₀ hb1 (by omega)
      exact (div_pos one_pos (by linarith)).le
  · by_cases hA : a ∈ A
    · rw [Set.indicator_of_mem hA]
      rcases Nat.eq_zero_or_pos a with h0 | hpos
      · subst h0
        simp
      · have hba : (2 : ℝ) ≤ (b : ℝ) ^ a := by
          calc (2 : ℝ) ≤ (b : ℝ) := hb2
            _ = (b : ℝ) ^ 1 := (pow_one _).symm
            _ ≤ (b : ℝ) ^ a := pow_le_pow_right₀ (by linarith) (by omega)
        have hpow : ((1 : ℝ) / b) ^ a = 1 / (b : ℝ) ^ a := by
          rw [div_pow, one_pow]
        rw [hpow, mul_one_div]
        rw [div_le_div_iff₀ (by linarith) (by positivity)]
        linarith
    · rw [Set.indicator_of_notMem hA]
      positivity
