import Definitions.Def_P2M_Erdos257_20260927_Erdos249257_TotientTailPeriodKiller
import Definitions.Def_P2M_Erdos257_20260927_Erdos249257_CarrySurvivorExtinction
import Definitions.Def_P2M_Erdos257_20260927_Erdos249257_LcmConeFlatness
import Definitions.Def_P2M_Erdos257_20260927_Erdos249257_LcmConeNonflat
import Definitions.Def_P2M_Erdos257_20260927_Erdos249257_MersenneLambertLadder
import Definitions.Def_P2M_Erdos257_20260927_Erdos249257_SternBrocotRunGeometry
import Definitions.Def_P2M_Erdos257_20260927_Erdos249257_CertificateKernel
import Definitions.Def_P2M_Erdos257_20260927_Erdos249257_GenericTailOrbitRigidity
import Definitions.Def_P2M_Erdos257_20260927_Erdos249257_GreedyAchievementSet
import Definitions.Def_P2M_Erdos257_20260927_Erdos249257_BooleanMobiusCarry
import Definitions.Def_P2M_Erdos257_20260927_Erdos249257_RationalSupportCarrySkeleton
import Definitions.Def_P2M_Erdos257_20260927_Erdos249257_ReciprocalSupportIrrationality
import Definitions.Def_P2M_Erdos257_20260927_ErdosProblems_Erdos257_PaperCompleteR8_FiniteMeans
import Theorems.Thm_P2M_Erdos257_20260927_ErdosProblems_Erdos257_DyadicShellSynchronisation_finite_average_le_of_two_error_budgets
import Theorems.Thm_P2M_Erdos257_20260927_ErdosProblems_Erdos257_PaperCompleteR8_progressionMean_kernel_le_mean_add_error
import Theorems.Thm_P2M_Erdos257_20260927_ErdosProblems_Erdos257_PaperCompleteR8_dyadic_transition_unique
import Theorems.Thm_P2M_Erdos257_20260927_ErdosProblems_Erdos257_PaperCompleteR8_progressionMean_kernel_le_of_far
import Theorems.Thm_P2M_Erdos257_20260927_ErdosProblems_Erdos257_PaperCompleteR8_progressionMean_kernel_le_transition
import Theorems.Thm_P2M_Erdos257_20260927_ErdosProblems_Erdos257_sum_dyadic_observation_weights_le
import Mathlib
import Mathlib.Algebra.BigOperators.Field
import Mathlib.Algebra.BigOperators.Intervals
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Algebra.Order.Antidiag.Prod
import Mathlib.Algebra.Order.Ring.Pow
import Mathlib.Algebra.Ring.GeomSum
import Mathlib.Analysis.Asymptotics.SpecificAsymptotics
import Mathlib.Analysis.Convex.SpecificFunctions.Basic
import Mathlib.Analysis.MeanInequalitiesPow
import Mathlib.Analysis.Normed.Group.FunctionSeries
import Mathlib.Analysis.Normed.Group.Tannery
import Mathlib.Analysis.Normed.Ring.InfiniteSum
import Mathlib.Analysis.RCLike.Basic
import Mathlib.Analysis.SpecialFunctions.Pow.Continuity
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Data.Finset.NatAntidiagonal
import Mathlib.Data.Nat.Choose.Dvd
import Mathlib.Data.Nat.Factorization.Basic
import Mathlib.Data.Nat.Fib.Basic
import Mathlib.Data.Nat.Find
import Mathlib.Data.Nat.ModEq
import Mathlib.Data.Nat.Totient
import Mathlib.Data.ZMod.Basic
import Mathlib.FieldTheory.Finite.Basic
import Mathlib.LinearAlgebra.Matrix.Determinant.Basic
import Mathlib.MeasureTheory.Group.Measure
import Mathlib.MeasureTheory.Measure.Lebesgue.Basic
import Mathlib.MeasureTheory.Measure.MeasureSpace
import Mathlib.NumberTheory.ArithmeticFunction.Misc
import Mathlib.NumberTheory.ArithmeticFunction.Moebius
import Mathlib.NumberTheory.Bertrand
import Mathlib.NumberTheory.Multiplicity
import Mathlib.NumberTheory.Real.Irrational
import Mathlib.NumberTheory.TsumDivisorsAntidiagonal
import Mathlib.Order.Filter.AtTopBot.Basic
import Mathlib.RingTheory.Polynomial.Cyclotomic.Eval
import Mathlib.RingTheory.Polynomial.Cyclotomic.Expand
import Mathlib.RingTheory.Polynomial.Cyclotomic.Roots
import Mathlib.Tactic
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.GCongr
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.LinearCombination
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.Set
import Mathlib.Topology.Algebra.InfiniteSum.NatInt
import Mathlib.Topology.Algebra.InfiniteSum.Order
import Mathlib.Topology.Algebra.InfiniteSum.Ring
import Mathlib.Topology.GDelta.Basic
import Mathlib.Topology.Order.IntermediateValue
import Mathlib.Topology.Perfect

namespace ErdosProblems.Erdos257
end ErdosProblems.Erdos257

namespace ErdosProblems.Erdos257.DyadicShellSynchronisation
end ErdosProblems.Erdos257.DyadicShellSynchronisation

namespace ErdosProblems.Erdos257.PaperCompleteR7
end ErdosProblems.Erdos257.PaperCompleteR7

namespace P2M_Erdos257_20260927.Erdos257PeriodNoncollapse
end P2M_Erdos257_20260927.Erdos257PeriodNoncollapse

noncomputable section

namespace P2M_Erdos257_20260927.ErdosProblems.Erdos257.PaperCompleteR8
open Finset
open ErdosProblems.Erdos257
open ErdosProblems.Erdos257.PaperCompleteR7
open ErdosProblems.Erdos257.DyadicShellSynchronisation
end P2M_Erdos257_20260927.ErdosProblems.Erdos257.PaperCompleteR8

open P2M_Erdos257_20260927
open P2M_Erdos257_20260927.ErdosProblems
open P2M_Erdos257_20260927.ErdosProblems.Erdos257
open P2M_Erdos257_20260927.ErdosProblems.Erdos257.PaperCompleteR8
open Finset
open ErdosProblems.Erdos257
open ErdosProblems.Erdos257.PaperCompleteR7
open ErdosProblems.Erdos257.DyadicShellSynchronisation
open P2M_Erdos257_20260927 in
open P2M_Erdos257_20260927.ErdosProblems in
open P2M_Erdos257_20260927.ErdosProblems.Erdos257 in
open P2M_Erdos257_20260927.ErdosProblems.Erdos257.PaperCompleteR8 in
open P2M_Erdos257_20260927.ErdosProblems.Erdos257 in
open P2M_Erdos257_20260927.ErdosProblems.Erdos257.DyadicShellSynchronisation in
open P2M_Erdos257_20260927.ErdosProblems.Erdos257.PaperCompleteR7 in
theorem solution (B : ℝ) (hB : 1 < B) (hB2 : B ≤ 2)
    (L d R M : ℕ) (hL : 0 < L) (hd : 0 < d) (hM : 0 < M) :
    dyadicMean L R M (kernelWeight B d) ≤
      (1 + 4 * (L : ℝ) / M) / ((d : ℝ) * (B - 1)) := by
  classical
  let J := Finset.Ico R (R + M)
  let a : ℝ := 1 / ((d : ℝ) * (B - 1))
  let near : ℕ → ℝ := fun j =>
    if d ≤ L * 2 ^ j then (1 / 2 : ℝ) ^ j / (B - 1) else 0
  let trans : ℕ → ℝ := fun j =>
    if L * 2 ^ j < d ∧ d ≤ 2 * (L * 2 ^ j) then 2 * (L : ℝ) * a else 0
  have hgap : 0 < B - 1 := sub_pos.mpr hB
  have ha : 0 ≤ a := by dsimp [a]; positivity
  have hcard : J.card = M := by dsimp [J]; rw [Nat.card_Ico]; omega
  have hpoint : ∀ j ∈ J,
      progressionMean L (2 ^ j) (kernelWeight B d) ≤ a + near j + trans j := by
    intro j _hj
    have hT : 0 < (2 : ℕ) ^ j := by positivity
    by_cases hn : d ≤ L * 2 ^ j
    · have hnot : ¬(L * 2 ^ j < d ∧ d ≤ 2 * (L * 2 ^ j)) := by omega
      have h := progressionMean_kernel_le_mean_add_error B hB L d (2 ^ j) hL hd hT
      have hid : 1 / (((2 ^ j : ℕ) : ℝ) * (B - 1)) =
          (1 / 2 : ℝ) ^ j / (B - 1) := by
        push_cast
        rw [div_pow, one_pow]
        field_simp
        <;> ring
      rw [hid] at h
      simpa only [a, near, trans, if_pos hn, if_neg hnot, add_zero] using h
    · have hlt : L * 2 ^ j < d := Nat.lt_of_not_ge hn
      by_cases ht : d ≤ 2 * (L * 2 ^ j)
      · have h := progressionMean_kernel_le_transition hB hB2 L d (2 ^ j) hL hT hlt
        have heq : 2 * (L : ℝ) / ((d : ℝ) * (B - 1)) = 2 * (L : ℝ) * a := by
          dsimp [a]; ring
        rw [heq] at h
        have htt : L * 2 ^ j < d ∧ d ≤ 2 * (L * 2 ^ j) := ⟨hlt, ht⟩
        simp only [near, trans, if_neg hn, if_pos htt, add_zero]
        exact h.trans (le_add_of_nonneg_left ha)
      · have hfar : 2 * (L * 2 ^ j) < d := Nat.lt_of_not_ge ht
        have h := progressionMean_kernel_le_of_far hB L d (2 ^ j) hT hfar
        have hnot : ¬(L * 2 ^ j < d ∧ d ≤ 2 * (L * 2 ^ j)) := fun h => ht h.2
        simpa only [a, near, trans, if_neg hn, if_neg hnot, add_zero] using h
  have hnear : (∑ j ∈ J, near j) ≤ 2 * (L : ℝ) * a := by
    have h := sum_dyadic_observation_weights_le J L d hd
    have hdiv := div_le_div_of_nonneg_right h hgap.le
    have heq : (∑ j ∈ J, near j) =
        (∑ j ∈ J.filter (fun j => d ≤ L * 2 ^ j), (1 / 2 : ℝ) ^ j) / (B - 1) := by
      rw [Finset.sum_div, Finset.sum_filter]
    rw [heq]
    convert hdiv using 1 <;> dsimp [a] <;> field_simp <;> ring
  have htrans : (∑ j ∈ J, trans j) ≤ 2 * (L : ℝ) * a := by
    let K := J.filter (fun j => L * 2 ^ j < d ∧ d ≤ 2 * (L * 2 ^ j))
    have hKcard : K.card ≤ 1 := by
      -- Mathlib/Data/Finset/Card.lean: card_le_one.
      apply Finset.card_le_one.mpr
      intro i hi j hj
      exact dyadic_transition_unique L d (Finset.mem_filter.mp hi).2
        (Finset.mem_filter.mp hj).2
    have hKreal : (K.card : ℝ) ≤ 1 := by exact_mod_cast hKcard
    have hsum : (∑ j ∈ J, trans j) = (K.card : ℝ) * (2 * (L : ℝ) * a) := by
      calc
        _ = ∑ _j ∈ K, 2 * (L : ℝ) * a := by
          dsimp [K]
          simp only [Finset.sum_filter, trans]
        _ = _ := by rw [Finset.sum_const, nsmul_eq_mul]
    rw [hsum]
    have h := mul_le_mul_of_nonneg_right hKreal
      (mul_nonneg (mul_nonneg (by norm_num : (0 : ℝ) ≤ 2) (Nat.cast_nonneg L)) ha)
    simpa only [one_mul] using h
  have hbudget := finite_average_le_of_two_error_budgets
    J M hM hcard (L : ℝ) a
    (fun j => progressionMean L (2 ^ j) (kernelWeight B d)) near trans
    hpoint hnear htrans
  change (∑ j ∈ J, progressionMean L (2 ^ j) (kernelWeight B d)) / (M : ℝ) ≤ _
  convert hbudget using 1 <;> dsimp [a] <;> ring
