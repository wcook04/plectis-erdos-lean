import Mathlib.Algebra.Order.Ring.Pow
import Mathlib.Analysis.Convex.SpecificFunctions.Basic
import Mathlib.Analysis.MeanInequalitiesPow
import Mathlib.Analysis.SpecialFunctions.Pow.Continuity
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.Tactic

namespace P2M_Erdos257_20260927
end P2M_Erdos257_20260927

namespace P2M_Erdos257_20260927.ErdosProblems.Erdos257.PaperCompleteR7
end P2M_Erdos257_20260927.ErdosProblems.Erdos257.PaperCompleteR7

noncomputable section

namespace P2M_Erdos257_20260927.ErdosProblems.Erdos257.PaperCompleteR7
open Finset Filter
/-- Bernoulli in the form the complete-cycle step uses. -/
theorem mul_sub_one_le_pow_sub_one (B : ℝ) (hB : 1 ≤ B) (g : ℕ) :
    (g : ℝ) * (B - 1) ≤ B ^ g - 1 := by
  have h : (1 : ℝ) + (g : ℝ) * (B - 1) ≤ (1 + (B - 1)) ^ g :=
    one_add_mul_le_pow (by linarith) g
  have hrw : (1 : ℝ) + (B - 1) = B := by ring
  rw [hrw] at h
  linarith
end P2M_Erdos257_20260927.ErdosProblems.Erdos257.PaperCompleteR7

open P2M_Erdos257_20260927
open P2M_Erdos257_20260927.ErdosProblems
open P2M_Erdos257_20260927.ErdosProblems.Erdos257
open P2M_Erdos257_20260927.ErdosProblems.Erdos257.PaperCompleteR7
open Finset Filter
open P2M_Erdos257_20260927 in
open P2M_Erdos257_20260927.ErdosProblems in
open P2M_Erdos257_20260927.ErdosProblems.Erdos257 in
open P2M_Erdos257_20260927.ErdosProblems.Erdos257.PaperCompleteR7 in
theorem solution {B : ℝ} (hB : 1 < B) (g : ℕ) (hg : 0 < g) :
    (g : ℝ) / (B ^ g - 1) ≤ 1 / (B - 1) := by
  have hB1 : (0 : ℝ) < B - 1 := by linarith
  have hgB : (1 : ℝ) < B ^ g := one_lt_pow₀ hB hg.ne'
  have hden : (0 : ℝ) < B ^ g - 1 := by linarith
  rw [div_le_div_iff₀ hden hB1]
  have := mul_sub_one_le_pow_sub_one B hB.le g
  linarith
