import Definitions.Def_P2M_Erdos257_20260927_Erdos249257_TotientTailPeriodKiller
import Definitions.Def_P2M_Erdos257_20260927_Erdos249257_CarrySurvivorExtinction
import Definitions.Def_P2M_Erdos257_20260927_Erdos249257_LcmConeFlatness
import Definitions.Def_P2M_Erdos257_20260927_Erdos249257_LcmConeNonflat
import Definitions.Def_P2M_Erdos257_20260927_Erdos249257_MersenneLambertLadder
import Definitions.Def_P2M_Erdos257_20260927_Erdos249257_SternBrocotRunGeometry
import Definitions.Def_P2M_Erdos257_20260927_Erdos249257_CertificateKernel
import Definitions.Def_P2M_Erdos257_20260927_Erdos249257_GenericTailOrbitRigidity
import Definitions.Def_P2M_Erdos257_20260927_Erdos249257_GreedyAchievementSet
import Definitions.Def_P2M_Erdos257_20260927_Erdos249257_BooleanMobiusCarry
import Definitions.Def_P2M_Erdos257_20260927_Erdos249257_RationalSupportCarrySkeleton
import Definitions.Def_P2M_Erdos257_20260927_Erdos249257_ReciprocalSupportIrrationality
import Definitions.Def_P2M_Erdos257_20260927_Erdos249257_AllBaseReciprocalSupportIrrationality
import Definitions.Def_P2M_Erdos257_20260927_ErdosProblems_Erdos257_PaperCompleteR7_Displacement
import Definitions.Def_P2M_Erdos257_20260927_ErdosProblems_Erdos257_PaperCompleteR7_AnalyticTargets
import Definitions.Def_P2M_Erdos257_20260927_ErdosProblems_Erdos257_PaperCompleteR8_FiniteMeans
import Definitions.Def_P2M_Erdos257_20260927_ErdosProblems_Erdos257_PaperCompleteR8_KernelRecurrence
import Theorems.Thm_P2M_Erdos257_20260927_ErdosProblems_Erdos257_PaperCompleteR8_divisorPotential_nonneg
import Theorems.Thm_P2M_Erdos257_20260927_ErdosProblems_Erdos257_PaperCompleteR8_framePotential_nonneg
import Theorems.Thm_P2M_Erdos257_20260927_ErdosProblems_Erdos257_PaperCompleteR8_divisorPotential_step
import Theorems.Thm_P2M_Erdos257_20260927_ErdosProblems_Erdos257_PaperCompleteR8_expanding_subsolution_nonpos
import Theorems.Thm_P2M_Erdos257_20260927_ErdosProblems_Erdos257_PaperCompleteR8_framePotential_step
import Theorems.Thm_P2M_Erdos257_20260927_ErdosProblems_Erdos257_PaperCompleteR8_kernelWeight_two_le_one
import Mathlib
import Mathlib.Algebra.BigOperators.Field
import Mathlib.Algebra.BigOperators.Intervals
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Algebra.Order.Antidiag.Prod
import Mathlib.Algebra.Order.Ring.Pow
import Mathlib.Algebra.Ring.GeomSum
import Mathlib.Analysis.Asymptotics.SpecificAsymptotics
import Mathlib.Analysis.Convex.SpecificFunctions.Basic
import Mathlib.Analysis.MeanInequalitiesPow
import Mathlib.Analysis.Normed.Group.FunctionSeries
import Mathlib.Analysis.Normed.Group.Tannery
import Mathlib.Analysis.Normed.Ring.InfiniteSum
import Mathlib.Analysis.RCLike.Basic
import Mathlib.Analysis.SpecialFunctions.Pow.Continuity
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Data.Finset.NatAntidiagonal
import Mathlib.Data.Nat.Choose.Dvd
import Mathlib.Data.Nat.Factorization.Basic
import Mathlib.Data.Nat.Fib.Basic
import Mathlib.Data.Nat.Find
import Mathlib.Data.Nat.ModEq
import Mathlib.Data.Nat.Totient
import Mathlib.Data.ZMod.Basic
import Mathlib.FieldTheory.Finite.Basic
import Mathlib.LinearAlgebra.Matrix.Determinant.Basic
import Mathlib.MeasureTheory.Group.Measure
import Mathlib.MeasureTheory.Measure.Lebesgue.Basic
import Mathlib.MeasureTheory.Measure.MeasureSpace
import Mathlib.NumberTheory.ArithmeticFunction.Misc
import Mathlib.NumberTheory.ArithmeticFunction.Moebius
import Mathlib.NumberTheory.Bertrand
import Mathlib.NumberTheory.Multiplicity
import Mathlib.NumberTheory.Real.Irrational
import Mathlib.NumberTheory.TsumDivisorsAntidiagonal
import Mathlib.Order.Filter.AtTopBot.Basic
import Mathlib.RingTheory.Polynomial.Cyclotomic.Eval
import Mathlib.RingTheory.Polynomial.Cyclotomic.Expand
import Mathlib.RingTheory.Polynomial.Cyclotomic.Roots
import Mathlib.Tactic
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.GCongr
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.LinearCombination
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.Set
import Mathlib.Topology.Algebra.InfiniteSum.NatInt
import Mathlib.Topology.Algebra.InfiniteSum.Order
import Mathlib.Topology.Algebra.InfiniteSum.Ring
import Mathlib.Topology.GDelta.Basic
import Mathlib.Topology.Order.IntermediateValue
import Mathlib.Topology.Perfect

namespace ErdosProblems.Erdos257.PaperCompleteR7
end ErdosProblems.Erdos257.PaperCompleteR7

namespace P2M_Erdos257_20260927.Erdos257PeriodNoncollapse
end P2M_Erdos257_20260927.Erdos257PeriodNoncollapse

noncomputable section

namespace P2M_Erdos257_20260927.ErdosProblems.Erdos257.PaperCompleteR8
open Finset
open Erdos257PeriodNoncollapse
open ErdosProblems.Erdos257.PaperCompleteR7
theorem framePotential_le_card (F : Finset ℕ) (N : ℕ) :
    framePotential F N ≤ (F.card : ℝ) := by
  calc
    _ ≤ ∑ _a ∈ F, (1 : ℝ) := Finset.sum_le_sum (fun a _ => kernelWeight_two_le_one a N)
    _ = _ := by simp only [Finset.sum_const, nsmul_eq_mul, mul_one]
end P2M_Erdos257_20260927.ErdosProblems.Erdos257.PaperCompleteR8

open P2M_Erdos257_20260927
open P2M_Erdos257_20260927.ErdosProblems
open P2M_Erdos257_20260927.ErdosProblems.Erdos257
open P2M_Erdos257_20260927.ErdosProblems.Erdos257.PaperCompleteR8
open Finset
open Erdos257PeriodNoncollapse
open ErdosProblems.Erdos257.PaperCompleteR7
open P2M_Erdos257_20260927 in
open P2M_Erdos257_20260927.ErdosProblems in
open P2M_Erdos257_20260927.ErdosProblems.Erdos257 in
open P2M_Erdos257_20260927.ErdosProblems.Erdos257.PaperCompleteR8 in
open P2M_Erdos257_20260927.ErdosProblems.Erdos257.PaperCompleteR7 in
theorem solution
    (F : Finset ℕ) (hF : 0 ∉ F) (α : ℝ) (hα : 0 < α) (hα1 : α ≤ 1)
    (c : ℕ → ℝ) (hc : ∀ d, 0 < d → 0 ≤ c d)
    (hs : Summable (fun d : ℕ => c d / (d : ℝ)))
    (hmajor : ∀ n : ℕ, 0 < n →
      (((F.filter (fun a => a ∣ n)).card : ℝ) ^ α) ≤ ∑ d ∈ n.divisors, c d)
    (N : ℕ) :
    framePotential F N ^ α ≤ divisorPotential ((2 : ℝ) ^ α) c N := by
  let B : ℝ := (2 : ℝ) ^ α
  have hB : 1 < B := Real.one_lt_rpow_iff_of_pos (by norm_num) |>.mpr
    (Or.inl ⟨by norm_num, hα⟩)
  let z : ℕ → ℝ := fun n => framePotential F n ^ α - divisorPotential B c n
  have hstep : ∀ n : ℕ, B * z n ≤ z (n + 1) := by
    intro n
    let f : ℝ := ((F.filter (fun a => a ∣ n + 1)).card : ℝ)
    have hf : 0 ≤ f := Nat.cast_nonneg _
    have hlinear : 2 * framePotential F n = framePotential F (n + 1) + f := by
      have hh := framePotential_step F hF n
      dsimp [f]
      linarith only [hh]
    have hfrac : B * framePotential F n ^ α ≤ framePotential F (n + 1) ^ α + f ^ α := by
      calc
        _ = (2 * framePotential F n) ^ α :=
          (Real.mul_rpow (by norm_num : (0 : ℝ) ≤ 2) (framePotential_nonneg F n)).symm
        _ = (framePotential F (n + 1) + f) ^ α := congrArg (fun x : ℝ => x ^ α) hlinear
        _ ≤ _ := Real.rpow_add_le_add_rpow (framePotential_nonneg F (n + 1)) hf hα.le hα1
    have hpulse := hmajor (n + 1) (Nat.succ_pos n)
    have hV := divisorPotential_step B hB c hc hs n
    change B * (framePotential F n ^ α - divisorPotential B c n) ≤
      framePotential F (n + 1) ^ α - divisorPotential B c (n + 1)
    change f ^ α ≤ _ at hpulse
    nlinarith only [hfrac, hpulse, hV]
  have hbound : ∀ n : ℕ, z n ≤ (F.card : ℝ) ^ α := by
    intro n
    have hpow := Real.rpow_le_rpow (framePotential_nonneg F n)
      (framePotential_le_card F n) hα.le
    have hV := divisorPotential_nonneg B hB c hc n
    dsimp [z]
    linarith only [hpow, hV]
  have hz := expanding_subsolution_nonpos B hB z ((F.card : ℝ) ^ α) hstep hbound N
  exact sub_nonpos.mp hz
