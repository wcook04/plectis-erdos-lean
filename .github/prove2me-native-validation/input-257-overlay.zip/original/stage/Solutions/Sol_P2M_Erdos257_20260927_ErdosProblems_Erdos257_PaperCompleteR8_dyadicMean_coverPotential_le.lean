import Definitions.Def_P2M_Erdos257_20260927_Erdos249257_TotientTailPeriodKiller
import Definitions.Def_P2M_Erdos257_20260927_Erdos249257_CarrySurvivorExtinction
import Definitions.Def_P2M_Erdos257_20260927_Erdos249257_LcmConeFlatness
import Definitions.Def_P2M_Erdos257_20260927_Erdos249257_LcmConeNonflat
import Definitions.Def_P2M_Erdos257_20260927_Erdos249257_MersenneLambertLadder
import Definitions.Def_P2M_Erdos257_20260927_Erdos249257_SternBrocotRunGeometry
import Definitions.Def_P2M_Erdos257_20260927_Erdos249257_CertificateKernel
import Definitions.Def_P2M_Erdos257_20260927_Erdos249257_GenericTailOrbitRigidity
import Definitions.Def_P2M_Erdos257_20260927_Erdos249257_GreedyAchievementSet
import Definitions.Def_P2M_Erdos257_20260927_Erdos249257_BooleanMobiusCarry
import Definitions.Def_P2M_Erdos257_20260927_Erdos249257_RationalSupportCarrySkeleton
import Definitions.Def_P2M_Erdos257_20260927_Erdos249257_ReciprocalSupportIrrationality
import Definitions.Def_P2M_Erdos257_20260927_Erdos249257_AllBaseReciprocalSupportIrrationality
import Definitions.Def_P2M_Erdos257_20260927_ErdosProblems_Erdos257_PaperCompleteR7_Displacement
import Definitions.Def_P2M_Erdos257_20260927_ErdosProblems_Erdos257_PaperCompleteR7_AnalyticTargets
import Definitions.Def_P2M_Erdos257_20260927_ErdosProblems_Erdos257_PaperCompleteR8_FiniteMeans
import Definitions.Def_P2M_Erdos257_20260927_ErdosProblems_Erdos257_PaperCompleteR8_KernelRecurrence
import Definitions.Def_P2M_Erdos257_20260927_ErdosProblems_Erdos257_PaperCompleteR8_CoverPotentialBounds
import Theorems.Thm_P2M_Erdos257_20260927_Erdos249257_positiveSupportBitAF_apply
import Theorems.Thm_P2M_Erdos257_20260927_Erdos249257_supportCoeffAF_apply
import Theorems.Thm_P2M_Erdos257_20260927_Erdos249257_twentyOneGreedyCarry_zero
import Theorems.Thm_P2M_Erdos257_20260927_ErdosProblems_Erdos257_PaperCompleteR8_coverBase_gt_one
import Theorems.Thm_P2M_Erdos257_20260927_ErdosProblems_Erdos257_PaperCompleteR8_kernelWeight_nonneg
import Theorems.Thm_P2M_Erdos257_20260927_ErdosProblems_Erdos257_PaperCompleteR8_summable_divisorPotential_terms
import Theorems.Thm_P2M_Erdos257_20260927_ErdosProblems_Erdos257_PaperCompleteR8_dyadicMean_const_mul
import Theorems.Thm_P2M_Erdos257_20260927_ErdosProblems_Erdos257_PaperCompleteR8_dyadicMean_kernelWeight_le
import Theorems.Thm_P2M_Erdos257_20260927_ErdosProblems_Erdos257_PaperCompleteR8_dyadicMean_nonneg
import Theorems.Thm_P2M_Erdos257_20260927_ErdosProblems_Erdos257_PaperCompleteR8_tsum_dyadicMean
import Mathlib
import Mathlib.Algebra.BigOperators.Field
import Mathlib.Algebra.BigOperators.Intervals
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Algebra.Order.Antidiag.Prod
import Mathlib.Algebra.Order.Ring.Pow
import Mathlib.Algebra.Ring.GeomSum
import Mathlib.Analysis.Asymptotics.SpecificAsymptotics
import Mathlib.Analysis.Convex.SpecificFunctions.Basic
import Mathlib.Analysis.MeanInequalitiesPow
import Mathlib.Analysis.Normed.Group.FunctionSeries
import Mathlib.Analysis.Normed.Group.Tannery
import Mathlib.Analysis.Normed.Ring.InfiniteSum
import Mathlib.Analysis.RCLike.Basic
import Mathlib.Analysis.SpecialFunctions.Pow.Continuity
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Data.Finset.NatAntidiagonal
import Mathlib.Data.Nat.Choose.Dvd
import Mathlib.Data.Nat.Factorization.Basic
import Mathlib.Data.Nat.Fib.Basic
import Mathlib.Data.Nat.Find
import Mathlib.Data.Nat.ModEq
import Mathlib.Data.Nat.Totient
import Mathlib.Data.ZMod.Basic
import Mathlib.FieldTheory.Finite.Basic
import Mathlib.LinearAlgebra.Matrix.Determinant.Basic
import Mathlib.MeasureTheory.Group.Measure
import Mathlib.MeasureTheory.Measure.Lebesgue.Basic
import Mathlib.MeasureTheory.Measure.MeasureSpace
import Mathlib.NumberTheory.ArithmeticFunction.Misc
import Mathlib.NumberTheory.ArithmeticFunction.Moebius
import Mathlib.NumberTheory.Bertrand
import Mathlib.NumberTheory.Multiplicity
import Mathlib.NumberTheory.Real.Irrational
import Mathlib.NumberTheory.TsumDivisorsAntidiagonal
import Mathlib.Order.Filter.AtTopBot.Basic
import Mathlib.RingTheory.Polynomial.Cyclotomic.Eval
import Mathlib.RingTheory.Polynomial.Cyclotomic.Expand
import Mathlib.RingTheory.Polynomial.Cyclotomic.Roots
import Mathlib.Tactic
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.GCongr
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.LinearCombination
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.Set
import Mathlib.Topology.Algebra.InfiniteSum.NatInt
import Mathlib.Topology.Algebra.InfiniteSum.Order
import Mathlib.Topology.Algebra.InfiniteSum.Ring
import Mathlib.Topology.GDelta.Basic
import Mathlib.Topology.Order.IntermediateValue
import Mathlib.Topology.Perfect

namespace ErdosProblems.Erdos257.PaperCompleteR7
end ErdosProblems.Erdos257.PaperCompleteR7

namespace P2M_Erdos257_20260927.Erdos257PeriodNoncollapse
end P2M_Erdos257_20260927.Erdos257PeriodNoncollapse

noncomputable section

namespace P2M_Erdos257_20260927.ErdosProblems.Erdos257.PaperCompleteR8
open Finset Filter
open ErdosProblems.Erdos257.PaperCompleteR7
theorem coverBase_le_two (C : PositiveCoverData) (j : ℕ) : coverBase C j ≤ 2 := by
  have h := Real.rpow_le_rpow_of_exponent_le (by norm_num : (1 : ℝ) ≤ 2)
    (C.exponent_bounds j).2
  simpa only [Real.rpow_one] using h
end P2M_Erdos257_20260927.ErdosProblems.Erdos257.PaperCompleteR8

open P2M_Erdos257_20260927
open P2M_Erdos257_20260927.ErdosProblems
open P2M_Erdos257_20260927.ErdosProblems.Erdos257
open P2M_Erdos257_20260927.ErdosProblems.Erdos257.PaperCompleteR8
open Finset Filter
open ErdosProblems.Erdos257.PaperCompleteR7
open P2M_Erdos257_20260927 in
open P2M_Erdos257_20260927.ErdosProblems in
open P2M_Erdos257_20260927.ErdosProblems.Erdos257 in
open P2M_Erdos257_20260927.ErdosProblems.Erdos257.PaperCompleteR8 in
open P2M_Erdos257_20260927.ErdosProblems.Erdos257.PaperCompleteR7 in
theorem solution (C : PositiveCoverData) (j L R M : ℕ)
    (hL : 0 < L) (hM : 0 < M) :
    dyadicMean L R M (coverPotential C j) ≤
      (1 + 4 * (L : ℝ) / M) * (C.cost j / (coverBase C j - 1)) := by
  let B := coverBase C j
  let K : ℝ := 1 + 4 * (L : ℝ) / M
  let u : ℕ → ℕ → ℝ := fun d N => C.coefficient j d * kernelWeight B d N
  have hB : 1 < B := coverBase_gt_one C j
  have hB2 : B ≤ 2 := coverBase_le_two C j
  have hu : ∀ N : ℕ, Summable (fun d => u d N) :=
    summable_divisorPotential_terms B hB (C.coefficient j)
      (C.coefficient_nonneg j) (C.column_summable j)
  have hdom : Summable (fun d : ℕ => K * ((C.coefficient j d / (d : ℝ)) / (B - 1))) :=
    ((C.column_summable j).div_const (B - 1)).mul_left K
  have hnonneg : ∀ d N, 0 ≤ u d N := by
    intro d N
    rcases Nat.eq_zero_or_pos d with rfl | hd
    · simp [u, kernelWeight]
    · exact mul_nonneg (C.coefficient_nonneg j d hd) (kernelWeight_nonneg hB d N)
  have hpoint : ∀ d : ℕ,
      dyadicMean L R M (u d) ≤ K * ((C.coefficient j d / (d : ℝ)) / (B - 1)) := by
    intro d
    rcases Nat.eq_zero_or_pos d with rfl | hd
    · simp [u, kernelWeight, dyadicMean, progressionMean]
    · rw [show u d = (fun N => C.coefficient j d * kernelWeight B d N) from rfl,
        dyadicMean_const_mul]
      have h := mul_le_mul_of_nonneg_left
        (dyadicMean_kernelWeight_le B hB hB2 L d R M hL hd hM)
        (C.coefficient_nonneg j d hd)
      dsimp only [K]
      simp only [div_eq_mul_inv, mul_inv_rev] at h ⊢
      convert h using 1 <;> ring
  have hs : Summable (fun d => dyadicMean L R M (u d)) :=
    Summable.of_nonneg_of_le
      (fun d => dyadicMean_nonneg L R M (u d) (hnonneg d)) hpoint hdom
  have h := Summable.tsum_le_tsum hpoint hs hdom
  rw [tsum_dyadicMean u hu L R M, tsum_mul_left, tsum_div_const] at h
  exact h
