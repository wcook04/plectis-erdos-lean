import Definitions.Def_P2M_Erdos257_20260927_Erdos249257_TotientTailPeriodKiller
import Definitions.Def_P2M_Erdos257_20260927_Erdos249257_CarrySurvivorExtinction
import Definitions.Def_P2M_Erdos257_20260927_Erdos249257_LcmConeFlatness
import Definitions.Def_P2M_Erdos257_20260927_Erdos249257_LcmConeNonflat
import Definitions.Def_P2M_Erdos257_20260927_Erdos249257_MersenneLambertLadder
import Definitions.Def_P2M_Erdos257_20260927_Erdos249257_SternBrocotRunGeometry
import Definitions.Def_P2M_Erdos257_20260927_Erdos249257_CertificateKernel
import Definitions.Def_P2M_Erdos257_20260927_Erdos249257_GenericTailOrbitRigidity
import Definitions.Def_P2M_Erdos257_20260927_Erdos249257_GreedyAchievementSet
import Definitions.Def_P2M_Erdos257_20260927_Erdos249257_BooleanMobiusCarry
import Definitions.Def_P2M_Erdos257_20260927_Erdos249257_RationalSupportCarrySkeleton
import Definitions.Def_P2M_Erdos257_20260927_Erdos249257_ReciprocalSupportIrrationality
import Definitions.Def_P2M_Erdos257_20260927_Erdos249257_AllBaseReciprocalSupportIrrationality
import Definitions.Def_P2M_Erdos257_20260927_ErdosProblems_Erdos257_PaperCompleteR7_Displacement
import Definitions.Def_P2M_Erdos257_20260927_ErdosProblems_Erdos257_PaperCompleteR7_AnalyticTargets
import Definitions.Def_P2M_Erdos257_20260927_ErdosProblems_Erdos257_PaperCompleteR8_FiniteMeans
import Definitions.Def_P2M_Erdos257_20260927_ErdosProblems_Erdos257_PaperCompleteR8_KernelRecurrence
import Definitions.Def_P2M_Erdos257_20260927_ErdosProblems_Erdos257_PaperCompleteR8_WeightedPrimeProfile
import Mathlib
import Mathlib.Algebra.BigOperators.Field
import Mathlib.Algebra.BigOperators.Intervals
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Algebra.Order.Antidiag.Prod
import Mathlib.Algebra.Order.Ring.Pow
import Mathlib.Algebra.Ring.GeomSum
import Mathlib.Analysis.Asymptotics.SpecificAsymptotics
import Mathlib.Analysis.Convex.SpecificFunctions.Basic
import Mathlib.Analysis.MeanInequalitiesPow
import Mathlib.Analysis.Normed.Group.FunctionSeries
import Mathlib.Analysis.Normed.Group.Tannery
import Mathlib.Analysis.Normed.Ring.InfiniteSum
import Mathlib.Analysis.RCLike.Basic
import Mathlib.Analysis.SpecialFunctions.Pow.Continuity
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Data.Finset.NatAntidiagonal
import Mathlib.Data.Nat.Choose.Dvd
import Mathlib.Data.Nat.Factorization.Basic
import Mathlib.Data.Nat.Fib.Basic
import Mathlib.Data.Nat.Find
import Mathlib.Data.Nat.ModEq
import Mathlib.Data.Nat.Totient
import Mathlib.Data.ZMod.Basic
import Mathlib.FieldTheory.Finite.Basic
import Mathlib.LinearAlgebra.Matrix.Determinant.Basic
import Mathlib.MeasureTheory.Group.Measure
import Mathlib.MeasureTheory.Measure.Lebesgue.Basic
import Mathlib.MeasureTheory.Measure.MeasureSpace
import Mathlib.NumberTheory.ArithmeticFunction.Misc
import Mathlib.NumberTheory.ArithmeticFunction.Moebius
import Mathlib.NumberTheory.Bertrand
import Mathlib.NumberTheory.Multiplicity
import Mathlib.NumberTheory.Real.Irrational
import Mathlib.NumberTheory.TsumDivisorsAntidiagonal
import Mathlib.Order.Filter.AtTopBot.Basic
import Mathlib.RingTheory.Polynomial.Cyclotomic.Eval
import Mathlib.RingTheory.Polynomial.Cyclotomic.Expand
import Mathlib.RingTheory.Polynomial.Cyclotomic.Roots
import Mathlib.Tactic
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.GCongr
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.LinearCombination
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.Set
import Mathlib.Topology.Algebra.InfiniteSum.NatInt
import Mathlib.Topology.Algebra.InfiniteSum.Order
import Mathlib.Topology.Algebra.InfiniteSum.Ring
import Mathlib.Topology.GDelta.Basic
import Mathlib.Topology.Order.IntermediateValue
import Mathlib.Topology.Perfect

namespace ErdosProblems.Erdos257.PaperCompleteR7
end ErdosProblems.Erdos257.PaperCompleteR7

namespace P2M_Erdos257_20260927.Erdos257PeriodNoncollapse
end P2M_Erdos257_20260927.Erdos257PeriodNoncollapse

noncomputable section

namespace P2M_Erdos257_20260927.ErdosProblems.Erdos257.PaperCompleteR8
open Finset
open ErdosProblems.Erdos257.PaperCompleteR7
end P2M_Erdos257_20260927.ErdosProblems.Erdos257.PaperCompleteR8

open P2M_Erdos257_20260927
open P2M_Erdos257_20260927.ErdosProblems
open P2M_Erdos257_20260927.ErdosProblems.Erdos257
open P2M_Erdos257_20260927.ErdosProblems.Erdos257.PaperCompleteR8
open Finset
open ErdosProblems.Erdos257.PaperCompleteR7
open P2M_Erdos257_20260927 in
open P2M_Erdos257_20260927.ErdosProblems in
open P2M_Erdos257_20260927.ErdosProblems.Erdos257 in
open P2M_Erdos257_20260927.ErdosProblems.Erdos257.PaperCompleteR8 in
open P2M_Erdos257_20260927.ErdosProblems.Erdos257.PaperCompleteR7 in
theorem solution (P : Finset ℕ) (a H : ℕ)
    (h : ∀ p ∈ P, a.factorization p ≤ H) :
    primeSetPart P a ∣ P.prod id ^ H := by
  classical
  unfold primeSetPart
  revert h
  induction P using Finset.induction_on with
  | empty => intro h; simp only [Finset.prod_empty, one_pow, dvd_refl]
  | @insert p S hpS ih =>
    intro h
    have hhead : a.factorization p ≤ H := h p (Finset.mem_insert_self p S)
    have htail : ∀ q ∈ S, a.factorization q ≤ H :=
      fun q hq => h q (Finset.mem_insert_of_mem hq)
    rw [Finset.prod_insert hpS, Finset.prod_insert hpS, mul_pow]
    exact Nat.mul_dvd_mul (pow_dvd_pow p hhead) (ih htail)
