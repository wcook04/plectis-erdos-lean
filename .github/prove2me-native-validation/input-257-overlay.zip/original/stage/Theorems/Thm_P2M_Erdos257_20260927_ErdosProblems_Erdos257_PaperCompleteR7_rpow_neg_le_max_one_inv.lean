import Mathlib.Algebra.Order.Ring.Pow
import Mathlib.Analysis.Convex.SpecificFunctions.Basic
import Mathlib.Analysis.MeanInequalitiesPow
import Mathlib.Analysis.SpecialFunctions.Pow.Continuity
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.Tactic

namespace P2M_Erdos257_20260927
end P2M_Erdos257_20260927

namespace P2M_Erdos257_20260927.ErdosProblems.Erdos257.PaperCompleteR7
end P2M_Erdos257_20260927.ErdosProblems.Erdos257.PaperCompleteR7

open P2M_Erdos257_20260927
open P2M_Erdos257_20260927.ErdosProblems
open P2M_Erdos257_20260927.ErdosProblems.Erdos257
open P2M_Erdos257_20260927.ErdosProblems.Erdos257.PaperCompleteR7
noncomputable section
open Finset Filter

open P2M_Erdos257_20260927.ErdosProblems.Erdos257.PaperCompleteR7

theorem P2M_Erdos257_20260927.ErdosProblems.Erdos257.PaperCompleteR7.rpow_neg_le_max_one_inv {t α : ℝ} (ht : 0 < t) (hα : 0 < α) (hα1 : α ≤ 1) :
    t ^ (-α) ≤ max 1 t⁻¹ := by sorry
