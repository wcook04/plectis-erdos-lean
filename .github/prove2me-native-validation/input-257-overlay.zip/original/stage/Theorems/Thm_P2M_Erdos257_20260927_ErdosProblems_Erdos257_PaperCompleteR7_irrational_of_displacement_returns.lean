import Definitions.Def_P2M_Erdos257_20260927_Erdos249257_TotientTailPeriodKiller
import Definitions.Def_P2M_Erdos257_20260927_Erdos249257_CarrySurvivorExtinction
import Definitions.Def_P2M_Erdos257_20260927_Erdos249257_LcmConeFlatness
import Definitions.Def_P2M_Erdos257_20260927_Erdos249257_LcmConeNonflat
import Definitions.Def_P2M_Erdos257_20260927_Erdos249257_MersenneLambertLadder
import Definitions.Def_P2M_Erdos257_20260927_Erdos249257_SternBrocotRunGeometry
import Definitions.Def_P2M_Erdos257_20260927_Erdos249257_CertificateKernel
import Definitions.Def_P2M_Erdos257_20260927_Erdos249257_GenericTailOrbitRigidity
import Definitions.Def_P2M_Erdos257_20260927_Erdos249257_GreedyAchievementSet
import Definitions.Def_P2M_Erdos257_20260927_Erdos249257_BooleanMobiusCarry
import Definitions.Def_P2M_Erdos257_20260927_Erdos249257_RationalSupportCarrySkeleton
import Definitions.Def_P2M_Erdos257_20260927_Erdos249257_ReciprocalSupportIrrationality
import Definitions.Def_P2M_Erdos257_20260927_Erdos249257_AllBaseReciprocalSupportIrrationality
import Definitions.Def_P2M_Erdos257_20260927_ErdosProblems_Erdos257_PaperCompleteR7_Displacement
import Mathlib.Algebra.BigOperators.Field
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Algebra.Order.Antidiag.Prod
import Mathlib.Algebra.Ring.GeomSum
import Mathlib.Analysis.Asymptotics.SpecificAsymptotics
import Mathlib.Analysis.Normed.Group.FunctionSeries
import Mathlib.Analysis.Normed.Group.Tannery
import Mathlib.Analysis.Normed.Ring.InfiniteSum
import Mathlib.Analysis.RCLike.Basic
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Data.Finset.NatAntidiagonal
import Mathlib.Data.Nat.Choose.Dvd
import Mathlib.Data.Nat.Factorization.Basic
import Mathlib.Data.Nat.Fib.Basic
import Mathlib.Data.Nat.Find
import Mathlib.Data.Nat.ModEq
import Mathlib.Data.Nat.Totient
import Mathlib.Data.ZMod.Basic
import Mathlib.FieldTheory.Finite.Basic
import Mathlib.LinearAlgebra.Matrix.Determinant.Basic
import Mathlib.MeasureTheory.Group.Measure
import Mathlib.MeasureTheory.Measure.Lebesgue.Basic
import Mathlib.MeasureTheory.Measure.MeasureSpace
import Mathlib.NumberTheory.ArithmeticFunction.Misc
import Mathlib.NumberTheory.ArithmeticFunction.Moebius
import Mathlib.NumberTheory.Bertrand
import Mathlib.NumberTheory.Multiplicity
import Mathlib.NumberTheory.Real.Irrational
import Mathlib.NumberTheory.TsumDivisorsAntidiagonal
import Mathlib.Order.Filter.AtTopBot.Basic
import Mathlib.RingTheory.Polynomial.Cyclotomic.Eval
import Mathlib.RingTheory.Polynomial.Cyclotomic.Expand
import Mathlib.RingTheory.Polynomial.Cyclotomic.Roots
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.GCongr
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.LinearCombination
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.Set
import Mathlib.Topology.Algebra.InfiniteSum.NatInt
import Mathlib.Topology.Algebra.InfiniteSum.Order
import Mathlib.Topology.Algebra.InfiniteSum.Ring
import Mathlib.Topology.GDelta.Basic
import Mathlib.Topology.Order.IntermediateValue
import Mathlib.Topology.Perfect

namespace P2M_Erdos257_20260927.Erdos257PeriodNoncollapse
end P2M_Erdos257_20260927.Erdos257PeriodNoncollapse

open P2M_Erdos257_20260927
open P2M_Erdos257_20260927.ErdosProblems
open P2M_Erdos257_20260927.ErdosProblems.Erdos257
open P2M_Erdos257_20260927.ErdosProblems.Erdos257.PaperCompleteR7
noncomputable section
open Erdos257PeriodNoncollapse Filter Set

open P2M_Erdos257_20260927.ErdosProblems.Erdos257.PaperCompleteR7

theorem P2M_Erdos257_20260927.ErdosProblems.Erdos257.PaperCompleteR7.irrational_of_displacement_returns (b : ℕ) (A : Set ℕ)
    (hb : 2 ≤ b) (hA : A.Infinite)
    (hreturn : ∀ ε : ℝ, 0 < ε → ∃ N : ℕ, 0 < N ∧ displacement b A N < ε) :
    Irrational (P2M_Erdos257_20260927.Erdos249257.erdosSupportSeries b A) := by sorry
