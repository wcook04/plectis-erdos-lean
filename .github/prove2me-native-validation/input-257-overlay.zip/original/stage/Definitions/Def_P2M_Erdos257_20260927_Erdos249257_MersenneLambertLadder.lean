import Mathlib.Analysis.RCLike.Basic
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Data.Nat.Totient
import Mathlib.NumberTheory.ArithmeticFunction.Misc
import Mathlib.NumberTheory.ArithmeticFunction.Moebius
import Mathlib.NumberTheory.TsumDivisorsAntidiagonal
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Positivity

namespace P2M_Erdos257_20260927

/-!
# The Mersenne–Lambert ladder for Erdős #249

`S = ∑ φ(n)/2ⁿ` (the #249 constant) is the Lambert-transform neighbour of two
*exactly rational* series and one *machine-checked irrational* one.  Writing
`L(f) = ∑_{n≥1} f(n)/(2ⁿ-1) = ∑_m (∑_{d∣m} f(d))/2^m`, the ladder is

* `L(μ) = 1/2`            (rational — `μ * ζ = ε`),
* `L(φ) = 2`              (rational — `φ * ζ = Id`, `∑ m/2^m = 2`),
* `L(1) = E`              (Erdős–Borwein; IRRATIONAL, machine-checked in
                           `CertificateKernel.irrational_erdosBorwein_series`),
* `L(A) = S`              (OPEN — this is #249), where `A = φ * μ ≥ 0` is the
                           primitive-conductor weight (`A(n)` counts primitive
                           Dirichlet characters of conductor `n`, OEIS A007431),
* `L(Id) = ∑ σ(m)/2^m`    (transcendental by Nesterenko 1996 via `E₂(1/2)`;
                           cited, NOT formalised here).

So one Dirichlet convolution by `ζ` separates the open constant from a trivially
rational value (`A * ζ = φ`), and one more separates rational from transcendental
(`φ * ζ = Id`, `Id * ζ = σ`).  This file machine-checks the two rational rungs,
the positive lift `L(A) = S`, and the signed Möbius-square lens

  `S = 1/2 + ∑_{d≥1} μ(d)/(2^d-1)²`.

It also checks the prime-wise integrality obstruction for the normalized
primitive coordinate: at every odd prime `p`, `p ∤ A(p)`, equivalently
`A(p) / p` is not an integer.  This is an obstruction to an ordinary integral
Euler/Witt realization, not an irrationality theorem for `S`.

The engine is a *signed, linear-growth* weighted Lambert rearrangement
(`tsum_lambert_pair_regroup`): the kernel's landed
`weighted_lambert_series_identity` requires `0 ≤ w ≤ 1`, which admits neither
`φ` (unbounded) nor `μ` (signed).  Summability rides Mathlib's
`summable_prod_mul_pow` through the AM–GM bound `d·m ≤ d² + m²`.

The honest boundary: every identity here is an *equality of convergent series* —
classical in shape (the `L(A) = S` form is recorded at OEIS A256936/A007431).
None of them decides irrationality of `S`; they relocate #249 into the positive
Erdős–Borwein family, where the kernel's own irrationality engine
(`irrational_erdosSum_full_support`) already handles the weight-1 member.
Whether the Erdős 1948 congruence mechanism tolerates the weight `A(p) = p - 2`
is exactly the open analytic core, and is NOT claimed.
-/

namespace MersenneLambertLadder

open ArithmeticFunction

/-! ## The signed linear-growth Lambert engine -/









/-! ## The primitive-conductor weight `A = φ * μ` -/

/-- The Euler totient as an integer-valued arithmetic function. -/
def totientZ : ArithmeticFunction ℤ :=
  ⟨fun n => (Nat.totient n : ℤ), by simp⟩

@[simp] theorem totientZ_apply (n : ℕ) : totientZ n = (Nat.totient n : ℤ) := rfl





























/-! ## Möbius divisor sums -/







/-! ## The four ladder identities (generic `0 ≤ r < 1`) -/









/-! ## Evaluations at `r = 1/2`: the Mersenne forms -/























-- Axiom audit: every result must rest only on the foundational axioms
-- (`propext`, `Classical.choice`, `Quot.sound`) — no `sorryAx`, no `Lean.ofReduceBool`.

end MersenneLambertLadder

end P2M_Erdos257_20260927
