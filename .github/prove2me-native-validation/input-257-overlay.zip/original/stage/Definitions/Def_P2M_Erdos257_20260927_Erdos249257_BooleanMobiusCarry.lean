import Definitions.Def_P2M_Erdos257_20260927_Erdos249257_TotientTailPeriodKiller
import Definitions.Def_P2M_Erdos257_20260927_Erdos249257_CarrySurvivorExtinction
import Definitions.Def_P2M_Erdos257_20260927_Erdos249257_LcmConeFlatness
import Definitions.Def_P2M_Erdos257_20260927_Erdos249257_LcmConeNonflat
import Definitions.Def_P2M_Erdos257_20260927_Erdos249257_MersenneLambertLadder
import Definitions.Def_P2M_Erdos257_20260927_Erdos249257_SternBrocotRunGeometry
import Definitions.Def_P2M_Erdos257_20260927_Erdos249257_CertificateKernel
import Definitions.Def_P2M_Erdos257_20260927_Erdos249257_GenericTailOrbitRigidity
import Definitions.Def_P2M_Erdos257_20260927_Erdos249257_GreedyAchievementSet
import Mathlib.Algebra.BigOperators.Field
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Algebra.Order.Antidiag.Prod
import Mathlib.Algebra.Ring.GeomSum
import Mathlib.Analysis.Normed.Group.FunctionSeries
import Mathlib.Analysis.Normed.Ring.InfiniteSum
import Mathlib.Analysis.RCLike.Basic
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Data.Finset.NatAntidiagonal
import Mathlib.Data.Nat.Choose.Dvd
import Mathlib.Data.Nat.Factorization.Basic
import Mathlib.Data.Nat.Fib.Basic
import Mathlib.Data.Nat.Find
import Mathlib.Data.Nat.ModEq
import Mathlib.Data.Nat.Totient
import Mathlib.Data.ZMod.Basic
import Mathlib.FieldTheory.Finite.Basic
import Mathlib.LinearAlgebra.Matrix.Determinant.Basic
import Mathlib.MeasureTheory.Group.Measure
import Mathlib.MeasureTheory.Measure.Lebesgue.Basic
import Mathlib.MeasureTheory.Measure.MeasureSpace
import Mathlib.NumberTheory.ArithmeticFunction.Misc
import Mathlib.NumberTheory.ArithmeticFunction.Moebius
import Mathlib.NumberTheory.Bertrand
import Mathlib.NumberTheory.Multiplicity
import Mathlib.NumberTheory.Real.Irrational
import Mathlib.NumberTheory.TsumDivisorsAntidiagonal
import Mathlib.Order.Filter.AtTopBot.Basic
import Mathlib.RingTheory.Polynomial.Cyclotomic.Eval
import Mathlib.RingTheory.Polynomial.Cyclotomic.Expand
import Mathlib.RingTheory.Polynomial.Cyclotomic.Roots
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.GCongr
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.LinearCombination
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.Set
import Mathlib.Topology.Algebra.InfiniteSum.NatInt
import Mathlib.Topology.Algebra.InfiniteSum.Order
import Mathlib.Topology.Algebra.InfiniteSum.Ring
import Mathlib.Topology.GDelta.Basic
import Mathlib.Topology.Order.IntermediateValue
import Mathlib.Topology.Perfect

namespace P2M_Erdos257_20260927

/-!
# Boolean–Möbius carry coordinates for Erdős #257

For a support `A ⊆ ℕ`, the binary Lambert expansion has positive-index
coefficient

`f_A(n) = #{a ∈ A : a ∣ n}`.

This file makes two exact coordinate changes kernel-visible.

* Dirichlet/Möbius: `f_A = 1_A * ζ` and `μ * f_A = 1_A` on positive
  integers.  Conversely, every arithmetic function whose Möbius transform
  is Boolean is the divisor-count coefficient of the support selected by
  that Boolean transform.
* Binary carry: rationality of the support series is equivalent to a
  tempered integer orbit for `f_A`; for a displayed fraction `p/q`, the
  orbit has multiplier `q`, initial value `p`, and its carry quotient is
  exactly `f_A`.

Exponent zero is analytically invisible because the existing support series
uses real division-by-zero conventions at `2^0 - 1`.  Accordingly, set-level
recovery is stated either on positive indices or under `0 ∉ A`.  Omitting
that guard would be false.

The worked support `{2,3}` gives `10/21` and the pure period-six orbit
`10,20,19,17,13,26`.  These coordinate theorems do **not** prove Erdős
#257: they neither exclude infinite Boolean carry paths nor turn finite
search into a completeness argument.  Both Erdős #249 and #257 remain open.

No novelty or priority claim is made for the new theorems in this file.
-/

namespace Erdos249257

open ArithmeticFunction Filter Set
open scoped ArithmeticFunction.Moebius

/-! ## Arithmetic-function packaging -/

/-- The positive-index integer indicator of a support.  Arithmetic functions
must vanish at zero, which is also the correct normalization for the Lambert
coefficient calculus. -/
noncomputable def positiveSupportBit (A : Set ℕ) (n : ℕ) : ℤ :=
  letI := Classical.propDecidable (0 < n ∧ n ∈ A)
  if 0 < n ∧ n ∈ A then 1 else 0

/-- `positiveSupportBit` packaged as an integer-valued arithmetic function. -/
noncomputable def positiveSupportBitAF (A : Set ℕ) : ArithmeticFunction ℤ :=
  ⟨positiveSupportBit A, by simp [positiveSupportBit]⟩

/-- The support divisor-count coefficient, cast to an integer-valued
arithmetic function. -/
noncomputable def supportCoeffAF (A : Set ℕ) : ArithmeticFunction ℤ :=
  ⟨fun n ↦ (supportCoeff A n : ℤ), by simp [supportCoeff]⟩



















/-! ## Converse Boolean inversion -/









/-! ## Sharp divisor and support-coefficient growth -/











/-! ## Lambert-series and tail-orbit bridge -/











/-! ## The exact half-residual carry bridge

The bridge below does not introduce a second carry model.  It uses the
existing `affineBinaryOrbit` twice: with doubled support coefficients it is
the denominator-two orbit for the displayed fraction `1/2`; after the
forced first digit it factors as twice the same affine orbit with undoubled
coefficients.  For a finite prefix, the remaining `binaryCoeffTail` is the
future-multiple tail of that finite support, not the tail of a hypothetical
completed representation.
-/































/-! ## The quotient-facing interface -/

























/-! ## Exact regression fixture: `A = {2,3}` -/





































/-! ## The prescribed point `1/21`

The visible-lattice identity supplies `1/21` with non-Boolean primitive
multiplicities.  The definitions below instead attach the existing affine
Lambert carry directly to the Boolean greedy support.  This exposes the exact
remaining endpoint: the carry is nonnegative at every depth, and any
subexponential upper bound makes it tempered and therefore proves that the
greedy support has value `1/21`.

This section does not assume that the greedy orbit survives.  In particular,
the nonnegativity theorem is an unconditional one-sided carry estimate, while
the subexponential bound remains the open arithmetic obligation.
-/







































/-- The canonical denominator-`21` carry driven by the greedy support of
`1/21`. -/
noncomputable def twentyOneGreedyCarry (N : ℕ) : ℤ :=
  affineBinaryOrbit
    (fun n : ℕ =>
      ((21 * supportCoeff
        (greedyMersenneSupport (1 / 21 : ℝ)) n : ℕ) : ℤ))
    1 N



















































































































































































































/-! ## Exact finite correction images

The reference checker does not manipulate the infinite correction value
directly.  At depth `N` it uses the exact identity

`x - correction(prefix N) = dyadic(prefix N) + remainder N`

and subtracts the complete unresolved correction tail.  The definitions and
lemmas below make that exact finite object available to theorem producers.
They are target-generic; only the final specialization fixes `x = 1/21`. -/



















































































end Erdos249257

end P2M_Erdos257_20260927
