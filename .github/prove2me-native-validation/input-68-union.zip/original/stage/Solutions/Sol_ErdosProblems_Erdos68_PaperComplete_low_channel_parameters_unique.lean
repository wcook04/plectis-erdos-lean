import Definitions.Def_ErdosProblems_Erdos68_FactorialChannelCertificate
import Definitions.Def_ErdosProblems_Erdos68_DivisorChannelBasis
import Definitions.Def_ErdosProblems_Erdos68_PaperCompleteDivisorCoordinates
import Definitions.Def_ErdosProblems_Erdos68_PaperCompleteIntegerSpan
import Definitions.Def_ErdosProblems_Erdos68_PaperCompleteLowKernel
import Theorems.Thm_ErdosProblems_Erdos68_factorialMoment_smul
import Theorems.Thm_ErdosProblems_Erdos68_factorialMoment_add
import Theorems.Thm_ErdosProblems_Erdos68_PaperComplete_canonicalKernel_moment
import Theorems.Thm_ErdosProblems_Erdos68_PaperComplete_channelSynthesis_injective
import Theorems.Thm_ErdosProblems_Erdos68_PaperComplete_tail_moment
import Theorems.Thm_ErdosProblems_Erdos68_PaperComplete_local_channelLCM_pos
import Lean.Elab.Tactic.Omega
import Mathlib.Algebra.BigOperators.Finsupp.Basic
import Mathlib.Algebra.BigOperators.GroupWithZero.Action
import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Data.Finsupp.Basic
import Mathlib.Data.Finsupp.SMul
import Mathlib.Data.Int.GCD
import Mathlib.Data.Int.ModEq
import Mathlib.Data.Nat.Choose.Multinomial
import Mathlib.Data.Nat.GCD.Prime
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.Rat.Lemmas
import Mathlib.NumberTheory.Divisors
import Mathlib.RingTheory.Coprime.Lemmas
import Mathlib.Tactic.Abel
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.NormNum.NatFactorial
import Mathlib.Tactic.Ring

   
                                                                      
                                                                        
                                                                 
                       
  

namespace ErdosProblems.Erdos68.PaperComplete
open scoped BigOperators
open Finsupp
end ErdosProblems.Erdos68.PaperComplete

open scoped BigOperators
open Finsupp
open ErdosProblems in
open ErdosProblems.Erdos68 in
open ErdosProblems.Erdos68.PaperComplete in
theorem solution {D : ℕ} (hD : 2 ≤ D)
    {t s : ℤ} {z w : ℕ →₀ ℤ}
    (hz : TailCoordinates D z) (hw : TailCoordinates D w)
    (he : t • canonicalKernel D + channelSynthesis z =
      s • canonicalKernel D + channelSynthesis w) : t = s ∧ z = w := by
  have hm := congrArg factorialMoment he
  simp only [factorialMoment_add, factorialMoment_smul, canonicalKernel_moment,
    tail_moment (by omega) hz, tail_moment (by omega) hw, add_zero] at hm
  have hL : (channelLCM D : ℤ) ≠ 0 := by
    exact_mod_cast (Nat.ne_of_gt (local_channelLCM_pos D))
  have hts : t = s := mul_right_cancel₀ hL hm
  refine ⟨hts, ?_⟩
  rw [hts] at he
  exact channelSynthesis_injective (add_left_cancel he)
