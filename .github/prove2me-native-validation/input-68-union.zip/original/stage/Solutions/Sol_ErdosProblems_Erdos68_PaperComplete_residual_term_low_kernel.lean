import Definitions.Def_ErdosProblems_Erdos68_ChannelBreakpointRigidity
import Definitions.Def_ErdosProblems_Erdos68_ChannelIntegralCongruence
import Definitions.Def_ErdosProblems_Erdos68_PrimeUnitTranslator
import Definitions.Def_ErdosProblems_Erdos68_FactorialChannelCertificate
import Definitions.Def_ErdosProblems_Erdos68_DivisorChannelBasis
import Definitions.Def_ErdosProblems_Erdos68_PaperCompleteDivisorCoordinates
import Definitions.Def_ErdosProblems_Erdos68_PaperCompleteIntegerSpan
import Definitions.Def_ErdosProblems_Erdos68_PaperCompleteLowKernel
import Definitions.Def_ErdosProblems_Erdos68_PaperCompleteResidualIdentity
import Theorems.Thm_ErdosProblems_Erdos68_channelNumerator_smul
import Theorems.Thm_ErdosProblems_Erdos68_channelNumerator_add
import Theorems.Thm_ErdosProblems_Erdos68_PaperComplete_synthesis_channel
import Theorems.Thm_ErdosProblems_Erdos68_PaperComplete_canonicalKernel_channel
import Lean.Elab.Tactic.Omega
import Mathlib.Algebra.BigOperators.Fin
import Mathlib.Algebra.BigOperators.Finsupp.Basic
import Mathlib.Algebra.BigOperators.GroupWithZero.Action
import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Algebra.GCDMonoid.FinsetLemmas
import Mathlib.Algebra.Order.Round
import Mathlib.Algebra.Ring.GeomSum
import Mathlib.Analysis.Asymptotics.Defs
import Mathlib.Analysis.Complex.ExponentialBounds
import Mathlib.Analysis.Real.Pi.Bounds
import Mathlib.Analysis.SpecialFunctions.Stirling
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Data.Fin.VecNotation
import Mathlib.Data.Finsupp.Basic
import Mathlib.Data.Finsupp.SMul
import Mathlib.Data.Int.GCD
import Mathlib.Data.Int.ModEq
import Mathlib.Data.Nat.Choose.Multinomial
import Mathlib.Data.Nat.Factorial.Basic
import Mathlib.Data.Nat.Factorial.BigOperators
import Mathlib.Data.Nat.GCD.Prime
import Mathlib.Data.Nat.ModEq
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.Rat.Lemmas
import Mathlib.LinearAlgebra.Matrix.Adjugate
import Mathlib.LinearAlgebra.Vandermonde
import Mathlib.NumberTheory.Divisors
import Mathlib.RingTheory.Coprime.Lemmas
import Mathlib.Tactic.Abel
import Mathlib.Tactic.FinCases
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.NormNum.NatFactorial
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.InfiniteSum.Basic
import Mathlib.Topology.Algebra.InfiniteSum.Ring

   
                                                                           
                                                                      
                                             
  

namespace ErdosProblems.Erdos68.PaperComplete
open scoped BigOperators
open Finsupp
end ErdosProblems.Erdos68.PaperComplete

open scoped BigOperators
open Finsupp
open ErdosProblems in
open ErdosProblems.Erdos68 in
open ErdosProblems.Erdos68.PaperComplete in
theorem solution {D : ℕ} (hD : 1 ≤ D) (t : ℤ)
    {z : ℕ →₀ ℤ} (hz : TailCoordinates D z) (d : ℕ) :
    fullResidualTerm (t • canonicalKernel D + channelSynthesis z) d =
      ((t : ℝ) * (channelLCM D : ℝ)) * _root_.Erdos68.factorialGapTailTerm D d +
        tailCoordinateTerm z d := by
  by_cases hd : 1 < d
  · have hd2 : 2 ≤ d := by omega
    rw [fullResidualTerm, if_pos hd, channelNumerator_add, channelNumerator_smul,
      canonicalKernel_channel hd2, synthesis_channel _ _ hd2, hz 0 (by omega),
      zero_add, tailCoordinateTerm, if_pos hd]
    by_cases hdD : d ≤ D
    · have hzj := hz (d - 1) (by omega)
      simp [hdD, hzj, _root_.Erdos68.factorialGapTailTerm, show ¬ D < d by omega]
    · rw [if_neg hdD, _root_.Erdos68.factorialGapTailTerm,
        if_pos (show D < d by omega)]
      have hf : (1 : ℝ) < (d.factorial : ℝ) := by
        exact_mod_cast Nat.one_lt_factorial.mpr hd2
      have hn : (d.factorial : ℝ) - 1 ≠ 0 := by linarith
      push_cast
      field_simp [hn] <;> ring
  · have hn : ¬ D < d := by omega
    simp [fullResidualTerm, hd, _root_.Erdos68.factorialGapTailTerm, hn,
      tailCoordinateTerm]
