import Definitions.Def_ErdosProblems_Erdos249_PaperCompleteR8_UnitPivotBasis_v2
import Mathlib
import Mathlib.LinearAlgebra.Basis.Basic
import Mathlib.LinearAlgebra.Finsupp.Defs
import Mathlib.LinearAlgebra.Finsupp.LinearCombination

namespace ErdosProblems.Erdos249.PaperCompleteR8.UnitPivot.System
set_option autoImplicit false
open scoped BigOperators
variable {R I J M : Type*} [CommRing R] [AddCommGroup M] [Module R M]
variable (D : System R I J M)
end ErdosProblems.Erdos249.PaperCompleteR8.UnitPivot.System

open ErdosProblems
open ErdosProblems.Erdos249
open ErdosProblems.Erdos249.PaperCompleteR8
open ErdosProblems.Erdos249.PaperCompleteR8.UnitPivot
open ErdosProblems.Erdos249.PaperCompleteR8.UnitPivot.System
set_option autoImplicit false
open scoped BigOperators
variable {R I J M : Type*} [CommRing R] [AddCommGroup M] [Module R M]
variable (D : System R I J M)
open ErdosProblems in
open ErdosProblems.Erdos249 in
open ErdosProblems.Erdos249.PaperCompleteR8 in
open ErdosProblems.Erdos249.PaperCompleteR8.UnitPivot in
open ErdosProblems.Erdos249.PaperCompleteR8.UnitPivot.System in
theorem solution (o : D.Omitted) :
    (D.relationBasis o : I →₀ R) = D.row o.val := by
  -- Mathlib/Algebra/Module/Submodule/Equiv.lean: coe_ofEq_apply.
  -- Basis.map_apply and Basis.coe_span_apply are the pinned source rules.
  simp only [relationBasis, Module.Basis.map_apply,
    LinearEquiv.coe_ofEq_apply, Module.Basis.coe_span_apply, rows]
