import Definitions.Def_Erdos249257_TotientKernelIndex
import Definitions.Def_Erdos249257_TotientKernelConditional
import Definitions.Def_Erdos249257_TotientMahlerDefect
import Definitions.Def_Erdos249257_AllBaseTotientKernel
import Definitions.Def_ErdosProblems_Erdos249_PaperCompleteR7_KernelIntegral
import Definitions.Def_ErdosProblems_Erdos249_PaperCompleteR8_UnitPivotBasis
import Definitions.Def_ErdosProblems_Erdos249_PaperCompleteR8_KernelRelationBasis
import Theorems.Thm_ErdosProblems_Erdos249_PaperCompleteR8_canonical_family_contains_nondiv
import Mathlib
import Mathlib.Algebra.Ring.GeomSum
import Mathlib.Data.Fintype.BigOperators
import Mathlib.Data.Nat.ChineseRemainder
import Mathlib.Data.Nat.Totient
import Mathlib.LinearAlgebra.Basis.Basic
import Mathlib.LinearAlgebra.Dimension.Constructions
import Mathlib.LinearAlgebra.Dimension.StrongRankCondition
import Mathlib.LinearAlgebra.Finsupp.Defs
import Mathlib.LinearAlgebra.Finsupp.LinearCombination
import Mathlib.LinearAlgebra.Matrix.Determinant.Basic
import Mathlib.NumberTheory.LSeries.PrimesInAP
import Mathlib.NumberTheory.PrimesCongruentOne

set_option autoImplicit false

/-!
# The integral relation-module basis missing from the paper

New r8 proof source. The r7 coordinate basis is reused unchanged. The map below
has the free Z-module on ALL channels as its domain and the actual integral
span as its codomain. Its kernel has the unit-pivot basis, not just a spanning
set. Maximal reductions are identified by uniqueness of canonical coordinates.

Pinned Mathlib source comments identify
APIs opened at 5e932f97dd25535344f80f9dd8da3aab83df0fe6.
-/

namespace ErdosProblems.Erdos249.PaperCompleteR8
open scoped BigOperators
open Erdos257PeriodNoncollapse
open ErdosProblems.Erdos249.PaperCompleteR7

































/-! ## Identification with the literal elementary reductions on the page -/
end ErdosProblems.Erdos249.PaperCompleteR8

open scoped BigOperators
open Erdos257PeriodNoncollapse
open ErdosProblems.Erdos249.PaperCompleteR7
open ErdosProblems in
open ErdosProblems.Erdos249 in
open ErdosProblems.Erdos249.PaperCompleteR8 in
theorem solution (k e : ℕ) (hk : 2 ≤ k) :
    ∀ j : ℕ, j ≤ e → ∀ r : ℕ, r < k ^ j →
      ∃ b : Erdos249257.AllBaseCanonicalIndex k e, ∃ a : ℕ,
        Erdos249257.allBaseTotientKernelSeq k j r = (a : ℤ) • Erdos249257.allBaseCanonicalFamily k e b := by
  have hkpos : 0 < k := by omega
  intro j
  induction j with
  | zero =>
      intro hje r hr
      have hr0 : r = 0 := by simpa only [pow_zero, Nat.lt_one_iff] using hr
      subst r
      exact ⟨Sum.inl 0, 1, (one_smul ℤ _).symm⟩
  | succ j ih =>
      intro hje r hr
      by_cases hr0 : r = 0
      · subst r
        exact ⟨Sum.inl 1, k ^ j, allBase_zero_integral k hkpos j⟩
      · by_cases hkr : k ∣ r
        · obtain ⟨u, rfl⟩ := hkr
          have hulk : u < k ^ j := by
            have hm : k * u < k * k ^ j := by
              calc
                k * u < k ^ (j + 1) := hr
                _ = k * k ^ j := by ring
            exact lt_of_mul_lt_mul_left hm (Nat.zero_le k)
          have hj : 1 ≤ j := by
            by_contra hn
            have hj0 : j = 0 := by omega
            rw [hj0, pow_zero] at hulk
            have hu0 : u = 0 := Nat.lt_one_iff.mp hulk
            exact hr0 (by rw [hu0, mul_zero])
          obtain ⟨b, a, ha⟩ := ih (by omega) u hulk
          refine ⟨b, integralStepScalar k u * a, ?_⟩
          rw [allBase_step_integral k hkpos j u hj, ha, smul_smul, Nat.cast_mul]
        · obtain ⟨b, hb⟩ := canonical_family_contains_nondiv k e (j + 1) r hk
              (by omega) hje hr hkr
          exact ⟨b, 1, by rw [Nat.cast_one, one_smul, hb]⟩
