import Definitions.Def_ErdosProblems_Erdos249_ResidueClassTotientSeries
import Theorems.Thm_ErdosProblems_Erdos249_irrational_totientObservable
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.NumberTheory.LSeries.PrimesInAP
import Mathlib.Tactic

namespace ErdosProblems.Erdos249
open Finset
theorem totientResidueValue_eq (m : ℕ) :
    totientResidueValue m = totientObservableValue (fun x => (x : ℤ)) m := by
  unfold totientResidueValue totientObservableValue
  refine tsum_congr fun n => ?_
  simp only [Int.cast_natCast]
end ErdosProblems.Erdos249

open ErdosProblems
open ErdosProblems.Erdos249
open Finset
open ErdosProblems in
open ErdosProblems.Erdos249 in
theorem solution {m : ℕ} (hm : 3 ≤ m) :
    Irrational (totientResidueValue m) := by
  have hcop : Nat.Coprime (m - 2 + 1) m := by
    have h : Nat.Coprime (m - 1) (m - 1 + 1) := by simp
    rw [show m - 1 + 1 = m from by omega] at h
    rw [show m - 2 + 1 = m - 1 from by omega]
    exact h
  rw [totientResidueValue_eq]
  refine irrational_totientObservable (by omega) _ (by simp) (by omega) hcop ?_
  simp only [ne_eq, Int.natCast_eq_zero]
  omega
