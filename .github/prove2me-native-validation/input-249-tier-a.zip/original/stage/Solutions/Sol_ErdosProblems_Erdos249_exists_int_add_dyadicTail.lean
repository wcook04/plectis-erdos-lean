import Definitions.Def_ErdosProblems_Erdos249_ResidueClassTotientSeries
import Theorems.Thm_ErdosProblems_Erdos249_summable_dyadicTerm
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.NumberTheory.LSeries.PrimesInAP
import Mathlib.Tactic

namespace ErdosProblems.Erdos249
open Finset
variable {a : ℕ → ℤ} {C : ℝ}
end ErdosProblems.Erdos249

open ErdosProblems
open ErdosProblems.Erdos249
open Finset
variable {a : ℕ → ℤ} {C : ℝ}
open ErdosProblems in
open ErdosProblems.Erdos249 in
theorem solution (hC : ∀ n, |(a n : ℝ)| ≤ C) (N : ℕ) :
    ∃ P : ℤ, (2 : ℝ) ^ N * dyadicValue a = (P : ℝ) + dyadicTail a N := by
  refine ⟨∑ i ∈ Finset.range (N + 1), a i * 2 ^ (N - i), ?_⟩
  have hs := summable_dyadicTerm hC
  have h := Summable.sum_add_tsum_nat_add (f := fun n : ℕ => (a n : ℝ) / 2 ^ n) (N + 1) hs
  have hpre : (2 : ℝ) ^ N * (∑ i ∈ Finset.range (N + 1), (a i : ℝ) / 2 ^ i)
      = ((∑ i ∈ Finset.range (N + 1), a i * 2 ^ (N - i) : ℤ) : ℝ) := by
    push_cast
    rw [Finset.mul_sum]
    refine Finset.sum_congr rfl fun i hi => ?_
    have hi' : i < N + 1 := Finset.mem_range.mp hi
    have hsp : (2 : ℝ) ^ N = 2 ^ i * 2 ^ (N - i) := by rw [← pow_add]; congr 1; omega
    have h2 : (2 : ℝ) ^ i ≠ 0 := by positivity
    rw [hsp]
    field_simp
  have htail : (2 : ℝ) ^ N * (∑' s : ℕ, (a (s + (N + 1)) : ℝ) / 2 ^ (s + (N + 1)))
      = dyadicTail a N := by
    rw [← tsum_mul_left]
    refine tsum_congr fun s => ?_
    have hidx : s + (N + 1) = N + 1 + s := by omega
    rw [hidx]
    have hpow : (2 : ℝ) ^ (N + 1 + s) = 2 ^ N * 2 ^ (s + 1) := by
      rw [← pow_add]; congr 1; omega
    have h2 : (2 : ℝ) ^ N ≠ 0 := by positivity
    rw [hpow]
    field_simp
  calc (2 : ℝ) ^ N * dyadicValue a
      = (2 : ℝ) ^ N * (∑' n : ℕ, (a n : ℝ) / 2 ^ n) := rfl
    _ = (2 : ℝ) ^ N * ((∑ i ∈ Finset.range (N + 1), (a i : ℝ) / 2 ^ i)
          + ∑' s : ℕ, (a (s + (N + 1)) : ℝ) / 2 ^ (s + (N + 1))) := by rw [← h]
    _ = (2 : ℝ) ^ N * (∑ i ∈ Finset.range (N + 1), (a i : ℝ) / 2 ^ i)
          + (2 : ℝ) ^ N * (∑' s : ℕ, (a (s + (N + 1)) : ℝ) / 2 ^ (s + (N + 1))) := by ring
    _ = _ := by rw [hpre, htail]
