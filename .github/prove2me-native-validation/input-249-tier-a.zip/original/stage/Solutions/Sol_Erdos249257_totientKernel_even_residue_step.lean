import Definitions.Def_Erdos249257_TotientMahlerDefect_v2
import Mathlib.Data.Nat.ChineseRemainder
import Mathlib.Data.Nat.Totient
import Mathlib.LinearAlgebra.Dimension.Constructions
import Mathlib.LinearAlgebra.Matrix.Determinant.Basic
import Mathlib.NumberTheory.LSeries.PrimesInAP
import Mathlib.NumberTheory.PrimesCongruentOne

/-!
# Exact ranks of dyadic totient kernels

For `K_{j,r}(n) = φ(2^j n + r)`, this module proves two unconditional rank
statements relevant to Erdős #249:

* the complete kernel through every positive level `e` has dimension
  exactly `2^e+1` over `ℚ`;
* the kernel containing all dyadic levels is infinite-dimensional.

The proof first removes the repeated even-residue channels.  It then proves
linear independence of the remaining canonical family by constructing a
nonzero evaluation minor: CRT and Dirichlet's theorem make one affine channel
prime while forcing a fresh prime divisor in every other channel.  The exact
rank of the complete truncation follows because the removed channels reduce
recursively to lower-level canonical channels.

These are structural theorems about Euler's totient sequence, not a proof that
the totient series is irrational.  A rationality argument would still have to
produce a finite-rank compression, or an equivalent contradiction object,
from the assumed rationality of that series.
-/

namespace Erdos249257
open Module Matrix
end Erdos249257

open Module Matrix
open Erdos249257 in
theorem solution (j s : ℕ) (hj : 0 < j) :
    totientKernelSeq (j + 1) (2 * s) =
      if Odd s then totientKernelSeq j s else
        (2 : ℚ) • totientKernelSeq j s := by
  funext n
  have hpowEven : Even (2 ^ j * n) := by
    exact Even.mul_right (even_two.pow_of_ne_zero (Nat.ne_of_gt hj)) n
  simp only [totientKernelSeq, Pi.smul_apply, smul_eq_mul, ite_apply]
  rw [show 2 ^ (j + 1) * n + 2 * s = 2 * (2 ^ j * n + s) by
    rw [pow_succ]
    ring]
  by_cases hs : Odd s
  · rw [if_pos hs]
    norm_cast
    exact Nat.totient_two_mul_of_odd (hpowEven.add_odd hs)
  · rw [if_neg hs]
    norm_cast
    apply Nat.totient_two_mul_of_even
    obtain ⟨a, ha⟩ := hpowEven
    obtain ⟨b, hb⟩ := Nat.not_odd_iff_even.mp hs
    exact ⟨a + b, by omega⟩
