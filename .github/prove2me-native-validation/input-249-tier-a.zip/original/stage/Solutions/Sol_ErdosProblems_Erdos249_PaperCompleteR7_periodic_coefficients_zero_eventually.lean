import Definitions.Def_Erdos249257_TotientKernelIndex
import Definitions.Def_Erdos249257_TotientKernelConditional
import Definitions.Def_Erdos249257_TotientMahlerDefect
import Definitions.Def_Erdos249257_AllBaseTotientKernel
import Definitions.Def_ErdosProblems_Erdos249_ResidueClassTotientSeries
import Theorems.Thm_ErdosProblems_Erdos249_PeriodicTotientIndependence_periodic_add_mul
import Theorems.Thm_ErdosProblems_Erdos249_PeriodicTotientIndependence_periodic_coefficients_zero
import Mathlib
import Mathlib.Algebra.Ring.GeomSum
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.Data.Fintype.BigOperators
import Mathlib.Data.Nat.ChineseRemainder
import Mathlib.Data.Nat.Totient
import Mathlib.LinearAlgebra.Dimension.Constructions
import Mathlib.LinearAlgebra.Matrix.Determinant.Basic
import Mathlib.NumberTheory.LSeries.PrimesInAP
import Mathlib.NumberTheory.PrimesCongruentOne
import Mathlib.Tactic

namespace ErdosProblems.Erdos249.PaperCompleteR7
end ErdosProblems.Erdos249.PaperCompleteR7

/-!
# Paper-complete interfaces: eventual periodic coefficients and cofinal pulses

Targets: short-note `cor:periodic-freezing` and `lem:bounded-pulse`.
This file extends the compiled r5 periodic theorem, not the uncompiled r6 helper.
Every theorem has a proof term and no extra mathematical assumption.
Build status for this return: source-reviewed, NOT RUN (no Lean executable).
-/

namespace ErdosProblems.Erdos249.PaperCompleteR7
open scoped BigOperators
end ErdosProblems.Erdos249.PaperCompleteR7

open scoped BigOperators
open ErdosProblems in
open ErdosProblems.Erdos249 in
open ErdosProblems.Erdos249.PaperCompleteR7 in
theorem solution
    {ι : Type*} [Fintype ι] [DecidableEq ι]
    (a b : ι → ℕ) (ha : ∀ i, 0 < a i)
    (hcross : ∀ i j, i ≠ j → a i * b j ≠ a j * b i)
    (w : ι → ℕ → ℚ) (Q : ℕ) (hQ : 0 < Q)
    (hw : ∀ i n, w i (n + Q) = w i n)
    (N₀ : ℕ)
    (hrel : ∀ n, N₀ ≤ n →
      ∑ i, w i n * (Nat.totient (a i * n + b i) : ℚ) = 0) :
    ∀ i n, w i n = 0 := by
  classical
  let bb : ι → ℕ := fun i => a i * N₀ + b i
  let ww : ι → ℕ → ℚ := fun i n => w i (n + N₀)
  have hcross' : ∀ i j, i ≠ j → a i * bb j ≠ a j * bb i := by
    intro i j hij h
    apply hcross i j hij
    dsimp [bb] at h
    nlinarith [h]
  have hw' : ∀ i n, ww i (n + Q) = ww i n := by
    intro i n
    dsimp [ww]
    simpa only [Nat.add_assoc, Nat.add_left_comm, Nat.add_comm] using
      hw i (n + N₀)
  have hrel' : ∀ n,
      ∑ i, ww i n * (Nat.totient (a i * n + bb i) : ℚ) = 0 := by
    intro n
    have h := hrel (n + N₀) (by omega)
    have hind : ∀ i, a i * (n + N₀) + b i = a i * n + bb i := by
      intro i
      dsimp [bb]
      ring
    simpa only [hind, ww] using h
  have hz := PeriodicTotientIndependence.periodic_coefficients_zero
    a bb ha hcross' Q hQ ww hw' hrel'
  intro i n
  have hlarge : N₀ ≤ n + Q * N₀ := by nlinarith
  have hzero := hz i (n + Q * N₀ - N₀)
  have hind : n + Q * N₀ - N₀ + N₀ = n + Q * N₀ := Nat.sub_add_cancel hlarge
  change w i (n + Q * N₀ - N₀ + N₀) = 0 at hzero
  rw [hind] at hzero
  rw [PeriodicTotientIndependence.periodic_add_mul (w i) Q (hw i) n N₀] at hzero
  exact hzero
