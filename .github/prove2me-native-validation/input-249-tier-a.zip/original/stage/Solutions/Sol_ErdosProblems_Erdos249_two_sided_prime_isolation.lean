import Definitions.Def_ErdosProblems_Erdos249_ResidueClassTotientSeries
import Theorems.Thm_ErdosProblems_Erdos249_exists_isolation_modulus
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.NumberTheory.LSeries.PrimesInAP
import Mathlib.Tactic

namespace ErdosProblems.Erdos249
open Finset
private theorem coprime_of_modEq {x y n : ℕ} (h : x ≡ y [MOD n]) (hy : Nat.Coprime y n) :
    Nat.Coprime x n := by
  have h' : x % n = y % n := h
  have h1 : Nat.gcd n x = Nat.gcd n y := by
    rw [Nat.gcd_rec n x, Nat.gcd_rec n y, h']
  have hy' : Nat.gcd n y = 1 := by rw [Nat.gcd_comm]; exact hy
  show Nat.gcd x n = 1
  rw [Nat.gcd_comm, h1]
  exact hy'
end ErdosProblems.Erdos249

open ErdosProblems
open ErdosProblems.Erdos249
open Finset
open ErdosProblems in
open ErdosProblems.Erdos249 in
theorem solution {m : ℕ} (hm : 2 ≤ m) (L N r : ℕ)
    (hr : Nat.Coprime (r + 1) m) :
    ∃ p : ℕ, N < p ∧ L + 1 < p ∧ p.Prime ∧ Nat.totient p ≡ r [MOD m] ∧
      ∀ j, 0 < j → j ≤ L → m ∣ Nat.totient (p - j) ∧ m ∣ Nat.totient (p + j) := by
  obtain ⟨Q, b, hQ0, hQm, hbQ, hmain⟩ := exists_isolation_modulus m (by omega) L
  obtain ⟨c, hc1, hc2⟩ := Nat.chineseRemainder hQm b (r + 1)
  have hcQ : Nat.Coprime c Q := coprime_of_modEq hc1 hbQ
  have hcm : Nat.Coprime c m := coprime_of_modEq hc2 hr
  obtain ⟨p, hpgt, hpp, hpc⟩ :=
    Nat.forall_exists_prime_gt_and_modEq (max N (L + 1)) (q := Q * m) (a := c)
      (Nat.mul_ne_zero hQ0.ne' (by omega)) (hcQ.mul_right hcm)
  rw [gt_iff_lt, max_lt_iff] at hpgt
  refine ⟨p, hpgt.1, hpgt.2, hpp, ?_, ?_⟩
  · have h1 : p ≡ r + 1 [MOD m] := (hpc.of_dvd ⟨Q, mul_comm Q m⟩).trans hc2
    rw [Nat.totient_prime hpp]
    refine Nat.ModEq.add_right_cancel' 1 ?_
    rw [show p - 1 + 1 = p from by omega]
    exact h1
  · intro j hj hjL
    exact hmain p (by omega) ((hpc.of_dvd ⟨m, rfl⟩).trans hc1) j hj hjL
