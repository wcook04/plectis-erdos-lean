import Definitions.Def_ErdosProblems_Erdos249_ResidueClassTotientSeries
import Theorems.Thm_ErdosProblems_Erdos249_summable_const_div_two_pow_succ
import Theorems.Thm_ErdosProblems_Erdos249_tsum_const_div_two_pow_succ
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.NumberTheory.LSeries.PrimesInAP
import Mathlib.Tactic

namespace ErdosProblems.Erdos249
open Finset
variable {a : ℕ → ℤ} {C : ℝ}
theorem summable_dyadicTailTerm (hC : ∀ n, |(a n : ℝ)| ≤ C) (N : ℕ) :
    Summable fun j : ℕ => (a (N + 1 + j) : ℝ) / 2 ^ (j + 1) := by
  refine Summable.of_norm_bounded (g := fun j : ℕ => C / 2 ^ (j + 1))
    (summable_const_div_two_pow_succ C) ?_
  intro j
  dsimp only
  have h2 : (0 : ℝ) < 2 ^ (j + 1) := by positivity
  rw [Real.norm_eq_abs, abs_div, abs_of_pos h2]
  gcongr
  exact hC _
end ErdosProblems.Erdos249

open ErdosProblems
open ErdosProblems.Erdos249
open Finset
variable {a : ℕ → ℤ} {C : ℝ}
open ErdosProblems in
open ErdosProblems.Erdos249 in
theorem solution (hC : ∀ n, |(a n : ℝ)| ≤ C) (N : ℕ) : |dyadicTail a N| ≤ C := by
  have hs := summable_dyadicTailTerm hC N
  have hub : ∀ j : ℕ, (a (N + 1 + j) : ℝ) / 2 ^ (j + 1) ≤ C / 2 ^ (j + 1) := by
    intro j
    have h3 : ((a (N + 1 + j) : ℤ) : ℝ) ≤ C := le_trans (le_abs_self _) (hC _)
    gcongr
  have hlb : ∀ j : ℕ, (-C) / 2 ^ (j + 1) ≤ (a (N + 1 + j) : ℝ) / 2 ^ (j + 1) := by
    intro j
    have h3 : -C ≤ ((a (N + 1 + j) : ℤ) : ℝ) := neg_le_of_abs_le (hC _)
    gcongr
  have h1 : dyadicTail a N ≤ C := by
    have h := Summable.tsum_le_tsum hub hs (summable_const_div_two_pow_succ C)
    rwa [tsum_const_div_two_pow_succ C] at h
  have h2 : -C ≤ dyadicTail a N := by
    have h := Summable.tsum_le_tsum hlb (summable_const_div_two_pow_succ (-C)) hs
    rwa [tsum_const_div_two_pow_succ (-C)] at h
  exact abs_le.mpr ⟨h2, h1⟩
