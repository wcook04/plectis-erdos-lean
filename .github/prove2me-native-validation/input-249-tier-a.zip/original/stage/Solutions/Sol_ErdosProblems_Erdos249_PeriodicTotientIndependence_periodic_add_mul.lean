import Definitions.Def_Erdos249257_TotientKernelIndex
import Definitions.Def_Erdos249257_TotientKernelConditional
import Definitions.Def_Erdos249257_TotientMahlerDefect
import Definitions.Def_Erdos249257_AllBaseTotientKernel
import Mathlib
import Mathlib.Algebra.Ring.GeomSum
import Mathlib.Data.Fintype.BigOperators
import Mathlib.Data.Nat.ChineseRemainder
import Mathlib.Data.Nat.Totient
import Mathlib.LinearAlgebra.Dimension.Constructions
import Mathlib.LinearAlgebra.Matrix.Determinant.Basic
import Mathlib.NumberTheory.LSeries.PrimesInAP
import Mathlib.NumberTheory.PrimesCongruentOne

namespace ErdosProblems.Erdos249.PeriodicTotientIndependence
end ErdosProblems.Erdos249.PeriodicTotientIndependence

/-!
# Freezing periodic coefficients in affine totient relations

Lean-checked helper (r5). Type A retargeted the import from the packet's
`Erdos249257.AllBaseTotientKernel` to the live
`Erdos249257.AllBaseTotientKernel`. Focused `lean_fast_build`
completed as `cf_8309991b61ac4c53b3e3` exit 0. Periodic transport only;
does not complete `dim = #signatures` and does not decide `S`.

This uses the already proved all-affine independence theorem after an affine
change of variable. It requires NO new prime-isolation hypothesis. The positive
intercept condition of that theorem is met by using n + Q + Q*m, even when an
original intercept is zero.
-/

namespace ErdosProblems.Erdos249.PeriodicTotientIndependence
open scoped BigOperators
end ErdosProblems.Erdos249.PeriodicTotientIndependence

open scoped BigOperators
open ErdosProblems in
open ErdosProblems.Erdos249 in
open ErdosProblems.Erdos249.PeriodicTotientIndependence in
theorem solution {K : Type*} (w : ℕ → K) (Q : ℕ)
    (hw : ∀ n, w (n + Q) = w n) (n t : ℕ) :
    w (n + Q * t) = w n := by
  induction t with
  | zero => simp
  | succ t ih =>
      rw [show n + Q * (t + 1) = (n + Q * t) + Q by ring, hw, ih]
