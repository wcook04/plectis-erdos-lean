import Definitions.Def_Erdos249257_TotientKernelIndex
import Definitions.Def_Erdos249257_TotientKernelConditional
import Definitions.Def_Erdos249257_TotientMahlerDefect
import Definitions.Def_Erdos249257_AllBaseTotientKernel
import Definitions.Def_ErdosProblems_Erdos249_PaperCompleteR7_KernelIntegral
import Definitions.Def_ErdosProblems_Erdos249_PaperCompleteR8_UnitPivotBasis
import Definitions.Def_ErdosProblems_Erdos249_PaperCompleteR8_KernelRelationBasis
import Definitions.Def_ErdosProblems_Erdos249_PaperCompleteR8_FullKernelAssemblies
import Theorems.Thm_Erdos249257_finrank_totientKernelThroughLevelFamily_eq
import Theorems.Thm_ErdosProblems_Erdos249_PaperCompleteR8_UnitPivot_System_relationBasis_apply
import Theorems.Thm_ErdosProblems_Erdos249_PaperCompleteR8_UnitPivot_System_row_of_scalar_reduction
import Theorems.Thm_ErdosProblems_Erdos249_PaperCompleteR8_scalar_canonical_reduction
import Mathlib
import Mathlib.Algebra.Ring.GeomSum
import Mathlib.Data.Fintype.BigOperators
import Mathlib.Data.Nat.ChineseRemainder
import Mathlib.Data.Nat.Totient
import Mathlib.LinearAlgebra.Basis.Basic
import Mathlib.LinearAlgebra.Dimension.Constructions
import Mathlib.LinearAlgebra.Dimension.StrongRankCondition
import Mathlib.LinearAlgebra.Finsupp.Defs
import Mathlib.LinearAlgebra.Finsupp.LinearCombination
import Mathlib.LinearAlgebra.Matrix.Determinant.Basic
import Mathlib.NumberTheory.LSeries.PrimesInAP
import Mathlib.NumberTheory.PrimesCongruentOne

set_option autoImplicit false

/-!
# Full displayed basis statements

All finite-level arithmetic and the full odd-core independence theorem are
inherited from the repaired library. No new CRT or limiting assertion is
assumed. The full relation module uses finite-support coefficient vectors;
this is what makes passage to the union of all levels precise.

Mathlib API (pinned source opened):
* LinearAlgebra/Basis/Basic.lean: Module.Basis.span, coe_span_apply.
* Algebra/Module/Submodule/Equiv.lean: LinearEquiv.coe_ofEq_apply.
* LinearAlgebra/Finsupp/LinearCombination.lean: linearCombination_single,
  mem_span_range_iff_exists_finsupp.
* LinearAlgebra/LinearIndependent/Defs.lean: independence is injectivity
  of finite-support evaluation.

Build status belongs to source-bound validation receipts.
-/

namespace ErdosProblems.Erdos249.PaperCompleteR8
open scoped BigOperators
open Erdos257PeriodNoncollapse
open ErdosProblems.Erdos249.PaperCompleteR7

private theorem complete_level_zero_rank_local (k : ℕ) :
    Module.finrank ℚ
      (Submodule.span ℚ (Set.range (Erdos249257.allBaseThroughLevelFamily k 0))) = 1 := by
  classical
  let v : Fin 1 → ℕ → ℚ := fun _ n => (Nat.totient n : ℚ)
  have hli : LinearIndependent ℚ v := by
    rw [Fintype.linearIndependent_iff]
    intro a ha i
    have hh := congrFun ha 1
    have hi : i = 0 := Subsingleton.elim _ _
    simpa [v, Fin.sum_univ_one, Pi.smul_apply, hi] using hh
  have hseq : ∀ i : Erdos249257.AllBaseThroughLevelIndex k 0,
      Erdos249257.allBaseThroughLevelFamily k 0 i = v 0 := by
    rintro ⟨⟨j, hj⟩, ⟨r, hr⟩⟩
    have hj0 : j = 0 := by omega
    subst j
    simp only [pow_zero] at hr
    have hr0 : r = 0 := by omega
    subst r
    funext n
    simp [Erdos249257.allBaseThroughLevelFamily, Erdos249257.allBaseTotientKernelSeq, v]
  have hrange : Set.range (Erdos249257.allBaseThroughLevelFamily k 0) = Set.range v := by
    apply Set.Subset.antisymm
    · rintro f ⟨i, rfl⟩
      exact ⟨0, (hseq i).symm⟩
    · rintro f ⟨i, rfl⟩
      refine ⟨⟨⟨0, by omega⟩, ⟨0, by simp⟩⟩, ?_⟩
      simpa [v] using hseq (⟨⟨0, by omega⟩, ⟨0, by simp⟩⟩ : Erdos249257.AllBaseThroughLevelIndex k 0)
  rw [hrange, finrank_span_eq_card hli]
  simp





















theorem twoCanonicalToOddCore_value (e : ℕ) (i : Erdos249257.AllBaseCanonicalIndex 2 e) :
    Erdos249257.oddCoreTotientKernelFamily (twoCanonicalToOddCore e i) =
      Erdos249257.allBaseCanonicalFamily 2 e i := by
  cases i with
  | inl i => rfl
  | inr x =>
      have hlast : x.2.2.val = 0 := by have hx := x.2.2.isLt; omega
      simp only [twoCanonicalToOddCore, Erdos249257.oddCoreTotientKernelFamily,
        Erdos249257.allBaseCanonicalFamily, Erdos249257.allBaseCanonicalResidue, hlast, zero_add]
      rfl

/-- Every full-kernel channel is a scalar multiple of an odd-core channel.
This applies the finite theorem at the channel's OWN depth, not at a fixed
cutoff, so it is genuinely a statement about the infinite union. -/
theorem full_scalar_reduction (i : Erdos249257.TotientDyadicKernelIndex) :
    ∃ j : Erdos249257.TotientOddCoreIndex, ∃ a : ℕ,
      Erdos249257.fullTotientKernelFamily i = (a : ℚ) • Erdos249257.oddCoreTotientKernelFamily j := by
  obtain ⟨b, a, ha⟩ := scalar_canonical_reduction 2 i.1 (by omega)
    i.1 le_rfl i.2.val i.2.isLt
  refine ⟨twoCanonicalToOddCore i.1 b, a, ?_⟩
  rw [twoCanonicalToOddCore_value]
  funext n
  have hn := congrFun ha n
  simpa only [Pi.smul_apply, smul_eq_mul, zsmul_eq_mul, Int.cast_natCast] using hn

/-- Every full relation-basis vector is an elementary scalar reduction. -/
theorem fullRelationBasis_two_term (o : FullOmitted) :
    ∃ j : Erdos249257.TotientOddCoreIndex, ∃ a : ℕ,
      Erdos249257.fullTotientKernelFamily o.val = (a : ℚ) • Erdos249257.oddCoreTotientKernelFamily j ∧
      (fullRelationBasis o : Erdos249257.TotientDyadicKernelIndex →₀ ℚ) =
        Finsupp.single o.val 1 - Finsupp.single (fullRetainedChannel j) (a : ℚ) := by
  obtain ⟨j, a, ha⟩ := full_scalar_reduction o.val
  refine ⟨j, a, ha, ?_⟩
  refine (fullRelationSystem.relationBasis_apply o).trans ?_
  apply fullRelationSystem.row_of_scalar_reduction
  change Erdos249257.fullTotientKernelFamily o.val =
    (a : ℚ) • Erdos249257.fullTotientKernelFamily (fullRetainedChannel j)
  rw [fullRetainedChannel_value]
  exact ha
end ErdosProblems.Erdos249.PaperCompleteR8

open scoped BigOperators
open Erdos257PeriodNoncollapse
open ErdosProblems.Erdos249.PaperCompleteR7
open ErdosProblems in
open ErdosProblems.Erdos249 in
open ErdosProblems.Erdos249.PaperCompleteR8 in
theorem solution :
    (∃ b : Module.Basis Erdos249257.TotientOddCoreIndex ℚ
        (Submodule.span ℚ (Set.range Erdos249257.fullTotientKernelFamily)),
      ∀ i, (b i : ℕ → ℚ) = Erdos249257.oddCoreTotientKernelFamily i) ∧
    (∃ b : Module.Basis FullOmitted ℚ FullRelations,
      ∀ o, ∃ j : Erdos249257.TotientOddCoreIndex, ∃ a : ℕ,
        Erdos249257.fullTotientKernelFamily o.val = (a : ℚ) • Erdos249257.oddCoreTotientKernelFamily j ∧
        (b o : Erdos249257.TotientDyadicKernelIndex →₀ ℚ) =
          Finsupp.single o.val 1 - Finsupp.single (fullRetainedChannel j) (a : ℚ)) ∧
    (∀ e : ℕ, 1 ≤ e → Module.finrank ℚ
      (Submodule.span ℚ (Set.range (Erdos249257.totientKernelThroughLevelFamily e))) = 2 ^ e + 1) ∧
    Module.finrank ℚ (Submodule.span ℚ (Set.range (Erdos249257.allBaseThroughLevelFamily 2 0))) = 1 := by
  refine ⟨?_, ⟨fullRelationBasis, fullRelationBasis_two_term⟩,
    Erdos249257.finrank_totientKernelThroughLevelFamily_eq, complete_level_zero_rank_local 2⟩
  refine ⟨Erdos249257.totientDyadicSectionBasis, ?_⟩
  intro i
  simp only [Erdos249257.totientDyadicSectionBasis, Module.Basis.map_apply,
    LinearEquiv.coe_ofEq_apply, Module.Basis.coe_span_apply]
