import Definitions.Def_ErdosProblems_Erdos249_ResidueClassTotientSeries
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.NumberTheory.LSeries.PrimesInAP
import Mathlib.Tactic

namespace ErdosProblems.Erdos249
open Finset
end ErdosProblems.Erdos249

open ErdosProblems
open ErdosProblems.Erdos249
open Finset
open ErdosProblems in
open ErdosProblems.Erdos249 in
theorem solution (c : ℝ) : (∑' j : ℕ, c / 2 ^ (j + 1)) = c := by
  have h : ∀ j : ℕ, c / 2 ^ (j + 1) = c / 2 / 2 ^ j := fun j => by rw [pow_succ]; ring
  rw [tsum_congr h, tsum_geometric_two']
