import Definitions.Def_Erdos249257_TotientMahlerDefect_v2
import Mathlib.Data.Nat.ChineseRemainder
import Mathlib.Data.Nat.Totient
import Mathlib.LinearAlgebra.Dimension.Constructions
import Mathlib.LinearAlgebra.Matrix.Determinant.Basic
import Mathlib.NumberTheory.LSeries.PrimesInAP
import Mathlib.NumberTheory.PrimesCongruentOne

/-!
# Exact ranks of dyadic totient kernels

For `K_{j,r}(n) = φ(2^j n + r)`, this module proves two unconditional rank
statements relevant to Erdős #249:

* the complete kernel through every positive level `e` has dimension
  exactly `2^e+1` over `ℚ`;
* the kernel containing all dyadic levels is infinite-dimensional.

The proof first removes the repeated even-residue channels.  It then proves
linear independence of the remaining canonical family by constructing a
nonzero evaluation minor: CRT and Dirichlet's theorem make one affine channel
prime while forcing a fresh prime divisor in every other channel.  The exact
rank of the complete truncation follows because the removed channels reduce
recursively to lower-level canonical channels.

These are structural theorems about Euler's totient sequence, not a proof that
the totient series is irrational.  A rationality argument would still have to
produce a finite-rank compression, or an equivalent contradiction object,
from the assumed rationality of that series.
-/

namespace Erdos249257
open Module Matrix

































/-! ## The normalized odd-input affine family -/





















































/-! ## A parity-separated determinant kernel -/











/-! ## The exact rank of the complete finite truncation -/
end Erdos249257

open Module Matrix
open Erdos249257 in
theorem solution
    (e : ℕ) (he : 1 ≤ e) :
    Set.range (canonicalTotientKernelFamily e) ⊆
      Set.range (totientKernelThroughLevelFamily e) := by
  rintro _ ⟨i, rfl⟩
  cases i with
  | inl i =>
      refine ⟨⟨⟨i.val, by omega⟩, ⟨0, by positivity⟩⟩, rfl⟩
  | inr i =>
      rcases i with ⟨j, r⟩
      refine ⟨⟨⟨j.val + 1, by omega⟩, ⟨2 * r.val + 1, ?_⟩⟩, rfl⟩
      rw [pow_succ]
      omega
