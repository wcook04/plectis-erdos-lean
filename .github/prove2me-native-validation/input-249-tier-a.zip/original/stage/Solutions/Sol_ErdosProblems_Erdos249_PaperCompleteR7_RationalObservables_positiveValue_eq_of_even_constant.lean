import Definitions.Def_ErdosProblems_Erdos249_ResidueClassTotientSeries
import Definitions.Def_ErdosProblems_Erdos249_PaperCompleteR7_RationalObservableClassification
import Theorems.Thm_ErdosProblems_Erdos249_summable_const_div_two_pow
import Theorems.Thm_ErdosProblems_Erdos249_tsum_const_div_two_pow_succ
import Mathlib
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.NumberTheory.LSeries.PrimesInAP
import Mathlib.Tactic

/-!
# Rational-valued dyadic observables: the missing paper assembly

Targets: short-note `res:residueseries`; long-record
`thm:dyadic-classification`, and the sharpness clause of
`thm:residueobservable`.

`positiveValue` subtracts the n=0 contribution explicitly.  The integer
observable in the imported library includes n=0 and assumes f(0)=0;
confusing these conventions would give the wrong rational-value formula.

The proof clears finitely many rational denominators, invokes the existing
integer-observable theorem, and evaluates the eventually constant tail.
No new CRT, Dirichlet, or isolated-pulse hypothesis is assumed.
Build status: NOT RUN; all declarations below are complete proof candidates.
-/

namespace ErdosProblems.Erdos249.PaperCompleteR7.RationalObservables
open scoped BigOperators





/-- Every residue observable is bounded, hence its full binary series converges. -/
theorem summable_terms (f : ℕ → ℚ) {m : ℕ} (hm : 0 < m) :
    Summable (fun n : ℕ => (f (Nat.totient n % m) : ℝ) / 2 ^ n) := by
  let C : ℝ := ∑ i ∈ Finset.range m, |(f i : ℝ)|
  have hbound (n : ℕ) : |(f (Nat.totient n % m) : ℝ)| ≤ C := by
    exact Finset.single_le_sum (fun i _ => abs_nonneg (f i : ℝ))
      (Finset.mem_range.mpr (Nat.mod_lt _ hm))
  apply Summable.of_norm_bounded
    (g := fun n : ℕ => C / 2 ^ n) (summable_const_div_two_pow C)
  intro n
  rw [Real.norm_eq_abs, abs_div, abs_of_pos (by positivity : (0 : ℝ) < 2 ^ n)]
  exact div_le_div_of_nonneg_right (hbound n) (by positivity)







theorem two_le_two_pow {k : ℕ} (hk : 1 ≤ k) : 2 ≤ 2 ^ k := by
  calc
    2 = 2 ^ 1 := by norm_num
    _ ≤ 2 ^ k := Nat.pow_le_pow_right (by norm_num) hk



/-- All n>=3 have an even totient residue at a positive dyadic resolution. -/
theorem totient_mod_two_pow_even {k : ℕ} (hk : 1 ≤ k) {n : ℕ} (hn : 3 ≤ n) :
    (Nat.totient n % 2 ^ k) % 2 = 0 := by
  have hd : 2 ∣ 2 ^ k := by
    obtain ⟨j, hj⟩ : ∃ j, k = j + 1 := ⟨k - 1, by omega⟩
    rw [hj, pow_succ]
    exact dvd_mul_left 2 (2 ^ j)
  rw [Nat.mod_mod_of_dvd _ hd]
  exact Nat.mod_eq_zero_of_dvd ((even_iff_two_dvd).mp (Nat.totient_even (by omega)))
end ErdosProblems.Erdos249.PaperCompleteR7.RationalObservables

open scoped BigOperators
open ErdosProblems in
open ErdosProblems.Erdos249 in
open ErdosProblems.Erdos249.PaperCompleteR7 in
open ErdosProblems.Erdos249.PaperCompleteR7.RationalObservables in
theorem solution
    {k : ℕ} (hk : 1 ≤ k) (f : ℕ → ℚ) (c : ℚ)
    (hc : ∀ r, r < 2 ^ k → r % 2 = 0 → f r = c) :
    positiveValue f (2 ^ k) = ((3 * f 1 / 4 + c / 4 : ℚ) : ℝ) := by
  have hm : 0 < 2 ^ k := by positivity
  have hm2 := two_le_two_pow hk
  have hsplit := Summable.sum_add_tsum_nat_add
    (f := fun n : ℕ => (f (Nat.totient n % 2 ^ k) : ℝ) / 2 ^ n) 3
    (summable_terms f hm)
  have htail : (∑' n : ℕ,
      (f (Nat.totient (n + 3) % 2 ^ k) : ℝ) / 2 ^ (n + 3)) = (c : ℝ) / 4 := by
    calc
      (∑' n : ℕ, (f (Nat.totient (n + 3) % 2 ^ k) : ℝ) / 2 ^ (n + 3))
          = ∑' n : ℕ, ((c : ℝ) / 4) / 2 ^ (n + 1) := by
              apply tsum_congr
              intro n
              rw [hc _ (Nat.mod_lt _ hm) (totient_mod_two_pow_even hk (by omega))]
              rw [show n + 3 = (n + 1) + 2 by omega, pow_add]
              norm_num <;> ring
      _ = (c : ℝ) / 4 := tsum_const_div_two_pow_succ _
  have hprefix : (∑ n ∈ Finset.range 3,
      (f (Nat.totient n % 2 ^ k) : ℝ) / 2 ^ n) =
      (f 0 : ℝ) + (f 1 : ℝ) / 2 + (f 1 : ℝ) / 4 := by
    norm_num [Finset.sum_range_succ, show Nat.totient 2 = 1 by decide,
      Nat.mod_eq_of_lt (show 1 < 2 ^ k by omega)]
  rw [htail, hprefix] at hsplit
  unfold positiveValue
  push_cast
  linarith
