import Definitions.Def_Erdos249257_TotientMahlerDefect_v2
import Theorems.Thm_Erdos249257_totientKernel_even_residue_step
import Mathlib.Data.Nat.ChineseRemainder
import Mathlib.Data.Nat.Totient
import Mathlib.LinearAlgebra.Dimension.Constructions
import Mathlib.LinearAlgebra.Matrix.Determinant.Basic
import Mathlib.NumberTheory.LSeries.PrimesInAP
import Mathlib.NumberTheory.PrimesCongruentOne

/-!
# Exact ranks of dyadic totient kernels

For `K_{j,r}(n) = φ(2^j n + r)`, this module proves two unconditional rank
statements relevant to Erdős #249:

* the complete kernel through every positive level `e` has dimension
  exactly `2^e+1` over `ℚ`;
* the kernel containing all dyadic levels is infinite-dimensional.

The proof first removes the repeated even-residue channels.  It then proves
linear independence of the remaining canonical family by constructing a
nonzero evaluation minor: CRT and Dirichlet's theorem make one affine channel
prime while forcing a fresh prime divisor in every other channel.  The exact
rank of the complete truncation follows because the removed channels reduce
recursively to lower-level canonical channels.

These are structural theorems about Euler's totient sequence, not a proof that
the totient series is irrational.  A rationality argument would still have to
produce a finite-rank compression, or an equivalent contradiction object,
from the assumed rationality of that series.
-/

namespace Erdos249257
open Module Matrix

































/-! ## The normalized odd-input affine family -/





















































/-! ## A parity-separated determinant kernel -/











/-! ## The exact rank of the complete finite truncation -/
end Erdos249257

open Module Matrix
open Erdos249257 in
theorem solution {e j r : ℕ}
    (he : 1 ≤ e) (hj : j ≤ e) (hr : r < 2 ^ j) :
    totientKernelSeq j r ∈
      Submodule.span ℚ (Set.range (canonicalTotientKernelFamily e)) := by
  induction j generalizing r with
  | zero =>
      have hr0 : r = 0 := by simpa using hr
      subst r
      exact Submodule.subset_span ⟨Sum.inl (0 : Fin 2), rfl⟩
  | succ j ih =>
      by_cases hr0 : r = 0
      · subst r
        have hbase : totientKernelSeq 1 0 ∈
            Submodule.span ℚ (Set.range (canonicalTotientKernelFamily e)) :=
          Submodule.subset_span ⟨Sum.inl (1 : Fin 2), rfl⟩
        have hzero : totientKernelSeq (j + 1) 0 =
            (2 ^ j : ℚ) • totientKernelSeq 1 0 := by
          funext n
          simpa [Pi.smul_apply, smul_eq_mul] using
            totientKernel_zero_residue j n
        rw [hzero]
        exact Submodule.smul_mem _ _ hbase
      · by_cases hj0 : j = 0
        · subst j
          have hr1 : r = 1 := by norm_num at hr; omega
          subst r
          exact Submodule.subset_span
            ⟨Sum.inr ⟨⟨0, he⟩, ⟨0, by simp⟩⟩, rfl⟩
        · by_cases hodd : Odd r
          · obtain ⟨q, hq⟩ := hodd
            have hjlt : j < e := by omega
            have hqBound : q < 2 ^ j := by
              rw [pow_succ] at hr
              omega
            refine Submodule.subset_span
              ⟨Sum.inr ⟨⟨j, hjlt⟩, ⟨q, hqBound⟩⟩, ?_⟩
            simp only [canonicalTotientKernelFamily]
            congr 1
            omega
          · obtain ⟨s, hs⟩ := Nat.not_odd_iff_even.mp hodd
            have hsBound : s < 2 ^ j := by
              rw [pow_succ] at hr
              omega
            have hlower := ih (by omega) hsBound
            have hstep := totientKernel_even_residue_step j s
              (Nat.pos_of_ne_zero hj0)
            rw [show r = 2 * s by omega, hstep]
            split_ifs
            · exact hlower
            · exact Submodule.smul_mem _ _ hlower
