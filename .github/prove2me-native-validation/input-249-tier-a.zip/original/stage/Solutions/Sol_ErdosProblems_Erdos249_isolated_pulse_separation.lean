import Definitions.Def_ErdosProblems_Erdos249_ResidueClassTotientSeries
import Theorems.Thm_ErdosProblems_Erdos249_abs_dyadicTail_le
import Theorems.Thm_ErdosProblems_Erdos249_dyadicTail_pulse
import Theorems.Thm_ErdosProblems_Erdos249_exists_int_add_dyadicTail
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.NumberTheory.LSeries.PrimesInAP
import Mathlib.Tactic

namespace ErdosProblems.Erdos249
open Finset
variable {a : ℕ → ℤ} {C : ℝ}
private theorem abs_le_abs_add_abs (X Y : ℝ) : |X| ≤ |X + Y| + |Y| := by
  have h := abs_add_le (X + Y) (-Y)
  simpa using h
private theorem abs_int_add_ge (M : ℤ) {x : ℝ} (hx : |x| < 1 / 2) : |x| ≤ |(M : ℝ) + x| := by
  rcases eq_or_ne M 0 with h | h
  · simp [h]
  · have h1 : (1 : ℝ) ≤ |(M : ℝ)| := by
      rw [← Int.cast_abs]
      exact_mod_cast Int.one_le_abs h
    have h2 : |(M : ℝ)| ≤ |(M : ℝ) + x| + |x| := abs_le_abs_add_abs _ _
    linarith
end ErdosProblems.Erdos249

open ErdosProblems
open ErdosProblems.Erdos249
open Finset
variable {a : ℕ → ℤ} {C : ℝ}
open ErdosProblems in
open ErdosProblems.Erdos249 in
theorem solution (hC : ∀ n, |(a n : ℝ)| ≤ C)
    {N L q : ℕ} {t : ℤ} (hq : 1 ≤ q) (hL : 2 * (q : ℝ) * C < 2 ^ L)
    (hcentre : a (N + 1 + L) = t) (ht : t ≠ 0)
    (hzero : ∀ i, i ≤ 2 * L → i ≠ L → a (N + 1 + i) = 0) (k : ℤ) :
    (q : ℝ) * (|(t : ℝ)| - C / 2 ^ L) / 2 ^ (N + 1 + L)
      ≤ |(q : ℝ) * dyadicValue a - (k : ℝ)| := by
  have hC0 : (0 : ℝ) ≤ C := le_trans (abs_nonneg _) (hC 0)
  have hq1 : (1 : ℝ) ≤ (q : ℝ) := by exact_mod_cast hq
  have hqpos : (0 : ℝ) < (q : ℝ) := by linarith
  have hLpos : (0 : ℝ) < (2 : ℝ) ^ L := by positivity
  have h2Npos : (0 : ℝ) < (2 : ℝ) ^ N := by positivity
  have hLsucc : (0 : ℝ) < (2 : ℝ) ^ (L + 1) := by positivity
  have hL2 : (0 : ℝ) < (2 : ℝ) ^ (2 * L + 1) := by positivity
  -- `q * C / 2 ^ L < 1 / 2`
  have hkey : (q : ℝ) * C / 2 ^ L < 1 / 2 := by
    rw [div_lt_iff₀ hLpos]
    linarith
  have hCsmall : C / 2 ^ L < 1 / 2 := by
    have hle : C ≤ (q : ℝ) * C := by nlinarith
    have : C / 2 ^ L ≤ (q : ℝ) * C / 2 ^ L := by gcongr
    linarith
  have ht1 : (1 : ℝ) ≤ |(t : ℝ)| := by
    rw [← Int.cast_abs]
    exact_mod_cast Int.one_le_abs ht
  have htC : |(t : ℝ)| ≤ C := by
    have h := hC (N + 1 + L)
    rwa [hcentre] at h
  -- structure of the tail
  have hsp := dyadicTail_pulse hC hcentre hzero
  have hrem : |dyadicTail a (N + 2 * L + 1) / 2 ^ (2 * L + 1)| ≤ C / 2 ^ (2 * L + 1) := by
    rw [abs_div, abs_of_pos hL2]
    gcongr
    exact abs_dyadicTail_le hC _
  have hctr : |(t : ℝ) / 2 ^ (L + 1)| = |(t : ℝ)| / 2 ^ (L + 1) := by
    rw [abs_div, abs_of_pos hLsucc]
  have hprod : (2 : ℝ) ^ L * 2 ^ (L + 1) = 2 ^ (2 * L + 1) := by
    rw [← pow_add]; congr 1; omega
  -- lower bound on the tail
  have hlower : (|(t : ℝ)| - C / 2 ^ L) / 2 ^ (L + 1) ≤ |dyadicTail a N| := by
    have hh := abs_le_abs_add_abs ((t : ℝ) / 2 ^ (L + 1))
      (dyadicTail a (N + 2 * L + 1) / 2 ^ (2 * L + 1))
    rw [← hsp] at hh
    have hsplit : (|(t : ℝ)| - C / 2 ^ L) / 2 ^ (L + 1)
        = |(t : ℝ)| / 2 ^ (L + 1) - C / 2 ^ (2 * L + 1) := by
      rw [sub_div, div_div, hprod]
    rw [hsplit]
    rw [hctr] at hh
    linarith
  -- upper bound on the tail
  have hupper : |dyadicTail a N| ≤ C / 2 ^ L := by
    have hple : (2 : ℝ) ^ (L + 1) ≤ 2 ^ (2 * L + 1) := by
      apply pow_le_pow_right₀ (by norm_num) (by omega)
    have h5 : C / 2 ^ (2 * L + 1) ≤ C / 2 ^ (L + 1) := by gcongr
    have h6 : |(t : ℝ)| / 2 ^ (L + 1) ≤ C / 2 ^ (L + 1) := by gcongr
    have h7 : C / 2 ^ (L + 1) + C / 2 ^ (L + 1) = C / 2 ^ L := by
      have h2L : (2 : ℝ) ^ L ≠ 0 := by positivity
      rw [pow_succ]
      field_simp
      ring
    calc |dyadicTail a N|
        = |(t : ℝ) / 2 ^ (L + 1) + dyadicTail a (N + 2 * L + 1) / 2 ^ (2 * L + 1)| := by rw [hsp]
      _ ≤ |(t : ℝ) / 2 ^ (L + 1)| + |dyadicTail a (N + 2 * L + 1) / 2 ^ (2 * L + 1)| :=
          abs_add_le _ _
      _ ≤ C / 2 ^ (L + 1) + C / 2 ^ (L + 1) := by rw [hctr]; linarith
      _ = C / 2 ^ L := h7
  -- the integer shift
  obtain ⟨P, hP⟩ := exists_int_add_dyadicTail hC N
  have hEq : (2 : ℝ) ^ N * ((q : ℝ) * dyadicValue a - (k : ℝ))
      = (((q : ℤ) * P - 2 ^ N * k : ℤ) : ℝ) + (q : ℝ) * dyadicTail a N := by
    have hrw : (2 : ℝ) ^ N * ((q : ℝ) * dyadicValue a - (k : ℝ))
        = (q : ℝ) * ((2 : ℝ) ^ N * dyadicValue a) - (2 : ℝ) ^ N * (k : ℝ) := by ring
    rw [hrw, hP]
    push_cast
    ring
  have hsmall : |(q : ℝ) * dyadicTail a N| < 1 / 2 := by
    rw [abs_mul, abs_of_pos hqpos]
    calc (q : ℝ) * |dyadicTail a N| ≤ (q : ℝ) * (C / 2 ^ L) := by gcongr
      _ < 1 / 2 := by rw [← mul_div_assoc]; exact hkey
  have hge : |(q : ℝ) * dyadicTail a N|
      ≤ |(2 : ℝ) ^ N * ((q : ℝ) * dyadicValue a - (k : ℝ))| := by
    rw [hEq]
    exact abs_int_add_ge _ hsmall
  have hfrom : (q : ℝ) * ((|(t : ℝ)| - C / 2 ^ L) / 2 ^ (L + 1))
      ≤ |(q : ℝ) * dyadicTail a N| := by
    rw [abs_mul, abs_of_pos hqpos]
    gcongr
  have habs : |(2 : ℝ) ^ N * ((q : ℝ) * dyadicValue a - (k : ℝ))|
      = 2 ^ N * |(q : ℝ) * dyadicValue a - (k : ℝ)| := by
    rw [abs_mul, abs_of_pos h2Npos]
  have hstep : (q : ℝ) * ((|(t : ℝ)| - C / 2 ^ L) / 2 ^ (L + 1))
      ≤ 2 ^ N * |(q : ℝ) * dyadicValue a - (k : ℝ)| := by
    calc (q : ℝ) * ((|(t : ℝ)| - C / 2 ^ L) / 2 ^ (L + 1))
        ≤ |(q : ℝ) * dyadicTail a N| := hfrom
      _ ≤ |(2 : ℝ) ^ N * ((q : ℝ) * dyadicValue a - (k : ℝ))| := hge
      _ = 2 ^ N * |(q : ℝ) * dyadicValue a - (k : ℝ)| := habs
  have hstep' : (q : ℝ) * (|(t : ℝ)| - C / 2 ^ L)
      ≤ 2 ^ N * |(q : ℝ) * dyadicValue a - (k : ℝ)| * 2 ^ (L + 1) := by
    rw [← mul_div_assoc, div_le_iff₀ hLsucc] at hstep
    linarith
  have hpow : (2 : ℝ) ^ (N + 1 + L) = 2 ^ N * 2 ^ (L + 1) := by
    rw [← pow_add]; congr 1; omega
  rw [hpow, div_le_iff₀ (by positivity)]
  calc (q : ℝ) * (|(t : ℝ)| - C / 2 ^ L)
      ≤ 2 ^ N * |(q : ℝ) * dyadicValue a - (k : ℝ)| * 2 ^ (L + 1) := hstep'
    _ = |(q : ℝ) * dyadicValue a - (k : ℝ)| * (2 ^ N * 2 ^ (L + 1)) := by ring
