import Definitions.Def_ErdosProblems_Erdos249_ResidueClassTotientSeries
import Definitions.Def_ErdosProblems_Erdos249_PaperCompleteR7_RationalObservableClassification
import Theorems.Thm_ErdosProblems_Erdos249_summable_const_div_two_pow
import Theorems.Thm_ErdosProblems_Erdos249_PaperCompleteR7_RationalObservables_irrational_positiveValue_of_unit
import Theorems.Thm_ErdosProblems_Erdos249_PaperCompleteR7_RationalObservables_positiveValue_eq_of_even_constant
import Theorems.Thm_ErdosProblems_Erdos249_residue_series_irrational
import Mathlib
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.NumberTheory.LSeries.PrimesInAP
import Mathlib.Tactic

/-!
# Rational-valued dyadic observables: the missing paper assembly

Targets: short-note `res:residueseries`; long-record
`thm:dyadic-classification`, and the sharpness clause of
`thm:residueobservable`.

`positiveValue` subtracts the n=0 contribution explicitly.  The integer
observable in the imported library includes n=0 and assumes f(0)=0;
confusing these conventions would give the wrong rational-value formula.

The proof clears finitely many rational denominators, invokes the existing
integer-observable theorem, and evaluates the eventually constant tail.
No new CRT, Dirichlet, or isolated-pulse hypothesis is assumed.
Build status: NOT RUN; all declarations below are complete proof candidates.
-/

namespace ErdosProblems.Erdos249.PaperCompleteR7.RationalObservables
open scoped BigOperators





/-- Every residue observable is bounded, hence its full binary series converges. -/
theorem summable_terms (f : ℕ → ℚ) {m : ℕ} (hm : 0 < m) :
    Summable (fun n : ℕ => (f (Nat.totient n % m) : ℝ) / 2 ^ n) := by
  let C : ℝ := ∑ i ∈ Finset.range m, |(f i : ℝ)|
  have hbound (n : ℕ) : |(f (Nat.totient n % m) : ℝ)| ≤ C := by
    exact Finset.single_le_sum (fun i _ => abs_nonneg (f i : ℝ))
      (Finset.mem_range.mpr (Nat.mod_lt _ hm))
  apply Summable.of_norm_bounded
    (g := fun n : ℕ => C / 2 ^ n) (summable_const_div_two_pow C)
  intro n
  rw [Real.norm_eq_abs, abs_div, abs_of_pos (by positivity : (0 : ℝ) < 2 ^ n)]
  exact div_le_div_of_nonneg_right (hbound n) (by positivity)

theorem positiveValue_eq_tsum_succ (f : ℕ → ℚ) {m : ℕ} (hm : 0 < m) :
    positiveValue f m =
      ∑' n : ℕ, (f (Nat.totient (n + 1) % m) : ℝ) / 2 ^ (n + 1) := by
  have h := Summable.sum_add_tsum_nat_add
    (f := fun n : ℕ => (f (Nat.totient n % m) : ℝ) / 2 ^ n) 1
    (summable_terms f hm)
  simp only [Finset.sum_range_one, Nat.totient_zero, Nat.zero_mod,
    pow_zero, div_one] at h
  unfold positiveValue
  linarith





theorem two_le_two_pow {k : ℕ} (hk : 1 ≤ k) : 2 ≤ 2 ^ k := by
  calc
    2 = 2 ^ 1 := by norm_num
    _ ≤ 2 ^ k := Nat.pow_le_pow_right (by norm_num) hk

/-- The unit condition is automatic for an even dyadic residue. -/
theorem irrational_positiveValue_of_even
    {k : ℕ} (hk : 1 ≤ k) (f : ℕ → ℚ)
    {r : ℕ} (hr : r < 2 ^ k) (heven : r % 2 = 0)
    (hfr : f r ≠ f 0) : Irrational (positiveValue f (2 ^ k)) := by
  have h2 : Nat.Coprime 2 (r + 1) :=
    (Nat.Prime.coprime_iff_not_dvd Nat.prime_two).mpr (by omega)
  exact irrational_positiveValue_of_unit (two_le_two_pow hk) f hr
    (Nat.Coprime.pow_right k h2.symm) hfr





/-- COMPLETE dyadic classification, in finite-residue representative coordinates.
The constant may equivalently be written f(0). -/
theorem rational_dyadic_observable_iff
    {k : ℕ} (hk : 1 ≤ k) (f : ℕ → ℚ) :
    (∃ q : ℚ, positiveValue f (2 ^ k) = (q : ℝ)) ↔
      ∀ r, r < 2 ^ k → r % 2 = 0 → f r = f 0 := by
  constructor
  · rintro ⟨q, hq⟩ r hr heven
    by_contra hne
    exact (irrational_positiveValue_of_even hk f hr heven hne).ne_rat q hq
  · intro hc
    exact ⟨3 * f 1 / 4 + f 0 / 4,
      positiveValue_eq_of_even_constant hk f (f 0) hc⟩

/-- Exact ZMod-domain formulation of the displayed paper theorem. -/
theorem rational_zmod_observable_iff
    {k : ℕ} (hk : 1 ≤ k) (f : ZMod (2 ^ k) → ℚ) :
    (∃ q : ℚ,
      (∑' n : ℕ, (f (Nat.totient (n + 1) : ZMod (2 ^ k)) : ℝ) /
        2 ^ (n + 1)) = (q : ℝ)) ↔
      ∀ r : ℕ, r < 2 ^ k → r % 2 = 0 → f (r : ZMod (2 ^ k)) = f 0 := by
  have h := rational_dyadic_observable_iff hk
    (fun r : ℕ => f (r : ZMod (2 ^ k)))
  have heq := positiveValue_eq_tsum_succ
    (fun r : ℕ => f (r : ZMod (2 ^ k))) (by positivity : 0 < 2 ^ k)
  rw [heq] at h
  simpa only [ZMod.natCast_mod, Nat.cast_zero] using h

/-- The value formula in the same literal ZMod coordinates. -/
theorem zmod_observable_value
    {k : ℕ} (hk : 1 ≤ k) (f : ZMod (2 ^ k) → ℚ) (c : ℚ)
    (hc : ∀ r : ℕ, r < 2 ^ k → r % 2 = 0 → f (r : ZMod (2 ^ k)) = c) :
    (∑' n : ℕ, (f (Nat.totient (n + 1) : ZMod (2 ^ k)) : ℝ) /
      2 ^ (n + 1)) = ((3 * f 1 / 4 + c / 4 : ℚ) : ℝ) := by
  have h := positiveValue_eq_of_even_constant hk
    (fun r : ℕ => f (r : ZMod (2 ^ k))) c hc
  rw [positiveValue_eq_tsum_succ _ (by positivity : 0 < 2 ^ k)] at h
  simpa only [ZMod.natCast_mod, Nat.cast_one] using h
end ErdosProblems.Erdos249.PaperCompleteR7.RationalObservables

open scoped BigOperators
open ErdosProblems in
open ErdosProblems.Erdos249 in
open ErdosProblems.Erdos249.PaperCompleteR7 in
open ErdosProblems.Erdos249.PaperCompleteR7.RationalObservables in
theorem solution :
    (∀ m : ℕ, 3 ≤ m → Irrational (totientResidueValue m)) ∧
    (∀ k : ℕ, 1 ≤ k → ∀ f : ZMod (2 ^ k) → ℚ,
      ((∃ q : ℚ,
        (∑' n : ℕ, (f (Nat.totient (n + 1) : ZMod (2 ^ k)) : ℝ) /
          2 ^ (n + 1)) = (q : ℝ)) ↔
        ∀ r : ℕ, r < 2 ^ k → r % 2 = 0 → f (r : ZMod (2 ^ k)) = f 0)) ∧
    (∀ k : ℕ, 1 ≤ k → ∀ f : ZMod (2 ^ k) → ℚ, ∀ c : ℚ,
      (∀ r : ℕ, r < 2 ^ k → r % 2 = 0 → f (r : ZMod (2 ^ k)) = c) →
      (∑' n : ℕ, (f (Nat.totient (n + 1) : ZMod (2 ^ k)) : ℝ) /
        2 ^ (n + 1)) = ((3 * f 1 / 4 + c / 4 : ℚ) : ℝ)) := by
  exact ⟨fun _ hm => residue_series_irrational hm,
    fun _ hk f => rational_zmod_observable_iff hk f,
    fun _ hk f c hc => zmod_observable_value hk f c hc⟩
