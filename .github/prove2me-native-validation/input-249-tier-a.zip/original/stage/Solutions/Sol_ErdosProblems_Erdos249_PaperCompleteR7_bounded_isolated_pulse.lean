import Definitions.Def_Erdos249257_TotientKernelIndex
import Definitions.Def_Erdos249257_TotientKernelConditional
import Definitions.Def_Erdos249257_TotientMahlerDefect
import Definitions.Def_Erdos249257_AllBaseTotientKernel
import Definitions.Def_ErdosProblems_Erdos249_ResidueClassTotientSeries
import Theorems.Thm_ErdosProblems_Erdos249_summable_dyadicTerm
import Theorems.Thm_ErdosProblems_Erdos249_irrational_dyadicValue_of_pulses
import Mathlib
import Mathlib.Algebra.Ring.GeomSum
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.Data.Fintype.BigOperators
import Mathlib.Data.Nat.ChineseRemainder
import Mathlib.Data.Nat.Totient
import Mathlib.LinearAlgebra.Dimension.Constructions
import Mathlib.LinearAlgebra.Matrix.Determinant.Basic
import Mathlib.NumberTheory.LSeries.PrimesInAP
import Mathlib.NumberTheory.PrimesCongruentOne
import Mathlib.Tactic

namespace ErdosProblems.Erdos249.PaperCompleteR7
end ErdosProblems.Erdos249.PaperCompleteR7

/-!
# Paper-complete interfaces: eventual periodic coefficients and cofinal pulses

Targets: short-note `cor:periodic-freezing` and `lem:bounded-pulse`.
This file extends the compiled r5 periodic theorem, not the uncompiled r6 helper.
Every theorem has a proof term and no extra mathematical assumption.
Build status for this return: source-reviewed, NOT RUN (no Lean executable).
-/

namespace ErdosProblems.Erdos249.PaperCompleteR7
open scoped BigOperators





/-- Cofinal lengths and the paper's weak `L < N` convention suffice for the
library pulse theorem, whose interface requests every length and `L+1 < N`.
The extra unit is obtained by selecting a strictly larger available length. -/
theorem irrational_dyadicValue_of_cofinal_pulses
    (a : ℕ → ℤ) (C : ℝ) (hC : ∀ n, |(a n : ℝ)| ≤ C)
    (hpulse : ∀ L₀ : ℕ, ∃ L N : ℕ, L₀ ≤ L ∧ L < N ∧ a N ≠ 0 ∧
      ∀ j, 0 < j → j ≤ L → a (N - j) = 0 ∧ a (N + j) = 0) :
    Irrational (dyadicValue a) := by
  apply irrational_dyadicValue_of_pulses hC
  intro L
  obtain ⟨L', N, hL', hN, haN, hzero⟩ := hpulse (L + 1)
  refine ⟨N, by omega, haN, ?_⟩
  intro j hj hjL
  exact hzero j hj (by omega)
end ErdosProblems.Erdos249.PaperCompleteR7

open scoped BigOperators
open ErdosProblems in
open ErdosProblems.Erdos249 in
open ErdosProblems.Erdos249.PaperCompleteR7 in
theorem solution
    (a : ℕ → ℤ) (C : ℝ) (hC : ∀ n, |(a n : ℝ)| ≤ C)
    (hpulse : ∀ L₀ : ℕ, ∃ L N : ℕ, L₀ ≤ L ∧ L < N ∧ a N ≠ 0 ∧
      ∀ j, 0 < j → j ≤ L → a (N - j) = 0 ∧ a (N + j) = 0) :
    Irrational (∑' n : ℕ, (a (n + 1) : ℝ) / 2 ^ (n + 1)) := by
  have hirr := irrational_dyadicValue_of_cofinal_pulses a C hC hpulse
  have hs := summable_dyadicTerm hC
  have hsplit := Summable.sum_add_tsum_nat_add
    (f := fun n : ℕ => (a n : ℝ) / 2 ^ n) 1 hs
  simp only [Finset.sum_range_one, pow_zero, div_one] at hsplit
  have heq : (∑' n : ℕ, (a (n + 1) : ℝ) / 2 ^ (n + 1)) =
      dyadicValue a - (a 0 : ℝ) := by
    change (a 0 : ℝ) + (∑' n : ℕ, (a (n + 1) : ℝ) / 2 ^ (n + 1)) =
      dyadicValue a at hsplit
    linarith
  rw [heq]
  exact hirr.sub_intCast (a 0)
