import Definitions.Def_ErdosProblems_Erdos249_ResidueClassTotientSeries
import Theorems.Thm_ErdosProblems_Erdos249_summable_const_div_two_pow
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.NumberTheory.LSeries.PrimesInAP
import Mathlib.Tactic

namespace ErdosProblems.Erdos249
open Finset
variable {a : ℕ → ℤ} {C : ℝ}
end ErdosProblems.Erdos249

open ErdosProblems
open ErdosProblems.Erdos249
open Finset
variable {a : ℕ → ℤ} {C : ℝ}
open ErdosProblems in
open ErdosProblems.Erdos249 in
theorem solution (hC : ∀ n, |(a n : ℝ)| ≤ C) :
    Summable fun n : ℕ => (a n : ℝ) / 2 ^ n := by
  refine Summable.of_norm_bounded (g := fun n : ℕ => C / 2 ^ n) (summable_const_div_two_pow C) ?_
  intro n
  dsimp only
  have h2 : (0 : ℝ) < 2 ^ n := by positivity
  rw [Real.norm_eq_abs, abs_div, abs_of_pos h2]
  gcongr
  exact hC n
