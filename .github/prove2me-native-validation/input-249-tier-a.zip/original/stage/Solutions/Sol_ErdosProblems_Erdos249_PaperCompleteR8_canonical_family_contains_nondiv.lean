import Definitions.Def_Erdos249257_TotientKernelIndex
import Definitions.Def_Erdos249257_TotientKernelConditional
import Definitions.Def_Erdos249257_TotientMahlerDefect_v2
import Definitions.Def_Erdos249257_AllBaseTotientKernel_v2
import Definitions.Def_ErdosProblems_Erdos249_PaperCompleteR7_KernelIntegral_v2
import Definitions.Def_ErdosProblems_Erdos249_PaperCompleteR8_UnitPivotBasis_v2
import Definitions.Def_ErdosProblems_Erdos249_PaperCompleteR8_KernelRelationBasis_v2
import Mathlib
import Mathlib.Algebra.Ring.GeomSum
import Mathlib.Data.Fintype.BigOperators
import Mathlib.Data.Nat.ChineseRemainder
import Mathlib.Data.Nat.Totient
import Mathlib.LinearAlgebra.Basis.Basic
import Mathlib.LinearAlgebra.Dimension.Constructions
import Mathlib.LinearAlgebra.Dimension.StrongRankCondition
import Mathlib.LinearAlgebra.Finsupp.Defs
import Mathlib.LinearAlgebra.Finsupp.LinearCombination
import Mathlib.LinearAlgebra.Matrix.Determinant.Basic
import Mathlib.NumberTheory.LSeries.PrimesInAP
import Mathlib.NumberTheory.PrimesCongruentOne

set_option autoImplicit false

/-!
# The integral relation-module basis missing from the paper

New r8 proof source. The r7 coordinate basis is reused unchanged. The map below
has the free Z-module on ALL channels as its domain and the actual integral
span as its codomain. Its kernel has the unit-pivot basis, not just a spanning
set. Maximal reductions are identified by uniqueness of canonical coordinates.

Pinned Mathlib source comments identify
APIs opened at 5e932f97dd25535344f80f9dd8da3aab83df0fe6.
-/

namespace ErdosProblems.Erdos249.PaperCompleteR8
open scoped BigOperators
open Erdos257PeriodNoncollapse
open ErdosProblems.Erdos249.PaperCompleteR7

































/-! ## Identification with the literal elementary reductions on the page -/
end ErdosProblems.Erdos249.PaperCompleteR8

open scoped BigOperators
open Erdos257PeriodNoncollapse
open ErdosProblems.Erdos249.PaperCompleteR7
open ErdosProblems in
open ErdosProblems.Erdos249 in
open ErdosProblems.Erdos249.PaperCompleteR8 in
theorem solution (k e h u : ℕ) (hk : 2 ≤ k)
    (hh : 1 ≤ h) (hhe : h ≤ e) (hu : u < k ^ h) (hku : ¬ k ∣ u) :
    ∃ b : Erdos249257.AllBaseCanonicalIndex k e,
      Erdos249257.allBaseCanonicalFamily k e b = Erdos249257.allBaseTotientKernelSeq k h u := by
  have hkpos : 0 < k := by omega
  obtain ⟨j, rfl⟩ : ∃ j, h = j + 1 := ⟨h - 1, (Nat.sub_add_cancel hh).symm⟩
  obtain ⟨s, v, hvpos, hvlt, rfl⟩ :
      ∃ s v, 0 < v ∧ v < k ∧ u = k * s + v := by
    refine ⟨u / k, u % k, ?_, Nat.mod_lt _ hkpos, (Nat.div_add_mod u k).symm⟩
    rcases Nat.eq_zero_or_pos (u % k) with hz | hp
    · exact False.elim (hku (Nat.dvd_of_mod_eq_zero hz))
    · exact hp
  have hs : s < k ^ j := by
    have hmul : k * s < k * k ^ j := by
      have hb : k * s + v < k * k ^ j := by
        calc
          k * s + v < k ^ (j + 1) := hu
          _ = k * k ^ j := by ring
      omega
    exact lt_of_mul_lt_mul_left hmul (Nat.zero_le k)
  refine ⟨Sum.inr ⟨⟨j, by omega⟩, (⟨s, hs⟩, ⟨v - 1, by omega⟩)⟩, ?_⟩
  simp only [Erdos249257.allBaseCanonicalFamily, Erdos249257.allBaseCanonicalResidue]
  congr 1
  omega
