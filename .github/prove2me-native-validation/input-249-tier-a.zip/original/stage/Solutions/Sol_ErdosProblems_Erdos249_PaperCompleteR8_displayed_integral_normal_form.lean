import Definitions.Def_Erdos249257_TotientKernelIndex
import Definitions.Def_Erdos249257_TotientKernelConditional
import Definitions.Def_Erdos249257_TotientMahlerDefect
import Definitions.Def_Erdos249257_AllBaseTotientKernel
import Definitions.Def_ErdosProblems_Erdos249_PaperCompleteR7_KernelIntegral
import Definitions.Def_ErdosProblems_Erdos249_PaperCompleteR8_UnitPivotBasis
import Definitions.Def_ErdosProblems_Erdos249_PaperCompleteR8_KernelRelationBasis
import Theorems.Thm_Erdos249257_card_allBaseCanonicalIndex
import Theorems.Thm_Erdos249257_card_allBaseThroughLevelIndex
import Theorems.Thm_ErdosProblems_Erdos249_PaperCompleteR8_UnitPivot_System_card_omitted_add_card_kept
import Theorems.Thm_ErdosProblems_Erdos249_PaperCompleteR8_UnitPivot_System_relationBasis_apply
import Theorems.Thm_ErdosProblems_Erdos249_PaperCompleteR8_UnitPivot_System_row_of_scalar_reduction
import Theorems.Thm_ErdosProblems_Erdos249_PaperCompleteR8_scalar_canonical_reduction
import Mathlib
import Mathlib.Algebra.Ring.GeomSum
import Mathlib.Data.Fintype.BigOperators
import Mathlib.Data.Nat.ChineseRemainder
import Mathlib.Data.Nat.Totient
import Mathlib.LinearAlgebra.Basis.Basic
import Mathlib.LinearAlgebra.Dimension.Constructions
import Mathlib.LinearAlgebra.Dimension.StrongRankCondition
import Mathlib.LinearAlgebra.Finsupp.Defs
import Mathlib.LinearAlgebra.Finsupp.LinearCombination
import Mathlib.LinearAlgebra.Matrix.Determinant.Basic
import Mathlib.NumberTheory.LSeries.PrimesInAP
import Mathlib.NumberTheory.PrimesCongruentOne

set_option autoImplicit false

/-!
# The integral relation-module basis missing from the paper

New r8 proof source. The r7 coordinate basis is reused unchanged. The map below
has the free Z-module on ALL channels as its domain and the actual integral
span as its codomain. Its kernel has the unit-pivot basis, not just a spanning
set. Maximal reductions are identified by uniqueness of canonical coordinates.

Pinned Mathlib source comments identify
APIs opened at 5e932f97dd25535344f80f9dd8da3aab83df0fe6.
-/

namespace ErdosProblems.Erdos249.PaperCompleteR8
open scoped BigOperators
open Erdos257PeriodNoncollapse
open ErdosProblems.Erdos249.PaperCompleteR7

























/-- Elementary identity for the number of omitted coordinates. -/
private theorem channel_count_split (k d : ℕ) :
    (∑ j ∈ Finset.range (d + 2), k ^ j) =
      k ^ (d + 1) + 1 + ∑ j ∈ Finset.range d, k ^ (j + 1) := by
  induction d with
  | zero => simp only [Finset.sum_range_succ, Finset.sum_range_zero,
      pow_zero, zero_add, add_zero]; omega
  | succ d ih =>
      have ht : (∑ j ∈ Finset.range (d + 1 + 2), k ^ j) =
          (∑ j ∈ Finset.range (d + 2), k ^ j) + k ^ (d + 2) := by
        simpa only [Nat.add_assoc] using
          (Finset.sum_range_succ (fun j => k ^ j) (d + 2))
      have hm : (∑ j ∈ Finset.range (d + 1), k ^ (j + 1)) =
          (∑ j ∈ Finset.range d, k ^ (j + 1)) + k ^ (d + 1) :=
        Finset.sum_range_succ _ _
      rw [ht, ih, hm]
      have hexp : d + 1 + 1 = d + 2 := by omega
      rw [hexp]
      omega

theorem card_omittedIntegralChannel (k e : ℕ) (hk : 2 ≤ k) (he : 1 ≤ e) :
    Fintype.card (OmittedIntegralChannel k e hk he) =
      ∑ j ∈ Finset.range (e - 1), k ^ (j + 1) := by
  classical
  have hcount := (integralRelationSystem k e hk he).card_omitted_add_card_kept
  change Fintype.card (OmittedIntegralChannel k e hk he) +
    Fintype.card (Erdos249257.AllBaseCanonicalIndex k e) =
      Fintype.card (Erdos249257.AllBaseThroughLevelIndex k e) at hcount
  rw [Erdos249257.card_allBaseCanonicalIndex k e (by omega), Erdos249257.card_allBaseThroughLevelIndex] at hcount
  have hsplit := channel_count_split k (e - 1)
  have h₁ : e - 1 + 1 = e := Nat.sub_add_cancel he
  have h₂ : e - 1 + 2 = e + 1 := by omega
  rw [h₁, h₂] at hsplit
  omega

/-- Exact integral rank; this follows from the exhibited basis and its pivots. -/
theorem finrank_integralRelations (k e : ℕ) (hk : 2 ≤ k) (he : 1 ≤ e) :
    Module.finrank ℤ (IntegralRelations k e hk he) =
      ∑ j ∈ Finset.range (e - 1), k ^ (j + 1) := by
  classical
  -- Mathlib/LinearAlgebra/Dimension/StrongRankCondition.lean:
  -- Module.finrank_eq_card_basis applies over Z, not just over fields.
  rw [Module.finrank_eq_card_basis (integralRelationBasis k e hk he)]
  exact card_omittedIntegralChannel k e hk he



/-! ## Identification with the literal elementary reductions on the page -/



/-- Any supplied canonical target and scalar identity produce the exact
maximal-reduction basis vector. This includes the printed Euler-product scalar;
the next theorem gives that scalar's integral value. -/
theorem integral_scalar_reduction_row (k e : ℕ) (hk : 2 ≤ k) (he : 1 ≤ e)
    (o : OmittedIntegralChannel k e hk he) (b : Erdos249257.AllBaseCanonicalIndex k e) (a : ℤ)
    (h : Erdos249257.allBaseThroughLevelFamily k e o.val = a • Erdos249257.allBaseCanonicalFamily k e b) :
    (integralRelationBasis k e hk he o : Erdos249257.AllBaseThroughLevelIndex k e →₀ ℤ) =
      Finsupp.single o.val 1 - Finsupp.single (retainedChannel k e hk he b) a := by
  refine ((integralRelationSystem k e hk he).relationBasis_apply _).trans ?_
  apply (integralRelationSystem k e hk he).row_of_scalar_reduction
  apply Subtype.ext
  change Erdos249257.allBaseThroughLevelFamily k e o.val =
    a • Erdos249257.allBaseThroughLevelFamily k e (retainedChannel k e hk he b)
  rw [retainedChannel_value]
  exact h














/-- Each actual basis vector is a literal two-term unit-pivot reduction.
There is no undisplayed many-term coordinate choice in this conclusion. -/
theorem integralRelationBasis_two_term (k e : ℕ) (hk : 2 ≤ k) (he : 1 ≤ e)
    (o : OmittedIntegralChannel k e hk he) :
    ∃ b : Erdos249257.AllBaseCanonicalIndex k e, ∃ a : ℕ,
      Erdos249257.allBaseThroughLevelFamily k e o.val = (a : ℤ) • Erdos249257.allBaseCanonicalFamily k e b ∧
      (integralRelationBasis k e hk he o : Erdos249257.AllBaseThroughLevelIndex k e →₀ ℤ) =
        Finsupp.single o.val 1 - Finsupp.single (retainedChannel k e hk he b) (a : ℤ) := by
  obtain ⟨b, a, ha⟩ := scalar_canonical_reduction k e hk o.val.1.val
    (Nat.le_of_lt_succ o.val.1.isLt) o.val.2.val o.val.2.isLt
  exact ⟨b, a, ha, integral_scalar_reduction_row k e hk he o b a ha⟩



/-- The coordinate basis has the literal canonical family as its values. -/
theorem integralTotientKernelBasis_values (k e : ℕ) (hk : 2 ≤ k) (he : 1 ≤ e)
    (i : Erdos249257.AllBaseCanonicalIndex k e) :
    (integralTotientKernelBasis k e hk he i : ℕ → ℚ) = Erdos249257.allBaseCanonicalFamily k e i := by
  -- Mathlib/LinearAlgebra/Basis/{Basic,Defs}.lean; Submodule/Equiv.lean.
  simp only [integralTotientKernelBasis, Module.Basis.map_apply,
    LinearEquiv.coe_ofEq_apply, Module.Basis.coe_span_apply]
end ErdosProblems.Erdos249.PaperCompleteR8

open scoped BigOperators
open Erdos257PeriodNoncollapse
open ErdosProblems.Erdos249.PaperCompleteR7
open ErdosProblems in
open ErdosProblems.Erdos249 in
open ErdosProblems.Erdos249.PaperCompleteR8 in
theorem solution (k e : ℕ) (hk : 2 ≤ k) (he : 1 ≤ e) :
    (∃ c : Module.Basis (Erdos249257.AllBaseCanonicalIndex k e) ℤ (IntegralChannelSpan k e),
      ∀ i, (c i : ℕ → ℚ) = Erdos249257.allBaseCanonicalFamily k e i) ∧
    (∃ b : Module.Basis (OmittedIntegralChannel k e hk he) ℤ
        (IntegralRelations k e hk he),
      ∀ o, ∃ j : Erdos249257.AllBaseCanonicalIndex k e, ∃ a : ℕ,
        Erdos249257.allBaseThroughLevelFamily k e o.val = (a : ℤ) • Erdos249257.allBaseCanonicalFamily k e j ∧
        (b o : Erdos249257.AllBaseThroughLevelIndex k e →₀ ℤ) =
          Finsupp.single o.val 1 - Finsupp.single (retainedChannel k e hk he j) (a : ℤ)) ∧
    Module.finrank ℤ (IntegralRelations k e hk he) =
      ∑ j ∈ Finset.range (e - 1), k ^ (j + 1) := by
  exact ⟨⟨integralTotientKernelBasis k e hk he,
      integralTotientKernelBasis_values k e hk he⟩,
    ⟨integralRelationBasis k e hk he, integralRelationBasis_two_term k e hk he⟩,
    finrank_integralRelations k e hk he⟩
