import Definitions.Def_Erdos249257_TotientMahlerDefect
import Theorems.Thm_Erdos249257_range_canonicalTotientKernelFamily_subset_throughLevel
import Theorems.Thm_Erdos249257_totientKernelSeq_mem_span_canonical_of_le
import Mathlib.Data.Nat.ChineseRemainder
import Mathlib.Data.Nat.Totient
import Mathlib.LinearAlgebra.Dimension.Constructions
import Mathlib.LinearAlgebra.Matrix.Determinant.Basic
import Mathlib.NumberTheory.LSeries.PrimesInAP
import Mathlib.NumberTheory.PrimesCongruentOne

/-!
# Exact ranks of dyadic totient kernels

For `K_{j,r}(n) = φ(2^j n + r)`, this module proves two unconditional rank
statements relevant to Erdős #249:

* the complete kernel through every positive level `e` has dimension
  exactly `2^e+1` over `ℚ`;
* the kernel containing all dyadic levels is infinite-dimensional.

The proof first removes the repeated even-residue channels.  It then proves
linear independence of the remaining canonical family by constructing a
nonzero evaluation minor: CRT and Dirichlet's theorem make one affine channel
prime while forcing a fresh prime divisor in every other channel.  The exact
rank of the complete truncation follows because the removed channels reduce
recursively to lower-level canonical channels.

These are structural theorems about Euler's totient sequence, not a proof that
the totient series is irrational.  A rationality argument would still have to
produce a finite-rank compression, or an equivalent contradiction object,
from the assumed rationality of that series.
-/

namespace Erdos249257
open Module Matrix

































/-! ## The normalized odd-input affine family -/





















































/-! ## A parity-separated determinant kernel -/











/-! ## The exact rank of the complete finite truncation -/
end Erdos249257

open Module Matrix
open Erdos249257 in
theorem solution
    (e : ℕ) (he : 1 ≤ e) :
    Submodule.span ℚ (Set.range (totientKernelThroughLevelFamily e)) =
      Submodule.span ℚ (Set.range (canonicalTotientKernelFamily e)) := by
  apply le_antisymm
  · rw [Submodule.span_le]
    rintro _ ⟨⟨j, r⟩, rfl⟩
    exact totientKernelSeq_mem_span_canonical_of_le he
      (Nat.le_of_lt_succ j.isLt) r.isLt
  · exact Submodule.span_mono
      (range_canonicalTotientKernelFamily_subset_throughLevel e he)
