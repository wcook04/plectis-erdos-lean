import Definitions.Def_ErdosProblems_Erdos249_ResidueClassTotientSeries
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.NumberTheory.LSeries.PrimesInAP
import Mathlib.Tactic

namespace ErdosProblems.Erdos249
open Finset
private theorem coprime_of_modEq {x y n : ℕ} (h : x ≡ y [MOD n]) (hy : Nat.Coprime y n) :
    Nat.Coprime x n := by
  have h' : x % n = y % n := h
  have h1 : Nat.gcd n x = Nat.gcd n y := by
    rw [Nat.gcd_rec n x, Nat.gcd_rec n y, h']
  have hy' : Nat.gcd n y = 1 := by rw [Nat.gcd_comm]; exact hy
  show Nat.gcd x n = 1
  rw [Nat.gcd_comm, h1]
  exact hy'
private theorem coprime_prime_of_lt {l n : ℕ} (hl : l.Prime) (hn0 : 0 < n) (hn : n < l) :
    Nat.Coprime l n :=
  (Nat.Prime.coprime_iff_not_dvd hl).mpr fun hd => absurd (Nat.le_of_dvd hn0 hd) (by omega)
private theorem dvd_totient_of_prime_dvd {m l n : ℕ} (hl : l.Prime) (hlm : l ≡ 1 [MOD m])
    (hdvd : l ∣ n) : m ∣ Nat.totient n := by
  have h1 : Nat.totient l ∣ Nat.totient n := Nat.totient_dvd_of_dvd hdvd
  rw [Nat.totient_prime hl] at h1
  exact (Nat.modEq_iff_dvd' hl.one_lt.le).mp hlm.symm |>.trans h1
end ErdosProblems.Erdos249

open ErdosProblems
open ErdosProblems.Erdos249
open Finset
open ErdosProblems in
open ErdosProblems.Erdos249 in
theorem solution (m : ℕ) (hm : 0 < m) (L : ℕ) :
    ∃ Q b : ℕ, 0 < Q ∧ Nat.Coprime Q m ∧ Nat.Coprime b Q ∧
      ∀ p : ℕ, L < p → p ≡ b [MOD Q] →
        ∀ j, 0 < j → j ≤ L → m ∣ Nat.totient (p - j) ∧ m ∣ Nat.totient (p + j) := by
  induction L with
  | zero =>
      refine ⟨1, 1, one_pos, Nat.coprime_one_left m, Nat.coprime_one_left 1, ?_⟩
      intro p _ _ j hj hjL
      exact absurd hjL (by omega)
  | succ L ih =>
      obtain ⟨Q, b, hQ0, hQm, hbQ, hmain⟩ := ih
      obtain ⟨l1, hl1gt, hl1p, hl1m⟩ :=
        Nat.forall_exists_prime_gt_and_modEq (max (max Q m) (L + 1)) (q := m) (a := 1)
          hm.ne' (Nat.coprime_one_left m)
      obtain ⟨l2, hl2gt, hl2p, hl2m⟩ :=
        Nat.forall_exists_prime_gt_and_modEq (max (max (max Q m) (L + 1)) l1) (q := m) (a := 1)
          hm.ne' (Nat.coprime_one_left m)
      simp only [gt_iff_lt, max_lt_iff] at hl1gt hl2gt
      obtain ⟨⟨hQl1, hml1⟩, hLl1⟩ := hl1gt
      obtain ⟨⟨⟨hQl2, hml2⟩, hLl2⟩, hl1l2⟩ := hl2gt
      have cl1Q : Nat.Coprime l1 Q := coprime_prime_of_lt hl1p hQ0 hQl1
      have cl1m : Nat.Coprime l1 m := coprime_prime_of_lt hl1p hm hml1
      have cl1L : Nat.Coprime l1 (L + 1) := coprime_prime_of_lt hl1p (by omega) hLl1
      have cl2Q : Nat.Coprime l2 Q := coprime_prime_of_lt hl2p hQ0 hQl2
      have cl2m : Nat.Coprime l2 m := coprime_prime_of_lt hl2p hm hml2
      have cl2l1 : Nat.Coprime l2 l1 := coprime_prime_of_lt hl2p hl1p.pos hl1l2
      have cl2sub : Nat.Coprime l2 (l2 - (L + 1)) :=
        coprime_prime_of_lt hl2p (by omega) (by omega)
      obtain ⟨k1, hk1a, hk1b⟩ := Nat.chineseRemainder cl1Q.symm b (L + 1)
      have cQl1l2 : Nat.Coprime (Q * l1) l2 := (cl2Q.mul_right cl2l1).symm
      obtain ⟨b', hb'1, hb'2⟩ := Nat.chineseRemainder cQl1l2 k1 (l2 - (L + 1))
      have hb'Q : Nat.Coprime b' Q :=
        coprime_of_modEq ((hb'1.of_dvd ⟨l1, rfl⟩).trans hk1a) hbQ
      have hb'l1 : Nat.Coprime b' l1 :=
        coprime_of_modEq ((hb'1.of_dvd ⟨Q, mul_comm Q l1⟩).trans hk1b) cl1L.symm
      have hb'l2 : Nat.Coprime b' l2 := coprime_of_modEq hb'2 cl2sub.symm
      refine ⟨Q * l1 * l2, b', Nat.mul_pos (Nat.mul_pos hQ0 hl1p.pos) hl2p.pos, ?_, (hb'Q.mul_right hb'l1).mul_right hb'l2, ?_⟩
      · exact ((hQm.symm.mul_right cl1m.symm).mul_right cl2m.symm).symm
      · intro p hp hpb
        have hpQ : p ≡ b [MOD Q] :=
          (((hpb.of_dvd ⟨l1 * l2, by ring⟩).trans (hb'1.of_dvd ⟨l1, rfl⟩)).trans hk1a)
        have hpl1 : p ≡ L + 1 [MOD l1] :=
          (((hpb.of_dvd ⟨Q * l2, by ring⟩).trans
            (hb'1.of_dvd ⟨Q, mul_comm Q l1⟩)).trans hk1b)
        have hpl2 : p ≡ l2 - (L + 1) [MOD l2] :=
          ((hpb.of_dvd ⟨Q * l1, by ring⟩).trans hb'2)
        have hd1 : l1 ∣ p - (L + 1) :=
          (Nat.modEq_iff_dvd' (by omega)).mp hpl1.symm
        have hd2 : l2 ∣ p + (L + 1) := by
          have h5 : p + (L + 1) ≡ l2 - (L + 1) + (L + 1) [MOD l2] := hpl2.add_right (L + 1)
          rw [show l2 - (L + 1) + (L + 1) = l2 from by omega] at h5
          exact Nat.modEq_zero_iff_dvd.mp (h5.trans (Nat.modEq_zero_iff_dvd.mpr dvd_rfl))
        intro j hj hjL
        rcases Nat.lt_or_ge j (L + 1) with hcase | hcase
        · exact hmain p (by omega) hpQ j hj (by omega)
        · have hjeq : j = L + 1 := by omega
          subst hjeq
          exact ⟨dvd_totient_of_prime_dvd hl1p hl1m hd1,
            dvd_totient_of_prime_dvd hl2p hl2m hd2⟩
