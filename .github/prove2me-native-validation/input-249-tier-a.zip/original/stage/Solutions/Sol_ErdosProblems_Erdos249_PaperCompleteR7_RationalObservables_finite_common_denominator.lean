import Definitions.Def_ErdosProblems_Erdos249_ResidueClassTotientSeries
import Definitions.Def_ErdosProblems_Erdos249_PaperCompleteR7_RationalObservableClassification
import Mathlib
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.NumberTheory.LSeries.PrimesInAP
import Mathlib.Tactic

/-!
# Rational-valued dyadic observables: the missing paper assembly

Targets: short-note `res:residueseries`; long-record
`thm:dyadic-classification`, and the sharpness clause of
`thm:residueobservable`.

`positiveValue` subtracts the n=0 contribution explicitly.  The integer
observable in the imported library includes n=0 and assumes f(0)=0;
confusing these conventions would give the wrong rational-value formula.

The proof clears finitely many rational denominators, invokes the existing
integer-observable theorem, and evaluates the eventually constant tail.
No new CRT, Dirichlet, or isolated-pulse hypothesis is assumed.
Build status: NOT RUN; all declarations below are complete proof candidates.
-/

namespace ErdosProblems.Erdos249.PaperCompleteR7.RationalObservables
open scoped BigOperators
end ErdosProblems.Erdos249.PaperCompleteR7.RationalObservables

open scoped BigOperators
open ErdosProblems in
open ErdosProblems.Erdos249 in
open ErdosProblems.Erdos249.PaperCompleteR7 in
open ErdosProblems.Erdos249.PaperCompleteR7.RationalObservables in
theorem solution (f : ℕ → ℚ) (m : ℕ) :
    ∃ D : ℕ, 0 < D ∧ ∀ i, i < m → ∃ z : ℤ,
      (D : ℝ) * (f i : ℝ) = (z : ℝ) := by
  induction m with
  | zero =>
      exact ⟨1, by omega, fun i hi => by omega⟩
  | succ m ih =>
      obtain ⟨D, hD, hclear⟩ := ih
      let d := (f m).den
      have hd : 0 < d := (f m).den_pos
      have hdR : (d : ℝ) ≠ 0 := by exact_mod_cast hd.ne'
      have hnum : (d : ℝ) * (f m : ℝ) = ((f m).num : ℝ) := by
        rw [Rat.cast_def]
        change (d : ℝ) * (((f m).num : ℝ) / (d : ℝ)) = ((f m).num : ℝ)
        field_simp [hdR]
      refine ⟨D * d, Nat.mul_pos hD hd, ?_⟩
      intro i hi
      by_cases him : i = m
      · subst i
        refine ⟨(D : ℤ) * (f m).num, ?_⟩
        push_cast
        rw [mul_assoc, hnum]
      · have hil : i < m := by omega
        obtain ⟨z, hz⟩ := hclear i hil
        refine ⟨(d : ℤ) * z, ?_⟩
        push_cast
        calc
          (D : ℝ) * (d : ℝ) * (f i : ℝ)
              = (d : ℝ) * ((D : ℝ) * (f i : ℝ)) := by ring
          _ = (d : ℝ) * (z : ℝ) := by rw [hz]
