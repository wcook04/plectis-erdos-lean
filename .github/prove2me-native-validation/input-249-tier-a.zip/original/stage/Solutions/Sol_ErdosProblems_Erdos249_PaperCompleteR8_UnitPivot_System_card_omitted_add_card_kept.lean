import Definitions.Def_ErdosProblems_Erdos249_PaperCompleteR8_UnitPivotBasis
import Mathlib
import Mathlib.LinearAlgebra.Basis.Basic
import Mathlib.LinearAlgebra.Finsupp.Defs
import Mathlib.LinearAlgebra.Finsupp.LinearCombination

namespace ErdosProblems.Erdos249.PaperCompleteR8.UnitPivot.System
set_option autoImplicit false
variable {R I J M : Type*} [CommRing R] [AddCommGroup M] [Module R M]
variable (D : System R I J M)
end ErdosProblems.Erdos249.PaperCompleteR8.UnitPivot.System

open ErdosProblems
open ErdosProblems.Erdos249
open ErdosProblems.Erdos249.PaperCompleteR8
open ErdosProblems.Erdos249.PaperCompleteR8.UnitPivot
open ErdosProblems.Erdos249.PaperCompleteR8.UnitPivot.System
set_option autoImplicit false
variable {R I J M : Type*} [CommRing R] [AddCommGroup M] [Module R M]
variable (D : System R I J M)
open ErdosProblems in
open ErdosProblems.Erdos249 in
open ErdosProblems.Erdos249.PaperCompleteR8 in
open ErdosProblems.Erdos249.PaperCompleteR8.UnitPivot in
open ErdosProblems.Erdos249.PaperCompleteR8.UnitPivot.System in
theorem solution [Nontrivial R] [Fintype I] [Fintype J] :
    Fintype.card D.Omitted + Fintype.card J = Fintype.card I := by
  classical
  -- Mathlib/Data/Fintype/Card.lean and Mathlib/Data/Fintype/Sum.lean.
  have h := Fintype.card_congr D.indexSplit
  rw [Fintype.card_sum] at h
  exact (Nat.add_comm _ _).trans h
