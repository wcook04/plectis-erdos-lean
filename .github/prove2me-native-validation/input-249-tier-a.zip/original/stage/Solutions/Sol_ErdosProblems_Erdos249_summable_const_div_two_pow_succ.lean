import Definitions.Def_ErdosProblems_Erdos249_ResidueClassTotientSeries
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.NumberTheory.LSeries.PrimesInAP
import Mathlib.Tactic

namespace ErdosProblems.Erdos249
open Finset
end ErdosProblems.Erdos249

open ErdosProblems
open ErdosProblems.Erdos249
open Finset
open ErdosProblems in
open ErdosProblems.Erdos249 in
theorem solution (c : ℝ) : Summable fun j : ℕ => c / 2 ^ (j + 1) := by
  refine (summable_geometric_two' c).congr fun j => ?_
  rw [pow_succ]
  ring
