import Definitions.Def_ErdosProblems_Erdos249_ResidueClassTotientSeries
import Theorems.Thm_ErdosProblems_Erdos249_isolated_pulse_separation
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.NumberTheory.LSeries.PrimesInAP
import Mathlib.Tactic

namespace ErdosProblems.Erdos249
open Finset
variable {a : ℕ → ℤ} {C : ℝ}
end ErdosProblems.Erdos249

open ErdosProblems
open ErdosProblems.Erdos249
open Finset
variable {a : ℕ → ℤ} {C : ℝ}
open ErdosProblems in
open ErdosProblems.Erdos249 in
theorem solution (hC : ∀ n, |(a n : ℝ)| ≤ C)
    (hpulse : ∀ L : ℕ, ∃ p : ℕ, L + 1 < p ∧ a p ≠ 0 ∧
      ∀ j, 0 < j → j ≤ L → a (p - j) = 0 ∧ a (p + j) = 0) :
    Irrational (dyadicValue a) := by
  rintro ⟨x, hx⟩
  have hC0 : (0 : ℝ) ≤ C := le_trans (abs_nonneg _) (hC 0)
  have hqpos : 0 < x.den := x.pos
  have hq1 : 1 ≤ x.den := hqpos
  have hqR : (1 : ℝ) ≤ (x.den : ℝ) := by exact_mod_cast hq1
  obtain ⟨L, hL⟩ := pow_unbounded_of_one_lt (2 * (x.den : ℝ) * C) (by norm_num : (1 : ℝ) < 2)
  obtain ⟨p, hp, hane, hzero⟩ := hpulse L
  have hNc : p - L - 1 + 1 + L = p := by omega
  have hcentre : a (p - L - 1 + 1 + L) = a p := by rw [hNc]
  have hwin : ∀ i, i ≤ 2 * L → i ≠ L → a (p - L - 1 + 1 + i) = 0 := by
    intro i hi hiL
    rcases Nat.lt_or_ge i L with h | h
    · have hidx : p - L - 1 + 1 + i = p - (L - i) := by omega
      rw [hidx]
      exact (hzero (L - i) (by omega) (by omega)).1
    · have hidx : p - L - 1 + 1 + i = p + (i - L) := by omega
      rw [hidx]
      exact (hzero (i - L) (by omega) (by omega)).2
  have key := isolated_pulse_separation hC hq1 hL hcentre hane hwin x.num
  have hdR : (x.den : ℝ) ≠ 0 := by positivity
  have hvanish : (x.den : ℝ) * dyadicValue a - ((x.num : ℤ) : ℝ) = 0 := by
    rw [← hx, Rat.cast_def]
    field_simp
    ring
  rw [hvanish, abs_zero] at key
  have hLpos : (0 : ℝ) < (2 : ℝ) ^ L := by positivity
  have hCsmall : C / 2 ^ L < 1 / 2 := by
    rw [div_lt_iff₀ hLpos]
    nlinarith
  have ht1 : (1 : ℝ) ≤ |((a p : ℤ) : ℝ)| := by
    rw [← Int.cast_abs]
    exact_mod_cast Int.one_le_abs hane
  have hpos : 0 < (x.den : ℝ) * (|((a p : ℤ) : ℝ)| - C / 2 ^ L) / 2 ^ (p - L - 1 + 1 + L) := by
    apply div_pos
    · apply mul_pos
      · linarith
      · linarith
    · positivity
  linarith
