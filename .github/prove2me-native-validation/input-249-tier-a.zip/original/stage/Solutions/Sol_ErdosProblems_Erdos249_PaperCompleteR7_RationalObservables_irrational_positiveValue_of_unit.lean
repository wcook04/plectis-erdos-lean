import Definitions.Def_ErdosProblems_Erdos249_ResidueClassTotientSeries
import Definitions.Def_ErdosProblems_Erdos249_PaperCompleteR7_RationalObservableClassification
import Theorems.Thm_ErdosProblems_Erdos249_PaperCompleteR7_RationalObservables_centred_integer_value_eq
import Theorems.Thm_ErdosProblems_Erdos249_PaperCompleteR7_RationalObservables_finite_common_denominator
import Theorems.Thm_ErdosProblems_Erdos249_irrational_totientObservable
import Mathlib
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.NumberTheory.LSeries.PrimesInAP
import Mathlib.Tactic

/-!
# Rational-valued dyadic observables: the missing paper assembly

Targets: short-note `res:residueseries`; long-record
`thm:dyadic-classification`, and the sharpness clause of
`thm:residueobservable`.

`positiveValue` subtracts the n=0 contribution explicitly.  The integer
observable in the imported library includes n=0 and assumes f(0)=0;
confusing these conventions would give the wrong rational-value formula.

The proof clears finitely many rational denominators, invokes the existing
integer-observable theorem, and evaluates the eventually constant tail.
No new CRT, Dirichlet, or isolated-pulse hypothesis is assumed.
Build status: NOT RUN; all declarations below are complete proof candidates.
-/

namespace ErdosProblems.Erdos249.PaperCompleteR7.RationalObservables
open scoped BigOperators
end ErdosProblems.Erdos249.PaperCompleteR7.RationalObservables

open scoped BigOperators
open ErdosProblems in
open ErdosProblems.Erdos249 in
open ErdosProblems.Erdos249.PaperCompleteR7 in
open ErdosProblems.Erdos249.PaperCompleteR7.RationalObservables in
theorem solution
    {m : ℕ} (hm : 2 ≤ m) (f : ℕ → ℚ)
    {r : ℕ} (hr : r < m) (hcop : Nat.Coprime (r + 1) m)
    (hfr : f r ≠ f 0) : Irrational (positiveValue f m) := by
  classical
  obtain ⟨D, hD, hclear⟩ := finite_common_denominator (fun i => f i - f 0) m
  let g : ℕ → ℤ := fun i =>
    if hi : i < m then Classical.choose (hclear i hi) else 0
  have hg (i : ℕ) (hi : i < m) :
      (g i : ℝ) = (D : ℝ) * ((f i : ℝ) - (f 0 : ℝ)) := by
    dsimp [g]
    rw [dif_pos hi]
    simpa only [Rat.cast_sub] using (Classical.choose_spec (hclear i hi)).symm
  have hg0 : g 0 = 0 := by
    apply Int.cast_injective (α := ℝ)
    simpa only [sub_self, mul_zero, Int.cast_zero] using hg 0 (by omega)
  have hgr : g r ≠ 0 := by
    intro hzero
    have hz := hg r hr
    rw [hzero, Int.cast_zero] at hz
    have hDR : (D : ℝ) ≠ 0 := by exact_mod_cast hD.ne'
    have heq : (f r : ℝ) = (f 0 : ℝ) := by
      exact sub_eq_zero.mp ((mul_eq_zero.mp hz.symm).resolve_left hDR)
    exact hfr (Rat.cast_injective heq)
  have hirr := irrational_totientObservable hm g hg0 hr hcop hgr
  have hvalue := centred_integer_value_eq f (by omega : 0 < m) g hg
  intro hrational
  obtain ⟨q, hq⟩ := hrational
  apply hirr
  refine ⟨(D : ℚ) * (q - f 0), ?_⟩
  rw [hvalue, ← hq]
  push_cast <;> rfl
