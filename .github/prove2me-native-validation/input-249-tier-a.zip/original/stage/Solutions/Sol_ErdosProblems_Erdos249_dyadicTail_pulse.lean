import Definitions.Def_ErdosProblems_Erdos249_ResidueClassTotientSeries
import Theorems.Thm_ErdosProblems_Erdos249_summable_const_div_two_pow_succ
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.NumberTheory.LSeries.PrimesInAP
import Mathlib.Tactic

namespace ErdosProblems.Erdos249
open Finset
variable {a : ℕ → ℤ} {C : ℝ}
theorem summable_dyadicTailTerm (hC : ∀ n, |(a n : ℝ)| ≤ C) (N : ℕ) :
    Summable fun j : ℕ => (a (N + 1 + j) : ℝ) / 2 ^ (j + 1) := by
  refine Summable.of_norm_bounded (g := fun j : ℕ => C / 2 ^ (j + 1))
    (summable_const_div_two_pow_succ C) ?_
  intro j
  dsimp only
  have h2 : (0 : ℝ) < 2 ^ (j + 1) := by positivity
  rw [Real.norm_eq_abs, abs_div, abs_of_pos h2]
  gcongr
  exact hC _
end ErdosProblems.Erdos249

open ErdosProblems
open ErdosProblems.Erdos249
open Finset
variable {a : ℕ → ℤ} {C : ℝ}
open ErdosProblems in
open ErdosProblems.Erdos249 in
theorem solution (hC : ∀ n, |(a n : ℝ)| ≤ C) {N L : ℕ} {t : ℤ}
    (hcentre : a (N + 1 + L) = t)
    (hzero : ∀ i, i ≤ 2 * L → i ≠ L → a (N + 1 + i) = 0) :
    dyadicTail a N
      = (t : ℝ) / 2 ^ (L + 1) + dyadicTail a (N + 2 * L + 1) / 2 ^ (2 * L + 1) := by
  have hs := summable_dyadicTailTerm hC N
  have h := Summable.sum_add_tsum_nat_add
    (f := fun j : ℕ => (a (N + 1 + j) : ℝ) / 2 ^ (j + 1)) (2 * L + 1) hs
  have hfin : (∑ i ∈ Finset.range (2 * L + 1), (a (N + 1 + i) : ℝ) / 2 ^ (i + 1))
      = (t : ℝ) / 2 ^ (L + 1) := by
    rw [Finset.sum_eq_single L]
    · rw [hcentre]
    · intro i hi hiL
      have hi' : i < 2 * L + 1 := Finset.mem_range.mp hi
      rw [hzero i (by omega) hiL]
      simp
    · intro hcon
      exact absurd (Finset.mem_range.mpr (by omega)) hcon
  have hkey : ∀ s : ℕ, (a (N + 1 + (s + (2 * L + 1))) : ℝ) / 2 ^ (s + (2 * L + 1) + 1)
      = (1 / 2 ^ (2 * L + 1) : ℝ) * ((a (N + 2 * L + 1 + 1 + s) : ℝ) / 2 ^ (s + 1)) := by
    intro s
    have hidx : N + 1 + (s + (2 * L + 1)) = N + 2 * L + 1 + 1 + s := by omega
    have hpow : (2 : ℝ) ^ (s + (2 * L + 1) + 1) = 2 ^ (2 * L + 1) * 2 ^ (s + 1) := by
      rw [← pow_add]; congr 1; omega
    have h2 : (2 : ℝ) ^ (2 * L + 1) ≠ 0 := by positivity
    rw [hidx, hpow]
    field_simp
  have htail : (∑' s : ℕ, (a (N + 1 + (s + (2 * L + 1))) : ℝ) / 2 ^ (s + (2 * L + 1) + 1))
      = dyadicTail a (N + 2 * L + 1) / 2 ^ (2 * L + 1) :=
    calc (∑' s : ℕ, (a (N + 1 + (s + (2 * L + 1))) : ℝ) / 2 ^ (s + (2 * L + 1) + 1))
        = ∑' s : ℕ, (1 / 2 ^ (2 * L + 1) : ℝ) * ((a (N + 2 * L + 1 + 1 + s) : ℝ) / 2 ^ (s + 1)) :=
          tsum_congr hkey
      _ = (1 / 2 ^ (2 * L + 1) : ℝ) * dyadicTail a (N + 2 * L + 1) := tsum_mul_left
      _ = dyadicTail a (N + 2 * L + 1) / 2 ^ (2 * L + 1) := by ring
  calc dyadicTail a N = ∑' j : ℕ, (a (N + 1 + j) : ℝ) / 2 ^ (j + 1) := rfl
    _ = (∑ i ∈ Finset.range (2 * L + 1), (a (N + 1 + i) : ℝ) / 2 ^ (i + 1))
          + ∑' s : ℕ, (a (N + 1 + (s + (2 * L + 1))) : ℝ) / 2 ^ (s + (2 * L + 1) + 1) := h.symm
    _ = (t : ℝ) / 2 ^ (L + 1) + dyadicTail a (N + 2 * L + 1) / 2 ^ (2 * L + 1) := by
          rw [hfin, htail]
