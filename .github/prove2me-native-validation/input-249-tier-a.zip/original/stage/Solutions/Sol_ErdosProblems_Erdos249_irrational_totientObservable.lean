import Definitions.Def_ErdosProblems_Erdos249_ResidueClassTotientSeries
import Theorems.Thm_ErdosProblems_Erdos249_irrational_dyadicValue_of_pulses
import Theorems.Thm_ErdosProblems_Erdos249_two_sided_prime_isolation
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.NumberTheory.LSeries.PrimesInAP
import Mathlib.Tactic

namespace ErdosProblems.Erdos249
open Finset
end ErdosProblems.Erdos249

open ErdosProblems
open ErdosProblems.Erdos249
open Finset
open ErdosProblems in
open ErdosProblems.Erdos249 in
theorem solution {m : ℕ} (hm : 2 ≤ m) (f : ℕ → ℤ) (hf0 : f 0 = 0)
    {r : ℕ} (hr : r < m) (hcop : Nat.Coprime (r + 1) m) (hfr : f r ≠ 0) :
    Irrational (totientObservableValue f m) := by
  have hval : totientObservableValue f m = dyadicValue (totientObservableCoeff f m) := rfl
  have hC : ∀ n : ℕ, |((totientObservableCoeff f m n : ℤ) : ℝ)|
      ≤ ((∑ i ∈ Finset.range m, |f i| : ℤ) : ℝ) := by
    intro n
    have hmem : Nat.totient n % m ∈ Finset.range m :=
      Finset.mem_range.mpr (Nat.mod_lt _ (by omega))
    have hz : |f (Nat.totient n % m)| ≤ ∑ i ∈ Finset.range m, |f i| :=
      Finset.single_le_sum (f := fun i => |f i|) (fun i _ => abs_nonneg _) hmem
    calc |((totientObservableCoeff f m n : ℤ) : ℝ)|
        = ((|f (Nat.totient n % m)| : ℤ) : ℝ) := by
          simp only [totientObservableCoeff, Int.cast_abs]
      _ ≤ ((∑ i ∈ Finset.range m, |f i| : ℤ) : ℝ) := by exact_mod_cast hz
  have hpulse : ∀ L : ℕ, ∃ p : ℕ, L + 1 < p ∧ totientObservableCoeff f m p ≠ 0 ∧
      ∀ j, 0 < j → j ≤ L → totientObservableCoeff f m (p - j) = 0
        ∧ totientObservableCoeff f m (p + j) = 0 := by
    intro L
    obtain ⟨p, -, hpL, -, hres, hnb⟩ := two_sided_prime_isolation hm L 0 r hcop
    refine ⟨p, hpL, ?_, ?_⟩
    · have hmod : Nat.totient p % m = r % m := hres
      simp only [totientObservableCoeff, hmod, Nat.mod_eq_of_lt hr]
      exact hfr
    · intro j hj hjL
      obtain ⟨hd1, hd2⟩ := hnb j hj hjL
      obtain ⟨c1, hc1⟩ := hd1
      obtain ⟨c2, hc2⟩ := hd2
      simp only [totientObservableCoeff]
      exact ⟨by rw [hc1, Nat.mul_mod_right, hf0], by rw [hc2, Nat.mul_mod_right, hf0]⟩
  rw [hval]
  exact irrational_dyadicValue_of_pulses hC hpulse
