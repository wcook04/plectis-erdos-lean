import Definitions.Def_ErdosProblems_Erdos249_ResidueClassTotientSeries
import Definitions.Def_ErdosProblems_Erdos249_PaperCompleteR7_RationalObservableClassification
import Theorems.Thm_ErdosProblems_Erdos249_summable_const_div_two_pow
import Mathlib
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.NumberTheory.LSeries.PrimesInAP
import Mathlib.Tactic

/-!
# Rational-valued dyadic observables: the missing paper assembly

Targets: short-note `res:residueseries`; long-record
`thm:dyadic-classification`, and the sharpness clause of
`thm:residueobservable`.

`positiveValue` subtracts the n=0 contribution explicitly.  The integer
observable in the imported library includes n=0 and assumes f(0)=0;
confusing these conventions would give the wrong rational-value formula.

The proof clears finitely many rational denominators, invokes the existing
integer-observable theorem, and evaluates the eventually constant tail.
No new CRT, Dirichlet, or isolated-pulse hypothesis is assumed.
Build status: NOT RUN; all declarations below are complete proof candidates.
-/

namespace ErdosProblems.Erdos249.PaperCompleteR7.RationalObservables
open scoped BigOperators





/-- Every residue observable is bounded, hence its full binary series converges. -/
theorem summable_terms (f : ℕ → ℚ) {m : ℕ} (hm : 0 < m) :
    Summable (fun n : ℕ => (f (Nat.totient n % m) : ℝ) / 2 ^ n) := by
  let C : ℝ := ∑ i ∈ Finset.range m, |(f i : ℝ)|
  have hbound (n : ℕ) : |(f (Nat.totient n % m) : ℝ)| ≤ C := by
    exact Finset.single_le_sum (fun i _ => abs_nonneg (f i : ℝ))
      (Finset.mem_range.mpr (Nat.mod_lt _ hm))
  apply Summable.of_norm_bounded
    (g := fun n : ℕ => C / 2 ^ n) (summable_const_div_two_pow C)
  intro n
  rw [Real.norm_eq_abs, abs_div, abs_of_pos (by positivity : (0 : ℝ) < 2 ^ n)]
  exact div_le_div_of_nonneg_right (hbound n) (by positivity)
end ErdosProblems.Erdos249.PaperCompleteR7.RationalObservables

open scoped BigOperators
open ErdosProblems in
open ErdosProblems.Erdos249 in
open ErdosProblems.Erdos249.PaperCompleteR7 in
open ErdosProblems.Erdos249.PaperCompleteR7.RationalObservables in
theorem solution
    (f : ℕ → ℚ) {m D : ℕ} (hm : 0 < m) (g : ℕ → ℤ)
    (hg : ∀ r, r < m → (g r : ℝ) = (D : ℝ) * ((f r : ℝ) - (f 0 : ℝ))) :
    totientObservableValue g m =
      (D : ℝ) * (positiveValue f m - (f 0 : ℝ)) := by
  have hs := summable_terms f hm
  have hc := summable_const_div_two_pow (f 0 : ℝ)
  have hcval : (∑' n : ℕ, (f 0 : ℝ) / 2 ^ n) = 2 * (f 0 : ℝ) := by
    calc
      (∑' n : ℕ, (f 0 : ℝ) / 2 ^ n)
          = ∑' n : ℕ, (2 * (f 0 : ℝ)) / 2 / 2 ^ n :=
              tsum_congr (fun n => by ring)
      _ = 2 * (f 0 : ℝ) := tsum_geometric_two' _
  unfold totientObservableValue positiveValue
  calc
    (∑' n : ℕ, (g (Nat.totient n % m) : ℝ) / 2 ^ n)
        = ∑' n : ℕ, (D : ℝ) *
            ((f (Nat.totient n % m) : ℝ) / 2 ^ n - (f 0 : ℝ) / 2 ^ n) := by
              apply tsum_congr
              intro n
              rw [hg _ (Nat.mod_lt _ hm)]
              ring
    _ = (D : ℝ) * (∑' n : ℕ,
          ((f (Nat.totient n % m) : ℝ) / 2 ^ n - (f 0 : ℝ) / 2 ^ n)) :=
            tsum_mul_left
    _ = (D : ℝ) * ((∑' n : ℕ,
          (f (Nat.totient n % m) : ℝ) / 2 ^ n) - 2 * (f 0 : ℝ)) := by
            rw [hs.tsum_sub hc, hcval]
    _ = _ := by ring
