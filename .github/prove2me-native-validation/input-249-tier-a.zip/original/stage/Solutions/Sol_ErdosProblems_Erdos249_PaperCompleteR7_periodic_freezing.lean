import Definitions.Def_Erdos249257_TotientKernelIndex
import Definitions.Def_Erdos249257_TotientKernelConditional
import Definitions.Def_Erdos249257_TotientMahlerDefect_v2
import Definitions.Def_Erdos249257_AllBaseTotientKernel_v2
import Definitions.Def_ErdosProblems_Erdos249_ResidueClassTotientSeries
import Theorems.Thm_ErdosProblems_Erdos249_PeriodicTotientIndependence_periodic_add_mul
import Theorems.Thm_ErdosProblems_Erdos249_PaperCompleteR7_periodic_coefficients_zero_eventually
import Mathlib
import Mathlib.Algebra.Ring.GeomSum
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.Data.Fintype.BigOperators
import Mathlib.Data.Nat.ChineseRemainder
import Mathlib.Data.Nat.Totient
import Mathlib.LinearAlgebra.Dimension.Constructions
import Mathlib.LinearAlgebra.Matrix.Determinant.Basic
import Mathlib.NumberTheory.LSeries.PrimesInAP
import Mathlib.NumberTheory.PrimesCongruentOne
import Mathlib.Tactic

namespace ErdosProblems.Erdos249.PaperCompleteR7
end ErdosProblems.Erdos249.PaperCompleteR7

/-!
# Paper-complete interfaces: eventual periodic coefficients and cofinal pulses

Targets: short-note `cor:periodic-freezing` and `lem:bounded-pulse`.
This file extends the compiled r5 periodic theorem, not the uncompiled r6 helper.
Every theorem has a proof term and no extra mathematical assumption.
Build status for this return: source-reviewed, NOT RUN (no Lean executable).
-/

namespace ErdosProblems.Erdos249.PaperCompleteR7
open scoped BigOperators
end ErdosProblems.Erdos249.PaperCompleteR7

open scoped BigOperators
open ErdosProblems in
open ErdosProblems.Erdos249 in
open ErdosProblems.Erdos249.PaperCompleteR7 in
theorem solution
    {ι : Type*} [Fintype ι] [DecidableEq ι]
    (a b : ι → ℕ) (ha : ∀ i, 0 < a i)
    (hcross : ∀ i j, i ≠ j → a i * b j ≠ a j * b i)
    (w : ι → ℕ → ℚ)
    (hperiodic : ∀ i, ∃ q : ℕ, 0 < q ∧ ∀ n, w i (n + q) = w i n)
    (hrel : ∃ N₀, ∀ n, N₀ ≤ n →
      ∑ i, w i n * (Nat.totient (a i * n + b i) : ℚ) = 0) :
    ∀ i n, w i n = 0 := by
  classical
  choose q hq hper using hperiodic
  let Q := ∏ i, q i
  have hQ : 0 < Q := by
    dsimp [Q]
    exact Finset.prod_pos (fun i _ => hq i)
  have hdiv (i : ι) : q i ∣ Q := by
    exact Finset.dvd_prod_of_mem q (Finset.mem_univ i)
  have hperQ : ∀ i n, w i (n + Q) = w i n := by
    intro i n
    obtain ⟨t, ht⟩ := hdiv i
    rw [ht]
    exact PeriodicTotientIndependence.periodic_add_mul (w i) (q i) (hper i) n t
  obtain ⟨N₀, hN₀⟩ := hrel
  exact periodic_coefficients_zero_eventually a b ha hcross w Q hQ hperQ N₀ hN₀
