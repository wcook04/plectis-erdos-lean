import Definitions.Def_ErdosProblems_Erdos249_PaperCompleteR8_UnitPivotBasis_v2
import Mathlib
import Mathlib.LinearAlgebra.Basis.Basic
import Mathlib.LinearAlgebra.Finsupp.Defs
import Mathlib.LinearAlgebra.Finsupp.LinearCombination

namespace ErdosProblems.Erdos249.PaperCompleteR8.UnitPivot.System
set_option autoImplicit false
open scoped BigOperators
variable {R I J M : Type*} [CommRing R] [AddCommGroup M] [Module R M]
variable (D : System R I J M)
end ErdosProblems.Erdos249.PaperCompleteR8.UnitPivot.System

open ErdosProblems
open ErdosProblems.Erdos249
open ErdosProblems.Erdos249.PaperCompleteR8
open ErdosProblems.Erdos249.PaperCompleteR8.UnitPivot
open ErdosProblems.Erdos249.PaperCompleteR8.UnitPivot.System
set_option autoImplicit false
open scoped BigOperators
variable {R I J M : Type*} [CommRing R] [AddCommGroup M] [Module R M]
variable (D : System R I J M)
open ErdosProblems in
open ErdosProblems.Erdos249 in
open ErdosProblems.Erdos249.PaperCompleteR8 in
open ErdosProblems.Erdos249.PaperCompleteR8.UnitPivot in
open ErdosProblems.Erdos249.PaperCompleteR8.UnitPivot.System in
theorem solution (i : I) (j : J) (a : R)
    (h : D.value i = a • D.value (D.keep j)) :
    D.row i = Finsupp.single i 1 - Finsupp.single (D.keep j) a := by
  have hc : D.coeff i = Finsupp.single j a := by
    apply D.independent
    rw [D.reconstruct, Finsupp.linearCombination_single]
    exact h
  rw [row, hc, D.includeKept_single]
