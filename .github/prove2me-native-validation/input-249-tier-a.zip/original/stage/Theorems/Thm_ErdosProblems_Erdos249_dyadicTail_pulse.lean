import Definitions.Def_ErdosProblems_Erdos249_ResidueClassTotientSeries
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.NumberTheory.LSeries.PrimesInAP
import Mathlib.Tactic

open ErdosProblems
open ErdosProblems.Erdos249
open Finset
variable {a : ℕ → ℤ} {C : ℝ}

open ErdosProblems.Erdos249

theorem ErdosProblems.Erdos249.dyadicTail_pulse (hC : ∀ n, |(a n : ℝ)| ≤ C) {N L : ℕ} {t : ℤ}
    (hcentre : a (N + 1 + L) = t)
    (hzero : ∀ i, i ≤ 2 * L → i ≠ L → a (N + 1 + i) = 0) :
    dyadicTail a N
      = (t : ℝ) / 2 ^ (L + 1) + dyadicTail a (N + 2 * L + 1) / 2 ^ (2 * L + 1) := by sorry
