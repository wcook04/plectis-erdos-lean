import Definitions.Def_ErdosProblems_Erdos249_PaperCompleteR8_UnitPivotBasis
import Mathlib
import Mathlib.LinearAlgebra.Basis.Basic
import Mathlib.LinearAlgebra.Finsupp.Defs
import Mathlib.LinearAlgebra.Finsupp.LinearCombination

open ErdosProblems
open ErdosProblems.Erdos249
open ErdosProblems.Erdos249.PaperCompleteR8
open ErdosProblems.Erdos249.PaperCompleteR8.UnitPivot
open ErdosProblems.Erdos249.PaperCompleteR8.UnitPivot.System
set_option autoImplicit false
open scoped BigOperators
variable {R I J M : Type*} [CommRing R] [AddCommGroup M] [Module R M]
variable (D : System R I J M)

open ErdosProblems.Erdos249.PaperCompleteR8.UnitPivot.System

theorem ErdosProblems.Erdos249.PaperCompleteR8.UnitPivot.System.relationBasis_apply (o : D.Omitted) :
    (D.relationBasis o : I →₀ R) = D.row o.val := by sorry
