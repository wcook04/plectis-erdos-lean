import Definitions.Def_ErdosProblems_Erdos249_ResidueClassTotientSeries
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.NumberTheory.LSeries.PrimesInAP
import Mathlib.Tactic

open ErdosProblems
open ErdosProblems.Erdos249
open Finset
variable {a : ℕ → ℤ} {C : ℝ}

open ErdosProblems.Erdos249

theorem ErdosProblems.Erdos249.abs_dyadicTail_le (hC : ∀ n, |(a n : ℝ)| ≤ C) (N : ℕ) : |dyadicTail a N| ≤ C := by sorry
