import Definitions.Def_ErdosProblems_Erdos249_ResidueClassTotientSeries
import Definitions.Def_ErdosProblems_Erdos249_PaperCompleteR7_RationalObservableClassification
import Mathlib
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.NumberTheory.LSeries.PrimesInAP
import Mathlib.Tactic

/-!
# Rational-valued dyadic observables: the missing paper assembly

Targets: short-note `res:residueseries`; long-record
`thm:dyadic-classification`, and the sharpness clause of
`thm:residueobservable`.

`positiveValue` subtracts the n=0 contribution explicitly.  The integer
observable in the imported library includes n=0 and assumes f(0)=0;
confusing these conventions would give the wrong rational-value formula.

The proof clears finitely many rational denominators, invokes the existing
integer-observable theorem, and evaluates the eventually constant tail.
No new CRT, Dirichlet, or isolated-pulse hypothesis is assumed.
Build status: NOT RUN; all declarations below are complete proof candidates.
-/


open scoped BigOperators

open ErdosProblems.Erdos249.PaperCompleteR7.RationalObservables

theorem ErdosProblems.Erdos249.PaperCompleteR7.RationalObservables.centred_integer_value_eq
    (f : ℕ → ℚ) {m D : ℕ} (hm : 0 < m) (g : ℕ → ℤ)
    (hg : ∀ r, r < m → (g r : ℝ) = (D : ℝ) * ((f r : ℝ) - (f 0 : ℝ))) :
    totientObservableValue g m =
      (D : ℝ) * (positiveValue f m - (f 0 : ℝ)) := by sorry
