import Definitions.Def_ErdosProblems_Erdos249_ResidueClassTotientSeries
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.NumberTheory.LSeries.PrimesInAP
import Mathlib.Tactic

open ErdosProblems
open ErdosProblems.Erdos249
open Finset
variable {a : ℕ → ℤ} {C : ℝ}

open ErdosProblems.Erdos249

theorem ErdosProblems.Erdos249.summable_dyadicTerm (hC : ∀ n, |(a n : ℝ)| ≤ C) :
    Summable fun n : ℕ => (a n : ℝ) / 2 ^ n := by sorry
