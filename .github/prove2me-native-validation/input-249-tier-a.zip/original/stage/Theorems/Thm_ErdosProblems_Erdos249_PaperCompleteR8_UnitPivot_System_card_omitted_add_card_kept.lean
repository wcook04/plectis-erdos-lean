import Definitions.Def_ErdosProblems_Erdos249_PaperCompleteR8_UnitPivotBasis
import Mathlib
import Mathlib.LinearAlgebra.Basis.Basic
import Mathlib.LinearAlgebra.Finsupp.Defs
import Mathlib.LinearAlgebra.Finsupp.LinearCombination

open ErdosProblems
open ErdosProblems.Erdos249
open ErdosProblems.Erdos249.PaperCompleteR8
open ErdosProblems.Erdos249.PaperCompleteR8.UnitPivot
open ErdosProblems.Erdos249.PaperCompleteR8.UnitPivot.System
set_option autoImplicit false
variable {R I J M : Type*} [CommRing R] [AddCommGroup M] [Module R M]
variable (D : System R I J M)

open ErdosProblems.Erdos249.PaperCompleteR8.UnitPivot.System

theorem ErdosProblems.Erdos249.PaperCompleteR8.UnitPivot.System.card_omitted_add_card_kept [Nontrivial R] [Fintype I] [Fintype J] :
    Fintype.card D.Omitted + Fintype.card J = Fintype.card I := by sorry
