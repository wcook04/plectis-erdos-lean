import Definitions.Def_ErdosProblems_Erdos249_ResidueClassTotientSeries
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.NumberTheory.LSeries.PrimesInAP
import Mathlib.Tactic

open ErdosProblems
open ErdosProblems.Erdos249
open Finset

open ErdosProblems.Erdos249

theorem ErdosProblems.Erdos249.exists_isolation_modulus (m : ℕ) (hm : 0 < m) (L : ℕ) :
    ∃ Q b : ℕ, 0 < Q ∧ Nat.Coprime Q m ∧ Nat.Coprime b Q ∧
      ∀ p : ℕ, L < p → p ≡ b [MOD Q] →
        ∀ j, 0 < j → j ≤ L → m ∣ Nat.totient (p - j) ∧ m ∣ Nat.totient (p + j) := by sorry
