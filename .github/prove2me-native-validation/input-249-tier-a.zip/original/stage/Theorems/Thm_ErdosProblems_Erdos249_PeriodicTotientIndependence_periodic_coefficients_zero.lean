import Definitions.Def_Erdos249257_TotientKernelIndex
import Definitions.Def_Erdos249257_TotientKernelConditional
import Definitions.Def_Erdos249257_TotientMahlerDefect_v2
import Definitions.Def_Erdos249257_AllBaseTotientKernel_v2
import Mathlib
import Mathlib.Algebra.Ring.GeomSum
import Mathlib.Data.Fintype.BigOperators
import Mathlib.Data.Nat.ChineseRemainder
import Mathlib.Data.Nat.Totient
import Mathlib.LinearAlgebra.Dimension.Constructions
import Mathlib.LinearAlgebra.Matrix.Determinant.Basic
import Mathlib.NumberTheory.LSeries.PrimesInAP
import Mathlib.NumberTheory.PrimesCongruentOne

namespace ErdosProblems.Erdos249.PeriodicTotientIndependence
end ErdosProblems.Erdos249.PeriodicTotientIndependence

/-!
# Freezing periodic coefficients in affine totient relations

Lean-checked helper (r5). Type A retargeted the import from the packet's
`Erdos249257.AllBaseTotientKernel` to the live
`Erdos249257.AllBaseTotientKernel`. Focused `lean_fast_build`
completed as `cf_8309991b61ac4c53b3e3` exit 0. Periodic transport only;
does not complete `dim = #signatures` and does not decide `S`.

This uses the already proved all-affine independence theorem after an affine
change of variable. It requires NO new prime-isolation hypothesis. The positive
intercept condition of that theorem is met by using n + Q + Q*m, even when an
original intercept is zero.
-/


open scoped BigOperators

open ErdosProblems.Erdos249.PeriodicTotientIndependence

theorem ErdosProblems.Erdos249.PeriodicTotientIndependence.periodic_coefficients_zero
    {ι : Type*} [Fintype ι] [DecidableEq ι]
    (a b : ι → ℕ) (ha : ∀ i, 0 < a i)
    (hcross : ∀ i j, i ≠ j → a i * b j ≠ a j * b i)
    (Q : ℕ) (hQ : 0 < Q) (w : ι → ℕ → ℚ)
    (hw : ∀ i n, w i (n + Q) = w i n)
    (hrel : ∀ n, ∑ i, w i n * (Nat.totient (a i * n + b i) : ℚ) = 0) :
    ∀ i n, w i n = 0 := by sorry
