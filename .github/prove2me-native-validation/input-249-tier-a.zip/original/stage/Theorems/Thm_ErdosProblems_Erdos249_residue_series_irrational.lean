import Definitions.Def_ErdosProblems_Erdos249_ResidueClassTotientSeries
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.NumberTheory.LSeries.PrimesInAP
import Mathlib.Tactic

open ErdosProblems
open ErdosProblems.Erdos249
open Finset

open ErdosProblems.Erdos249

theorem ErdosProblems.Erdos249.residue_series_irrational {m : ℕ} (hm : 3 ≤ m) :
    Irrational (totientResidueValue m) := by sorry
