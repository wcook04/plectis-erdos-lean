import Definitions.Def_ErdosProblems_Erdos249_ResidueClassTotientSeries
import Mathlib
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.NumberTheory.LSeries.PrimesInAP
import Mathlib.Tactic

/-!
# Rational-valued dyadic observables: the missing paper assembly

Targets: short-note `res:residueseries`; long-record
`thm:dyadic-classification`, and the sharpness clause of
`thm:residueobservable`.

`positiveValue` subtracts the n=0 contribution explicitly.  The integer
observable in the imported library includes n=0 and assumes f(0)=0;
confusing these conventions would give the wrong rational-value formula.

The proof clears finitely many rational denominators, invokes the existing
integer-observable theorem, and evaluates the eventually constant tail.
No new CRT, Dirichlet, or isolated-pulse hypothesis is assumed.
Build status: NOT RUN; all declarations below are complete proof candidates.
-/

namespace ErdosProblems.Erdos249.PaperCompleteR7.RationalObservables

open scoped BigOperators

/-- Full n>=0 series minus its n=0 coefficient: the paper's n>=1 sum. -/
noncomputable def positiveValue (f : ℕ → ℚ) (m : ℕ) : ℝ :=
  (∑' n : ℕ, (f (Nat.totient n % m) : ℝ) / 2 ^ n) - (f 0 : ℝ)




































end ErdosProblems.Erdos249.PaperCompleteR7.RationalObservables
