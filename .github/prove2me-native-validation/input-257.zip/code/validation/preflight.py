#!/usr/bin/env python3
"""Read-only, fail-closed checks of a generated Prove2Me project package.

This checks provenance and byte identity. It never runs Lean and its receipt is
deliberately incompatible with the production validation receipt.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import tempfile
from pathlib import Path


class PreflightError(ValueError):
    pass


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def unique_object(pairs: list[tuple[str, object]]) -> dict:
    result = {}
    for key, value in pairs:
        if key in result:
            raise PreflightError(f"duplicate JSON key: {key}")
        result[key] = value
    return result


def load_json(path: Path) -> dict:
    value = json.loads(path.read_bytes(), object_pairs_hook=unique_object)
    if not isinstance(value, dict):
        raise PreflightError(f"{path}: expected JSON object")
    return value


def checked_file(path: Path, expected: str, label: str) -> bytes:
    if not isinstance(expected, str) or not re.fullmatch(r"[0-9a-f]{64}", expected):
        raise PreflightError(f"{label}: invalid SHA-256 pin")
    if not path.is_file():
        raise PreflightError(f"{label}: missing file: {path}")
    data = path.read_bytes()
    if sha(data) != expected:
        raise PreflightError(f"{label}: SHA-256 mismatch: {path}")
    return data


def package_file(root: Path, relative: str) -> Path:
    if (not isinstance(relative, str) or not relative
            or Path(relative).is_absolute() or ".." in Path(relative).parts):
        raise PreflightError(f"unsafe package path: {relative!r}")
    path = root / relative
    if path.is_symlink() or not path.resolve().is_relative_to(root.resolve()):
        raise PreflightError(f"package path escapes staging: {relative}")
    return path


def imports(data: bytes, label: str) -> list[str]:
    """Read the complete contiguous top import block, rejecting later imports."""
    lines = data.splitlines()
    found, past = [], False
    for line in lines:
        stripped = line.strip()
        if stripped.startswith(b"import "):
            if past or not line.startswith(b"import "):
                raise PreflightError(f"{label}: import outside top block")
            try:
                names = stripped[7:].decode("ascii").split()
            except UnicodeDecodeError as exc:
                raise PreflightError(f"{label}: non-ASCII import") from exc
            if not names:
                raise PreflightError(f"{label}: empty import")
            found.extend(names)
        elif stripped and found:
            past = True
    if not found or len(found) != len(set(found)):
        raise PreflightError(f"{label}: missing or duplicate imports")
    return found


def mask_comments(data: bytes, label: str) -> bytes:
    """Hide nested Lean comments without changing offsets or line numbers."""
    visible = bytearray(data)
    index = 0
    while index < len(data):
        if data.startswith(b"--", index):
            end = data.find(b"\n", index)
            if end < 0:
                end = len(data)
            visible[index:end] = b" " * (end - index)
            index = end
        elif data.startswith(b"/-", index):
            start, depth = index, 1
            index += 2
            while depth and index < len(data):
                if data.startswith(b"/-", index):
                    depth += 1
                    index += 2
                elif data.startswith(b"-/", index):
                    depth -= 1
                    index += 2
                else:
                    index += 1
            if depth:
                raise PreflightError(f"{label}: unterminated block comment")
            for offset in range(start, index):
                if visible[offset] not in (10, 13):
                    visible[offset] = 32
        else:
            index += 1
    return bytes(visible)


def checked_graph_absent_shim(module: str, source: bytes, sketch: bytes,
                              source_header: list[str]) -> str:
    """Authenticate only import-only or exact import/export compatibility shims.

    A graph-absent module cannot hide a declaration. For an export shim, every
    Stage 2 ref must match one source export token at its reported byte span.
    """
    label = f"{module} graph-absent shim"
    visible = mask_comments(source, label)
    source_lines = source.splitlines(keepends=True)
    visible_lines = visible.splitlines(keepends=True)
    if len(source_lines) != len(visible_lines):
        raise PreflightError(f"{label}: comment mask changed line count")
    import_names: list[str] = []
    expected_refs: list[tuple[str, int, int, int, int, int, int]] = []
    namespace_stack: list[str] = []
    in_imports, saw_namespace = True, False
    offset = 0
    export_pattern = re.compile(
        rb"export ([A-Za-z_][A-Za-z0-9_.]*) \(([A-Za-z_][A-Za-z0-9_']*(?: [A-Za-z_][A-Za-z0-9_']*)*)\)"
    )
    for line_number, (original, masked) in enumerate(zip(source_lines, visible_lines), 1):
        line = masked.removesuffix(b"\n").removesuffix(b"\r")
        if not line.strip():
            offset += len(original)
            continue
        if original != masked or line != line.strip():
            raise PreflightError(f"{label}: unsupported source command at line {line_number}")
        if line.startswith(b"import ") and in_imports:
            if not re.fullmatch(rb"import [A-Za-z_][A-Za-z0-9_.]*", line):
                raise PreflightError(f"{label}: unsupported import line")
            import_names.append(line[7:].decode("ascii"))
        elif (match := re.fullmatch(rb"namespace ([A-Za-z_][A-Za-z0-9_.]*)", line)):
            in_imports = False
            saw_namespace = True
            namespace_stack.append(match.group(1).decode("ascii"))
        elif (match := export_pattern.fullmatch(line)):
            in_imports = False
            if not namespace_stack:
                raise PreflightError(f"{label}: export outside namespace")
            owner = match.group(1).decode("ascii")
            if not any(imp.startswith(owner.split(".", 1)[0] + ".") for imp in import_names):
                raise PreflightError(f"{label}: export owner has no imported root")
            for name_match in re.finditer(rb"[A-Za-z_][A-Za-z0-9_']*", match.group(2)):
                token = name_match.group().decode("ascii")
                start = offset + match.start(2) + name_match.start()
                end = offset + match.start(2) + name_match.end()
                expected_refs.append((owner + "." + token, start, end,
                                      line_number, start - offset,
                                      line_number, end - offset))
        elif (match := re.fullmatch(rb"end ([A-Za-z_][A-Za-z0-9_.]*)", line)):
            in_imports = False
            if not namespace_stack or namespace_stack.pop() != match.group(1).decode("ascii"):
                raise PreflightError(f"{label}: namespace/end mismatch")
        else:
            raise PreflightError(f"{label}: unsupported source command at line {line_number}")
        offset += len(original)
    if not import_names or import_names != source_header or namespace_stack:
        raise PreflightError(f"{label}: import or namespace inventory differs")
    if saw_namespace != bool(expected_refs):
        raise PreflightError(f"{label}: empty export namespace or missing wrapper")
    actual_refs = []
    for line in sketch.splitlines():
        if not line.strip():
            continue
        row = json.loads(line, object_pairs_hook=unique_object)
        if not isinstance(row, dict) or row.get("kind") != "ref":
            raise PreflightError(f"{label}: Stage 2 contains non-export fact")
        start, end = row.get("start"), row.get("end")
        if not isinstance(start, dict) or not isinstance(end, dict):
            raise PreflightError(f"{label}: malformed Stage 2 ref span")
        if (not isinstance(row.get("const"), str)
                or any(type(pos.get(key)) is not int for pos in (start, end)
                       for key in ("offset", "line", "col"))
                or not 0 <= start["offset"] < end["offset"] <= len(source)):
            raise PreflightError(f"{label}: malformed Stage 2 ref fields")
        actual_refs.append((row["const"], start["offset"], end["offset"],
                            start["line"], start["col"], end["line"], end["col"]))
        if (end.get("line") != start.get("line") or end.get("col") !=
                start.get("col", -1) + end.get("offset", -1) - start.get("offset", -1)):
            raise PreflightError(f"{label}: invalid Stage 2 ref end")
    if sorted(actual_refs) != sorted(expected_refs):
        raise PreflightError(f"{label}: Stage 2 refs differ from export tokens")
    return "export_only" if expected_refs else "import_only"


def source_imports(module: str, source_headers: dict[str, list[str]]) -> tuple[set[str], set[str]]:
    internal, external = set(), set()
    def visit(current: str) -> None:
        if current in internal:
            return
        internal.add(current)
        for imp in source_headers[current]:
            if imp in source_headers:
                visit(imp)
            else:
                external.add(imp)
    visit(module)
    return internal, external


def expected_path(kind: str, name: str) -> str:
    prefixes = {
        "submit_definition": ("Definitions", "Def"),
        "submit_problem": ("Theorems", "Thm"),
        "verify_solution": ("Solutions", "Sol"),
    }
    if kind not in prefixes or not isinstance(name, str) or not re.fullmatch(
            r"[A-Za-z_][A-Za-z0-9_]*(?:\.[A-Za-z_][A-Za-z0-9_]*)*", name):
        raise PreflightError(f"invalid action kind/name: {kind}:{name}")
    directory, stem = prefixes[kind]
    return f"{directory}/{stem}_{name.replace('.', '_')}.lean"


def check(plan_path: Path, map_path: Path) -> dict:
    plan_raw = plan_path.read_bytes()
    plan = load_json(plan_path)
    if plan.get("schema") != "prove2me_native_offline_plan_v1":
        raise PreflightError("unexpected plan schema")
    validation = plan.get("validation")
    if not isinstance(validation, dict) or validation.get("upload_allowed") is not False:
        raise PreflightError("plan unexpectedly permits upload")
    authority = plan.get("authority")
    if not isinstance(authority, dict) or not isinstance(authority.get("stage2"), dict):
        raise PreflightError("missing extraction authority")
    graph_path = Path(authority["stage1"])
    graph_raw = checked_file(graph_path, authority.get("stage1_sha256"), "Stage 1 graph")
    graph_rows = [json.loads(line, object_pairs_hook=unique_object)
                  for line in graph_raw.splitlines() if line.strip()]
    if not graph_rows or any(not isinstance(row, dict) for row in graph_rows):
        raise PreflightError("empty or malformed Stage 1 graph")
    module_map = load_json(map_path)
    stage2 = authority["stage2"]
    if not stage2 or set(stage2) != set(module_map):
        raise PreflightError("module map differs from plan Stage 2 inventory")
    source_headers = {}
    source_bytes = {}
    sketch_bytes = {}
    for module, pin in stage2.items():
        spec = module_map[module]
        if not isinstance(pin, dict) or not isinstance(spec, dict):
            raise PreflightError(f"{module}: malformed source or Stage 2 entry")
        source_path, sketch_path = Path(spec["source"]), Path(spec["stage2"])
        if (str(sketch_path) != pin.get("path")
                or spec.get("sha256") != pin.get("source_sha256")):
            raise PreflightError(f"{module}: module map differs from plan authority")
        source = checked_file(source_path, pin.get("source_sha256"), f"{module} source")
        sketch = checked_file(sketch_path, pin.get("sha256"), f"{module} Stage 2")
        source_headers[module] = imports(source, f"{module} source")
        source_bytes[module] = source
        sketch_bytes[module] = sketch
    graph_names = {row.get("name") for row in graph_rows}
    if len(graph_names) != len(graph_rows) or any(not isinstance(name, str) for name in graph_names):
        raise PreflightError("duplicate or malformed graph names")
    graph_modules = {row.get("module") for row in graph_rows}
    if graph_modules - set(module_map):
        raise PreflightError("Stage 1 has modules absent from module map")
    graph_absent = set(module_map) - graph_modules
    shim_kinds = {
        module: checked_graph_absent_shim(module, source_bytes[module], sketch_bytes[module],
                                          source_headers[module])
        for module in sorted(graph_absent)
    }
    reachable_modules = set().union(
        *(source_imports(module, source_headers)[0] for module in graph_modules)
    )
    if graph_absent - reachable_modules:
        raise PreflightError("graph-absent shim outside project import closure")
    if plan.get("import_only_modules", {}) != {
            module: source_headers[module] for module in sorted(graph_absent)}:
        raise PreflightError("graph-absent shim inventory differs from plan")
    for row in graph_rows:
        if not isinstance(row.get("typeDeps"), list) or not isinstance(row.get("valueDeps"), list):
            raise PreflightError("malformed graph dependencies")
        if set(row["typeDeps"] + row["valueDeps"]) - graph_names:
            raise PreflightError("Stage 1 graph has missing project dependencies")
    root = plan_path.parent
    payload_raw = checked_file(root / "payloads.json", plan.get("payloads_sha256"), "payloads")
    payloads = json.loads(payload_raw, object_pairs_hook=unique_object)
    if not isinstance(payloads, dict):
        raise PreflightError("payloads must be a JSON object")
    defs, nodes = plan.get("definition_modules"), plan.get("theorem_nodes")
    if (not isinstance(defs, list) or not isinstance(nodes, list)
            or len(defs) != len(set(defs)) or len(nodes) != len(set(nodes))
            or set(payloads) != set(nodes) or set(nodes) - graph_names
            or set(defs) - set(module_map)):
        raise PreflightError("plan node/definition inventory mismatch")
    if set(plan.get("targets", [])) - set(nodes):
        raise PreflightError("target absent from theorem nodes")
    node_checks = validation.get("node_checks")
    if not isinstance(node_checks, dict) or set(node_checks) != set(nodes):
        raise PreflightError("node-check inventory mismatch")
    actions = plan.get("actions")
    if not isinstance(actions, list):
        raise PreflightError("missing action list")
    desired_order = ([('submit_definition', n) for n in defs]
                     + [('submit_problem', n) for n in nodes]
                     + [('verify_solution', n) for n in nodes])
    if [(a.get("kind"), a.get("name")) for a in actions] != desired_order:
        raise PreflightError("action phase or dependency order differs from plan")
    def_index, node_index = {n: i for i, n in enumerate(defs)}, {n: i for i, n in enumerate(nodes)}
    action_imports = {}
    for action in actions:
        kind, name = action["kind"], action["name"]
        relative = expected_path(kind, name)
        if action.get("file") != relative:
            raise PreflightError(f"{kind}:{name}: unexpected artifact path")
        data = checked_file(package_file(root, relative), action.get("sha256"), relative)
        action_imports[(kind, name)] = imports(data, relative)
    def_import = lambda n: "Definitions.Def_" + n.replace(".", "_")
    thm_import = lambda n: "Theorems.Thm_" + n.replace(".", "_")
    for action in actions:
        kind, name = action["kind"], action["name"]
        actual = action_imports[(kind, name)]
        if kind == "submit_definition":
            deps = action.get("depends_on")
            internal, external = source_imports(name, source_headers)
            if (not isinstance(deps, list) or set(deps) !=
                    {n for n in defs if n in internal and n != name}
                    or any(def_index[d] >= def_index[name] for d in deps)):
                raise PreflightError(f"{name}: invalid definition dependency order")
            expected = [def_import(d) for d in defs if d in deps] + sorted(external)
        else:
            check_row = node_checks[name]
            original_module = check_row.get("original_import")
            if original_module not in source_headers or check_row.get("original_constant") != name:
                raise PreflightError(f"{name}: invalid original node check")
            internal, external = source_imports(original_module, source_headers)
            def_part = [def_import(d) for d in defs if d in internal]
            if kind == "submit_problem":
                expected = def_part + sorted(external)
                if (check_row.get("staged_theorem_import") != thm_import(name)
                        or check_row.get("staged_constant") != name):
                    raise PreflightError(f"{name}: staged theorem check mismatch")
            else:
                children = action.get("requires_proved")
                if (not isinstance(children, list) or len(children) != len(set(children))
                        or any(c not in node_index or node_index[c] >= node_index[name]
                               for c in children)
                        or children != check_row.get("imported_stub_dependencies")):
                    raise PreflightError(f"{name}: invalid proof dependency order")
                expected = def_part + [thm_import(c) for c in nodes if c in children] + sorted(external)
                if (check_row.get("staged_solution_import") !=
                        "Solutions.Sol_" + name.replace(".", "_")
                        or check_row.get("solution_constant") != "solution"):
                    raise PreflightError(f"{name}: staged solution check mismatch")
        if actual != expected:
            raise PreflightError(f"{kind}:{name}: import list differs from declared closure")
    for name, payload in payloads.items():
        if not isinstance(payload, dict) or payload.get("theorem_name") != name:
            raise PreflightError(f"{name}: malformed payload")
        try:
            theorem_bytes = (payload["preamble"] + payload["formal_statement"]).encode("utf-8")
            solution_bytes = payload["solution"].encode("utf-8")
        except (KeyError, AttributeError, UnicodeError) as exc:
            raise PreflightError(f"{name}: invalid payload text") from exc
        if theorem_bytes != package_file(root, expected_path("submit_problem", name)).read_bytes():
            raise PreflightError(f"{name}: preamble + formal_statement differs from file")
        if solution_bytes != package_file(root, expected_path("verify_solution", name)).read_bytes():
            raise PreflightError(f"{name}: solution differs from file")
        module = node_checks[name]["original_import"]
        if (payload.get("source_file") != str(Path(module_map[module]["source"]))
                or payload.get("source_sha256") != stage2[module]["source_sha256"]
                or payload.get("imported_theorem_stubs") !=
                    next(a["requires_proved"] for a in actions
                         if a["kind"] == "verify_solution" and a["name"] == name)):
            raise PreflightError(f"{name}: payload provenance/dependencies differ from plan")
    return {
        "schema": "prove2me_native_offline_preflight_v1",
        "mode": "offline_preflight_only",
        "plan_sha256": sha(plan_raw),
        "module_map_sha256": sha(map_path.read_bytes()),
        "stage1_sha256": sha(graph_raw),
        "checked_sources": len(stage2),
        "checked_graph_absent_shims": shim_kinds,
        "checked_nodes": len(nodes),
        "checked_artifacts": len(actions),
        "checks": {
            "extraction_and_source_hashes": "passed",
            "artifact_and_payload_byte_identity": "passed",
            "declared_import_closure_and_order": "passed",
            "stage_build": "pending",
            "type_diff": "pending",
            "axiom_audit": "pending",
        },
        "upload_allowed": False,
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--plan", type=Path, required=True)
    parser.add_argument("--module-map", type=Path, required=True)
    parser.add_argument("--receipt", type=Path, required=True)
    args = parser.parse_args()
    try:
        receipt = check(args.plan, args.module_map)
        if args.receipt.exists() or args.receipt.is_symlink():
            raise PreflightError("receipt path already exists; use a fresh path")
        args.receipt.parent.mkdir(parents=True, exist_ok=True)
        with tempfile.NamedTemporaryFile("w", dir=args.receipt.parent,
                                         prefix=".preflight-", delete=False) as handle:
            json.dump(receipt, handle, indent=2, sort_keys=True)
            handle.write("\n")
            handle.flush()
            os.fsync(handle.fileno())
            temporary = Path(handle.name)
        temporary.replace(args.receipt)
    except (OSError, KeyError, TypeError, ValueError) as exc:
        parser.exit(1, f"preflight failed: {exc}\n")
    print(json.dumps(receipt, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
