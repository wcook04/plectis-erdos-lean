#!/usr/bin/env python3
"""Audit elaborated theorem types and axioms after a pinned staged Lean build.

All Lean queries import built modules. This is local evidence, not a production
validation receipt or a claim that sorry-backed child nodes are hosted Proved.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
import re
import subprocess
import time
from pathlib import Path
from typing import Callable

from preflight import PreflightError, check, checked_file, load_json, sha, unique_object
from run_stage_build import cache_preflight, lean_version, save, stop_group


class AuditError(ValueError):
    pass


ALLOWED = frozenset({"propext", "Classical.choice", "Quot.sound"})
STUB = "sorryAx"
IDENT = re.compile(r"[A-Za-z_][A-Za-z0-9_]*(?:\.[A-Za-z_][A-Za-z0-9_]*)*\Z")
UNIVERSE_DISPLAY = re.compile(r"(?<![\w.])u_[0-9]+\b")
PREFIX = "P2M_AUDIT "


def canonical_universe_display(value: str) -> str:
    """Alpha-rename only Lean's generated u_<digits> display names."""
    mapping: dict[str, str] = {}
    def replace(match: re.Match[str]) -> str:
        return mapping.setdefault(match.group(), f"u_{len(mapping)}")
    return UNIVERSE_DISPLAY.sub(replace, value)


def lean_script(imports: list[str], queries: list[tuple[str, str, str]]) -> bytes:
    if not imports or len(imports) != len(set(imports)):
        raise AuditError("Lean audit needs unique imports")
    for imp in imports:
        if not IDENT.fullmatch(imp):
            raise AuditError(f"invalid Lean import: {imp}")
    lines = [*(f"import {imp}" for imp in imports), "open Lean",
             "set_option pp.universes true", "set_option pp.fullNames true",
             "set_option pp.notation false", "set_option pp.explicit true",
             ""]
    for role, label, constant in queries:
        if role not in {"original", "stub", "solution"} or not IDENT.fullmatch(label) or not IDENT.fullmatch(constant):
            raise AuditError("invalid Lean audit query")
        lines += [
            "run_meta do",
            f"  let name := `{constant}",
            "  let ci ← getConstInfo name",
            "  let typeFmt ← Lean.Meta.ppExpr ci.type",
            "  let axioms ← collectAxioms name",
            "  let record := Json.mkObj [",
            f"    (\"role\", Json.str \"{role}\"),",
            f"    (\"name\", Json.str \"{label}\"),",
            "    (\"type\", Json.str typeFmt.pretty),",
            "    (\"axioms\", toJson (axioms.toList.map (fun n => n.toString)))]",
            f"  IO.println (\"{PREFIX}\" ++ record.compress)",
            "",
        ]
    return ("\n".join(lines) + "\n").encode("utf-8")


def parse_rows(output: bytes, queries: list[tuple[str, str, str]]) -> dict[str, dict]:
    expected = [(role, label) for role, label, _ in queries]
    rows = []
    for raw in output.splitlines():
        if raw.startswith(PREFIX.encode()):
            try:
                row = json.loads(raw[len(PREFIX):], object_pairs_hook=unique_object)
            except (ValueError, UnicodeDecodeError) as exc:
                raise AuditError("malformed Lean audit JSON") from exc
            if (not isinstance(row, dict) or not isinstance(row.get("type"), str)
                    or not row["type"] or not isinstance(row.get("axioms"), list)
                    or any(not isinstance(a, str) for a in row["axioms"])):
                raise AuditError("incomplete Lean audit record")
            rows.append(row)
    if [(r.get("role"), r.get("name")) for r in rows] != expected:
        raise AuditError("Lean audit emitted missing, extra, or reordered records")
    return {row["name"]: row for row in rows}


def analyze(nodes: list[str], proof_edges: dict[str, list[str]],
            original: dict[str, dict], stubs: dict[str, dict],
            solutions: dict[str, dict], solution_bytes: dict[str, bytes]) -> tuple[dict, dict]:
    if any(set(records) != set(nodes) for records in (original, stubs, solutions)):
        raise AuditError("Lean audit record inventory differs from plan")
    types, axioms = {}, {}
    for name in nodes:
        orig, stub, sol = original[name], stubs[name], solutions[name]
        source_type = canonical_universe_display(orig["type"])
        stage_type = canonical_universe_display(stub["type"])
        solution_type = canonical_universe_display(sol["type"])
        matched = source_type == stage_type == solution_type
        types[name] = {
            "matched": matched,
            "source_type": orig["type"],
            "staged_stub_type": stub["type"],
            "staged_solution_type": sol["type"],
            "comparison": "exact_except_generated_universe_display_names",
        }
        source_ax, stub_ax, solution_ax = (set(record["axioms"]) for record in (orig, stub, sol))
        children = proof_edges[name]
        text_clean = b"sorry" not in solution_bytes[name] and b"sorryAx" not in solution_bytes[name]
        source_clean = source_ax <= ALLOWED
        stub_expected = STUB in stub_ax and stub_ax <= ALLOWED | {STUB}
        solution_clean = solution_ax <= ALLOWED | {STUB} and (STUB not in solution_ax or bool(children))
        axioms[name] = {
            "source": sorted(source_ax), "staged_stub": sorted(stub_ax),
            "staged_solution": sorted(solution_ax),
            "imported_stub_dependencies": children,
            "source_allowed": source_clean,
            "stub_has_only_expected_sorry_ax": stub_expected,
            "solution_has_no_sorry_text": text_clean,
            "solution_axioms_compatible_with_imported_stubs": solution_clean,
            "hosted_children_proved": "pending" if STUB in solution_ax else "not_required_by_axiom_trace",
        }
    return ({"schema": "prove2me_native_type_diff_v1", "all_matched": all(v["matched"] for v in types.values()),
             "nodes": types},
            {"schema": "prove2me_native_axiom_audit_v1",
             "local_boundary_passed": all(
                 row["source_allowed"] and row["stub_has_only_expected_sorry_ax"]
                 and row["solution_has_no_sorry_text"]
                 and row["solution_axioms_compatible_with_imported_stubs"]
                 for row in axioms.values()),
             "allowed_source_axioms": sorted(ALLOWED),
             "stub_sorry_ax_is_not_hosted_proof": True,
             "nodes": axioms})


def run_lean(binary: Path, script: Path, cwd: Path, lean_path: list[Path],
             timeout: float, stdout_path: Path, stderr_path: Path) -> dict:
    if (not binary.is_absolute() or not script.is_absolute() or not cwd.is_absolute()
            or not stdout_path.is_absolute() or not stderr_path.is_absolute()
            or any(not path.is_absolute() for path in lean_path)):
        raise AuditError("Lean audit paths must be absolute before changing child cwd")
    environment = os.environ.copy()
    environment["LEAN_PATH"] = os.pathsep.join(map(str, lean_path))
    start = time.monotonic()
    timed_out = False
    with stdout_path.open("xb") as stdout, stderr_path.open("xb") as stderr:
        process = subprocess.Popen([str(binary), script.name], cwd=cwd,
                                   env=environment, stdout=stdout, stderr=stderr,
                                   start_new_session=True)
        try:
            process.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            timed_out = True
            stop_group(process)
        except BaseException:
            stop_group(process)
            raise
        stdout.flush()
        stderr.flush()
        os.fsync(stdout.fileno())
        os.fsync(stderr.fileno())
    return {"script": script.name, "script_sha256": sha(script.read_bytes()),
            "exit_code": process.returncode, "timed_out": timed_out,
            "elapsed_seconds": round(time.monotonic() - start, 3),
            "stdout": {"path": stdout_path.name, "sha256": sha(stdout_path.read_bytes())},
            "stderr": {"path": stderr_path.name, "sha256": sha(stderr_path.read_bytes())}}


def audit(plan_path: Path, map_path: Path, build_path: Path, graph_path: Path,
          gate_path: Path, out: Path, *, max_load: float, timeout: float,
          runtime_check: Callable[[dict, dict], dict] = cache_preflight,
          load_reader: Callable[[], tuple[float, float, float]] = os.getloadavg) -> tuple[int, dict]:
    if (not math.isfinite(max_load) or max_load <= 0 or
            not math.isfinite(timeout) or timeout <= 0):
        raise AuditError("max load and timeout must be finite positive numbers")
    if out.exists() or out.is_symlink():
        raise AuditError("output exists; choose a fresh audit directory")
    plan_path, map_path, build_path, graph_path, gate_path, out = (
        path.resolve() for path in (plan_path, map_path, build_path,
                                    graph_path, gate_path, out))
    if out.exists() or out.is_symlink():
        raise AuditError("resolved output exists; choose a fresh audit directory")
    offline = check(plan_path, map_path)
    plan, build = load_json(plan_path), load_json(build_path)
    if (build.get("schema") != "prove2me_native_stage_build_v1"
            or build.get("status") != "passed" or build.get("stage_build") != "passed"
            or build.get("plan_sha256") != offline["plan_sha256"]
            or build.get("module_map_sha256") != offline["module_map_sha256"]
            or len(build.get("actions", [])) != len(plan["actions"])):
        raise AuditError("exact staged build receipt has not passed")
    graph, gate = load_json(graph_path), load_json(gate_path)
    if (sha(graph_path.read_bytes()) != build.get("graph_config_sha256")
            or sha(gate_path.read_bytes()) != build.get("source_gate_sha256")):
        raise AuditError("build graph/source gate pins differ")
    binary = Path(graph.get("lean_binary", ""))
    roots = [Path(p).resolve() for p in graph["lean_library_roots"]]
    oleans = build_path.parent / "oleans"
    if (str(binary) != build.get("lean_binary") or sha(binary.read_bytes()) != build.get("lean_binary_sha256")
            or not oleans.is_dir()):
        raise AuditError("built Lean binary or olean root differs")
    for planned, row in zip(plan["actions"], build["actions"]):
        if (row.get("kind") != planned["kind"] or row.get("name") != planned["name"]
                or row.get("source_sha256") != planned["sha256"]
                or row.get("exit_code") != 0 or row.get("timed_out") is not False):
            raise AuditError("build action receipt differs from plan")
        relative = Path(row["olean"])
        if relative.is_absolute() or ".." in relative.parts:
            raise AuditError("unsafe staged olean path")
        checked_file(oleans / relative, row.get("olean_sha256"), row["name"] + " olean")
    source_runtime = runtime_check(graph, gate)
    if source_runtime != build.get("final_runtime_preflight"):
        raise AuditError("source/cache inputs changed after staged build")
    version = lean_version(binary, gate["toolchain"])
    if version != build.get("lean_version"):
        raise AuditError("Lean version changed after staged build")
    nodes = plan["theorem_nodes"]
    checks = plan["validation"]["node_checks"]
    edges = {n: checks[n]["imported_stub_dependencies"] for n in nodes}
    stage = plan_path.parent
    solution_bytes = {}
    for action in plan["actions"]:
        if action["kind"] == "verify_solution":
            solution_bytes[action["name"]] = checked_file(stage / action["file"],
                                                           action["sha256"], action["name"])
    original_imports = sorted({checks[n]["original_import"] for n in nodes})
    stub_imports = [checks[n]["staged_theorem_import"] for n in nodes]
    jobs: list[tuple[str, list[str], list[tuple[str, str, str]], list[Path]]] = [
        ("original", original_imports,
         [("original", n, checks[n]["original_constant"]) for n in nodes], roots),
        ("stubs", stub_imports,
         [("stub", n, checks[n]["staged_constant"]) for n in nodes], [oleans] + roots),
    ]
    for index, name in enumerate(nodes):
        jobs.append((f"solution_{index:03d}", [checks[name]["staged_solution_import"]],
                     [("solution", name, checks[name]["solution_constant"])], [oleans] + roots))
    out.mkdir(parents=True)
    receipt_path = out / "audit_receipt.json"
    receipt = {"schema": "prove2me_native_type_axiom_audit_run_v1",
               "mode": "local_lean_audit_only", "status": "running",
               "plan_sha256": offline["plan_sha256"], "build_receipt_sha256": sha(build_path.read_bytes()),
               "source_runtime_preflight": source_runtime, "lean_version": version,
               "jobs": [], "type_diff": "pending", "axiom_audit": "pending",
               "hosted_child_closure": "pending", "upload_allowed": False}
    save(receipt_path, receipt)
    records: dict[str, dict[str, dict]] = {}
    for index, (label, imports, queries, paths) in enumerate(jobs):
        script = out / f"{label}.lean"
        script.write_bytes(lean_script(imports, queries))
        try:
            if (sha(plan_path.read_bytes()) != receipt["plan_sha256"]
                    or sha(build_path.read_bytes()) != receipt["build_receipt_sha256"]
                    or runtime_check(graph, gate) != source_runtime):
                raise AuditError("pinned audit inputs changed")
            load = load_reader()[0]
            if load > max_load:
                receipt["status"] = "deferred_host_load"
                receipt["deferred_at_job"] = index
                save(receipt_path, receipt)
                return 75, receipt
            row = run_lean(binary, script, out, paths, timeout,
                           out / f"{label}.stdout.log", out / f"{label}.stderr.log")
            row["load_1m_before"] = load
            receipt["jobs"].append(row)
            if row["exit_code"] != 0 or row["timed_out"]:
                raise AuditError(f"Lean audit job failed: {label}")
            records["original" if label == "original" else "stub" if label == "stubs" else label] = \
                parse_rows((out / f"{label}.stdout.log").read_bytes(), queries)
            save(receipt_path, receipt)
        except (OSError, KeyError, TypeError, ValueError) as exc:
            receipt["status"] = "failed"
            receipt["failed_at_job"] = index
            receipt["error"] = str(exc)
            save(receipt_path, receipt)
            return 1, receipt
    try:
        solutions = {n: records[f"solution_{i:03d}"][n] for i, n in enumerate(nodes)}
        type_diff, axiom_log = analyze(nodes, edges, records["original"], records["stub"],
                                       solutions, solution_bytes)
        type_path, axiom_path = out / "type-diff.json", out / "axioms.json"
        save(type_path, type_diff)
        save(axiom_path, axiom_log)
        receipt["type_diff_evidence"] = {"path": type_path.name, "sha256": sha(type_path.read_bytes())}
        receipt["axiom_evidence"] = {"path": axiom_path.name, "sha256": sha(axiom_path.read_bytes())}
        if not type_diff["all_matched"] or not axiom_log["local_boundary_passed"]:
            raise AuditError("elaborated type or local axiom boundary failed")
        if (check(plan_path, map_path) != offline
                or sha(build_path.read_bytes()) != receipt["build_receipt_sha256"]
                or runtime_check(graph, gate) != source_runtime):
            raise AuditError("pinned package, build, or cache changed at audit closeout")
    except (OSError, KeyError, TypeError, ValueError) as exc:
        receipt["status"] = "failed_review"
        receipt["error"] = str(exc)
        save(receipt_path, receipt)
        return 1, receipt
    receipt["status"] = "passed_local"
    receipt["type_diff"] = "passed"
    receipt["axiom_audit"] = "passed_local_with_stub_dependencies"
    save(receipt_path, receipt)
    return 0, receipt


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--plan", type=Path, required=True)
    parser.add_argument("--module-map", type=Path, required=True)
    parser.add_argument("--build-receipt", type=Path, required=True)
    parser.add_argument("--graph-config", type=Path, required=True)
    parser.add_argument("--source-gate", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--max-load", type=float, default=10.0)
    parser.add_argument("--timeout-seconds", type=float, default=300.0)
    args = parser.parse_args()
    try:
        code, receipt = audit(args.plan, args.module_map, args.build_receipt,
                              args.graph_config, args.source_gate, args.out,
                              max_load=args.max_load, timeout=args.timeout_seconds)
    except (OSError, KeyError, TypeError, ValueError, PreflightError) as exc:
        parser.exit(1, f"type/axiom audit preflight failed: {exc}\n")
    print(json.dumps({"status": receipt["status"], "jobs": len(receipt["jobs"]),
                      "receipt": str(args.out / "audit_receipt.json")}, indent=2))
    raise SystemExit(code)


if __name__ == "__main__":
    main()
