#!/usr/bin/env python3
"""Compile a generated Prove2Me tree in action order, without editing source.

The command is singleflight and resource-gated. It produces build evidence only:
it cannot establish type parity, axiom cleanliness, or hosted acceptance.
"""

from __future__ import annotations

import argparse
import copy
import hashlib
import json
import math
import os
import re
import signal
import subprocess
import time
from pathlib import Path
from typing import Callable

from preflight import PreflightError, check, checked_file, expected_path, load_json, sha, unique_object
from cache_preflight import cache_preflight


class BuildError(ValueError):
    pass


def save(path: Path, value: dict) -> None:
    temporary = path.with_name("." + path.name + ".tmp")
    with temporary.open("w", encoding="utf-8") as handle:
        json.dump(value, handle, indent=2, sort_keys=True)
        handle.write("\n")
        handle.flush()
        os.fsync(handle.fileno())
    temporary.replace(path)


def stop_group(process: subprocess.Popen) -> None:
    try:
        os.killpg(process.pid, signal.SIGTERM)
    except ProcessLookupError:
        pass
    try:
        process.wait(timeout=1)
    except subprocess.TimeoutExpired:
        try:
            os.killpg(process.pid, signal.SIGKILL)
        except ProcessLookupError:
            pass
        process.wait(timeout=2)


def lean_version(binary: Path, toolchain: str) -> str:
    if not binary.is_absolute() or not binary.is_file() or not os.access(binary, os.X_OK):
        raise BuildError("pinned Lean binary missing or not executable")
    match = re.fullmatch(r"leanprover/lean4:v(\d+\.\d+\.\d+)", toolchain)
    if not match:
        raise BuildError("source gate has unsupported toolchain pin")
    try:
        result = subprocess.run([str(binary), "--version"], capture_output=True,
                                text=True, timeout=10, check=False)
    except (OSError, subprocess.TimeoutExpired) as exc:
        raise BuildError("Lean version probe failed") from exc
    if result.returncode != 0 or not re.search(r"\bversion " + re.escape(match.group(1)) + r"\b",
                                                result.stdout):
        raise BuildError("Lean binary version differs from source gate")
    return result.stdout.strip()


def run_action(binary: Path, relative: str, olean: Path, olean_root: Path,
               roots: list[Path], staging: Path, timeout: float,
               stdout_path: Path, stderr_path: Path) -> dict:
    olean.parent.mkdir(parents=True, exist_ok=True)
    env = os.environ.copy()
    env["LEAN_PATH"] = os.pathsep.join([str(olean_root)] + [str(root) for root in roots])
    # Lean 4.30 requires the input to be contained in its cwd root. The source
    # argument is relative to the generated staging root for that reason.
    command = [str(binary), "-o", str(olean), relative]
    start = time.monotonic()
    timed_out = False
    with stdout_path.open("xb") as stdout, stderr_path.open("xb") as stderr:
        process = subprocess.Popen(command, cwd=staging, env=env,
                                   stdout=stdout, stderr=stderr,
                                   start_new_session=True)
        try:
            process.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            timed_out = True
            stop_group(process)
        except BaseException:
            stop_group(process)
            raise
        stdout.flush()
        stderr.flush()
        os.fsync(stdout.fileno())
        os.fsync(stderr.fileno())
    return {
        "source": relative,
        "command": command,
        "cwd": str(staging),
        "timeout_seconds": timeout,
        "elapsed_seconds": round(time.monotonic() - start, 3),
        "exit_code": process.returncode,
        "timed_out": timed_out,
        "olean": str(olean.relative_to(olean_root)),
        "olean_sha256": sha(olean.read_bytes()) if olean.is_file() and process.returncode == 0 else None,
        "stdout": {"path": stdout_path.name, "sha256": sha(stdout_path.read_bytes())},
        "stderr": {"path": stderr_path.name, "sha256": sha(stderr_path.read_bytes())},
    }


def verified_resume_prefix(prior: Path, plan: dict, stage: Path,
                           expected: dict, binary: Path,
                           max_load: float, timeout: float) -> tuple[list[dict], str]:
    """Accept only a byte-checked, load-deferred prefix of this exact build."""
    if prior.is_symlink() or not prior.is_dir() or (prior / "oleans").is_symlink():
        raise BuildError("resume source must be a real prior build directory")
    receipt_path = prior / "build_receipt.json"
    if receipt_path.is_symlink():
        raise BuildError("resume receipt cannot be a symlink")
    raw = receipt_path.read_bytes()
    old = json.loads(raw, object_pairs_hook=unique_object)
    if not isinstance(old, dict):
        raise BuildError("resume receipt must be a JSON object")
    pins = ("plan_sha256", "module_map_sha256", "graph_config_sha256",
            "source_gate_sha256", "lean_binary", "lean_binary_sha256",
            "lean_version", "lean_library_roots", "initial_runtime_preflight")
    if (old.get("schema") != "prove2me_native_stage_build_v1"
            or old.get("mode") != "local_build_only"
            or old.get("status") != "deferred_host_load"
            or old.get("stage_build") != "pending"
            or old.get("type_diff") != "pending"
            or old.get("axiom_audit") != "pending"
            or old.get("upload_allowed") is not False
            or any(old.get(key) != expected[key] for key in pins)
            or old.get("max_load_1m") != max_load
            or old.get("per_action_timeout_seconds") != timeout
            or "final_runtime_preflight" in old
            or "failed_at_action" in old or "error" in old):
        raise BuildError("resume receipt is not a matching load-deferred build")
    actions = old.get("actions")
    if (not isinstance(actions, list) or len(actions) >= len(plan["actions"])
            or old.get("deferred_at_action") != len(actions)
            or not isinstance(old.get("last_load_1m"), (int, float))
            or not math.isfinite(old["last_load_1m"])
            or old["last_load_1m"] <= max_load):
        raise BuildError("resume action prefix or load deferral is invalid")
    prior = prior.resolve()
    olean_root = prior / "oleans"
    if not olean_root.is_dir():
        raise BuildError("resume olean root is missing")
    for index, row in enumerate(actions):
        action = plan["actions"][index]
        relative = expected_path(action["kind"], action["name"])
        module = Path(relative).with_suffix("")
        olean_rel = str(module.with_suffix(".olean"))
        olean = olean_root / olean_rel
        logbase = f"{index:03d}_{module.name}"
        if (not isinstance(row, dict)
                or row.get("kind") != action["kind"] or row.get("name") != action["name"]
                or row.get("source") != relative
                or row.get("source_sha256") != action["sha256"]
                or row.get("cwd") != str(stage)
                or row.get("command") != [str(binary), "-o", str(olean), relative]
                or row.get("olean") != olean_rel
                or row.get("exit_code") != 0 or row.get("timed_out") is not False
                or row.get("timeout_seconds") != timeout
                or not isinstance(row.get("load_1m_before"), (int, float))
                or not math.isfinite(row["load_1m_before"])
                or row["load_1m_before"] > max_load):
            raise BuildError(f"resume action {index} differs from the exact plan")
        checked_file(stage / relative, action["sha256"], relative)
        for label in ("stdout", "stderr"):
            log = row.get(label)
            expected_log = f"{logbase}.{label}.log"
            if not isinstance(log, dict) or log.get("path") != expected_log:
                raise BuildError(f"resume action {index} has an invalid {label} log")
            file = prior / expected_log
            if file.is_symlink():
                raise BuildError(f"resume action {index} has a symlinked {label} log")
            checked_file(file, log.get("sha256"), expected_log)
        if olean.is_symlink() or not olean.resolve().is_relative_to(olean_root):
            raise BuildError(f"resume action {index} has an unsafe olean")
        if not checked_file(olean, row.get("olean_sha256"), olean_rel):
            raise BuildError(f"resume action {index} has an empty olean")
    if sha(receipt_path.read_bytes()) != sha(raw):
        raise BuildError("resume receipt changed during prefix verification")
    return actions, sha(raw)


def build(plan_path: Path, map_path: Path, graph_path: Path, gate_path: Path,
          out: Path, *, max_load: float, timeout: float,
          resume_from: Path | None = None,
          runtime_check: Callable[[dict, dict], dict] = cache_preflight,
          load_reader: Callable[[], tuple[float, float, float]] = os.getloadavg) -> tuple[int, dict]:
    if (not math.isfinite(max_load) or max_load <= 0 or
            not math.isfinite(timeout) or timeout <= 0):
        raise BuildError("max load and timeout must be finite positive numbers")
    if out.exists() or out.is_symlink():
        raise BuildError("output already exists; choose a fresh directory")
    # The Lean child runs with cwd=staging, so every -o and LEAN_PATH entry must
    # be absolute even when the caller supplies a relative output directory.
    out = out.resolve()
    if out.exists() or out.is_symlink():
        raise BuildError("resolved output already exists; choose a fresh directory")
    offline = check(plan_path, map_path)
    plan = load_json(plan_path)
    graph, gate = load_json(graph_path), load_json(gate_path)
    if gate.get("status") != "source_import_cache_candidate":
        raise BuildError("source gate is not ready")
    binary = Path(graph.get("lean_binary", ""))
    raw_roots = graph.get("lean_library_roots")
    if not isinstance(raw_roots, list) or not raw_roots or any(
            not isinstance(root, str) or not Path(root).is_absolute() for root in raw_roots):
        raise BuildError("invalid pinned Lean library roots")
    roots = [Path(root) for root in raw_roots]
    initial_runtime = runtime_check(graph, gate)
    version = lean_version(binary, gate.get("toolchain", ""))
    binary_hash = sha(binary.read_bytes())
    stage = plan_path.parent.resolve()
    expected = {
        "plan_sha256": offline["plan_sha256"],
        "module_map_sha256": offline["module_map_sha256"],
        "graph_config_sha256": sha(graph_path.read_bytes()),
        "source_gate_sha256": sha(gate_path.read_bytes()),
        "lean_binary": str(binary), "lean_binary_sha256": binary_hash,
        "lean_version": version, "lean_library_roots": [str(root) for root in roots],
        "initial_runtime_preflight": initial_runtime,
    }
    prior_actions, prior_receipt_sha = [], None
    if resume_from is not None:
        if out.is_relative_to(resume_from.resolve()) or resume_from.resolve().is_relative_to(out):
            raise BuildError("resume source and fresh output must be separate directories")
        prior_actions, prior_receipt_sha = verified_resume_prefix(
            resume_from, plan, stage, expected, binary, max_load, timeout)
    out.mkdir(parents=True)
    oleans = out / "oleans"
    oleans.mkdir()
    receipt_path = out / "build_receipt.json"
    receipt = {
        "schema": "prove2me_native_stage_build_v1",
        "mode": "local_build_only",
        "status": "running",
        **expected,
        "max_load_1m": max_load,
        "per_action_timeout_seconds": timeout,
        "actions": [],
        "stage_build": "pending",
        "type_diff": "pending",
        "axiom_audit": "pending",
        "upload_allowed": False,
    }
    if resume_from is not None:
        prior = resume_from.resolve()
        for index, old_row in enumerate(prior_actions):
            row = copy.deepcopy(old_row)
            olean = oleans / row["olean"]
            olean.parent.mkdir(parents=True, exist_ok=True)
            olean.write_bytes(checked_file(prior / "oleans" / row["olean"],
                                           row["olean_sha256"], row["olean"]))
            row["command"][2] = str(olean)
            row["reused_from"] = {"receipt_sha256": prior_receipt_sha,
                                  "action_index": index}
            for label in ("stdout", "stderr"):
                log = row[label]
                (out / log["path"]).write_bytes(checked_file(prior / log["path"],
                                                         log["sha256"], log["path"]))
            receipt["actions"].append(row)
        receipt["resume"] = {"source": str(prior),
                             "receipt_sha256": prior_receipt_sha,
                             "reused_actions": len(prior_actions)}
        if sha((prior / "build_receipt.json").read_bytes()) != prior_receipt_sha:
            raise BuildError("resume receipt changed while copying verified prefix")
    save(receipt_path, receipt)
    for index in range(len(prior_actions), len(plan["actions"])):
        action = plan["actions"][index]
        relative = expected_path(action["kind"], action["name"])
        try:
            if (sha(plan_path.read_bytes()) != receipt["plan_sha256"]
                    or sha(map_path.read_bytes()) != receipt["module_map_sha256"]
                    or sha(graph_path.read_bytes()) != receipt["graph_config_sha256"]
                    or sha(gate_path.read_bytes()) != receipt["source_gate_sha256"]
                    or sha(binary.read_bytes()) != binary_hash):
                raise BuildError("pinned input changed during staged build")
            checked_file(stage / relative, action["sha256"], relative)
            if runtime_check(graph, gate) != initial_runtime:
                raise BuildError("pinned cache inputs changed during staged build")
            load = load_reader()[0]
            if load > max_load:
                receipt["status"] = "deferred_host_load"
                receipt["last_load_1m"] = load
                receipt["deferred_at_action"] = index
                save(receipt_path, receipt)
                return 75, receipt
            module = Path(relative).with_suffix("")
            olean = oleans / module.with_suffix(".olean")
            logbase = f"{index:03d}_{module.name}"
            row = run_action(binary, relative, olean, oleans, roots, stage,
                             timeout, out / (logbase + ".stdout.log"),
                             out / (logbase + ".stderr.log"))
            row["kind"] = action["kind"]
            row["name"] = action["name"]
            row["source_sha256"] = action["sha256"]
            row["load_1m_before"] = load
            receipt["actions"].append(row)
            if row["exit_code"] != 0 or row["timed_out"] or row["olean_sha256"] is None:
                receipt["status"] = "failed"
                receipt["failed_at_action"] = index
                save(receipt_path, receipt)
                return 1, receipt
            checked_file(stage / relative, action["sha256"], relative)
            save(receipt_path, receipt)
        except (OSError, KeyError, TypeError, ValueError) as exc:
            receipt["status"] = "failed_preflight"
            receipt["failed_at_action"] = index
            receipt["error"] = str(exc)
            save(receipt_path, receipt)
            return 1, receipt
    try:
        if (sha(plan_path.read_bytes()) != receipt["plan_sha256"]
                or sha(map_path.read_bytes()) != receipt["module_map_sha256"]
                or sha(graph_path.read_bytes()) != receipt["graph_config_sha256"]
                or sha(gate_path.read_bytes()) != receipt["source_gate_sha256"]
                or sha(binary.read_bytes()) != binary_hash):
            raise BuildError("pinned input changed at staged build closeout")
        if check(plan_path, map_path) != offline:
            raise BuildError("generated package changed at staged build closeout")
        final_runtime = runtime_check(graph, gate)
        if final_runtime != initial_runtime:
            raise BuildError("pinned cache inputs changed at staged build closeout")
        receipt["final_runtime_preflight"] = final_runtime
        for row in receipt["actions"]:
            olean = oleans / row["olean"]
            checked_file(olean, row["olean_sha256"], row["olean"])
    except (OSError, KeyError, TypeError, ValueError) as exc:
        receipt["status"] = "failed_closeout"
        receipt["error"] = str(exc)
        save(receipt_path, receipt)
        return 1, receipt
    receipt["status"] = "passed"
    receipt["stage_build"] = "passed"
    save(receipt_path, receipt)
    return 0, receipt


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--plan", type=Path, required=True)
    parser.add_argument("--module-map", type=Path, required=True)
    parser.add_argument("--graph-config", type=Path, required=True)
    parser.add_argument("--source-gate", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--resume-from", type=Path,
                        help="prior exact-plan load-deferred build directory; output must be fresh")
    parser.add_argument("--max-load", type=float, default=10.0)
    parser.add_argument("--timeout-seconds", type=float, default=300.0)
    args = parser.parse_args()
    try:
        code, receipt = build(args.plan, args.module_map, args.graph_config,
                              args.source_gate, args.out, max_load=args.max_load,
                              timeout=args.timeout_seconds, resume_from=args.resume_from)
    except (OSError, KeyError, TypeError, ValueError, PreflightError) as exc:
        parser.exit(1, f"staged build preflight failed: {exc}\n")
    print(json.dumps({"status": receipt["status"], "completed_actions": len(receipt["actions"]),
                      "total_actions": len(load_json(args.plan)["actions"]),
                      "receipt": str(args.out / "build_receipt.json")}, indent=2))
    raise SystemExit(code)


if __name__ == "__main__":
    main()
