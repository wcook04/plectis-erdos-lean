"""Read-only source/cache preflight for a generated Prove2Me validation run."""

from __future__ import annotations

import hashlib
import json
import re
import subprocess
from pathlib import Path
from typing import Any


MODULE = re.compile(r"[A-Za-z_][A-Za-z0-9_]*(?:\.[A-Za-z_][A-Za-z0-9_]*)*\Z")
SHA256 = re.compile(r"[0-9a-f]{64}\Z")


def file_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def git(cache: Path, *args: str) -> bytes:
    return subprocess.run(["git", "-C", str(cache), *args], capture_output=True,
                          timeout=5.0, check=True).stdout


def cache_preflight(graph: dict[str, Any], gate: dict[str, Any]) -> dict[str, Any]:
    """Verify every declared module against one pinned cache without running Lean.

    The source gate defines the inventory; this function never infers a smaller
    selection from a problem number or a historical four-module diagnostic.
    """
    if gate.get("status") != "source_import_cache_candidate":
        raise ValueError("source gate is not ready")
    if (graph.get("source_commit") != gate.get("source_commit")
            or graph.get("cache_checkout_commit") != gate.get("cache_checkout_commit")):
        raise ValueError("graph and source gate pins differ")
    roots = graph.get("lean_library_roots")
    if not isinstance(roots, list) or not roots or any(not isinstance(root, str) for root in roots):
        raise ValueError("graph has no cached Lean library root")
    library = Path(roots[0]).resolve()
    cache = library.parents[3]
    if (library != cache / ".lake/build/lib/lean"
            or any(not Path(root).resolve().is_relative_to(cache) or not Path(root).is_dir()
                   for root in roots)):
        raise ValueError("Lean library roots do not belong to one cache checkout")
    pinned_head = gate.get("cache_checkout_commit")
    if not isinstance(pinned_head, str) or not re.fullmatch(r"[0-9a-f]{40}", pinned_head):
        raise ValueError("invalid cache checkout pin")
    actual_head = git(cache, "rev-parse", "HEAD").decode().strip()
    ancestor = subprocess.run(["git", "-C", str(cache), "merge-base", "--is-ancestor",
                               pinned_head, actual_head], capture_output=True, timeout=5.0)
    if ancestor.returncode != 0:
        raise ValueError("cache HEAD is not a descendant of the audited checkout")
    toolchain = (cache / "lean-toolchain").read_bytes()
    manifest = (cache / "lake-manifest.json").read_bytes()
    if (toolchain != git(cache, "show", f"{pinned_head}:lean-toolchain")
            or manifest != git(cache, "show", f"{pinned_head}:lake-manifest.json")):
        raise ValueError("cache toolchain or Lake manifest changed from audited checkout")
    if toolchain.decode().strip() != gate.get("cache_toolchain") or gate.get("cache_toolchain") != gate.get("toolchain"):
        raise ValueError("cache Lean toolchain differs from source gate")
    packages = json.loads(manifest)["packages"]
    mathlib_revs = [package["rev"] for package in packages if package["name"] == "mathlib"]
    if mathlib_revs != [gate.get("mathlib_rev")] or gate.get("cache_mathlib_rev") != gate.get("mathlib_rev"):
        raise ValueError("cache Mathlib revision differs from source gate")
    modules = gate.get("modules")
    count = gate.get("module_count")
    if (not isinstance(modules, list) or not modules or type(count) is not int
            or count != len(modules)):
        raise ValueError("source gate must declare a nonempty exact module inventory")
    sources: dict[str, str] = {}
    oleans: dict[str, str] = {}
    seen_paths: set[Path] = set()
    for row in modules:
        if not isinstance(row, dict):
            raise ValueError("invalid source gate module row")
        module, path, source_hash = row.get("module"), row.get("path"), row.get("sha256")
        if (not isinstance(module, str) or not MODULE.fullmatch(module)
                or not isinstance(path, str) or not isinstance(source_hash, str)
                or not SHA256.fullmatch(source_hash)):
            raise ValueError("invalid source gate module row")
        relative = Path(path)
        if (relative.is_absolute() or ".." in relative.parts or relative.suffix != ".lean"
                or relative != Path(*module.split(".")).with_suffix(".lean")):
            raise ValueError(f"source gate module path differs: {module}")
        if module in sources or relative in seen_paths:
            raise ValueError(f"duplicate source gate module or path: {module}")
        seen_paths.add(relative)
        source = cache / relative
        olean = library / relative.with_suffix(".olean")
        if not source.is_file() or file_sha256(source) != source_hash:
            raise ValueError(f"cached source changed: {module}")
        if not olean.is_file() or olean.stat().st_size == 0:
            raise ValueError(f"cached olean missing or empty: {module}")
        sources[module] = source_hash
        oleans[module] = file_sha256(olean)
    if git(cache, "rev-parse", "HEAD").decode().strip() != actual_head:
        raise ValueError("cache HEAD changed during preflight")
    return {"cache_head": actual_head, "audited_cache_head": pinned_head,
            "toolchain_sha256": hashlib.sha256(toolchain).hexdigest(),
            "manifest_sha256": hashlib.sha256(manifest).hexdigest(),
            "source_sha256": sources, "observed_olean_sha256": oleans,
            "olean_scope": "observed_for_this_run; historical_gate_records_presence_only"}
