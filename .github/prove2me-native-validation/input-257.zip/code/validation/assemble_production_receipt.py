#!/usr/bin/env python3
"""Assemble a reviewed local Prove2Me validation gate from exact evidence.

This never runs Lean or calls Prove2Me. The receipt permits ordered upload
preparation; it does not say imported theorem stubs are hosted Proved nodes.
"""

from __future__ import annotations

import argparse
import json
import os
import tempfile
from pathlib import Path

from preflight import PreflightError, check, checked_file, expected_path, load_json, sha
from run_type_axiom_audit import (AuditError, analyze, lean_script, parse_rows)


class AssemblyError(ValueError):
    pass


def require(ok: bool, message: str) -> None:
    if not ok:
        raise AssemblyError(message)


def evidence_file(root: Path, row: dict, name: str) -> bytes:
    require(isinstance(row, dict) and row.get("path") == name,
            f"{name}: evidence path differs from runner output")
    file = root / name
    require(not file.is_symlink() and file.resolve().is_relative_to(root),
            f"{name}: unsafe evidence path")
    return checked_file(file, row.get("sha256"), name)


def checked_build(plan: dict, stage: Path, build_path: Path, graph_path: Path,
                  gate_path: Path, offline: dict) -> dict:
    build, graph, gate = (load_json(path) for path in
                          (build_path, graph_path, gate_path))
    binary = Path(graph.get("lean_binary", ""))
    require(build.get("schema") == "prove2me_native_stage_build_v1" and
            build.get("mode") == "local_build_only" and
            build.get("status") == build.get("stage_build") == "passed" and
            build.get("type_diff") == build.get("axiom_audit") == "pending" and
            build.get("upload_allowed") is False,
            "build receipt has not passed the local staged build")
    require(build.get("plan_sha256") == offline["plan_sha256"] and
            build.get("module_map_sha256") == offline["module_map_sha256"] and
            build.get("graph_config_sha256") == sha(graph_path.read_bytes()) and
            build.get("source_gate_sha256") == sha(gate_path.read_bytes()),
            "build plan or environment evidence pin differs")
    require(gate.get("status") == "source_import_cache_candidate" and
            binary.is_absolute() and binary.is_file() and
            build.get("lean_binary") == str(binary) and
            build.get("lean_binary_sha256") == sha(binary.read_bytes()) and
            isinstance(graph.get("lean_library_roots"), list) and
            graph["lean_library_roots"] and
            build.get("lean_library_roots") == graph["lean_library_roots"] and
            isinstance(build.get("lean_version"), str) and
            gate.get("toolchain", "").removeprefix("leanprover/lean4:v") in build["lean_version"],
            "build binary or library pin differs")
    runtime = build.get("final_runtime_preflight")
    require(isinstance(runtime, dict) and bool(runtime) and
            runtime == build.get("initial_runtime_preflight"),
            "build runtime pin did not remain stable")
    actions = build.get("actions")
    require(isinstance(actions, list) and len(actions) == len(plan["actions"]),
            "build action count differs from exact plan")
    oleans = build_path.parent / "oleans"
    require(oleans.is_dir() and not oleans.is_symlink(),
            "build olean root is missing or symlinked")
    for index, (planned, row) in enumerate(zip(plan["actions"], actions)):
        relative = expected_path(planned["kind"], planned["name"])
        olean_rel = str(Path(relative).with_suffix(".olean"))
        olean = oleans / olean_rel
        logbase = f"{index:03d}_{Path(relative).stem}"
        require(isinstance(row, dict) and
                row.get("kind") == planned["kind"] and
                row.get("name") == planned["name"] and
                row.get("source") == relative and
                row.get("source_sha256") == planned["sha256"] and
                row.get("cwd") == str(stage) and
                row.get("command") == [str(binary), "-o", str(olean), relative] and
                row.get("olean") == olean_rel and
                row.get("exit_code") == 0 and row.get("timed_out") is False,
                f"build action {index} differs from exact plan")
        checked_file(stage / relative, planned["sha256"], relative)
        require(not olean.is_symlink() and
                olean.resolve().is_relative_to(oleans),
                f"build action {index} has unsafe olean path")
        require(bool(checked_file(olean, row.get("olean_sha256"), olean_rel)),
                f"build action {index} has empty olean")
        for label in ("stdout", "stderr"):
            evidence_file(build_path.parent, row.get(label), f"{logbase}.{label}.log")
    return build


def checked_audit(plan: dict, stage: Path, build: dict, build_path: Path,
                  audit_path: Path, offline: dict) -> tuple[dict, Path, Path]:
    audit = load_json(audit_path)
    require(audit.get("schema") == "prove2me_native_type_axiom_audit_run_v1" and
            audit.get("mode") == "local_lean_audit_only" and
            audit.get("status") == "passed_local" and
            audit.get("type_diff") == "passed" and
            audit.get("axiom_audit") == "passed_local_with_stub_dependencies" and
            audit.get("hosted_child_closure") == "pending" and
            audit.get("upload_allowed") is False,
            "type/axiom audit has not passed its local stub boundary")
    require(audit.get("plan_sha256") == offline["plan_sha256"] and
            audit.get("build_receipt_sha256") == sha(build_path.read_bytes()) and
            audit.get("source_runtime_preflight") == build["final_runtime_preflight"] and
            audit.get("lean_version") == build["lean_version"],
            "audit plan, build, runtime, or Lean version pin differs")
    root = audit_path.parent
    type_raw = evidence_file(root, audit.get("type_diff_evidence"), "type-diff.json")
    axiom_raw = evidence_file(root, audit.get("axiom_evidence"), "axioms.json")
    type_diff, axiom_log = json.loads(type_raw), json.loads(axiom_raw)
    require(isinstance(type_diff, dict) and isinstance(axiom_log, dict),
            "type/axiom evidence must be JSON objects")
    nodes = plan["theorem_nodes"]
    checks = plan["validation"]["node_checks"]
    require(isinstance(nodes, list) and nodes and set(checks) == set(nodes),
            "plan node checks differ from theorem inventory")
    jobs = audit.get("jobs")
    require(isinstance(jobs, list) and len(jobs) == 2 + len(nodes),
            "audit job inventory is incomplete")
    original_imports = sorted({checks[n]["original_import"] for n in nodes})
    specifications = [
        ("original", original_imports,
         [("original", n, checks[n]["original_constant"]) for n in nodes]),
        ("stubs", [checks[n]["staged_theorem_import"] for n in nodes],
         [("stub", n, checks[n]["staged_constant"]) for n in nodes]),
    ]
    specifications += [
        (f"solution_{i:03d}", [checks[n]["staged_solution_import"]],
         [("solution", n, checks[n]["solution_constant"])])
        for i, n in enumerate(nodes)
    ]
    records = {}
    for index, (job, (label, imports, queries)) in enumerate(zip(jobs, specifications)):
        require(isinstance(job, dict) and job.get("script") == f"{label}.lean" and
                job.get("exit_code") == 0 and job.get("timed_out") is False,
                f"audit job {index} did not complete as planned")
        script = evidence_file(root, {"path": job["script"],
                                      "sha256": job.get("script_sha256")}, job["script"])
        require(script == lean_script(imports, queries),
                f"audit job {index} script differs from exact plan queries")
        stdout = evidence_file(root, job.get("stdout"), f"{label}.stdout.log")
        evidence_file(root, job.get("stderr"), f"{label}.stderr.log")
        records[label] = parse_rows(stdout, queries)
    original, stubs = records["original"], records["stubs"]
    solutions = {n: records[f"solution_{i:03d}"][n] for i, n in enumerate(nodes)}
    solution_bytes = {a["name"]: checked_file(stage / a["file"], a["sha256"], a["file"])
                      for a in plan["actions"] if a["kind"] == "verify_solution"}
    expected_types, expected_axioms = analyze(
        nodes, {n: checks[n]["imported_stub_dependencies"] for n in nodes},
        original, stubs, solutions, solution_bytes,
    )
    require(type_diff == expected_types and type_diff.get("all_matched") is True and
            axiom_log == expected_axioms and axiom_log.get("local_boundary_passed") is True and
            axiom_log.get("stub_sorry_ax_is_not_hosted_proof") is True,
            "type/axiom evidence does not match complete Lean audit logs")
    return audit, root / "type-diff.json", root / "axioms.json"


def assemble(plan_path: Path, map_path: Path, build_path: Path,
             audit_path: Path, graph_path: Path, gate_path: Path,
             output: Path) -> dict:
    require(not output.exists() and not output.is_symlink(),
            "production validation output already exists")
    plan_path, map_path, build_path, audit_path, graph_path, gate_path = (
        path.resolve() for path in
        (plan_path, map_path, build_path, audit_path, graph_path, gate_path))
    offline = check(plan_path, map_path)
    plan = load_json(plan_path)
    audit_sha_before = sha(audit_path.read_bytes())
    build = checked_build(plan, plan_path.parent, build_path,
                          graph_path, gate_path, offline)
    audit, type_path, axiom_path = checked_audit(
        plan, plan_path.parent, build, build_path, audit_path, offline)
    sources = {"build_log": build_path, "type_diff_log": type_path,
               "axiom_log": axiom_path}
    receipt = {
        "schema": "prove2me_native_validation_v1", "mode": "production",
        "plan_sha256": offline["plan_sha256"],
        "stage_build": "passed", "type_diff": "passed", "axiom_audit": "passed",
        "stub_axioms_acknowledged": True,
        "stub_boundary": "local_only; hosted child theorem closure remains pending",
        "hosted_child_closure": audit["hosted_child_closure"],
        "action_count": len(plan["actions"]),
        "audit_receipt": {"path": str(audit_path),
                          "sha256": audit_sha_before},
        "graph_config_sha256": build["graph_config_sha256"],
        "source_gate_sha256": build["source_gate_sha256"],
        "evidence": {label: {"path": str(path), "sha256": sha(path.read_bytes())}
                     for label, path in sources.items()},
    }
    # No evidence may change between the checks and the authority handoff.
    require(check(plan_path, map_path) == offline and
            sha(build_path.read_bytes()) == audit["build_receipt_sha256"] and
            sha(graph_path.read_bytes()) == build["graph_config_sha256"] and
            sha(gate_path.read_bytes()) == build["source_gate_sha256"] and
            sha(Path(build["lean_binary"]).read_bytes()) == build["lean_binary_sha256"] and
            all(sha(path.read_bytes()) == receipt["evidence"][label]["sha256"]
                for label, path in sources.items()) and
            sha(audit_path.read_bytes()) == audit_sha_before,
            "validation evidence changed during assembly")
    output.parent.mkdir(parents=True, exist_ok=True)
    require(not output.exists() and not output.is_symlink(),
            "production validation output already exists")
    with tempfile.NamedTemporaryFile("w", dir=output.parent,
                                     prefix=".production-validation-", delete=False) as handle:
        json.dump(receipt, handle, indent=2, sort_keys=True)
        handle.write("\n")
        handle.flush()
        os.fsync(handle.fileno())
        temporary = Path(handle.name)
    try:
        os.link(temporary, output)
    finally:
        temporary.unlink(missing_ok=True)
    return receipt


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--plan", type=Path, required=True)
    parser.add_argument("--module-map", type=Path, required=True)
    parser.add_argument("--build-receipt", type=Path, required=True)
    parser.add_argument("--audit-receipt", type=Path, required=True)
    parser.add_argument("--graph-config", type=Path, required=True)
    parser.add_argument("--source-gate", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    try:
        receipt = assemble(args.plan, args.module_map, args.build_receipt,
                           args.audit_receipt, args.graph_config,
                           args.source_gate, args.out)
    except (OSError, KeyError, TypeError, ValueError, PreflightError, AuditError) as exc:
        parser.exit(1, f"production validation assembly failed: {exc}\n")
    print(json.dumps({"receipt": str(args.out), "action_count": receipt["action_count"],
                      "hosted_child_closure": receipt["hosted_child_closure"]}, sort_keys=True))


if __name__ == "__main__":
    main()
