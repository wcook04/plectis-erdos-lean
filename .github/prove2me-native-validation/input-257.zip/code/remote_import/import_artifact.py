#!/usr/bin/env python3
"""Verify a pinned remote extraction and prepare project.py's module map.

The input inventory is not a declaration graph. Only the official Stage 1 and
Stage 2 outputs in the artifact supply those facts. This importer runs no Lean.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import re
import shutil
import subprocess
import tempfile
import zipfile
from pathlib import Path


# .github/prove2me-extraction/manifest.json at control commit b3e18b509963eed74e8a9d52908af118264a9fef.
PINNED_MANIFEST_SHA256 = "d44fb46790df839ef54c9ba6ea678b73eefdb15e5f833fa1f50da79c49941963"
MAX_FILE_BYTES = 100_000_000
MAX_BUNDLE_BYTES = 400_000_000
MODULE = re.compile(r"[A-Za-z_][A-Za-z0-9_]*(?:\.[A-Za-z_][A-Za-z0-9_]*)*")


class InvalidArtifact(ValueError):
    pass


def require(condition: bool, message: str) -> None:
    if not condition:
        raise InvalidArtifact(message)


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def read_json(data: bytes, label: str) -> dict:
    try:
        value = json.loads(data)
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise InvalidArtifact(f"invalid JSON: {label}") from exc
    require(isinstance(value, dict), f"expected JSON object: {label}")
    return value


def read_jsonl(data: bytes, label: str) -> list[dict]:
    try:
        rows = [json.loads(line) for line in data.decode("utf-8").splitlines() if line.strip()]
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise InvalidArtifact(f"invalid JSONL: {label}") from exc
    require(all(isinstance(row, dict) for row in rows), f"non-object JSONL row: {label}")
    return rows


class Artifact:
    """Read fixed artifact members from a directory or a GitHub artifact zip."""

    def __init__(self, path: Path):
        self.path = path.resolve()
        self.archive = None
        if path.is_dir():
            self.root = path / "output" if (path / "output" / "input_receipt.json").is_file() else path
        elif path.is_file() and zipfile.is_zipfile(path):
            self.root = None
            self.archive = zipfile.ZipFile(path)
            names = [info.filename for info in self.archive.infolist() if not info.is_dir()]
            require(len(names) == len(set(names)), "duplicate zip member")
            require(all(not name.startswith("/") and "\\" not in name and
                        all(part not in {"", ".", ".."} for part in name.split("/"))
                        for name in names), "unsafe zip member path")
            require(all((info.external_attr >> 16) & 0o170000 != 0o120000
                        for info in self.archive.infolist()), "zip symlink is not allowed")
            require(sum(info.file_size for info in self.archive.infolist()) <= MAX_BUNDLE_BYTES,
                    "artifact exceeds 400 MB ceiling")
            self.prefix = "output/" if "output/input_receipt.json" in names else ""
        else:
            raise InvalidArtifact(f"expected artifact directory or zip: {path}")

    def read(self, relative: str) -> bytes:
        require(relative and all(part not in {"", ".", ".."} for part in relative.split("/")),
                f"unsafe artifact member: {relative}")
        if self.archive:
            name = self.prefix + relative
            try:
                info = self.archive.getinfo(name)
            except KeyError as exc:
                raise InvalidArtifact(f"missing artifact member: {relative}") from exc
            require(info.file_size <= MAX_FILE_BYTES, f"oversized artifact member: {relative}")
            with self.archive.open(info) as stream:
                data = stream.read(MAX_FILE_BYTES + 1)
        else:
            file = self.root / relative
            require(file.is_file() and not file.is_symlink() and
                    file.resolve().is_relative_to(self.root.resolve()),
                    f"missing or unsafe artifact member: {relative}")
            require(file.stat().st_size <= MAX_FILE_BYTES,
                    f"oversized artifact member: {relative}")
            data = file.read_bytes()
        require(len(data) <= MAX_FILE_BYTES, f"oversized artifact member: {relative}")
        return data

    def close(self) -> None:
        if self.archive:
            self.archive.close()


def source_pin(source: Path, case: dict) -> dict[str, bytes]:
    source = source.resolve()
    try:
        head = subprocess.check_output(["git", "-C", str(source), "rev-parse", "HEAD"],
                                       text=True, stderr=subprocess.DEVNULL).strip()
    except subprocess.CalledProcessError as exc:
        raise InvalidArtifact(f"not a Git source checkout: {source}") from exc
    require(head == case["source_commit"], "source checkout commit differs from pinned manifest")
    for path in ("lean-toolchain", "lake-manifest.json"):
        try:
            committed = subprocess.check_output(
                ["git", "-C", str(source), "show", f"{head}:{path}"], stderr=subprocess.DEVNULL)
        except subprocess.CalledProcessError as exc:
            raise InvalidArtifact(f"missing committed source pin: {path}") from exc
        require((source / path).read_bytes() == committed, f"source pin changed: {path}")
    require((source / "lean-toolchain").read_text().strip() == case["toolchain"],
            "Lean toolchain differs from pinned manifest")
    lake = read_json((source / "lake-manifest.json").read_bytes(), "lake-manifest.json")
    mathlib = [package for package in lake.get("packages", []) if package.get("name") == "mathlib"]
    require(len(mathlib) == 1 and mathlib[0].get("rev") == case["mathlib_rev"],
            "Mathlib revision differs from pinned manifest")
    sources: dict[str, bytes] = {}
    for row in case["module_rows"]:
        module = row["module"]
        require(isinstance(module, str) and MODULE.fullmatch(module) is not None,
                f"invalid module name: {module}")
        require(module not in sources, f"duplicate source module: {module}")
        relative = Path(*module.split(".")).with_suffix(".lean")
        file = source / relative
        require(file.is_file() and not file.is_symlink() and file.resolve().is_relative_to(source),
                f"missing or unsafe source module: {module}")
        data = file.read_bytes()
        require(sha256(data) == row["sha256"], f"source module hash changed: {module}")
        sources[module] = data
    require(set(case["root_modules"]) <= set(sources), "root module absent from inventory")
    return sources


def check_input(receipt: dict, manifest: dict, problem: str, case: dict) -> None:
    expected = {
        "schema": "prove2me_remote_extraction_input_v1",
        "problem": problem,
        "source_commit": case["source_commit"],
        "toolchain": case["toolchain"],
        "mathlib_rev": case["mathlib_rev"],
        "official_workspace_commit": manifest["official_workspace_commit"],
        "official_script_sha256": manifest["extractor_sha256"],
        "prepared_graph_sha256": case["prepared_graph_sha256"],
        "module_count": len(case["module_rows"]),
        "root_modules": case["root_modules"],
        "selected_declarations": case["selected_declarations"],
    }
    require(receipt == expected, "input receipt differs from pinned extraction manifest")


def import_artifact(artifact_path: Path, source: Path, manifest_path: Path,
                    problem: str, out: Path) -> dict:
    manifest_bytes = manifest_path.read_bytes()
    require(sha256(manifest_bytes) == PINNED_MANIFEST_SHA256,
            "control manifest differs from reviewed b3e18b5 bytes")
    manifest = read_json(manifest_bytes, "manifest.json")
    require(manifest.get("schema") == "prove2me_pinned_remote_extraction_v1",
            "unexpected manifest schema")
    require(problem in manifest["cases"], f"problem not in reviewed manifest: {problem}")
    case = manifest["cases"][problem]
    sources = source_pin(source, case)
    artifact = Artifact(artifact_path)
    try:
        check_input(read_json(artifact.read("input_receipt.json"), "input_receipt.json"),
                    manifest, problem, case)
        graph_bytes = artifact.read("decl_graph.jsonl")
        graph_hash = sha256(graph_bytes)
        graph = read_jsonl(graph_bytes, "decl_graph.jsonl")
        stage1 = read_json(artifact.read("stage1_receipt.json"), "stage1_receipt.json")
        require(stage1 == {
            "schema": "prove2me_remote_stage1_v1",
            "source_commit": case["source_commit"],
            "row_count": len(graph),
            "selected_declarations": case["selected_declarations"],
            "decl_graph_sha256": graph_hash,
        }, "Stage 1 receipt differs from graph or pinned selection")
        for selected in case["selected_declarations"]:
            matches = [row for row in graph if row.get("name") == selected["name"]]
            require(len(matches) == 1 and matches[0].get("module") == selected["module"],
                    f"selected declaration absent or ambiguous: {selected['name']}")
        require(all(any(row.get("module", "") == prefix or
                        row.get("module", "").startswith(prefix + ".")
                        for prefix in case["project_prefixes"]) for row in graph),
                "declaration graph has an unreviewed project prefix")
        stage2 = read_json(artifact.read("stage2_receipt.json"), "stage2_receipt.json")
        outputs = stage2.get("outputs")
        require(stage2.get("schema") == "prove2me_remote_stage2_v1" and
                stage2.get("source_commit") == case["source_commit"] and
                stage2.get("module_count") == len(sources) and isinstance(outputs, list) and
                len(outputs) == len(sources), "Stage 2 receipt incomplete or wrong source")
        output_by_module = {}
        for row in outputs:
            require(isinstance(row, dict) and set(row) == {"module", "sha256", "row_count"} and
                    row["module"] in sources and row["module"] not in output_by_module,
                    "Stage 2 output inventory has extra, duplicate, or malformed module")
            output_by_module[row["module"]] = row
        require(set(output_by_module) == set(sources), "Stage 2 module inventory incomplete")
        stage2_bytes = {}
        for module, row in output_by_module.items():
            data = artifact.read(f"sketch_info/{module}.jsonl")
            require(sha256(data) == row["sha256"], f"Stage 2 hash changed: {module}")
            facts = read_jsonl(data, f"sketch_info/{module}.jsonl")
            require(len(facts) == row["row_count"], f"Stage 2 row count changed: {module}")
            stage2_bytes[module] = data
        require(len(graph_bytes) + sum(len(data) for data in stage2_bytes.values()) <= MAX_BUNDLE_BYTES,
                "verified extraction data exceeds 400 MB ceiling")
    finally:
        artifact.close()

    out = out.resolve()
    require(not out.exists(), f"output already exists: {out}")
    out.parent.mkdir(parents=True, exist_ok=True)
    scratch = Path(tempfile.mkdtemp(prefix=".prove2me-remote-import-", dir=out.parent))
    try:
        (scratch / "sketch_info").mkdir()
        (scratch / "decl_graph.jsonl").write_bytes(graph_bytes)
        module_map = {}
        for module in sorted(sources):
            relative = f"sketch_info/{module}.jsonl"
            (scratch / relative).write_bytes(stage2_bytes[module])
            module_map[module] = {
                "source": str(source.resolve() / Path(*module.split(".")).with_suffix(".lean")),
                "stage2": str(out / relative),
                "sha256": sha256(sources[module]),
            }
        (scratch / "module_map.json").write_text(json.dumps(module_map, indent=2) + "\n")
        receipt = {
            "schema": "prove2me_remote_import_v1",
            "problem": problem,
            "status": "full_extraction_verified",
            "source_commit": case["source_commit"],
            "manifest_sha256": PINNED_MANIFEST_SHA256,
            "stage1_sha256": graph_hash,
            "module_count": len(module_map),
            "selected_declarations": case["selected_declarations"],
            "module_map_sha256": sha256((scratch / "module_map.json").read_bytes()),
            "boundary": "project.py must handle any import-only source modules, then check declaration spans and generated Lean separately",
        }
        (scratch / "import_receipt.json").write_text(json.dumps(receipt, indent=2) + "\n")
        scratch.rename(out)
    except BaseException:
        shutil.rmtree(scratch)
        raise
    return receipt


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--artifact", type=Path, required=True,
                        help="downloaded GitHub Actions artifact directory or zip")
    parser.add_argument("--source", type=Path, required=True,
                        help="checkout at the pinned Lean source commit")
    parser.add_argument("--manifest", type=Path, required=True,
                        help="manifest.json from reviewed control commit b3e18b5")
    parser.add_argument("--problem", choices=["257", "243"], required=True)
    parser.add_argument("--out", type=Path, required=True,
                        help="new directory for verified graph, Stage 2, and module map")
    args = parser.parse_args()
    try:
        result = import_artifact(args.artifact, args.source, args.manifest,
                                 args.problem, args.out)
    except (InvalidArtifact, FileNotFoundError, KeyError, TypeError) as exc:
        parser.exit(2, f"remote import rejected: {exc}\n")
    print(json.dumps(result, sort_keys=True))


if __name__ == "__main__":
    main()
