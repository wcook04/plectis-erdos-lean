#!/usr/bin/env python3
"""Derive a generic source gate and graph config from a verified remote extraction.

This reads the reviewed extraction manifest, original artifact, imported map,
and exact source/cache checkouts. It does not invoke Lean or Prove2Me.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import re
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "remote_import"))
sys.path.insert(0, str(ROOT / "validation"))
from import_artifact import (  # noqa: E402
    PINNED_MANIFEST_SHA256, InvalidArtifact, import_artifact, source_pin,
)
from cache_preflight import cache_preflight  # noqa: E402


COMMIT = re.compile(r"[0-9a-f]{40}\Z")
MODULE = re.compile(r"[A-Za-z_][A-Za-z0-9_]*(?:\.[A-Za-z_][A-Za-z0-9_]*)*\Z")
SHA256 = re.compile(r"[0-9a-f]{64}\Z")


class DerivationError(ValueError):
    pass


def require(ok: bool, message: str) -> None:
    if not ok:
        raise DerivationError(message)


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def file_sha(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def read_json(path: Path) -> dict:
    def unique(pairs: list[tuple[str, object]]) -> dict:
        value = {}
        for key, item in pairs:
            require(key not in value, f"duplicate JSON key in {path}: {key}")
            value[key] = item
        return value

    value = json.loads(path.read_bytes(), object_pairs_hook=unique)
    require(isinstance(value, dict), f"expected JSON object: {path}")
    return value


def encode(value: dict) -> bytes:
    return (json.dumps(value, sort_keys=True, indent=2) + "\n").encode()


def git(path: Path, *args: str) -> bytes:
    return subprocess.run(["git", "-C", str(path), *args], check=True,
                          capture_output=True, timeout=10).stdout


def checked_checkout_pins(checkout: Path, case: dict, label: str) -> str:
    require(checkout.is_dir() and not checkout.is_symlink(),
            f"{label} checkout missing or symlinked")
    head = git(checkout, "rev-parse", "HEAD").decode().strip()
    require(COMMIT.fullmatch(head) is not None, f"invalid {label} commit")
    require(Path(git(checkout, "rev-parse", "--show-toplevel").decode().strip()).resolve()
            == checkout, f"{label} path is not the checkout root")
    for name in ("lean-toolchain", "lake-manifest.json"):
        local = checkout / name
        require(local.is_file() and not local.is_symlink() and
                local.read_bytes() == git(checkout, "show", f"{head}:{name}"),
                f"{label} {name} differs from pinned commit")
    require((checkout / "lean-toolchain").read_text().strip() == case["toolchain"],
            f"{label} Lean toolchain differs from manifest")
    packages = read_json(checkout / "lake-manifest.json").get("packages")
    require(isinstance(packages, list), f"{label} has no Lake packages")
    mathlib = [row.get("rev") for row in packages
               if isinstance(row, dict) and row.get("name") == "mathlib"]
    require(mathlib == [case["mathlib_rev"]],
            f"{label} Mathlib revision differs from manifest")
    return head


def library_roots(cache: Path) -> list[str]:
    primary = cache / ".lake/build/lib/lean"
    require(primary.is_dir() and not primary.is_symlink(),
            "cache has no project Lean library root")
    packages = cache / ".lake/packages"
    require(packages.is_dir() and not packages.is_symlink(),
            "cache has no Lake package directory")
    roots = [primary]
    mathlib_root = packages / "mathlib" / ".lake/build/lib/lean"
    require(mathlib_root.is_dir() and not mathlib_root.is_symlink() and
            any(path.is_file() and not path.is_symlink()
                for path in mathlib_root.rglob("*.olean")),
            "cache has no compiled Mathlib library")
    for package in sorted(packages.iterdir(), key=lambda item: item.name):
        if package.is_dir() and not package.is_symlink():
            root = package / ".lake/build/lib/lean"
            if root.is_dir() and not root.is_symlink():
                roots.append(root)
    require(all(path.resolve().is_relative_to(cache) for path in roots),
            "library root escapes cache checkout")
    require(mathlib_root in roots, "compiled Mathlib root absent from library paths")
    return [str(path) for path in roots]


def compose(case: dict, source: Path, cache: Path, lean_binary: Path,
            *, problem: str, manifest_sha256: str,
            imported_receipt_sha256: str, artifact_sha256: str) -> tuple[dict, dict]:
    """Verify exact source/cache state and compose the existing runner contracts."""
    require(not source.is_symlink() and not cache.is_symlink() and
            not lean_binary.is_symlink(), "checkout or Lean binary is symlinked")
    source, cache, lean_binary = source.resolve(), cache.resolve(), lean_binary.resolve()
    require(source != cache, "source and cache checkouts must be distinct")
    require(lean_binary.is_file() and not lean_binary.is_symlink(),
            "Lean binary is missing or symlinked")
    source_head = checked_checkout_pins(source, case, "source")
    require(source_head == case["source_commit"],
            "source checkout commit differs from reviewed manifest")
    cache_head = checked_checkout_pins(cache, case, "cache")
    require(subprocess.run(["git", "-C", str(cache), "merge-base", "--is-ancestor",
                            source_head, cache_head], capture_output=True,
                           timeout=10).returncode == 0,
            "cache checkout does not descend from pinned source commit")
    sources = source_pin(source, case)
    rows = case.get("module_rows")
    require(isinstance(rows, list) and rows and len(rows) == len(sources),
            "manifest module inventory incomplete")
    gate_rows = []
    seen: set[str] = set()
    for row in rows:
        module = row.get("module")
        require(isinstance(module, str) and MODULE.fullmatch(module) is not None
                and module not in seen, "invalid or duplicate manifest module")
        require(isinstance(row.get("sha256"), str) and
                SHA256.fullmatch(row["sha256"]) is not None,
                f"invalid manifest source hash: {module}")
        seen.add(module)
        relative = Path(*module.split(".")).with_suffix(".lean")
        data = sources[module]
        cached = cache / relative
        olean = cache / ".lake/build/lib/lean" / relative.with_suffix(".olean")
        require(cached.is_file() and not cached.is_symlink() and
                cached.resolve().is_relative_to(cache) and
                cached.read_bytes() == data and sha(data) == row["sha256"],
                f"cached source differs from reviewed manifest: {module}")
        require(olean.is_file() and not olean.is_symlink() and
                olean.resolve().is_relative_to(cache) and olean.stat().st_size > 0,
                f"cached olean missing or empty: {module}")
        gate_rows.append({"module": module, "path": relative.as_posix(),
                          "sha256": row["sha256"]})
    gate_rows.sort(key=lambda row: row["module"])
    gate = {
        "schema": "prove2me_remote_source_gate_v1",
        "status": "source_import_cache_candidate",
        "problem": problem,
        "source_commit": source_head,
        "cache_checkout_commit": cache_head,
        "toolchain": case["toolchain"],
        "cache_toolchain": case["toolchain"],
        "mathlib_rev": case["mathlib_rev"],
        "cache_mathlib_rev": case["mathlib_rev"],
        "manifest_sha256": manifest_sha256,
        "imported_receipt_sha256": imported_receipt_sha256,
        "artifact_sha256": artifact_sha256,
        "root_modules": case["root_modules"],
        "module_count": len(gate_rows),
        "modules": gate_rows,
        "boundary": "Source/cache candidate only; generated Lean build and type/axiom audit pending.",
    }
    graph = {
        "schema": "prove2me_remote_validation_graph_config_v1",
        "stage": "validation",
        "status": "source_import_cache_candidate",
        "problem": problem,
        "source_commit": source_head,
        "cache_checkout_commit": cache_head,
        "manifest_sha256": manifest_sha256,
        "source_gate_sha256": sha(encode(gate)),
        "lean_binary": str(lean_binary),
        "lean_binary_sha256": file_sha(lean_binary),
        "lean_library_roots": library_roots(cache),
    }
    observed = cache_preflight(graph, gate)
    require(observed["source_sha256"] ==
            {row["module"]: row["sha256"] for row in gate_rows}
            and len(observed["observed_olean_sha256"]) == len(gate_rows),
            "generic cache preflight did not consume the complete inventory")
    return gate, graph


def verify_imported(artifact: Path, source: Path, manifest: Path,
                    imported: Path, problem: str) -> tuple[dict, dict, dict]:
    manifest_sha = file_sha(manifest)
    require(manifest_sha == PINNED_MANIFEST_SHA256,
            "extraction manifest differs from reviewed control bytes")
    control = read_json(manifest)
    require(control.get("schema") == "prove2me_pinned_remote_extraction_v1" and
            problem in control.get("cases", {}), "unexpected extraction manifest/case")
    case = control["cases"][problem]
    original_receipt_path = imported / "import_receipt.json"
    original_map_path = imported / "module_map.json"
    original_graph_path = imported / "decl_graph.jsonl"
    original_receipt = read_json(original_receipt_path)
    original_map = read_json(original_map_path)
    require(original_receipt.get("schema") == "prove2me_remote_import_v1" and
            original_receipt.get("status") == "full_extraction_verified" and
            original_receipt.get("problem") == problem and
            original_receipt.get("source_commit") == case["source_commit"] and
            original_receipt.get("manifest_sha256") == manifest_sha and
            original_receipt.get("module_map_sha256") == file_sha(original_map_path) and
            original_receipt.get("stage1_sha256") == file_sha(original_graph_path) and
            original_receipt.get("module_count") == len(case["module_rows"]) and
            original_receipt.get("selected_declarations") == case["selected_declarations"],
            "imported receipt does not match pinned extraction")
    with tempfile.TemporaryDirectory(prefix=".p2m-recheck-") as temporary:
        replay = Path(temporary) / "reimported"
        replay_receipt = import_artifact(artifact, source, manifest, problem, replay)
        require(file_sha(replay / "decl_graph.jsonl") == file_sha(original_graph_path)
                and set(original_receipt) == set(replay_receipt)
                and all(original_receipt[key] == value
                        for key, value in replay_receipt.items()
                        if key != "module_map_sha256"),
                "imported graph or receipt differs from fresh artifact replay")
        replay_map = read_json(replay / "module_map.json")
        require(set(original_map) == set(replay_map) ==
                {row["module"] for row in case["module_rows"]},
                "imported module map inventory differs from reviewed case")
        for module, row in original_map.items():
            known = replay_map[module]
            expected_stage2 = imported / "sketch_info" / (module + ".jsonl")
            require(row == {"source": known["source"], "sha256": known["sha256"],
                            "stage2": str(expected_stage2.resolve())}
                    and expected_stage2.is_file() and not expected_stage2.is_symlink()
                    and expected_stage2.read_bytes() ==
                    (replay / "sketch_info" / (module + ".jsonl")).read_bytes(),
                    f"imported Stage 2 differs from fresh artifact replay: {module}")
    return case, original_receipt, original_map


def derive(artifact: Path, imported: Path, source: Path, cache: Path,
           manifest: Path, lean_binary: Path, problem: str, out: Path) -> dict:
    require(problem in ("243", "257"), "unsupported problem")
    require(not out.exists() and not out.is_symlink(), "output already exists")
    require(artifact.is_file() and not artifact.is_symlink(),
            "artifact must be a downloaded ZIP file")
    require(not source.is_symlink() and not cache.is_symlink() and
            not manifest.is_symlink() and not imported.is_symlink() and
            not lean_binary.is_symlink(), "input path is symlinked")
    artifact, imported, source, cache, manifest = (
        path.resolve() for path in (artifact, imported, source, cache, manifest))
    artifact_sha = file_sha(artifact)
    import_sha = file_sha(imported / "import_receipt.json")
    case, _, _ = verify_imported(artifact, source, manifest, imported, problem)
    gate, graph = compose(case, source, cache, lean_binary, problem=problem,
                          manifest_sha256=PINNED_MANIFEST_SHA256,
                          imported_receipt_sha256=import_sha,
                          artifact_sha256=artifact_sha)
    out.parent.mkdir(parents=True, exist_ok=True)
    scratch = Path(tempfile.mkdtemp(prefix=".p2m-gate-", dir=out.parent))
    try:
        gate_path, graph_path = scratch / "source_gate.json", scratch / "graph_config.json"
        gate_path.write_bytes(encode(gate))
        graph_path.write_bytes(encode(graph))
        require(graph["source_gate_sha256"] == file_sha(gate_path),
                "graph/source gate digest differs")
        final_cache = cache_preflight(graph, gate)
        require(source_pin(source, case) and
                final_cache["source_sha256"] ==
                {row["module"]: row["sha256"] for row in gate["modules"]} and
                set(final_cache["observed_olean_sha256"]) ==
                {row["module"] for row in gate["modules"]} and
                checked_checkout_pins(cache, case, "cache") == gate["cache_checkout_commit"] and
                file_sha(artifact) == artifact_sha and
                file_sha(imported / "import_receipt.json") == import_sha and
                file_sha(manifest) == PINNED_MANIFEST_SHA256 and
                file_sha(lean_binary) == graph["lean_binary_sha256"],
                "pinned source, cache, artifact, manifest or Lean binary changed")
        receipt = {
            "schema": "prove2me_remote_runtime_input_derivation_v1",
            "status": "source_cache_verified_lean_pending",
            "problem": problem,
            "source_commit": gate["source_commit"],
            "cache_checkout_commit": gate["cache_checkout_commit"],
            "module_count": gate["module_count"],
            "manifest_sha256": PINNED_MANIFEST_SHA256,
            "artifact_sha256": artifact_sha,
            "import_receipt_sha256": import_sha,
            "source_gate_sha256": file_sha(gate_path),
            "graph_config_sha256": file_sha(graph_path),
            "source_toolchain_sha256": file_sha(source / "lean-toolchain"),
            "source_lake_manifest_sha256": file_sha(source / "lake-manifest.json"),
            "cache_toolchain_sha256": final_cache["toolchain_sha256"],
            "cache_lake_manifest_sha256": final_cache["manifest_sha256"],
            "lean_binary_sha256": graph["lean_binary_sha256"],
            "observed_olean_sha256": final_cache["observed_olean_sha256"],
            "lean_executed": False,
        }
        (scratch / "derivation_receipt.json").write_bytes(encode(receipt))
        scratch.rename(out)
    except BaseException:
        shutil.rmtree(scratch)
        raise
    return receipt


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    for flag in ("artifact", "imported", "source", "cache", "manifest",
                 "lean-binary", "out"):
        parser.add_argument("--" + flag, type=Path, required=True)
    parser.add_argument("--problem", choices=("243", "257"), required=True)
    args = parser.parse_args()
    try:
        result = derive(args.artifact, args.imported, args.source, args.cache,
                        args.manifest, args.lean_binary, args.problem, args.out)
    except (OSError, KeyError, TypeError, ValueError, InvalidArtifact,
            subprocess.SubprocessError) as exc:
        parser.exit(1, f"source/cache derivation rejected: {exc}\n")
    print(json.dumps(result, sort_keys=True))


if __name__ == "__main__":
    main()
