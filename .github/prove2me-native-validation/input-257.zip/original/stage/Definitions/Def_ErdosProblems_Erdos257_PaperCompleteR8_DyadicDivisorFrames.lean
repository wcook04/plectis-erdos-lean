import Mathlib

/-! # Disjoint dyadic divisor frames for the weighted separating host

These are the actual frames F_k = {2^(k+2) d : d divides M_k}. Positive odd
M_k make them pairwise disjoint and give an infinite positive union. The
prime-block harmonic bounds, weighted summability and divergent logarithmic
means are further obligations, not hypotheses hidden in a class-separation
conclusion.
-/
namespace ErdosProblems.Erdos257.PaperCompleteR8
open Finset



def dyadicDivisorFrame (M k : ℕ) : Finset ℕ :=
  M.divisors.image (fun d => 2 ^ (k + 2) * d)

def dyadicDivisorHost (M : ℕ → ℕ) : Set ℕ :=
  {a | ∃ k, a ∈ dyadicDivisorFrame (M k) k}







end ErdosProblems.Erdos257.PaperCompleteR8
