import Mathlib.Algebra.Order.Antidiag.Prod
import Mathlib.Analysis.Normed.Ring.InfiniteSum
import Mathlib.Analysis.RCLike.Basic
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Data.Finset.NatAntidiagonal
import Mathlib.Data.Nat.Fib.Basic
import Mathlib.Data.Nat.Totient
import Mathlib.NumberTheory.ArithmeticFunction.Misc
import Mathlib.NumberTheory.ArithmeticFunction.Moebius
import Mathlib.NumberTheory.TsumDivisorsAntidiagonal
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Positivity

/-!
# Stern--Brocot geometry after inducing parabolic runs

This file isolates the unconditional combinatorial core of the induced-run
coordinate for the positive primitive-pair mass

`∑_{a,b ≥ 1, Nat.Coprime a b} 2^{-(a+b)}`.

The existing `GcdMomentCalculus` module uses the same mediant children for its
Mersenne cylinder mass.  Here the observable is different: the height of the
literal primitive pair.  A word is stored newest run first, so its head acts
last.  This convention makes the continuant recurrence structural:

`(A,B) ↦ (n*A+B,A)`.

The first theorem is the exact Fibonacci floor.  A word with `r` nonempty
alternating runs has height at least `Nat.fib (r+3)`, with equality when every
run has length one.  The defect-sensitivity layer then expands the complete
positive continuant defect, identifies the one-site coefficient
`F_{i+2} F_{r-i+1}`, and proves the sharp global gain
`F_{r+1} * ∑ eᵢ`.  The final section records the companion arithmetic
knife-edge: the sum of the natural Fibonacci run exponents is exactly two less
than the same Fibonacci height scale.

Nothing here proves irrationality of Erdős #249.  In particular, this module
does not assert that the analytic run tail survives denominator clearing.
-/

namespace SternBrocotRunGeometry

/-! ## The literal mediant tree -/

/-- The two Stern--Brocot mediant moves. -/
inductive LR
  | left
  | right
  deriving DecidableEq, Repr

















/-! ## Exact run encoding -/

















/-! ## Fibonacci pressure -/











/-! ## Exact defect sensitivity away from the Fibonacci spine -/



































/-! ## The first two analytic run layers -/









/-! ## The natural denominator exponent is at the Fibonacci knife-edge -/





-- Axiom audit: the induced-run geometry is foundational only.

end SternBrocotRunGeometry
