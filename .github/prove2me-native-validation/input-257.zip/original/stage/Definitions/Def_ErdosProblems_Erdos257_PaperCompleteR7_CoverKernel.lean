import Mathlib.Algebra.Order.Ring.Pow
import Mathlib.Analysis.Convex.SpecificFunctions.Basic
import Mathlib.Analysis.MeanInequalitiesPow
import Mathlib.Analysis.SpecialFunctions.Pow.Continuity
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.Tactic

   
                                                             

                                                                             
                                                                             
                                                                            

                                                                                
                                                                                
                            
                                                                                        
                                                           
                                                                                
                                                                   

                                                                            
                                                                          
                                                            
                                                                             
                                                  
                                                                           
                                                                             
                                                                              
                                                                              
                                                                                
                                                              

                                                                               
                                                                              
                                                                                
                                                                    
                                                           
  

noncomputable section

namespace ErdosProblems.Erdos257.PaperCompleteR7

open Finset Filter





/-- The scalar tail-budget bound `ε ^ (-α) ≤ max 1 ε⁻¹`, uniform over the
exponents `0 < α ≤ 1`. -/
theorem rpow_neg_le_max_one_inv {t α : ℝ} (ht : 0 < t) (hα : 0 < α) (hα1 : α ≤ 1) :
    t ^ (-α) ≤ max 1 t⁻¹ := by
  rcases le_total t 1 with h | h
  · have hmono : t ^ (-α) ≤ t ^ (-1 : ℝ) :=
      Real.rpow_le_rpow_of_exponent_ge ht h (by linarith)
    rw [Real.rpow_neg_one] at hmono
    exact hmono.trans (le_max_right _ _)
  · have hone : t ^ (-α) ≤ t ^ (0 : ℝ) :=
      Real.rpow_le_rpow_of_exponent_le h (by linarith)
    rw [Real.rpow_zero] at hone
    exact hone.trans (le_max_left _ _)

/-- The geometric factor of the displayed cost condition. -/
theorem tsum_inv_pow_succ {B : ℝ} (hB : 1 < B) :
    ∑' r : ℕ, (B ^ (r + 1))⁻¹ = 1 / (B - 1) := by
  have hB0 : (0 : ℝ) < B := lt_trans zero_lt_one hB
  have hBne : B ≠ 0 := ne_of_gt hB0
  have hinv0 : (0 : ℝ) ≤ B⁻¹ := by positivity
  have hinv1 : B⁻¹ < 1 := by
    rw [inv_lt_one_iff₀]
    exact Or.inr hB
  have hterm : ∀ r : ℕ, (B ^ (r + 1))⁻¹ = B⁻¹ * (B⁻¹) ^ r := by
    intro r
    rw [pow_succ, mul_inv, ← inv_pow]
    ring
  rw [tsum_congr hterm, tsum_mul_left, tsum_geometric_of_lt_one hinv0 hinv1]
  have hsub : (1 : ℝ) - B⁻¹ ≠ 0 := by
    have : (0 : ℝ) < 1 - B⁻¹ := by linarith
    exact ne_of_gt this
  have hBm : B - 1 ≠ 0 := by
    have : (0 : ℝ) < B - 1 := by linarith
    exact ne_of_gt this
  field_simp



                                                      

                                                                                           
                                                                                       
                                                                                       
                                                                                         







                                                     

                                                                                             
                                                                                           
                                                                                    
                                                                                           







                                         

                                                                                            
                                                                                              
                                                                                     
                                                        





                           

                                                                                 
                                                                                 
                                                                              



                                               

                                                                               
                                                                               
                                                                               
                                                                               
                                                 





end ErdosProblems.Erdos257.PaperCompleteR7

end
