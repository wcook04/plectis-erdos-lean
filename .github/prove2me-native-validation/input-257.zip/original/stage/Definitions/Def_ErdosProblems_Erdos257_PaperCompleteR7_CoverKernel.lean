import Mathlib.Algebra.Order.Ring.Pow
import Mathlib.Analysis.Convex.SpecificFunctions.Basic
import Mathlib.Analysis.MeanInequalitiesPow
import Mathlib.Analysis.SpecialFunctions.Pow.Continuity
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.Tactic

/-!
# Finite and scalar kernel of the strengthened positive cover

The short note's `thm:variable-fractional-cover` and `res:mixed-supports` are
not available as end-to-end Lean theorems. Their proofs use three ingredients
that are finite or scalar, and those are isolated here as ordinary theorems.

* `rpow_sum_le_sum_rpow` and `rpow_tsum_le_tsum_rpow` are the subadditivity of a
  fractional power used to pass from the dyadic observation mean `U_j(N)` to the
  divisor majorant `V_j(N)`.
* `rpow_neg_le_max_one_inv` is the scalar step `ε ^ (-α) ≤ max 1 ε⁻¹` that makes
  the tail budget choice uniform over the exponents `α_j`.
* `tsum_inv_pow_succ` and `tsum_rpow_two_inv_succ` evaluate the geometric factor
  `1 / (2 ^ α - 1)` appearing in the displayed cost condition (V).

Round 7 wave 2 adds the finite and scalar steps that the same two proofs use
further down: the complete-orbit facts of the observation kernel `w_{B,d}`
(`mul_sub_one_le_pow_sub_one`, `cycle_ratio_le_inv_sub_one`,
`sum_cycle_weight_eq`), the scalar minimisation behind the cover-cost display
(`two_rpow_sub_one_le_self`, `exp_one_mul_le_exp`,
`exp_one_mul_log_le_rpow_div`, which is the second inequality of the note's
cover-log obstruction for every admissible exponent), and the atom inequality
`(b^r-1)/(b^d-1) <= 2 (2^r-1)/(2^d-1)` that carries the base-two conclusion to
every integer base (`atom_base_transfer`), the one-sample step of the averaged
tail test (`exists_lt_of_mean_lt`), and the geometric lower bound of the no-wrap
case (`two_mul_sqrt_mul_le_add`, `card_mul_sqrt_le_geom_sum`).

None of these is the analytic theorem. The irrationality conclusion still needs
the one sampling step that is neither finite nor scalar: a single `N` at which
the averaged tail test `S_J(N) < 1` holds, obtained from the finite estimate (S)
by averaging over the dyadic ranges. The remaining goal is stated as
`StrengthenedPositiveCoverClaim` in `AnalyticTargets.lean`.
-/

noncomputable section

namespace ErdosProblems.Erdos257.PaperCompleteR7

open Finset Filter





/-- The scalar tail-budget bound `ε ^ (-α) ≤ max 1 ε⁻¹`, uniform over the
exponents `0 < α ≤ 1`. -/
theorem rpow_neg_le_max_one_inv {t α : ℝ} (ht : 0 < t) (hα : 0 < α) (hα1 : α ≤ 1) :
    t ^ (-α) ≤ max 1 t⁻¹ := by
  rcases le_total t 1 with h | h
  · have hmono : t ^ (-α) ≤ t ^ (-1 : ℝ) :=
      Real.rpow_le_rpow_of_exponent_ge ht h (by linarith)
    rw [Real.rpow_neg_one] at hmono
    exact hmono.trans (le_max_right _ _)
  · have hone : t ^ (-α) ≤ t ^ (0 : ℝ) :=
      Real.rpow_le_rpow_of_exponent_le h (by linarith)
    rw [Real.rpow_zero] at hone
    exact hone.trans (le_max_left _ _)

/-- The geometric factor of the displayed cost condition. -/
theorem tsum_inv_pow_succ {B : ℝ} (hB : 1 < B) :
    ∑' r : ℕ, (B ^ (r + 1))⁻¹ = 1 / (B - 1) := by
  have hB0 : (0 : ℝ) < B := lt_trans zero_lt_one hB
  have hBne : B ≠ 0 := ne_of_gt hB0
  have hinv0 : (0 : ℝ) ≤ B⁻¹ := by positivity
  have hinv1 : B⁻¹ < 1 := by
    rw [inv_lt_one_iff₀]
    exact Or.inr hB
  have hterm : ∀ r : ℕ, (B ^ (r + 1))⁻¹ = B⁻¹ * (B⁻¹) ^ r := by
    intro r
    rw [pow_succ, mul_inv, ← inv_pow]
    ring
  rw [tsum_congr hterm, tsum_mul_left, tsum_geometric_of_lt_one hinv0 hinv1]
  have hsub : (1 : ℝ) - B⁻¹ ≠ 0 := by
    have : (0 : ℝ) < 1 - B⁻¹ := by linarith
    exact ne_of_gt this
  have hBm : B - 1 ≠ 0 := by
    have : (0 : ℝ) < B - 1 := by linarith
    exact ne_of_gt this
  field_simp



/-! ### Cycle weights of the finite observation kernel

The kernel weight of the short note's estimate (S) is `w_{B,d}(n) = B^(n % d) / (B^d - 1)`.
The two lemmas below are its complete-orbit facts: one full residue cycle carries total
weight exactly `1 / (B - 1)`, and the orbit of a common divisor `g` carries at most the
same total. Both are finite identities in `B`, uniform in `d` as `B` decreases to one. -/







/-! ### The scalar minimisation behind the cover cost

`Ψ(t) = inf_{0 < α ≤ 1} t ^ α / (2 ^ α - 1)` is the cover-independent cost of the short
note's display (eq:cover-log-obstruction). The bound `Ψ(t) ≥ e log t` is proved here for
every admissible exponent, which is the second inequality of that display. The first
inequality, the averaging over `F` against the uniform mean modulo `lcm F`, is not here. -/







/-! ### The base-transfer atom inequality

The short note's proof closes at base two and then transfers to every integer base `b ≥ 2`
through the atom inequality `(b^r - 1)/(b^d - 1) ≤ 2 (2^r - 1)/(2^d - 1)` for `0 ≤ r < d`.
That inequality is finite and is proved here. It is not the transfer step itself: the
displacement estimate it is applied to is still open. -/





/-! ### The one-sample step

The printed proof averages the tail test `S_J` over an observation range and then
says "one sample therefore has `S_J(N) < 1`". That step is finite and is recorded
here in the form the cover proof uses it, over an arbitrary nonempty range. -/



/-! ### The no-wrap case of the finite estimate

When the modulus exceeds twice the observation length there is no wrap, and the
printed proof bounds each atom by `1 / (d (B - 1))` through the geometric lower
bound `sum_{i<d} B^i >= d B^{(d-1)/2}`. That bound is two-term AM-GM applied to
the reflected pairing `B^i + B^{d-1-i}`, and it is proved here. The square root
of `B ^ (d - 1)` is the printed `B^{(d-1)/2}`. -/





end ErdosProblems.Erdos257.PaperCompleteR7

end
