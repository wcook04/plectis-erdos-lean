import Definitions.Def_ErdosProblems_Erdos257_PaperCompleteR8_DyadicDivisorFrames
import Definitions.Def_ErdosProblems_Erdos257_PaperCompleteR8_PrimeHarmonicBlocks
import Mathlib
import Mathlib.NumberTheory.SumPrimeReciprocals
import Mathlib.Tactic

/-!
# Divisor-product masses and the separating host's weighted frame budget

The reciprocal divisor sum is computed from the actual prime product. Its
exponential upper bound and the prescribed harmonic scales give a summable
sequence of literal dyadic frame weights. Identifying these literal weights
with the finite-prime weighted term uses the odd-cofactor valuation identity;
the divergent logarithmic moment is a separate remaining step.
-/
noncomputable section
namespace ErdosProblems.Erdos257.PaperCompleteR8
open Finset









def divisorFrameBudget (P : Finset ℕ) (k : ℕ) : ℝ :=
  (∑ d ∈ (P.prod id).divisors, (1 : ℝ) / d) /
    ((2 : ℝ) ^ (2 ^ (k + 2) : ℕ) - 1)









end ErdosProblems.Erdos257.PaperCompleteR8
end
