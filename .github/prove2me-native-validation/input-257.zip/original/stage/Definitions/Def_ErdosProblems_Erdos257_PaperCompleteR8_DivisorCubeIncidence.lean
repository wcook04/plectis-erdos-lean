import Definitions.Def_ErdosProblems_Erdos257_PaperCompleteR8_DyadicDivisorFrames
import Mathlib

/-!
# Literal divisor cubes and logarithmic incidence

New proof candidates; all elaboration and axiom checks are UNRUN.
The subsets counted below are actual prime subsets, not independent random
variables supplied as an extra assumption. The multiplier q may have common
prime factors with the cube: the relevant rank counts q*p dividing n.
-/
noncomputable section
namespace ErdosProblems.Erdos257.PaperCompleteR8
open Finset

/-- The literal finite divisor cube used in the paper. -/
def divisorCube (q : ℕ) (P : Finset ℕ) : Finset ℕ :=
  (P.prod id).divisors.image (fun d => q * d)

/-- Primes which can be inserted after the mandatory factor q. -/
def cubePrimeRank (q : ℕ) (P : Finset ℕ) (n : ℕ) : ℕ :=
  (P.filter (fun p => q * p ∣ n)).card









/-- Exact dyadic row events, counted as a finite cardinality. -/
def dyadicBlockCount (P : Finset ℕ) (r n : ℕ) : ℕ :=
  (P.filter (fun p => 2 ^ r * p ∣ n ∧ ¬ 2 * (2 ^ r * p) ∣ n)).card









end ErdosProblems.Erdos257.PaperCompleteR8
end
