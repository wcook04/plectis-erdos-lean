import Definitions.Def_Erdos249257_TotientTailPeriodKiller
import Definitions.Def_Erdos249257_CarrySurvivorExtinction
import Definitions.Def_Erdos249257_LcmConeFlatness
import Definitions.Def_Erdos249257_LcmConeNonflat
import Definitions.Def_Erdos249257_SternBrocotRunGeometry
import Definitions.Def_Erdos249257_CertificateKernel
import Definitions.Def_Erdos249257_GenericTailOrbitRigidity
import Definitions.Def_Erdos249257_GreedyAchievementSet
import Definitions.Def_Erdos249257_RationalSupportCarrySkeleton
import Definitions.Def_Erdos249257_ReciprocalSupportIrrationality
import Definitions.Def_Erdos249257_AllBaseReciprocalSupportIrrationality
import Definitions.Def_ErdosProblems_Erdos257_PaperCompleteR7_Displacement
import Definitions.Def_ErdosProblems_Erdos257_PaperCompleteR7_AnalyticTargets
import Definitions.Def_ErdosProblems_Erdos257_PaperCompleteR7_CoverKernel
import Definitions.Def_ErdosProblems_Erdos257_PaperCompleteR8_FiniteMeans
import Definitions.Def_ErdosProblems_Erdos257_PaperCompleteR8_WeightedPrimeProfile
import Definitions.Def_ErdosProblems_Erdos257_PaperCompleteR8_WeightedFiniteEstimates
import Theorems.Thm_ErdosProblems_Erdos257_PaperCompleteR8_kernel_den_pos
import Mathlib
import Mathlib.Algebra.BigOperators.Field
import Mathlib.Algebra.BigOperators.Intervals
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Algebra.Order.Antidiag.Prod
import Mathlib.Algebra.Order.Ring.Pow
import Mathlib.Algebra.Ring.GeomSum
import Mathlib.Analysis.Asymptotics.SpecificAsymptotics
import Mathlib.Analysis.Convex.SpecificFunctions.Basic
import Mathlib.Analysis.MeanInequalitiesPow
import Mathlib.Analysis.Normed.Group.FunctionSeries
import Mathlib.Analysis.Normed.Group.Tannery
import Mathlib.Analysis.Normed.Ring.InfiniteSum
import Mathlib.Analysis.RCLike.Basic
import Mathlib.Analysis.SpecialFunctions.Pow.Continuity
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Data.Finset.NatAntidiagonal
import Mathlib.Data.Nat.Choose.Dvd
import Mathlib.Data.Nat.Factorization.Basic
import Mathlib.Data.Nat.Fib.Basic
import Mathlib.Data.Nat.Find
import Mathlib.Data.Nat.ModEq
import Mathlib.Data.Nat.Totient
import Mathlib.Data.ZMod.Basic
import Mathlib.FieldTheory.Finite.Basic
import Mathlib.LinearAlgebra.Matrix.Determinant.Basic
import Mathlib.MeasureTheory.Group.Measure
import Mathlib.MeasureTheory.Measure.Lebesgue.Basic
import Mathlib.MeasureTheory.Measure.MeasureSpace
import Mathlib.NumberTheory.ArithmeticFunction.Misc
import Mathlib.NumberTheory.ArithmeticFunction.Moebius
import Mathlib.NumberTheory.Bertrand
import Mathlib.NumberTheory.Multiplicity
import Mathlib.NumberTheory.Real.Irrational
import Mathlib.NumberTheory.TsumDivisorsAntidiagonal
import Mathlib.Order.Filter.AtTopBot.Basic
import Mathlib.RingTheory.Polynomial.Cyclotomic.Eval
import Mathlib.RingTheory.Polynomial.Cyclotomic.Expand
import Mathlib.RingTheory.Polynomial.Cyclotomic.Roots
import Mathlib.Tactic
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.GCongr
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.LinearCombination
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.Set
import Mathlib.Topology.Algebra.InfiniteSum.NatInt
import Mathlib.Topology.Algebra.InfiniteSum.Order
import Mathlib.Topology.Algebra.InfiniteSum.Ring
import Mathlib.Topology.GDelta.Basic
import Mathlib.Topology.Order.IntermediateValue
import Mathlib.Topology.Perfect

namespace Erdos257PeriodNoncollapse
end Erdos257PeriodNoncollapse

/-!
# Finite weighted estimates with an explicit observation window

The high-GCD remainder is charged against a dyadic harmonic
bound, not against the cardinality of an unbounded conductor support.
The future-conductor contribution is bounded geometrically before any
infinite interchange. All constants here are deliberately non-sharp.
-/
noncomputable section

namespace ErdosProblems.Erdos257.PaperCompleteR8
open Finset
open ErdosProblems.Erdos257
open ErdosProblems.Erdos257.PaperCompleteR7
end ErdosProblems.Erdos257.PaperCompleteR8

open Finset
open ErdosProblems.Erdos257
open ErdosProblems.Erdos257.PaperCompleteR7
open ErdosProblems in
open ErdosProblems.Erdos257 in
open ErdosProblems.Erdos257.PaperCompleteR8 in
theorem solution (B : ℝ) (hB2 : 2 ≤ B)
    (d N : ℕ) (hNd : N < d) :
    kernelWeight B d N ≤ 2 * (2 : ℝ) ^ N * (1/2 : ℝ) ^ d := by
  have hB : 1 < B := lt_of_lt_of_le (by norm_num) hB2
  have hB0 : 0 < B := lt_trans zero_lt_one hB
  have hd : 0 < d := Nat.zero_lt_of_lt hNd
  have hden : 0 < B ^ d - 1 := kernel_den_pos hB hd
  have hk : 0 < d - N := Nat.sub_pos_of_lt hNd
  have hBk : 0 < B ^ (d - N) := pow_pos hB0 _
  have hBd : (2 : ℝ) ≤ B ^ d :=
    hB2.trans (le_self_pow₀ hB.le hd.ne')
  have hfact : B ^ N * B ^ (d - N) = B ^ d := by
    rw [← pow_add, Nat.add_sub_of_le hNd.le]
  have hfirst : B ^ N / (B ^ d - 1) ≤ 2 / B ^ (d - N) := by
    apply (div_le_div_iff₀ hden hBk).mpr
    rw [hfact]
    linarith only [hBd]
  have hpow : (2 : ℝ) ^ (d - N) ≤ B ^ (d - N) :=
    pow_le_pow_left₀ (by norm_num) hB2 _
  have hsecond : 2 / B ^ (d - N) ≤ 2 / (2 : ℝ) ^ (d - N) :=
    div_le_div_of_nonneg_left (by norm_num) (pow_pos (by norm_num) _) hpow
  have htwo : (2 : ℝ) ^ N * 2 ^ (d - N) = 2 ^ d := by
    rw [← pow_add, Nat.add_sub_of_le hNd.le]
  have hend : 2 / (2 : ℝ) ^ (d - N) =
      2 * (2 : ℝ) ^ N * (1/2 : ℝ) ^ d := by
    rw [one_div, inv_pow]
    calc
      2 / (2 : ℝ) ^ (d-N) = 2 * (2 : ℝ)^N / ((2 : ℝ)^N * 2^(d-N)) := by
        field_simp
      _ = 2 * (2 : ℝ)^N * ((2 : ℝ)^d)⁻¹ := by rw [htwo]; ring
  rw [kernelWeight, Nat.mod_eq_of_lt hNd]
  exact hfirst.trans (hsecond.trans_eq hend)
end
