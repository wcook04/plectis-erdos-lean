import Definitions.Def_Erdos249257_TotientTailPeriodKiller
import Definitions.Def_Erdos249257_CarrySurvivorExtinction
import Definitions.Def_Erdos249257_LcmConeFlatness
import Definitions.Def_Erdos249257_LcmConeNonflat
import Definitions.Def_Erdos249257_SternBrocotRunGeometry
import Definitions.Def_Erdos249257_CertificateKernel
import Definitions.Def_Erdos249257_GenericTailOrbitRigidity
import Definitions.Def_Erdos249257_GreedyAchievementSet
import Definitions.Def_Erdos249257_RationalSupportCarrySkeleton
import Definitions.Def_Erdos249257_ReciprocalSupportIrrationality
import Definitions.Def_Erdos249257_AllBaseReciprocalSupportIrrationality
import Definitions.Def_ErdosProblems_Erdos257_PaperCompleteR7_Displacement
import Definitions.Def_ErdosProblems_Erdos257_PaperCompleteR7_AnalyticTargets
import Definitions.Def_ErdosProblems_Erdos257_PaperCompleteR8_FiniteMeans
import Definitions.Def_ErdosProblems_Erdos257_PaperCompleteR8_KernelRecurrence
import Definitions.Def_ErdosProblems_Erdos257_PaperCompleteR8_CoverPotentialBounds
import Definitions.Def_ErdosProblems_Erdos257_PaperCompleteR8_OptimizedCoverBudget
import Definitions.Def_ErdosProblems_Erdos257_PaperCompleteR8_PositiveCoverReturn
import Definitions.Def_ErdosProblems_Erdos257_PaperCompleteR8_ArbitraryWeightReturns
import Theorems.Thm_ErdosProblems_Erdos257_PaperCompleteR8_coverPotential_nonneg
import Theorems.Thm_ErdosProblems_Erdos257_PaperCompleteR8_coverPotential_le_cost
import Theorems.Thm_ErdosProblems_Erdos257_PaperCompleteR8_thresholdScale_pos
import Theorems.Thm_ErdosProblems_Erdos257_PaperCompleteR8_dyadicMean_const_mul
import Theorems.Thm_ErdosProblems_Erdos257_PaperCompleteR8_dyadicMean_nonneg
import Theorems.Thm_ErdosProblems_Erdos257_PaperCompleteR8_tsum_dyadicMean
import Theorems.Thm_ErdosProblems_Erdos257_PaperCompleteR8_dyadicMean_coverPotential_le
import Mathlib
import Mathlib.Algebra.BigOperators.Field
import Mathlib.Algebra.BigOperators.Intervals
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Algebra.Order.Antidiag.Prod
import Mathlib.Algebra.Order.Ring.Pow
import Mathlib.Algebra.Ring.GeomSum
import Mathlib.Analysis.Asymptotics.SpecificAsymptotics
import Mathlib.Analysis.Convex.SpecificFunctions.Basic
import Mathlib.Analysis.MeanInequalitiesPow
import Mathlib.Analysis.Normed.Group.FunctionSeries
import Mathlib.Analysis.Normed.Group.Tannery
import Mathlib.Analysis.Normed.Ring.InfiniteSum
import Mathlib.Analysis.RCLike.Basic
import Mathlib.Analysis.SpecialFunctions.Pow.Continuity
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Data.Finset.NatAntidiagonal
import Mathlib.Data.Nat.Choose.Dvd
import Mathlib.Data.Nat.Factorization.Basic
import Mathlib.Data.Nat.Fib.Basic
import Mathlib.Data.Nat.Find
import Mathlib.Data.Nat.ModEq
import Mathlib.Data.Nat.Totient
import Mathlib.Data.ZMod.Basic
import Mathlib.FieldTheory.Finite.Basic
import Mathlib.LinearAlgebra.Matrix.Determinant.Basic
import Mathlib.MeasureTheory.Group.Measure
import Mathlib.MeasureTheory.Measure.Lebesgue.Basic
import Mathlib.MeasureTheory.Measure.MeasureSpace
import Mathlib.NumberTheory.ArithmeticFunction.Misc
import Mathlib.NumberTheory.ArithmeticFunction.Moebius
import Mathlib.NumberTheory.Bertrand
import Mathlib.NumberTheory.Multiplicity
import Mathlib.NumberTheory.Real.Irrational
import Mathlib.NumberTheory.TsumDivisorsAntidiagonal
import Mathlib.Order.Filter.AtTopBot.Basic
import Mathlib.RingTheory.Polynomial.Cyclotomic.Eval
import Mathlib.RingTheory.Polynomial.Cyclotomic.Expand
import Mathlib.RingTheory.Polynomial.Cyclotomic.Roots
import Mathlib.Tactic
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.GCongr
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.LinearCombination
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.Set
import Mathlib.Topology.Algebra.InfiniteSum.NatInt
import Mathlib.Topology.Algebra.InfiniteSum.Order
import Mathlib.Topology.Algebra.InfiniteSum.Ring
import Mathlib.Topology.GDelta.Basic
import Mathlib.Topology.Order.IntermediateValue
import Mathlib.Topology.Perfect

/-!
# Actual return supplier for arbitrary strictly positive probability weights

This proves the paper's arbitrary-weight remark. It does not attempt to
re-enumerate an arbitrary probability sequence into geometric weights.
The checked single-column potential and finite-prefix limits are reused.
Build and axiom-audit status belongs to source-bound validation receipts.
-/
noncomputable section

namespace ErdosProblems.Erdos257.PaperCompleteR8
open Finset Filter
open Erdos249257
open ErdosProblems.Erdos257.PaperCompleteR7













theorem summable_thresholdTailTest_terms (C : PositiveCoverData) (t : ℕ → ℝ)
    (ht : ∀ j, 0 < t j) (hs : Summable (thresholdCost C t)) (J N : ℕ) :
    Summable (fun k => thresholdScale C t (k + J) * coverPotential C (k + J) N) := by
  have htail : Summable (fun k => thresholdCost C t (k + J)) :=
    (summable_nat_add_iff J).mpr hs
  apply Summable.of_nonneg_of_le _ _ (htail.mul_left (2 * (N : ℝ) + 1))
  · intro k
    exact mul_nonneg (thresholdScale_pos C t ht (k + J)).le (coverPotential_nonneg C (k + J) N)
  · intro k
    have h := mul_le_mul_of_nonneg_left (coverPotential_le_cost C (k + J) N)
      (thresholdScale_pos C t ht (k + J)).le
    convert h using 1 <;> unfold thresholdCost <;> ring
end ErdosProblems.Erdos257.PaperCompleteR8

open Finset Filter
open Erdos249257
open ErdosProblems.Erdos257.PaperCompleteR7
open ErdosProblems in
open ErdosProblems.Erdos257 in
open ErdosProblems.Erdos257.PaperCompleteR8 in
theorem solution (C : PositiveCoverData) (t : ℕ → ℝ)
    (ht : ∀ j, 0 < t j) (hs : Summable (thresholdCost C t))
    (J L R M : ℕ) (hL : 0 < L) (hM : 0 < M) :
    dyadicMean L R M (thresholdTailTest C t J) ≤
      (1 + 4 * (L : ℝ) / M) * (∑' k, thresholdCost C t (k + J)) := by
  let u : ℕ → ℕ → ℝ := fun k N => thresholdScale C t (k + J) * coverPotential C (k + J) N
  let K : ℝ := 1 + 4 * (L : ℝ) / M
  have hu : ∀ N, Summable (fun k => u k N) := summable_thresholdTailTest_terms C t ht hs J
  have hc : Summable (fun k => thresholdCost C t (k + J)) := (summable_nat_add_iff J).mpr hs
  have hdom : Summable (fun k => K * thresholdCost C t (k + J)) := hc.mul_left K
  have hp : ∀ k, dyadicMean L R M (u k) ≤ K * thresholdCost C t (k + J) := by
    intro k
    change dyadicMean L R M (fun N => thresholdScale C t (k + J) * coverPotential C (k + J) N) ≤ _
    rw [dyadicMean_const_mul]
    have h := mul_le_mul_of_nonneg_left
      (dyadicMean_coverPotential_le C (k + J) L R M hL hM)
      (thresholdScale_pos C t ht (k + J)).le
    convert h using 1 <;> dsimp [K, thresholdCost] <;> ring
  have hleft : Summable (fun k => dyadicMean L R M (u k)) := by
    refine Summable.of_nonneg_of_le ?_ hp hdom
    intro k
    exact dyadicMean_nonneg L R M (u k) (fun N =>
      mul_nonneg (thresholdScale_pos C t ht (k + J)).le (coverPotential_nonneg C (k + J) N))
  have h := Summable.tsum_le_tsum hp hleft hdom
  rw [tsum_dyadicMean u hu L R M, tsum_mul_left] at h
  exact h
end
