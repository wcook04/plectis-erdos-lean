import Mathlib

namespace ErdosProblems.Erdos257.DyadicShellSynchronisation
end ErdosProblems.Erdos257.DyadicShellSynchronisation

/-!
# Finite interfaces for dyadic-shell synchronisation

Candidate module supplied with the round-5 ordinary proof. NOT COMPILED in
this return. There are no admitted propositions or added axioms in this file.

These lemmas isolate finite gluing and witness extraction. They do not
formalise the modular-atom estimate, the countable sums, the weighted
schedule, or the mixed-support irrationality theorem. Those obligations are
listed in the accompanying formalisation plan. All analytic hypotheses below
are explicit premises.
-/

open ErdosProblems in
open ErdosProblems.Erdos257 in
open ErdosProblems.Erdos257.DyadicShellSynchronisation in
theorem solution
    {ι : Type*} (s : Finset ι) (m : ℕ) (hm : 0 < m)
    (hcard : s.card = m) (L a : ℝ) (u near transition : ι → ℝ)
    (hpoint : ∀ i ∈ s, u i ≤ a + near i + transition i)
    (hnear : ∑ i ∈ s, near i ≤ 2 * L * a)
    (htransition : ∑ i ∈ s, transition i ≤ 2 * L * a) :
    (∑ i ∈ s, u i) / (m : ℝ) ≤ (1 + 4 * L / m) * a := by
  have hmR : 0 < (m : ℝ) := by exact_mod_cast hm
  have hsum : (∑ i ∈ s, u i) ≤ (m : ℝ) * a + 4 * L * a := by
    calc
      (∑ i ∈ s, u i) ≤ ∑ i ∈ s, (a + near i + transition i) :=
        Finset.sum_le_sum hpoint
      _ = (m : ℝ) * a + (∑ i ∈ s, near i) +
          (∑ i ∈ s, transition i) := by
        simp only [Finset.sum_add_distrib, Finset.sum_const,
          nsmul_eq_mul, hcard]
      _ ≤ (m : ℝ) * a + 4 * L * a := by linarith
  apply (div_le_iff₀ hmR).2
  calc
    (∑ i ∈ s, u i) ≤ (m : ℝ) * a + 4 * L * a := hsum
    _ = ((1 + 4 * L / (m : ℝ)) * a) * m := by
      field_simp [ne_of_gt hmR]
      <;> ring
