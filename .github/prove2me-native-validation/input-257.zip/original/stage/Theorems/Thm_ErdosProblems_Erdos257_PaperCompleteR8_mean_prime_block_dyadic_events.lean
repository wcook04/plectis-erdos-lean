import Definitions.Def_ErdosProblems_Erdos257_CoverIndependentPeriodicMean
import Mathlib

namespace ErdosProblems.Erdos257.PaperCompleteR8
end ErdosProblems.Erdos257.PaperCompleteR8

/-! # Exact finite-period counts for dyadic logarithmic events

For the separating divisor frames, the event for a prime in row k is
2^(k+2)*p divides n but 2^(k+3)*p does not. Counting it by subtraction
avoids probabilistic independence assumptions or limiting density suppliers.
-/
open Finset

open ErdosProblems.Erdos257.PaperCompleteR8

theorem ErdosProblems.Erdos257.PaperCompleteR8.mean_prime_block_dyadic_events (P : Finset ℕ) (r X : ℕ)
    (hP : ∀ p ∈ P, 0 < p) (hX : 0 < X)
    (hperiod : ∀ p ∈ P, 2 * (2 ^ r * p) ∣ X) :
    (∑ n ∈ Icc 1 X, ∑ p ∈ P,
      if 2 ^ r * p ∣ n ∧ ¬ 2 * (2 ^ r * p) ∣ n then (1 : ℝ) else 0) /
        (X : ℝ) =
      (∑ p ∈ P, (1 : ℝ) / p) / (2 * (2 : ℝ) ^ r) := by sorry
