import Definitions.Def_ErdosProblems_Erdos257_PaperCompleteR8_DyadicDivisorFrames
import Definitions.Def_ErdosProblems_Erdos257_PaperCompleteR8_DivisorCubeIncidence
import Mathlib

/-!
# Literal divisor cubes and logarithmic incidence

New proof candidates; all elaboration and axiom checks are UNRUN.
The subsets counted below are actual prime subsets, not independent random
variables supplied as an extra assumption. The multiplier q may have common
prime factors with the cube: the relevant rank counts q*p dividing n.
-/
noncomputable section
open Finset

open ErdosProblems.Erdos257.PaperCompleteR8

theorem ErdosProblems.Erdos257.PaperCompleteR8.odd_cofactor_of_dyadic_event (r p n : ℕ) (hp : ¬ 2 ∣ p)
    (he : 2 ^ r * p ∣ n ∧ ¬ 2 * (2 ^ r * p) ∣ n) :
    ∃ u : ℕ, ¬ 2 ∣ u ∧ n = 2 ^ r * u := by sorry
end
