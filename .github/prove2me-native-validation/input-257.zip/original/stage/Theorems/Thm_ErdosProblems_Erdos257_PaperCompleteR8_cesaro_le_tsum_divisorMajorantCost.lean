import Definitions.Def_ErdosProblems_Erdos257_CoverIndependentPeriodicMean
import Definitions.Def_ErdosProblems_Erdos257_PaperCompleteR7_CoverKernel
import Mathlib
import Mathlib.Algebra.Order.Ring.Pow
import Mathlib.Analysis.Convex.SpecificFunctions.Basic
import Mathlib.Analysis.MeanInequalitiesPow
import Mathlib.Analysis.SpecialFunctions.Pow.Continuity
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.Tactic

namespace ErdosProblems.Erdos257.PaperCompleteR8
end ErdosProblems.Erdos257.PaperCompleteR8

/-!
# Countable positive-cover first logarithmic moment

A finite test support admits a finite subcover. The omitted frame weights
are retained as a subprobability inequality, so no renormalisation cost is
lost. Countable divisor majorants are truncated only at the actual finite
observation horizon; their reciprocal costs are bounded by their convergent
series. The endpoint assumes summability of the explicit total cover cost,
not the logarithmic obstruction it proves.
-/
noncomputable section
open Finset
open ErdosProblems.Erdos257.PaperCompleteR7

open ErdosProblems.Erdos257.PaperCompleteR8

theorem ErdosProblems.Erdos257.PaperCompleteR8.cesaro_le_tsum_divisorMajorantCost
    (g c : ℕ → ℝ) (X : ℕ) (hX : 0 < X)
    (hg : ∀ n, 0 ≤ g n) (hc : ∀ d, 0 < d → 0 ≤ c d)
    (hs : Summable (fun d : ℕ => c d / (d : ℝ)))
    (hmaj : ∀ n, 0 < n → g n ≤ ∑ d ∈ n.divisors, c d) :
    (∑ n ∈ Finset.Icc 1 X, g n) / X ≤ ∑' d : ℕ, c d / (d : ℝ) := by sorry
end
