import Definitions.Def_ErdosProblems_Erdos257_PaperCompleteR8_DyadicDivisorFrames
import Definitions.Def_ErdosProblems_Erdos257_PaperCompleteR8_DivisorCubeIncidence
import Mathlib

/-!
# Literal divisor cubes and logarithmic incidence

New proof candidates; all elaboration and axiom checks are UNRUN.
The subsets counted below are actual prime subsets, not independent random
variables supplied as an extra assumption. The multiplier q may have common
prime factors with the cube: the relevant rank counts q*p dividing n.
-/
noncomputable section
open Finset

open ErdosProblems.Erdos257.PaperCompleteR8

theorem ErdosProblems.Erdos257.PaperCompleteR8.dyadic_union_log_pointwise (P : ℕ → Finset ℕ) (J : Finset ℕ) (n : ℕ)
    (hn : 0 < n) (hP : ∀ k p, p ∈ P k → Nat.Prime p ∧ 2 < p) :
    Real.log 2 * (∑ k ∈ J, (dyadicBlockCount (P k) (k + 2) n : ℝ)) ≤
      Real.log (((J.biUnion (fun k => dyadicDivisorFrame ((P k).prod id) k)).filter
        (fun a => a ∣ n)).card : ℝ) := by sorry
end
