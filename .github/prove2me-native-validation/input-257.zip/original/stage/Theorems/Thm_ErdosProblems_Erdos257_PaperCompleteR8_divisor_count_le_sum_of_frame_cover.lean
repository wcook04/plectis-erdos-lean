import Definitions.Def_ErdosProblems_Erdos257_CoverIndependentPeriodicMean
import Definitions.Def_ErdosProblems_Erdos257_PaperCompleteR7_CoverKernel
import Mathlib
import Mathlib.Algebra.Order.Ring.Pow
import Mathlib.Analysis.Convex.SpecificFunctions.Basic
import Mathlib.Analysis.MeanInequalitiesPow
import Mathlib.Analysis.SpecialFunctions.Pow.Continuity
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.Tactic

namespace ErdosProblems.Erdos257.PaperCompleteR8
end ErdosProblems.Erdos257.PaperCompleteR8

/-!
# Finite positive-cover logarithmic budget

The scalar logarithmic bound is combined with actual divisor-majorant
averaging. Frames may overlap: only domination of the incidence count by
the sum of frame counts is used. The family and each divisor majorant are
finite. This does not assert the countable-cover obstruction or construct
the infinite class-separating host.
-/
noncomputable section
open Finset
open ErdosProblems.Erdos257.PaperCompleteR7

open ErdosProblems.Erdos257.PaperCompleteR8

theorem ErdosProblems.Erdos257.PaperCompleteR8.divisor_count_le_sum_of_frame_cover (F J : Finset ℕ)
    (G : ℕ → Finset ℕ) (hcover : F ⊆ J.biUnion G) (n : ℕ) :
    (F.filter (fun a => a ∣ n)).card ≤
      ∑ j ∈ J, ((G j).filter (fun a => a ∣ n)).card := by sorry
end
