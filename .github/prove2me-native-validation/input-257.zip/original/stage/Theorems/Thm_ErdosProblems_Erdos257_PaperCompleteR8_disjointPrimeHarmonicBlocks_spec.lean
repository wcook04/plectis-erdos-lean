import Definitions.Def_ErdosProblems_Erdos257_PaperCompleteR8_PrimeHarmonicBlocks
import Mathlib.NumberTheory.SumPrimeReciprocals
import Mathlib.Tactic

/-!
# Prime harmonic blocks with bounded overshoot

Reciprocal-prime divergence supplies a finite block beyond any finite forbidden
set. A finite threshold-crossing argument limits overshoot to one. Recursive
exclusion of all earlier blocks then gives pairwise disjoint odd-prime blocks
at any prescribed nonnegative harmonic scales. No weighted or logarithmic
moment assertion about their divisor frames is assumed here.
-/
noncomputable section
open Finset

open ErdosProblems.Erdos257.PaperCompleteR8

theorem ErdosProblems.Erdos257.PaperCompleteR8.disjointPrimeHarmonicBlocks_spec (R : ℕ → ℝ) (hR : ∀ k, 0 ≤ R k) :
    Pairwise (fun k l => Disjoint (disjointPrimeHarmonicBlock R hR k)
      (disjointPrimeHarmonicBlock R hR l)) ∧
    ∀ k, (∀ p ∈ disjointPrimeHarmonicBlock R hR k, Nat.Prime p ∧ 2 < p) ∧
      R k ≤ ∑ p ∈ disjointPrimeHarmonicBlock R hR k, (1 : ℝ) / p ∧
      (∑ p ∈ disjointPrimeHarmonicBlock R hR k, (1 : ℝ) / p) ≤ R k + 1 := by sorry
end
