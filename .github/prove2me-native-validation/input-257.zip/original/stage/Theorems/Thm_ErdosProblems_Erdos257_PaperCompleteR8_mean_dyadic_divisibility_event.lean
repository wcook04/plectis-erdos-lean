import Definitions.Def_ErdosProblems_Erdos257_CoverIndependentPeriodicMean
import Mathlib

namespace ErdosProblems.Erdos257.PaperCompleteR8
end ErdosProblems.Erdos257.PaperCompleteR8

/-! # Exact finite-period counts for dyadic logarithmic events

For the separating divisor frames, the event for a prime in row k is
2^(k+2)*p divides n but 2^(k+3)*p does not. Counting it by subtraction
avoids probabilistic independence assumptions or limiting density suppliers.
-/
open Finset

open ErdosProblems.Erdos257.PaperCompleteR8

theorem ErdosProblems.Erdos257.PaperCompleteR8.mean_dyadic_divisibility_event (d X : ℕ) (hd : 0 < d)
    (hX : 0 < X) (hperiod : 2 * d ∣ X) :
    (∑ n ∈ Icc 1 X, if d ∣ n ∧ ¬ 2 * d ∣ n then (1 : ℝ) else 0) /
        (X : ℝ) = 1 / (2 * (d : ℝ)) := by sorry
