import Definitions.Def_ErdosProblems_Erdos257_CoverIndependentPeriodicMean
import Mathlib

/-!
# Cover-independent periodic means

Lemma A.1 of the 2026-09-06 Type B revision return: a nonnegative divisor
majorant of `g` controls every Cesàro average of `g`, hence every periodic
mean. This is not an irrationality theorem. It bounds cover cost.

The coprime-cover obstruction (Type B Theorem B.1) uses this averaging plus
the elementary density `1 - ∏(1 - 1/a)`; that density identity is recorded
as an ordinary proof in `VariableExponentCoverSeparation.md`.
-/


open Finset

open ErdosProblems.Erdos257

theorem ErdosProblems.Erdos257.cesaro_le_divisorMajorantCost
    (g : ℕ → ℝ) (D : Finset ℕ) (c : ℕ → ℝ) (X : ℕ)
    (hX : 0 < X)
    (hD : ∀ d ∈ D, 0 < d)
    (hc : ∀ d ∈ D, 0 ≤ c d)
    (hg0 : ∀ n, 0 ≤ g n)
    (hmaj : ∀ n, 0 < n → g n ≤ ∑ d ∈ D.filter (fun d => d ∣ n), c d) :
    (∑ n ∈ Icc 1 X, g n) / X ≤ divisorMajorantCost D c := by sorry
