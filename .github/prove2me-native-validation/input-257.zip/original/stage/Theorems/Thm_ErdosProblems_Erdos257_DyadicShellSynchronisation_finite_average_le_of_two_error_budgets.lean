import Mathlib

namespace ErdosProblems.Erdos257.DyadicShellSynchronisation
end ErdosProblems.Erdos257.DyadicShellSynchronisation

/-!
# Finite interfaces for dyadic-shell synchronisation

Candidate module supplied with the round-5 ordinary proof. NOT COMPILED in
this return. There are no admitted propositions or added axioms in this file.

These lemmas isolate finite gluing and witness extraction. They do not
formalise the modular-atom estimate, the countable sums, the weighted
schedule, or the mixed-support irrationality theorem. Those obligations are
listed in the accompanying formalisation plan. All analytic hypotheses below
are explicit premises.
-/

open ErdosProblems.Erdos257.DyadicShellSynchronisation

theorem ErdosProblems.Erdos257.DyadicShellSynchronisation.finite_average_le_of_two_error_budgets
    {ι : Type*} (s : Finset ι) (m : ℕ) (hm : 0 < m)
    (hcard : s.card = m) (L a : ℝ) (u near transition : ι → ℝ)
    (hpoint : ∀ i ∈ s, u i ≤ a + near i + transition i)
    (hnear : ∑ i ∈ s, near i ≤ 2 * L * a)
    (htransition : ∑ i ∈ s, transition i ≤ 2 * L * a) :
    (∑ i ∈ s, u i) / (m : ℝ) ≤ (1 + 4 * L / m) * a := by sorry
