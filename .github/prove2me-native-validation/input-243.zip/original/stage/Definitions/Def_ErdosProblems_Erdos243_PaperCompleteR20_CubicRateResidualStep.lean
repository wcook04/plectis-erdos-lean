import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR20_CubicRateFiniteDifference
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR20_CubicRateDifferenceLimits
import Mathlib

/-!
# Erdős 243: the cubic-rate residual recurrence

This is the exact algebraic step between the ratio comparison and the finite
difference argument.  The additive recurrence defect and the sublinear
residual together force the first residual difference to tend to zero.
-/

noncomputable section

namespace ErdosProblems.Erdos243.PaperCompleteR20

open Filter

/-- The additive defect from the cubic model ratio `1 + 3/n`. -/
def cubicAdditiveDefect (C : ℕ → ℝ) (n : ℕ) : ℝ :=
  C (n + 1) - (1 + 3 / (n : ℝ)) * C n










end ErdosProblems.Erdos243.PaperCompleteR20
