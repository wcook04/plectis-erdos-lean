import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_CubicSquareCoordinates
import Mathlib
import Mathlib.RingTheory.PowerBasis

/-!
# Extracting the square-root coordinates from a cubic algebra

The power-basis representation is extracted from the actual square root.
The degree bound then forces all three rational coordinate equations.
No trace, norm, coordinate equation, or coefficient relation is assumed.
-/

namespace ErdosProblems.Erdos243.PaperCompleteR11

open Polynomial
open scoped BigOperators

noncomputable section

def cubicScalePolynomial (η : ℚ) : ℚ[X] := X^3 - X + C η











end

end ErdosProblems.Erdos243.PaperCompleteR11
