import Mathlib

   
                                           

                                                    

                                                                  
                                                                       
                                                                  
                                                                        
                                                                         
                                                                        
                                                                      

                                                             
                                                                       
                                                                   
  

namespace ErdosProblems.Erdos243.PaperCompleteR11

def cubicCoordinateB (x z : ℚ) : ℚ := -2*x-3*z

def cubicCoordinateD (x y z η : ℚ) : ℚ :=
  3*η*x*y + 3*η*x + x^2 + 4*x*z - y^2 - 2*y + 3*z^2 - 1

def cubicCoordinateW (x y z η : ℚ) : ℚ :=
  -η^2*x^3 - η*x^2*y - η*x^2 - 3*η*x*y*z - 3*η*x*z +
    η*y^3 + 3*η*y^2 + 3*η*y + η - x^2*z - 2*x*z^2 + y^2*z + 2*y*z - z^3 + z











end ErdosProblems.Erdos243.PaperCompleteR11
