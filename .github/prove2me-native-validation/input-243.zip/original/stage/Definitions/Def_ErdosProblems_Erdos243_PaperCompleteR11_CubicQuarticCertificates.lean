import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR9_PolynomialCorrections
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_WindowIncidence
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_CubicIntegralNormalisation
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_CubicQuarticWindows
import Mathlib
import Mathlib.Algebra.Order.BigOperators.GroupWithZero.Finset
import Mathlib.Algebra.Ring.Basic
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.Data.Fin.Pigeonhole
import Mathlib.Data.Int.GCD
import Mathlib.Data.Nat.ChineseRemainder
import Mathlib.Data.Nat.Choose.Basic
import Mathlib.Data.Nat.Find
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.Rat.Defs
import Mathlib.Data.ZMod.Basic
import Mathlib.Data.ZMod.QuotientRing
import Mathlib.Order.Filter.AtTopBot.Basic
import Mathlib.Tactic
import Mathlib.Tactic.Ring

/-!
# Explicit small-prime quartic certificates

Authored, UNRUN. Each certificate has an explicit root and a finite `decide`
proof body; no Python result is imported as a proof. The independent exact
arithmetic suite regenerates and exhaustively checks these data. The theorems
cover coefficient congruence classes, not all integer coefficient pairs.
-/

namespace ErdosProblems.Erdos243.PaperCompleteR11


local instance instFactPrimeOfNatNat_erdosProblems_1 : Fact (Nat.Prime 7) := ⟨by decide⟩








































end ErdosProblems.Erdos243.PaperCompleteR11
