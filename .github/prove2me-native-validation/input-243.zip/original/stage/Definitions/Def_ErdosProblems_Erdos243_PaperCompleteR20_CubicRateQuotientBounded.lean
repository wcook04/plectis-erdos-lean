import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR20_CubicRateFiniteDifference
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR20_CubicRateDifferenceLimits
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR20_CubicRateResidualStep
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR20_CubicRateDefect
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR20_CubicRateNormalisation
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR20_CubicRateQuotientIncrement
import Mathlib
import Mathlib.Analysis.PSeries
import Mathlib.Analysis.SpecialFunctions.Log.Summable

/-!
# Erdős 243: boundedness of the cubic quotient

The literal `o(n⁻³)` relative error is summable.  Iterating the exact quotient
recurrence therefore expresses the quotient as a fixed initial value times a
convergent infinite-product prefix, which is eventually bounded.
-/

noncomputable section

namespace ErdosProblems.Erdos243.PaperCompleteR20

open Filter Finset

def cubicRelativeError (C : ℕ → ℝ) (n : ℕ) : ℝ :=
  cubicRatioError C n / (1 + 3 / (n : ℝ))










end ErdosProblems.Erdos243.PaperCompleteR20
