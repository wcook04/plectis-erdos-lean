import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR9_PolynomialCorrections
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_WindowIncidence
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_CubicIntegralNormalisation
import Mathlib
import Mathlib.Algebra.Order.BigOperators.GroupWithZero.Finset
import Mathlib.Algebra.Ring.Basic
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.Data.Fin.Pigeonhole
import Mathlib.Data.Int.GCD
import Mathlib.Data.Nat.ChineseRemainder
import Mathlib.Data.Nat.Choose.Basic
import Mathlib.Data.Nat.Find
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.Rat.Defs
import Mathlib.Data.ZMod.Basic
import Mathlib.Data.ZMod.QuotientRing
import Mathlib.Order.Filter.AtTopBot.Basic
import Mathlib.Tactic
import Mathlib.Tactic.Ring

/-!
# Four-term cubic words and a quartic obstruction

Authored proof candidates; Lean elaboration and actual axiom checks are UNRUN.
A word (x,y,0,t) in an exact reciprocal orbit forces
  (d*(d+y))^2 = -x^2*y*t.
This retains a compatibility equation lost by using only the three-term word
(y,0,t). No primitivity, unit constant, or infinite prime family is assumed.
-/

namespace ErdosProblems.Erdos243.PaperCompleteR11





/-- Values at distances two to the left, one to the left and one to the right
of a root of a depressed cubic, after subtracting its root equation. -/
def cubicLeftTwo {R : Type*} [CommRing R] (r : R) : R := -6 * (r - 1) ^ 2

def cubicLeftOne {R : Type*} [CommRing R] (r : R) : R := -3 * r * (r - 1)

def cubicRightOne {R : Type*} [CommRing R] (r : R) : R := 3 * r * (r + 1)

/-- A finite-field certificate that the four-term word cannot occur. -/
def CubicQuarticNonresidue {R : Type*} [CommRing R] (r : R) : Prop :=
  ∀ d : R, (d * (d + cubicLeftOne r)) ^ 2 ≠
    -(cubicLeftTwo r) ^ 2 * cubicLeftOne r * cubicRightOne r

/-- A concrete coefficient ratio is covered when it has an obstructed root. -/
def CubicQuarticWitness (p : ℕ) (ρ : ZMod p) : Prop :=
  ∃ r : ZMod p, r ^ 3 - r + 6 * ρ = 0 ∧ CubicQuarticNonresidue r











end ErdosProblems.Erdos243.PaperCompleteR11
