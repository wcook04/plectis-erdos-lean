import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR20_CubicRateFiniteDifference
import Mathlib

/-!
# Erdős 243: limit transport for the cubic finite-difference extraction

The paper's analytic comparison produces a residual whose first forward
difference tends to zero.  This file proves that this is exactly enough for
the fourth difference of the integer numerator to tend to zero, because the
rising cubic has identically zero fourth difference.
-/

noncomputable section

namespace ErdosProblems.Erdos243.PaperCompleteR20

open Filter

def realForwardDiff (u : ℕ → ℝ) (n : ℕ) : ℝ := u (n + 1) - u n

def iterRealForwardDiff : ℕ → (ℕ → ℝ) → ℕ → ℝ
  | 0, u => u
  | k + 1, u => realForwardDiff (iterRealForwardDiff k u)















/-- The rising cubic used in the paper. -/
def risingCubic (n : ℕ) : ℝ := (n : ℝ) * (n + 1) * (n + 2)








end ErdosProblems.Erdos243.PaperCompleteR20
