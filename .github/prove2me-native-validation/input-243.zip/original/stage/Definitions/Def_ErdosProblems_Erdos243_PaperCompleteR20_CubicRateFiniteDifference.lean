import Mathlib

/-!
# Erdős 243: integer finite differences for the cubic-rate bridge

This file isolates the discrete integrality step in the proof of the paper's
cubic-rate theorem.  Once the analytic comparison with the rising-factorial
model shows that a sufficiently high finite difference tends to zero, its
integer values force it to vanish identically on a tail.
-/

noncomputable section

namespace ErdosProblems.Erdos243.PaperCompleteR20

open Filter

/-- The forward difference of an integer sequence. -/
def intForwardDiff (u : ℕ → ℤ) (n : ℕ) : ℤ := u (n + 1) - u n

/-- Iterated integer forward differences. -/
def iterIntForwardDiff : ℕ → (ℕ → ℤ) → ℕ → ℤ
  | 0, u => u
  | k + 1, u => intForwardDiff (iterIntForwardDiff k u)














end ErdosProblems.Erdos243.PaperCompleteR20
