import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR20_CubicRateFiniteDifference
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR20_CubicRateDifferenceLimits
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR20_CubicRateResidualStep
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR20_CubicRateDefect
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR20_CubicRateNormalisation
import Mathlib

/-!
# Erdős 243: quotient increments at the cubic rate
-/

noncomputable section

namespace ErdosProblems.Erdos243.PaperCompleteR20

open Filter

def cubicQuotient (C : ℕ → ℝ) (n : ℕ) : ℝ := C n / risingCubic n








end ErdosProblems.Erdos243.PaperCompleteR20
