import Definitions.Def_ErdosProblems_Erdos243_ReciprocalTailRigidity
import Definitions.Def_ErdosProblems_Erdos243_GlobalLcmHeight
import Definitions.Def_ErdosProblems_Erdos243_CumulativeLcmTransfer
import Definitions.Def_ErdosProblems_Erdos243_LcmRecordCrossing
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR7_Limits
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR7_RealTail
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR7_CanonicalState
import Definitions.Def_ErdosProblems_Erdos243_PrimitiveRecordBarrier
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_RecordDivisibility
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR7_ProductDefect
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR7_LcmDefect
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_GrowthRecordEquivalence
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_CanonicalGrowthBounds
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_CoprimeCores
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_LogLogNormaliser
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_OrbitBlockArithmetic
import Theorems.Thm_ErdosProblems_Erdos243_PaperCompleteR11_binaryTower_pos
import Theorems.Thm_ErdosProblems_Erdos243_PaperCompleteR11_square_block_exponent_budget
import Mathlib
import Mathlib.Algebra.Order.BigOperators.GroupWithZero.Finset
import Mathlib.Algebra.Ring.Basic
import Mathlib.Analysis.SpecialFunctions.Log.Basic
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Analysis.SumIntegralComparisons
import Mathlib.Data.Fin.Pigeonhole
import Mathlib.Data.Fintype.BigOperators
import Mathlib.Data.Nat.ChineseRemainder
import Mathlib.Data.Nat.Factorization.Basic
import Mathlib.Data.Nat.Find
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.Rat.Defs
import Mathlib.Data.ZMod.Basic
import Mathlib.Order.Filter.AtTopBot.Basic
import Mathlib.Tactic
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.InfiniteSum.NatInt

/-!
# Explicit square-sized blocks for the inclusive boundary

These bounds apply simultaneously
throughout a block whose width grows with the selection parameter. They
replace the previously missing uniform `ceil(log B)` estimates with exact
natural arithmetic on the cofinal choices `k = 2^t`, `B = k^2`.
-/

namespace ErdosProblems.Erdos243.PaperCompleteR11
open scoped BigOperators
end ErdosProblems.Erdos243.PaperCompleteR11

open scoped BigOperators
open ErdosProblems in
open ErdosProblems.Erdos243 in
open ErdosProblems.Erdos243.PaperCompleteR11 in
theorem solution (U : ℕ → ℕ) (K N t : ℕ)
    (ht : 5 ≤ t) (hKN : K + N ≤ 2 ^ t)
    (hH : runningMax U (N + 2 ^ t + (2 ^ t) ^ 2) ≤
      2 ^ (K + (N + 2 ^ t + (2 ^ t) ^ 2)))
    (A : Fin ((2 ^ t) ^ 2) → ℕ)
    (hA : ∀ i, 2 * binaryTower (2 ^ t) ≤ A i) :
    ∀ i, max ((2 ^ t) ^ 2) (runningMax U (N + 2 ^ t + (2 ^ t) ^ 2)) *
      (runningMax U (N + 2 ^ t + (2 ^ t) ^ 2)) ^ ((2 ^ t) ^ 2 - 1) < A i := by
  let B := (2 ^ t) ^ 2
  let M := N + 2 ^ t + B
  let H := runningMax U M
  let V := 2 ^ (K + M)
  have hB : 1 ≤ B := by
    dsimp [B]
    exact Nat.one_le_pow 2 (2 ^ t) (pow_pos (by norm_num) t)
  have hBV : B ≤ V := by
    have hindex := index_succ_le_two_pow M
    have hmono := two_pow_mono (show M ≤ K + M by omega)
    dsimp [M, V] at *
    omega
  have hHV : H ≤ V := hH
  have hexp := square_block_exponent_budget K N t ht hKN
  intro i
  calc
    max B H * H ^ (B - 1) ≤ V * V ^ (B - 1) :=
      Nat.mul_le_mul (max_le hBV hHV) (Nat.pow_le_pow_left hHV _)
    _ = V ^ B := by
      calc
        _ = V ^ (B - 1 + 1) := by rw [pow_succ]; ring
        _ = V ^ B := by rw [Nat.sub_add_cancel hB]
    _ = 2 ^ ((K + M) * B) := by dsimp [V]; rw [pow_mul]
    _ ≤ binaryTower (2 ^ t) := two_pow_mono hexp
    _ < 2 * binaryTower (2 ^ t) := by have := binaryTower_pos (2 ^ t); omega
    _ ≤ A i := hA i
