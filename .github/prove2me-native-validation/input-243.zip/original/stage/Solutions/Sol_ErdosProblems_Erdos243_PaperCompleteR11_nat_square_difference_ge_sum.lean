import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_CubicSquareCoordinates
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_CubicFieldCoordinates
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR9_PolynomialCorrections
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_WindowIncidence
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_CubicIntegralNormalisation
import Mathlib
import Mathlib.Algebra.Order.BigOperators.GroupWithZero.Finset
import Mathlib.Algebra.Polynomial.SpecificDegree
import Mathlib.Algebra.Ring.Basic
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.Data.Fin.Pigeonhole
import Mathlib.Data.Int.GCD
import Mathlib.Data.Nat.ChineseRemainder
import Mathlib.Data.Nat.Choose.Basic
import Mathlib.Data.Nat.Find
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.Rat.Defs
import Mathlib.Data.ZMod.Basic
import Mathlib.Data.ZMod.QuotientRing
import Mathlib.Order.Filter.AtTopBot.Basic
import Mathlib.RingTheory.PowerBasis
import Mathlib.Tactic
import Mathlib.Tactic.Ring

/-!
# Complete rational-root classification for unit-constant cubic profiles

Authored proof candidates, UNRUN. For m > 0 and c = ±1, a rational root of
m*(X^3-X)+6*c forces m = 1 or m = 16. The reduced numerator and denominator
are constructed from the root. The resulting entire reducible unit branch
has exceptional lower density at least 1/5, by the existing explicit prime.
The unit premise is retained: it is NOT inferred from a positive-density bound.
-/

open ErdosProblems.Erdos243.PaperCompleteR11 in
theorem solution (s t : ℕ) (hst : s < t) :
    s + t ≤ t ^ 2 - s ^ 2 := by
  have hle : s ≤ t := Nat.le_of_lt hst
  have hpow : s ^ 2 ≤ t ^ 2 := by nlinarith
  have hid : (t - s) * (s + t) + s ^ 2 = t ^ 2 := by
    calc
      (t - s) * (s + t) + s ^ 2 = (t - s) * t + s * (t - s + s) := by ring
      _ = (t - s) * t + s * t := by rw [Nat.sub_add_cancel hle]
      _ = (t - s + s) * t := by ring
      _ = t ^ 2 := by rw [Nat.sub_add_cancel hle]; ring
  have hdiff : (t - s) * (s + t) = t ^ 2 - s ^ 2 := by omega
  have hh := Nat.mul_le_mul_right (s + t) (show 1 ≤ t - s by omega)
  simpa only [one_mul, hdiff] using hh
