import Definitions.Def_ErdosProblems_Erdos243_ReciprocalTailRigidity
import Definitions.Def_ErdosProblems_Erdos243_GlobalLcmHeight
import Definitions.Def_ErdosProblems_Erdos243_CumulativeLcmTransfer
import Definitions.Def_ErdosProblems_Erdos243_LcmRecordCrossing
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR7_Limits
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR7_RealTail
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR7_CanonicalState
import Definitions.Def_ErdosProblems_Erdos243_PrimitiveRecordBarrier
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_RecordDivisibility
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR7_ProductDefect
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR7_LcmDefect
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_GrowthRecordEquivalence
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_CanonicalGrowthBounds
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_CoprimeCores
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_LogLogNormaliser
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_OrbitBlockArithmetic
import Mathlib
import Mathlib.Algebra.Order.BigOperators.GroupWithZero.Finset
import Mathlib.Algebra.Ring.Basic
import Mathlib.Analysis.SpecialFunctions.Log.Basic
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Analysis.SumIntegralComparisons
import Mathlib.Data.Fin.Pigeonhole
import Mathlib.Data.Fintype.BigOperators
import Mathlib.Data.Nat.ChineseRemainder
import Mathlib.Data.Nat.Factorization.Basic
import Mathlib.Data.Nat.Find
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.Rat.Defs
import Mathlib.Data.ZMod.Basic
import Mathlib.Order.Filter.AtTopBot.Basic
import Mathlib.Tactic
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.InfiniteSum.NatInt

namespace PaperCompleteR7
end PaperCompleteR7

/-!
# The nonprimitive coefficient-one lower boundary


This module performs the growing-block selection and the logarithmic
composition, rather than taking the needed block as a hypothesis. The
canonical corollary derives all growth budgets from the original series.
It proves the subcritical part, not the strict primitive amplification
which is needed for the inclusive coefficient-one endpoint.
-/

namespace ErdosProblems.Erdos243.PaperCompleteR11
open Filter PaperCompleteR7
open scoped BigOperators Topology
end ErdosProblems.Erdos243.PaperCompleteR11

open Filter PaperCompleteR7
open scoped BigOperators Topology
open ErdosProblems in
open ErdosProblems.Erdos243 in
open ErdosProblems.Erdos243.PaperCompleteR11 in
open ErdosProblems.Erdos243.PaperCompleteR7 in
theorem solution (c : ℝ) (d e F : ℕ)
    (hc0 : 0 ≤ c) (hslack : c * d < e) :
    ∃ K : ℕ, ∀ k : ℕ, K ≤ k →
      c * ((d : ℝ) * (k : ℝ) ^ 2 + k + F) ≤ (e : ℝ) * (k : ℝ) ^ 2 := by
  let δ : ℝ := e - c * d
  have hδ : 0 < δ := by dsimp [δ]; linarith
  obtain ⟨K, hK⟩ := exists_nat_gt (max (1 : ℝ) (c * ((F : ℝ) + 1) / δ))
  refine ⟨K, fun k hk ↦ ?_⟩
  have hKk : (K : ℝ) ≤ (k : ℝ) := by exact_mod_cast hk
  have hk1 : 1 ≤ (k : ℝ) := ((le_max_left _ _).trans hK.le).trans hKk
  have hq : c * ((F : ℝ) + 1) / δ ≤ (k : ℝ) :=
    ((le_max_right _ _).trans hK.le).trans hKk
  have hq' := (div_le_iff₀ hδ).1 hq
  have hmul := mul_le_mul_of_nonneg_right hq' (show (0 : ℝ) ≤ k by positivity)
  have hFk : (k : ℝ) + F ≤ ((F : ℝ) + 1) * k := by
    nlinarith [mul_nonneg (show (0 : ℝ) ≤ F by positivity) (sub_nonneg.mpr hk1)]
  have hsmall := mul_le_mul_of_nonneg_left hFk hc0
  dsimp [δ] at hmul
  nlinarith
