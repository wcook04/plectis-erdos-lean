import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_CubicSquareCoordinates
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_CubicFieldCoordinates
import Theorems.Thm_ErdosProblems_Erdos243_PaperCompleteR11_cubic_root_field_scale_twelve
import Mathlib
import Mathlib.FieldTheory.IntermediateField.Adjoin.Basic
import Mathlib.RingTheory.PowerBasis

/-!
# Scale twelve from the actual irreducible cubic root field

Candidate source. Lean elaboration and the axiom audit are UNRUN.
The root field is the actual intermediate field ℚ(α). Its power basis,
dimension, rational coordinates and reduced scale parameter are constructed
from the irreducible polynomial and square-root hypotheses. No Chebotarev
prime-production result is needed for this algebraic implication; obtaining
the square-root hypothesis from reductions is a separate endpoint.
-/

namespace ErdosProblems.Erdos243.PaperCompleteR11
open Polynomial

noncomputable section
end
end ErdosProblems.Erdos243.PaperCompleteR11

open Polynomial
open ErdosProblems.Erdos243.PaperCompleteR11 in
theorem solution
    {L : Type*} [Field L] [Algebra ℚ L]
    (m : ℕ) (c : ℚ) (hm : 0 < m) (hc : c = 1 ∨ c = -1)
    (α β : L)
    (hirr : Irreducible (cubicScalePolynomial (6*c/(m : ℚ))))
    (hroot : α^3 = α - algebraMap ℚ L (6*c/(m : ℚ)))
    (hβmem : β ∈ IntermediateField.adjoin ℚ ({α} : Set L))
    (hβ : β^2 = α^2 - 1) : m = 12 := by
  apply cubic_root_field_scale_twelve m c hm hc α hirr hroot
  refine ⟨⟨β, hβmem⟩, ?_⟩
  apply Subtype.ext
  simpa using hβ
