import Definitions.Def_ErdosProblems_Erdos243_ReciprocalTailRigidity
import Definitions.Def_ErdosProblems_Erdos243_GlobalLcmHeight
import Definitions.Def_ErdosProblems_Erdos243_CumulativeLcmTransfer
import Definitions.Def_ErdosProblems_Erdos243_LcmRecordCrossing
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR7_Limits
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR7_RealTail
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR7_CanonicalState
import Definitions.Def_ErdosProblems_Erdos243_PrimitiveRecordBarrier
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_RecordDivisibility
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR7_ProductDefect
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR7_LcmDefect
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_GrowthRecordEquivalence
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_CanonicalGrowthBounds
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_CoprimeCores
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_LogLogNormaliser
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_OrbitBlockArithmetic
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_PresievedCRT
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_RecordGcdReduction
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_InclusiveRecordAssembly
import Theorems.Thm_ErdosProblems_Erdos243_PaperCompleteR11_RecordGrowthOrbit_no_inclusive_record_cap
import Mathlib
import Mathlib.Algebra.Order.BigOperators.GroupWithZero.Finset
import Mathlib.Algebra.Ring.Basic
import Mathlib.Analysis.SpecialFunctions.Log.Basic
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Analysis.SumIntegralComparisons
import Mathlib.Data.Fin.Pigeonhole
import Mathlib.Data.Fintype.BigOperators
import Mathlib.Data.Fintype.EquivFin
import Mathlib.Data.Nat.ChineseRemainder
import Mathlib.Data.Nat.Factorization.Basic
import Mathlib.Data.Nat.Find
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.Nat.Totient
import Mathlib.Data.Rat.Defs
import Mathlib.Data.ZMod.Basic
import Mathlib.Order.Filter.AtTopBot.Basic
import Mathlib.Tactic
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.InfiniteSum.NatInt

namespace PaperCompleteR7
end PaperCompleteR7

/-!
# Inclusive coefficient-one record boundary


The exact conclusion is a fixed coefficient c>1 exceeded cofinally at
strict global records. This implies the paper's strict limsup inequality;
the separate extended-real presentation is not used in this proof.
Both gcd alternatives are handled by constructed quotient tails.
-/

namespace ErdosProblems.Erdos243.PaperCompleteR11
open PaperCompleteR7 Filter
open scoped Topology
end ErdosProblems.Erdos243.PaperCompleteR11

open PaperCompleteR7 Filter
open scoped Topology
open ErdosProblems in
open ErdosProblems.Erdos243 in
open ErdosProblems.Erdos243.PaperCompleteR11 in
open ErdosProblems.Erdos243.PaperCompleteR7 in
theorem solution (O : RecordGrowthOrbit) :
    ∃ c : ℝ, 1 < c ∧ ∀ T : ℕ, ∃ n, T ≤ n ∧ runningMax O.U n < O.U (n + 1) ∧
      c * recordLogLog (runningMax O.U n) <
        ((O.U (n + 1) - runningMax O.U n : ℕ) : ℝ) := by
  obtain ⟨c, hc, hnocap⟩ := O.no_inclusive_record_cap
  refine ⟨c, hc, fun T ↦ ?_⟩
  by_contra hnot
  apply hnocap
  refine ⟨T, fun n hn hnew ↦ ?_⟩
  by_contra hh
  exact hnot ⟨n, hn, hnew, lt_of_not_ge hh⟩
