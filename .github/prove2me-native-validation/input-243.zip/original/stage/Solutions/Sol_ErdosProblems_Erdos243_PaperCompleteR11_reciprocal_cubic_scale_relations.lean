import Mathlib

namespace ErdosProblems.Erdos243.PaperCompleteR11
end ErdosProblems.Erdos243.PaperCompleteR11

/-! UNRUN. Exact coefficient and denominator arithmetic in the cubic
classification. These declarations do not construct a number-field basis or
supply a prime-specialisation theorem. -/

namespace ErdosProblems.Erdos243.PaperCompleteR11
/-- Coefficient comparison for reciprocal cubic factors, without division. -/
theorem reciprocal_cubic_coefficient_factor
    {K : Type*} [Field K] (b d w : K)
    (h5 : b * w + d = 0)
    (h4 : d * w + b * d + b = -w) :
    (b * w - 1) * (b + w) = 0 := by
  linear_combination (b + w) * h5 - h4
end ErdosProblems.Erdos243.PaperCompleteR11

open ErdosProblems in
open ErdosProblems.Erdos243 in
open ErdosProblems.Erdos243.PaperCompleteR11 in
theorem solution
    {K : Type*} [Field K] (b d w η : K)
    (h5 : b * w + d = 0)
    (h4 : d * w + b * d + b = -w)
    (h3 : w ^ 2 + 1 + b ^ 2 + d ^ 2 = 8 * η * w) :
    (w ^ 2 + 1) ^ 2 = 8 * η * w ^ 3 ∨
      (w ^ 2 + 1) ^ 2 = 8 * η * w := by
  have hfactor := reciprocal_cubic_coefficient_factor b d w h5 h4
  rcases mul_eq_zero.mp hfactor with hb | hb
  · left
    have hd : d = -1 := by linear_combination h5 - hb
    rw [hd] at h3
    linear_combination w ^ 2 * h3 - (b * w + 1) * hb
  · right
    have hb' : b = -w := by linear_combination hb
    rw [hb'] at h5 h3
    have hd : d = w ^ 2 := by linear_combination h5
    rw [hd] at h3
    linear_combination h3
