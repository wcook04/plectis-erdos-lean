import Definitions.Def_ErdosProblems_Erdos243_ReciprocalTailRigidity
import Definitions.Def_ErdosProblems_Erdos243_LcmRecordCrossing
import Theorems.Thm_ErdosProblems_Erdos243_LcmRecordCrossing_covering_of_crt_block
import Theorems.Thm_ErdosProblems_Erdos243_exists_consecutiveMultiples_between
import Mathlib
import Mathlib.Algebra.Order.BigOperators.GroupWithZero.Finset
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.Data.Fin.Pigeonhole
import Mathlib.Data.Nat.ChineseRemainder
import Mathlib.Data.Nat.Find
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.ZMod.Basic
import Mathlib.Order.Filter.AtTopBot.Basic
import Mathlib.Tactic.Ring

namespace LcmRecordExcess
end LcmRecordExcess

/-!
# Counting the CRT heights crossed by one arithmetic step

The heights are the actual arithmetic progression `x + k * P`, not an
assumed cardinality bound. This supplies the finite local charging step in
the weighted-record argument of `LcmRecordExcess.md`. First-crossing existence,
uniqueness, and the finite partition across time require no monotonicity of
the numerator sequence. The existing CRT construction supplies the covering
from any finite family of sufficiently large pairwise-coprime old divisors.
Producing that family from an infinite canonical orbit and the analytic
divergence argument are not asserted by this module.
-/

namespace ErdosProblems.Erdos243.LcmRecordCrossing
open LcmRecordExcess



/-- The block product exceeds the baseline, including the empty B=0 block. -/
theorem baseline_lt_block_product {B : ℕ} (m : Fin B → ℕ)
    (hm : ∀ i, B < m i) : B < ∏ i, m i := by
  by_cases hB : B = 0
  · subst B
    simp
  · have hBpos : 0 < B := by omega
    let i : Fin B := ⟨0, hBpos⟩
    have hprodpos : 0 < ∏ j, m j :=
      Finset.prod_pos (fun j _ => lt_of_le_of_lt (Nat.zero_le B) (hm j))
    have hdiv : m i ∣ ∏ j, m j := by
      simpa using Finset.dvd_prod_of_mem m (Finset.mem_univ i)
    exact (hm i).trans_le (Nat.le_of_dvd hprodpos hdiv)
end ErdosProblems.Erdos243.LcmRecordCrossing

open LcmRecordExcess
open ErdosProblems in
open ErdosProblems.Erdos243 in
open ErdosProblems.Erdos243.LcmRecordCrossing in
theorem solution {B : ℕ} (m : Fin B → ℕ)
    (hm : ∀ i, B < m i)
    (hpair : ∀ i j, i ≠ j → Nat.Coprime (m i) (m j)) :
    ∃ x, B < (∏ i, m i) ∧ (∏ i, m i) ≤ x ∧ x < 2 * ∏ i, m i ∧
      ∀ L : ℤ, (∀ i, (m i : ℤ) ∣ L) → ∀ k : ℕ, ∀ z : ℤ,
        (x + B + k * (∏ i, m i) : ℕ) - (B : ℤ) ≤ z →
        z < (x + B + k * (∏ i, m i) : ℕ) →
        ∃ d : ℤ, (B : ℤ) < d ∧ d ∣ L ∧ d ∣ z := by
  have hm1 : ∀ i, 1 < m i := by
    intro i
    have := i.isLt
    have := hm i
    omega
  obtain ⟨x, hxlo, hxhi, hresidue⟩ :=
    exists_consecutiveMultiples_between m hm1 hpair
  refine ⟨x, baseline_lt_block_product m hm, hxlo, hxhi, ?_⟩
  intro L hL k
  exact covering_of_crt_block m x (∏ i, m i) k L hm
    (fun i => by simpa using Finset.dvd_prod_of_mem m (Finset.mem_univ i)) hL hresidue
