import Definitions.Def_ErdosProblems_Erdos243_ReciprocalTailRigidity
import Definitions.Def_ErdosProblems_Erdos243_GlobalLcmHeight
import Definitions.Def_ErdosProblems_Erdos243_CumulativeLcmTransfer
import Definitions.Def_ErdosProblems_Erdos243_LcmRecordCrossing
import Definitions.Def_ErdosProblems_Erdos243_LcmRecordDivergence
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR7_Limits
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR7_RealTail
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR7_CanonicalState
import Definitions.Def_ErdosProblems_Erdos243_PrimitiveRecordBarrier
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR7_ProductDefect
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR7_LcmDefect
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR8_WeightAnalysis
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR8_WeightedRecords
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR8_CanonicalWeightedRecords
import Theorems.Thm_ErdosProblems_Erdos243_PaperCompleteR8_canonical_weighted_record_nat
import Theorems.Thm_ErdosProblems_Erdos243_PaperCompleteR8_heightWeight_antitone
import Theorems.Thm_ErdosProblems_Erdos243_PaperCompleteR8_heightWeight_eq
import Theorems.Thm_ErdosProblems_Erdos243_PaperCompleteR8_heightWeight_nonneg
import Theorems.Thm_ErdosProblems_Erdos243_PaperCompleteR8_not_summable_heightWeight
import Mathlib
import Mathlib.Algebra.Order.BigOperators.GroupWithZero.Finset
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Analysis.SumIntegralComparisons
import Mathlib.Data.Fin.Pigeonhole
import Mathlib.Data.Nat.ChineseRemainder
import Mathlib.Data.Nat.Factorization.Basic
import Mathlib.Data.Nat.Find
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.ZMod.Basic
import Mathlib.Order.Filter.AtTopBot.Basic
import Mathlib.Tactic
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.InfiniteSum.NatInt
import Mathlib.Topology.Algebra.InfiniteSum.Real

/-!
# The canonical weighted-record equivalence

Complete compiled candidates for both occurrences of `res:weightedrecord`.
The rational value is supplied as `HasSum ... (p/q)`, exactly as in the
repaired r7 canonical-state theorem. All tail integrality and small-error
facts come from that theorem; none are additional hypotheses here.

The eventual-centred arithmetic theorem is obtained by shifting at a genuine
running maximum. Shifting at an arbitrary index would change the record set.
The converse implication uses the exact squared-error transport on a
Sylvester tail, rather than presuming zero error from the recurrence.

Mathlib facts used for casts and products also occur in the repaired r7
`LcmDefect.lean`: Int.natAbs_mul, Int.natAbs_natCast,
Nat.mul_lt_mul_left. All substantial arithmetic imports are supplied sources.
-/

namespace ErdosProblems.Erdos243.PaperCompleteR8
open Filter Classical
open scoped BigOperators
end ErdosProblems.Erdos243.PaperCompleteR8

open Filter Classical
open scoped BigOperators
open ErdosProblems in
open ErdosProblems.Erdos243 in
open ErdosProblems.Erdos243.PaperCompleteR8 in
theorem solution
    (a : ℕ → ℕ) (ha : StrictMono a) (hapos : ∀ n, 0 < a n)
    (p : ℤ) (q : ℕ) (hq : 0 < q)
    (hs : HasSum (fun n => 1 / (a n : ℝ)) ((p : ℝ) / (q : ℝ)))
    (hg : Tendsto (fun n => (a (n + 1) : ℝ) / (a n : ℝ) ^ 2) atTop (nhds 1))
    (f : ℝ → ℝ) (hf : AntitoneOn f (Set.Ici 1))
    (hpos : ∀ x : ℝ, 1 ≤ x → 0 ≤ f x) (hdiv : DivergentIntegral f) :
    let o := canonicalLcmOrbit a ha hapos p q hq hs hg
    (∃ N, ∀ n, N ≤ n → (a (n + 1) : ℤ) = sylvesterNext (a n : ℤ)) ↔
      ∃ B : ℕ, Summable (fun n : ℕ => if Record o.U n then
        (((-o.V n - B).toNat : ℕ) : ℝ) * f (o.U n) else 0) := by
  let o := canonicalLcmOrbit a ha hapos p q hq hs hg
  have hh := canonical_weighted_record_nat a ha hapos p q hq hs hg
    (heightWeight f) (heightWeight_antitone f hf) (heightWeight_nonneg f hpos)
    (not_summable_heightWeight f hf hpos hdiv)
  have heq : ∀ B : ℕ, rawRecordWeight o.U o.V B (heightWeight f) =
      fun n : ℕ => if Record o.U n then
        (((-o.V n - B).toNat : ℕ) : ℝ) * f (o.U n) else 0 := by
    intro B
    funext n
    unfold rawRecordWeight
    rw [heightWeight_eq f (o.U n) (o.Upos n)]
  change (∃ N, ∀ n, N ≤ n → (a (n + 1) : ℤ) = sylvesterNext (a n : ℤ)) ↔
    ∃ B : ℕ, Summable (rawRecordWeight o.U o.V B (heightWeight f)) at hh
  simpa only [heq] using hh
