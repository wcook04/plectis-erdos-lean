import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_CubicSquareCoordinates
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_CubicFieldCoordinates
import Mathlib
import Mathlib.RingTheory.PowerBasis

/-!
# Extracting the square-root coordinates from a cubic algebra

The power-basis representation is extracted from the actual square root.
The degree bound then forces all three rational coordinate equations.
No trace, norm, coordinate equation, or coefficient relation is assumed.
-/

namespace ErdosProblems.Erdos243.PaperCompleteR11
open Polynomial
open scoped BigOperators

noncomputable section
end
end ErdosProblems.Erdos243.PaperCompleteR11

open Polynomial
open scoped BigOperators
open ErdosProblems.Erdos243.PaperCompleteR11 in
theorem solution (η : ℚ) :
    (cubicScalePolynomial η).natDegree = 3 := by
  dsimp [cubicScalePolynomial]
  compute_degree
  exact one_ne_zero
