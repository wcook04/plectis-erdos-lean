import Definitions.Def_ErdosProblems_Erdos243_ReciprocalTailRigidity
import Definitions.Def_ErdosProblems_Erdos243_GlobalLcmHeight
import Definitions.Def_ErdosProblems_Erdos243_CumulativeLcmTransfer
import Definitions.Def_ErdosProblems_Erdos243_LcmRecordCrossing
import Definitions.Def_ErdosProblems_Erdos243_LcmRecordDivergence
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR7_Limits
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR7_RealTail
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR7_CanonicalState
import Definitions.Def_ErdosProblems_Erdos243_PrimitiveRecordBarrier
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR7_ProductDefect
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR7_LcmDefect
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR8_WeightAnalysis
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR8_WeightedRecords
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR8_CanonicalWeightedRecords
import Mathlib
import Mathlib.Algebra.Order.BigOperators.GroupWithZero.Finset
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Analysis.SumIntegralComparisons
import Mathlib.Data.Fin.Pigeonhole
import Mathlib.Data.Nat.ChineseRemainder
import Mathlib.Data.Nat.Factorization.Basic
import Mathlib.Data.Nat.Find
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.ZMod.Basic
import Mathlib.Order.Filter.AtTopBot.Basic
import Mathlib.Tactic
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.InfiniteSum.NatInt
import Mathlib.Topology.Algebra.InfiniteSum.Real

/-!
# The canonical weighted-record equivalence

Complete compiled candidates for both occurrences of `res:weightedrecord`.
The rational value is supplied as `HasSum ... (p/q)`, exactly as in the
repaired r7 canonical-state theorem. All tail integrality and small-error
facts come from that theorem; none are additional hypotheses here.

The eventual-centred arithmetic theorem is obtained by shifting at a genuine
running maximum. Shifting at an arbitrary index would change the record set.
The converse implication uses the exact squared-error transport on a
Sylvester tail, rather than presuming zero error from the recurrence.

Mathlib facts used for casts and products also occur in the repaired r7
`LcmDefect.lean`: Int.natAbs_mul, Int.natAbs_natCast,
Nat.mul_lt_mul_left. All substantial arithmetic imports are supplied sources.
-/

namespace ErdosProblems.Erdos243.PaperCompleteR8
open Filter Classical
open scoped BigOperators
end ErdosProblems.Erdos243.PaperCompleteR8

open Filter Classical
open scoped BigOperators
open ErdosProblems in
open ErdosProblems.Erdos243 in
open ErdosProblems.Erdos243.PaperCompleteR8 in
theorem solution
    (a : ℕ → ℕ) (ha : StrictMono a) (hapos : ∀ n, 0 < a n)
    (p : ℤ) (q : ℕ) (hq : 0 < q)
    (hs : HasSum (fun n => 1 / (a n : ℝ)) ((p : ℝ) / (q : ℝ)))
    (hg : Tendsto (fun n => (a (n + 1) : ℝ) / (a n : ℝ) ^ 2) atTop (nhds 1)) :
    let o := canonicalLcmOrbit a ha hapos p q hq hs hg
    ∀ K : ℕ, ∃ N, ∀ n, N ≤ n → K * Int.natAbs (o.V n) < o.U n := by
  let C := PaperCompleteR7.canonicalNaturalNumerator a p q
  let D := PaperCompleteR7.canonicalDenominator a q
  obtain ⟨_, _, hC, _, _, hv, _⟩ :=
    PaperCompleteR7.canonical_integer_tail_normalized a ha hapos p q hq hs hg
  have hscale : ∀ n, D n = digitProductScale q a n :=
    fun n => (PaperCompleteR7.productScale_eq_canonicalDenominator q a n).symm
  dsimp only
  intro K
  obtain ⟨N, hN⟩ := hv K
  refine ⟨N, ?_⟩
  intro n hn
  have hM := cumulativeOverlapDebt_pos hq hapos n
  have hUeq := lcmLiftedNumerator_spec q a C D hscale hC n
  have hVeq := lcmLiftedDigit_mul_overlapDebt q a C D hscale hC n
  have hh := hN n hn
  change K * Int.natAbs (centeredState (a n : ℤ) (D n : ℤ) (C n : ℤ)) < C n at hh
  rw [← hVeq, ← hUeq, Int.natAbs_mul, Int.natAbs_natCast] at hh
  change K * Int.natAbs (lcmLiftedDigit q a C n) < lcmLiftedNumerator q a C n
  apply (Nat.mul_lt_mul_left hM).mp
  calc
    cumulativeOverlapDebt q a n * (K * Int.natAbs (lcmLiftedDigit q a C n)) =
      K * (cumulativeOverlapDebt q a n * Int.natAbs (lcmLiftedDigit q a C n)) := by ring
    _ < cumulativeOverlapDebt q a n * lcmLiftedNumerator q a C n := hh
