import Definitions.Def_ErdosProblems_Erdos243_ReciprocalTailRigidity
import Definitions.Def_ErdosProblems_Erdos243_GlobalLcmHeight
import Definitions.Def_ErdosProblems_Erdos243_CumulativeLcmTransfer
import Definitions.Def_ErdosProblems_Erdos243_LcmRecordCrossing
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR7_Limits
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR7_RealTail
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR7_CanonicalState
import Definitions.Def_ErdosProblems_Erdos243_PrimitiveRecordBarrier
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_RecordDivisibility
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_PresievedCRT
import Mathlib
import Mathlib.Algebra.Order.BigOperators.GroupWithZero.Finset
import Mathlib.Algebra.Ring.Basic
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Data.Fin.Pigeonhole
import Mathlib.Data.Nat.ChineseRemainder
import Mathlib.Data.Nat.Factorization.Basic
import Mathlib.Data.Nat.Find
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.Nat.Totient
import Mathlib.Data.Rat.Defs
import Mathlib.Data.ZMod.Basic
import Mathlib.Order.Filter.AtTopBot.Basic
import Mathlib.Tactic
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.InfiniteSum.NatInt

/-!
# Exact finite pre-sieving and the primitive record fence


The modulus W is part of the CRT construction, not merely mentioned in
an offset-counting hypothesis.  Thus x is a multiple of W, and only the
phi(W)/W proportion of offsets coprime to W need individual old moduli.
The exact count, its asymptotic proportion, the bounded CRT phase and the
primitive first-crossing contradiction are all supplied here.  Selection
of the canonical moduli and the final log-log limit remain separate.
-/

namespace ErdosProblems.Erdos243.PaperCompleteR11
open Filter
open scoped BigOperators Topology
end ErdosProblems.Erdos243.PaperCompleteR11

open Filter
open scoped BigOperators Topology
open ErdosProblems in
open ErdosProblems.Erdos243 in
open ErdosProblems.Erdos243.PaperCompleteR11 in
theorem solution
    {ι : Type*} [Fintype ι] [DecidableEq ι]
    (W : ℕ) (hW : 0 < W) (m offset : ι → ℕ)
    (hm : ∀ i, 0 < m i)
    (hpair : ∀ i j, i ≠ j → Nat.Coprime (m i) (m j))
    (hWm : ∀ i, Nat.Coprime W (m i)) :
    ∃ x : ℕ, W * (∏ i, m i) ≤ x ∧ x < 2 * (W * (∏ i, m i)) ∧
      W ∣ x ∧ ∀ i, m i ∣ x + offset i := by
  classical
  let residue : ι → ℕ := fun i ↦ m i - offset i % m i
  have hm0 : ∀ i ∈ (Finset.univ : Finset ι), m i ≠ 0 := fun i _ ↦ (hm i).ne'
  have hpairSet : Set.Pairwise (↑(Finset.univ : Finset ι) : Set ι)
      (fun i j ↦ Nat.Coprime (m i) (m j)) := by
    intro i _ j _ hij
    exact hpair i j hij
  let y₀ := Nat.chineseRemainderOfFinset residue m Finset.univ hm0 hpairSet
  let P₀ : ℕ := ∏ i, m i
  have hWP₀ : Nat.Coprime W P₀ := Nat.coprime_fintype_prod_right_iff.mpr hWm
  let y := Nat.chineseRemainder hWP₀ 0 (y₀ : ℕ)
  let P : ℕ := W * P₀
  have hPpos : 0 < P := mul_pos hW (Finset.prod_pos (fun i _ ↦ hm i))
  let x : ℕ := (y : ℕ) % P + P
  have hmodLt := Nat.mod_lt (y : ℕ) hPpos
  have hxmod {d : ℕ} (hd : d ∣ P) : x ≡ (y : ℕ) [MOD d] := by
    have h₁ := (Nat.mod_modEq (y : ℕ) P).of_dvd hd
    have h₂ : P ≡ 0 [MOD d] := Nat.modEq_zero_iff_dvd.mpr hd
    simpa only [add_zero] using h₁.add h₂
  refine ⟨x, by dsimp [x, P, P₀] at *; omega,
    by dsimp [x, P, P₀] at *; omega, ?_, fun i ↦ ?_⟩
  · exact Nat.modEq_zero_iff_dvd.mp
      ((hxmod (dvd_mul_right W P₀)).trans y.property.1)
  · have hmP₀ : m i ∣ P₀ := Finset.dvd_prod_of_mem m (Finset.mem_univ i)
    have hmP : m i ∣ P := hmP₀.trans (dvd_mul_left P₀ W)
    have hyi : (y : ℕ) ≡ residue i [MOD m i] :=
      (y.property.2.of_dvd hmP₀).trans (y₀.property i (Finset.mem_univ i))
    have hres : m i ∣ residue i + offset i := by
      let r := offset i % m i
      let q := offset i / m i
      have hrem : r < m i := by simpa only [r] using Nat.mod_lt (offset i) (hm i)
      have hdiv : r + m i * q = offset i := by
        simpa only [r, q] using Nat.mod_add_div (offset i) (m i)
      refine ⟨q + 1, ?_⟩
      change m i - r + offset i = m i * (q + 1)
      conv_lhs => rhs; rw [← hdiv]
      rw [← Nat.add_assoc, Nat.sub_add_cancel hrem.le]
      simp [Nat.mul_succ, Nat.add_comm]
    have hcong : x + offset i ≡ residue i + offset i [MOD m i] :=
      ((hxmod hmP).trans hyi).add_right (offset i)
    exact Nat.modEq_zero_iff_dvd.mp
      (hcong.trans (Nat.modEq_zero_iff_dvd.mpr hres))
