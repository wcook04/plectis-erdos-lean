import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_CubicSquareCoordinates
import Mathlib

   
                                           

                                                    

                                                                  
                                                                       
                                                                  
                                                                        
                                                                         
                                                                        
                                                                      

                                                             
                                                                       
                                                                   
  

open ErdosProblems in
open ErdosProblems.Erdos243 in
open ErdosProblems.Erdos243.PaperCompleteR11 in
theorem solution
    (x y z η : ℚ)
    (h1 : x^2 + 2*x*z + y^2 - 1 = 0)
    (h2 : 2*x*y + 2*y*z - η*x^2 = 0)
    (h3 : z^2 - 2*η*x*y + 1 = 0) :
    cubicCoordinateD x y z η + cubicCoordinateB x z * cubicCoordinateW x y z η = 0 := by
  unfold cubicCoordinateB cubicCoordinateD cubicCoordinateW
  linear_combination (8*η^2*x^2 - 10*η*x*y + 2*η*x - 7*η*y*z + 3*η*z + 2*x*z + 3*z^2 + 1) * h1 +
    (6*η*x^2 + 13*η*x*z + 2*η*y^2 - 6*η*y - 8*η - 2*y*z - 2*z) * h2 +
    (3*η*x*y + 3*η*x + 2*x*z - 2*y^2 - 2*y + 3*z^2) * h3
