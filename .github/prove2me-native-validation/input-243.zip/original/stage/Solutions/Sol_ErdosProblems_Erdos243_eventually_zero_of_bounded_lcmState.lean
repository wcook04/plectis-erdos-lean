import Definitions.Def_ErdosProblems_Erdos243_ReciprocalTailRigidity
import Mathlib.Algebra.Order.BigOperators.GroupWithZero.Finset
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.Data.Fin.Pigeonhole
import Mathlib.Data.Nat.ChineseRemainder
import Mathlib.Data.Nat.Find
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.ZMod.Basic
import Mathlib.Order.Filter.AtTopBot.Basic
import Mathlib.Tactic.Ring

open scoped BigOperators

/-!
# Erdős 243: the LCM critical boundary

This module formalizes the strict-rise CRT consumer and weighted block
telescope arising from the LCM-cleared tail state.
-/

open ErdosProblems in
open ErdosProblems.Erdos243 in
theorem solution
    (u : ℕ → ℕ) (V : ℕ → ℤ) (M : ℕ)
    (hbound : ∀ n, u n ≤ M)
    (hvanish : ∀ K, ∃ N, ∀ n, N ≤ n →
      K * (V n).natAbs < u n) :
    ∃ N, ∀ n, N ≤ n → V n = 0 := by
  obtain ⟨N, hN⟩ := hvanish (M + 1)
  refine ⟨N, fun n hn ↦ ?_⟩
  have hsmall := hN n hn
  have habs : (V n).natAbs = 0 := by
    by_contra hne
    have hpos : 0 < (V n).natAbs := Nat.pos_of_ne_zero hne
    have hM := hbound n
    nlinarith
  exact Int.natAbs_eq_zero.mp habs
