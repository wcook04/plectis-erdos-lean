import Definitions.Def_ErdosProblems_Erdos243_ReciprocalTailRigidity
import Definitions.Def_ErdosProblems_Erdos243_GlobalLcmHeight
import Definitions.Def_ErdosProblems_Erdos243_CumulativeLcmTransfer
import Definitions.Def_ErdosProblems_Erdos243_LcmRecordCrossing
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR7_Limits
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR7_RealTail
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR7_CanonicalState
import Definitions.Def_ErdosProblems_Erdos243_PrimitiveRecordBarrier
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_RecordDivisibility
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR7_ProductDefect
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR7_LcmDefect
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_GrowthRecordEquivalence
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_CanonicalGrowthBounds
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_CoprimeCores
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_LogLogNormaliser
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_OrbitBlockArithmetic
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_PresievedCRT
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_RecordGcdReduction
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_InclusiveRecordAssembly
import Theorems.Thm_ErdosProblems_Erdos243_PaperCompleteR11_RecordGrowthOrbit_quotient_record_cap
import Theorems.Thm_ErdosProblems_Erdos243_PaperCompleteR11_exists_late_attained_record
import Theorems.Thm_ErdosProblems_Erdos243_PaperCompleteR11_no_primitive_totient_record_cap
import Theorems.Thm_ErdosProblems_Erdos243_PaperCompleteR11_no_subcritical_record_cap
import Theorems.Thm_ErdosProblems_Erdos243_PaperCompleteR11_presieved_totient_ratio_gt_one
import Theorems.Thm_ErdosProblems_Erdos243_dvdChain_eventuallyConstant_of_cofinally_bounded
import Theorems.Thm_ErdosProblems_Erdos243_tailGcd_dvd_succ
import Mathlib
import Mathlib.Algebra.Order.BigOperators.GroupWithZero.Finset
import Mathlib.Algebra.Ring.Basic
import Mathlib.Analysis.SpecialFunctions.Log.Basic
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Analysis.SumIntegralComparisons
import Mathlib.Data.Fin.Pigeonhole
import Mathlib.Data.Fintype.BigOperators
import Mathlib.Data.Fintype.EquivFin
import Mathlib.Data.Nat.ChineseRemainder
import Mathlib.Data.Nat.Factorization.Basic
import Mathlib.Data.Nat.Find
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.Nat.Totient
import Mathlib.Data.Rat.Defs
import Mathlib.Data.ZMod.Basic
import Mathlib.Order.Filter.AtTopBot.Basic
import Mathlib.Tactic
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.InfiniteSum.NatInt

namespace PaperCompleteR7
end PaperCompleteR7

/-!
# Inclusive coefficient-one record boundary


The exact conclusion is a fixed coefficient c>1 exceeded cofinally at
strict global records. This implies the paper's strict limsup inequality;
the separate extended-real presentation is not used in this proof.
Both gcd alternatives are handled by constructed quotient tails.
-/

namespace ErdosProblems.Erdos243.PaperCompleteR11
open PaperCompleteR7 Filter
open scoped Topology

/-- The exact tail gcd is a positive monotone divisibility chain. -/
theorem RecordGrowthOrbit.gcd_monotone (O : RecordGrowthOrbit) :
    Monotone (fun n ↦ Nat.gcd (O.U n) (O.D n)) := by
  apply monotone_nat_of_le_succ
  intro n
  exact Nat.le_of_dvd (Nat.gcd_pos_of_pos_left _ (O.U_pos _))
    (tailGcd_dvd_succ _ _ _ _ _ (O.U_step n) (O.D_step n))
end ErdosProblems.Erdos243.PaperCompleteR11

open PaperCompleteR7 Filter
open scoped Topology
open ErdosProblems in
open ErdosProblems.Erdos243 in
open ErdosProblems.Erdos243.PaperCompleteR11 in
open ErdosProblems.Erdos243.PaperCompleteR7 in
theorem solution (O : RecordGrowthOrbit) :
    ∃ c : ℝ, 1 < c ∧ ¬ ∃ T : ℕ, ∀ n, T ≤ n → runningMax O.U n < O.U (n + 1) →
      ((O.U (n + 1) - runningMax O.U n : ℕ) : ℝ) ≤ c * recordLogLog (runningMax O.U n) := by
  classical
  let G := fun n ↦ Nat.gcd (O.U n) (O.D n)
  have hGpos : ∀ n, 0 < G n := fun n ↦ Nat.gcd_pos_of_pos_left _ (O.U_pos n)
  by_cases hbounded : ∃ B : ℕ, ∀ n, G n ≤ B
  · obtain ⟨B, hB⟩ := hbounded
    obtain ⟨N, hN⟩ := dvdChain_eventuallyConstant_of_cofinally_bounded G B hGpos
      (fun n ↦ tailGcd_dvd_succ _ _ _ _ _ (O.U_step n) (O.D_step n))
      (fun n ↦ ⟨n, le_rfl, hB n⟩)
    obtain ⟨s, hNs, hs⟩ := exists_late_attained_record O.U O.unbounded N
    let g := G s
    have hg : 0 < g := hGpos s
    have hUg : g ∣ O.U s := Nat.gcd_dvd_left _ _
    have hDg : g ∣ O.D s := Nat.gcd_dvd_right _ _
    let V := O.quotientAt s g hg hUg hDg
    have hstable : ∀ n, G (s + n) = g := by
      intro n
      exact (hN (s + n) (by omega)).trans (hN s hNs).symm
    have hred : ∀ n, Nat.Coprime (V.U n) (V.D n) := by
      intro n
      have hh := Nat.coprime_div_gcd_div_gcd (hGpos (s + n))
      change Nat.Coprime (O.U (s + n) / g) (O.D (s + n) / g)
      simpa only [← hstable n] using hh
    let W := V.D 2
    have hW : 1 < W := by
      have ha2 : 2 ≤ V.a 1 := by
        have hmono := V.increasing (show 0 < 1 by omega)
        have hpos := V.a_pos 0
        omega
      have hmul := Nat.mul_le_mul ha2 (show 1 ≤ V.D 1 by have := V.D_pos 1; omega)
      have hstep : V.D 2 = V.a 1 * V.D 1 := V.D_step 1
      dsimp [W]
      omega
    have hphi : (0 : ℝ) < Nat.totient W := by
      exact_mod_cast (Nat.totient_pos.mpr (by omega : 0 < W))
    let c : ℝ := (1 + (W : ℝ) / Nat.totient W) / 2
    have hratio := presieved_totient_ratio_gt_one W hW
    have hc1 : 1 < c := by dsimp [c]; linarith
    have hc0 : 0 ≤ c := by linarith
    have hcW : c * Nat.totient W < W := by
      apply (lt_div_iff₀ hphi).1
      dsimp [c]
      linarith
    have hgR : (0 : ℝ) < g := by exact_mod_cast hg
    have hg1 : (1 : ℝ) ≤ g := by exact_mod_cast (show 1 ≤ g by omega)
    have hcdiv : c / g ≤ c := by
      apply (div_le_iff₀ hgR).2
      have hh := mul_le_mul_of_nonneg_left hg1 hc0
      nlinarith
    refine ⟨c, hc1, ?_⟩
    rintro ⟨T, hcap⟩
    apply no_primitive_totient_record_cap V.a V.U V.D V.increasing
      V.a_pos V.U_pos V.D_pos V.U_step V.D_step hred
      V.lower V.record_bound V.den_bound V.unbounded W 2 hW (dvd_refl W)
      g (c / g) (div_nonneg hc0 hgR.le)
      ((mul_le_mul_of_nonneg_right hcdiv hphi.le).trans_lt hcW)
    exact ⟨T, O.quotient_record_cap s g hg hUg hDg hs c T hcap⟩
  · have hex : ∃ n, 3 ≤ G n := by
      by_contra hnot
      apply hbounded
      refine ⟨2, fun n ↦ ?_⟩
      by_contra hn
      exact hnot ⟨n, by omega⟩
    obtain ⟨N, hGN⟩ := hex
    obtain ⟨s, hNs, hs⟩ := exists_late_attained_record O.U O.unbounded N
    let g := G s
    have hg3 : 3 ≤ g := hGN.trans (O.gcd_monotone hNs)
    have hg : 0 < g := by omega
    have hUg : g ∣ O.U s := Nat.gcd_dvd_left _ _
    have hDg : g ∣ O.D s := Nat.gcd_dvd_right _ _
    let V := O.quotientAt s g hg hUg hDg
    refine ⟨2, by norm_num, ?_⟩
    rintro ⟨T, hcap⟩
    have hgR : (0 : ℝ) < g := by exact_mod_cast hg
    have hsmall : (2 : ℝ) / g < 1 := by
      apply (div_lt_iff₀ hgR).2
      have hh : (3 : ℝ) ≤ g := by exact_mod_cast hg3
      linarith
    apply no_subcritical_record_cap V.a V.U V.D V.increasing V.a_pos V.U_pos V.D_pos
      V.U_step V.D_step V.lower V.record_bound V.den_bound V.unbounded
      g (2 / g) (by positivity) hsmall
    exact ⟨T, O.quotient_record_cap s g hg hUg hDg hs 2 T hcap⟩
