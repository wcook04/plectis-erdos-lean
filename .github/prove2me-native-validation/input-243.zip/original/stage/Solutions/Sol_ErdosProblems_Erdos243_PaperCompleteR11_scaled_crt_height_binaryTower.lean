import Definitions.Def_ErdosProblems_Erdos243_ReciprocalTailRigidity
import Definitions.Def_ErdosProblems_Erdos243_GlobalLcmHeight
import Definitions.Def_ErdosProblems_Erdos243_CumulativeLcmTransfer
import Definitions.Def_ErdosProblems_Erdos243_LcmRecordCrossing
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR7_Limits
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR7_RealTail
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR7_CanonicalState
import Definitions.Def_ErdosProblems_Erdos243_PrimitiveRecordBarrier
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_RecordDivisibility
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR7_ProductDefect
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR7_LcmDefect
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_GrowthRecordEquivalence
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_CanonicalGrowthBounds
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_CoprimeCores
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_LogLogNormaliser
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_OrbitBlockArithmetic
import Theorems.Thm_ErdosProblems_Erdos243_PaperCompleteR11_binaryTower_mono
import Theorems.Thm_ErdosProblems_Erdos243_PaperCompleteR11_binaryTower_succ
import Mathlib
import Mathlib.Algebra.Order.BigOperators.GroupWithZero.Finset
import Mathlib.Algebra.Ring.Basic
import Mathlib.Analysis.SpecialFunctions.Log.Basic
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Analysis.SumIntegralComparisons
import Mathlib.Data.Fin.Pigeonhole
import Mathlib.Data.Fintype.BigOperators
import Mathlib.Data.Nat.ChineseRemainder
import Mathlib.Data.Nat.Factorization.Basic
import Mathlib.Data.Nat.Find
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.Rat.Defs
import Mathlib.Data.ZMod.Basic
import Mathlib.Order.Filter.AtTopBot.Basic
import Mathlib.Tactic
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.InfiniteSum.NatInt

/-!
# Explicit square-sized blocks for the inclusive boundary

These bounds apply simultaneously
throughout a block whose width grows with the selection parameter. They
replace the previously missing uniform `ceil(log B)` estimates with exact
natural arithmetic on the cofinal choices `k = 2^t`, `B = k^2`.
-/

namespace ErdosProblems.Erdos243.PaperCompleteR11
open scoped BigOperators
end ErdosProblems.Erdos243.PaperCompleteR11

open scoped BigOperators
open ErdosProblems in
open ErdosProblems.Erdos243 in
open ErdosProblems.Erdos243.PaperCompleteR11 in
theorem solution (g P B h : ℕ)
    (hP : P ≤ binaryTower h) (hB : B ≤ binaryTower h) :
    g * (2 * P + B) ≤ binaryTower (h + g + 2) := by
  let S := binaryTower (h + g)
  have hS : 2 ≤ S := by
    have hh := binaryTower_mono (show 0 ≤ h + g by omega)
    norm_num [binaryTower] at hh
    exact hh
  have hPS : P ≤ S := hP.trans (binaryTower_mono (by omega))
  have hBS : B ≤ S := hB.trans (binaryTower_mono (by omega))
  have hgS : g ≤ S := by
    have hh := index_succ_le_two_pow g
    have hh' := index_succ_le_two_pow (2 ^ g)
    have ht := binaryTower_mono (show g ≤ h + g by omega)
    dsimp [S, binaryTower] at *
    omega
  have hfirst : g * (2 * P + B) ≤ 3 * S ^ 2 := by
    have hh := Nat.mul_le_mul hgS (show 2 * P + B ≤ 3 * S by omega)
    nlinarith
  have hsq : 3 ≤ S ^ 2 := by nlinarith
  calc
    g * (2 * P + B) ≤ 3 * S ^ 2 := hfirst
    _ ≤ S ^ 4 := by
      have hh := Nat.mul_le_mul_right (S ^ 2) hsq
      nlinarith
    _ = binaryTower (h + g + 2) := by
      rw [show h + g + 2 = (h + g + 1) + 1 by omega,
        binaryTower_succ, binaryTower_succ]
      dsimp [S]
      ring
