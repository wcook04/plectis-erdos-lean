import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_CubicSquareCoordinates
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_CubicFieldCoordinates
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR9_PolynomialCorrections
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_WindowIncidence
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_CubicIntegralNormalisation
import Theorems.Thm_ErdosProblems_Erdos243_PaperCompleteR11_nat_square_difference_ge_sum
import Theorems.Thm_ErdosProblems_Erdos243_PaperCompleteR11_unit_cubic_root_difference_dvd_six
import Mathlib
import Mathlib.Algebra.Order.BigOperators.GroupWithZero.Finset
import Mathlib.Algebra.Polynomial.SpecificDegree
import Mathlib.Algebra.Ring.Basic
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.Data.Fin.Pigeonhole
import Mathlib.Data.Int.GCD
import Mathlib.Data.Nat.ChineseRemainder
import Mathlib.Data.Nat.Choose.Basic
import Mathlib.Data.Nat.Find
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.Rat.Defs
import Mathlib.Data.ZMod.Basic
import Mathlib.Data.ZMod.QuotientRing
import Mathlib.Order.Filter.AtTopBot.Basic
import Mathlib.RingTheory.PowerBasis
import Mathlib.Tactic
import Mathlib.Tactic.Ring

/-!
# Complete rational-root classification for unit-constant cubic profiles

Authored proof candidates, UNRUN. For m > 0 and c = ±1, a rational root of
m*(X^3-X)+6*c forces m = 1 or m = 16. The reduced numerator and denominator
are constructed from the root. The resulting entire reducible unit branch
has exceptional lower density at least 1/5, by the existing explicit prime.
The unit premise is retained: it is NOT inferred from a positive-density bound.
-/

open ErdosProblems.Erdos243.PaperCompleteR11 in
theorem solution
    (m s t : ℕ) (hs : 0 < s) (ht : 0 < t) (hcop : Nat.Coprime s t)
    (heq : (s < t ∧ m * s * (t ^ 2 - s ^ 2) = 6 * t ^ 3) ∨
      (t < s ∧ m * s * (s ^ 2 - t ^ 2) = 6 * t ^ 3)) :
    (s = 1 ∧ t = 2 ∧ m = 16) ∨ (s = 2 ∧ t = 1 ∧ m = 1) := by
  have hd := unit_cubic_root_difference_dvd_six m s t hcop heq
  rcases hd with ⟨hlt, hd⟩ | ⟨hlt, hd⟩
  · have hb := Nat.le_of_dvd (by decide : 0 < 6) hd
    have hgap := nat_square_difference_ge_sum s t hlt
    have hs1 : s = 1 := by
      by_contra h
      have hs2 : 2 ≤ s := by omega
      have hgap5 : 5 ≤ t ^ 2 - s ^ 2 := by omega
      have hh := Nat.mul_le_mul hs2 hgap5
      omega
    have ht2 : t = 2 := by
      subst s
      have htge : 2 ≤ t := by omega
      have hpow : 1 ≤ t ^ 2 := by nlinarith
      have hsub := Nat.sub_add_cancel hpow
      norm_num at hb hsub
      by_contra h
      have hge : 3 ≤ t := by omega
      have hh := Nat.mul_le_mul hge hge
      nlinarith
    left
    refine ⟨hs1, ht2, ?_⟩
    rcases heq with ⟨_, hh⟩ | ⟨hh, _⟩
    · rw [hs1, ht2] at hh
      norm_num at hh
      omega
    · omega
  · have hb := Nat.le_of_dvd (by decide : 0 < 6) hd
    have hgap := nat_square_difference_ge_sum t s hlt
    have hs2 : s ≤ 2 := by
      by_contra h
      have hs3 : 3 ≤ s := by omega
      have hgap4 : 4 ≤ s ^ 2 - t ^ 2 := by omega
      have hh := Nat.mul_le_mul hs3 hgap4
      omega
    have hsEq : s = 2 := by omega
    have htEq : t = 1 := by omega
    right
    refine ⟨hsEq, htEq, ?_⟩
    rcases heq with ⟨hh, _⟩ | ⟨_, hh⟩
    · omega
    · rw [hsEq, htEq] at hh
      norm_num at hh
      omega
