import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR9_PolynomialCorrections
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_WindowIncidence
import Theorems.Thm_ErdosProblems_Erdos243_PaperCompleteR11_LowerDensityAtLeast_of_eventual_subset
import Mathlib
import Mathlib.Algebra.Ring.Basic
import Mathlib.Data.Rat.Defs
import Mathlib.Data.ZMod.Basic
import Mathlib.Tactic

/-! Finite-prefix and constant transport for the literal
lower asymptotic density used throughout the R11 window arguments. -/

namespace ErdosProblems.Erdos243.PaperCompleteR11
open ErdosProblems.Erdos243.PaperCompleteR9
end ErdosProblems.Erdos243.PaperCompleteR11

open ErdosProblems.Erdos243.PaperCompleteR9
open ErdosProblems.Erdos243.PaperCompleteR11 in
theorem solution (E F : Set ℕ) (T : ℕ) (d : ℝ)
    (heq : ∀ n, T ≤ n → (n ∈ E ↔ n ∈ F)) :
    LowerDensityAtLeast E d ↔ LowerDensityAtLeast F d := by
  constructor
  · intro h
    exact h.of_eventual_subset T (fun n hn ↦ (heq n hn).mp)
  · intro h
    exact h.of_eventual_subset T (fun n hn ↦ (heq n hn).mpr)
