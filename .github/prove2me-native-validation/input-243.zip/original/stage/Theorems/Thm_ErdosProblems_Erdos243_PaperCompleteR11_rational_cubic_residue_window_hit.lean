import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR9_PolynomialCorrections
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_WindowIncidence
import Mathlib
import Mathlib.Algebra.Ring.Basic
import Mathlib.Data.Rat.Defs
import Mathlib.Data.ZMod.Basic
import Mathlib.Data.ZMod.QuotientRing
import Mathlib.Tactic

/-!
# From actual modular cubic roots to the exceptional-set density

Rational profile coefficients are cleared over the
integers before reduction. There is deliberately no ring homomorphism from
`ℚ` to `ZMod p`. The final theorem is conditional on an actual divergent family
of good primes; producing that family from a number-field nonsquare remains a
separate global obligation, not a premise silently claimed to have been proved.
-/


open scoped BigOperators

open ErdosProblems.Erdos243.PaperCompleteR11

theorem ErdosProblems.Erdos243.PaperCompleteR11.rational_cubic_residue_window_hit
    (a u v : ℕ → ℤ) (P : ℕ → ℚ) (q A B : ℤ) (T n : ℕ) (hn : T ≤ n)
    (hclear : ∀ k : ℕ, (q : ℚ) * P k =
      (A : ℚ) * (k : ℚ) * ((k : ℚ) + 1) * ((k : ℚ) + 2) + (B : ℚ))
    (hnum : ∀ j, T ≤ j → u (j + 1) + v j = a j * u j)
    (hden : ∀ j, T ≤ j → v (j + 1) = a j * v j)
    (p : ℕ) [Fact p.Prime] (r : ZMod p)
    (hroot : (A : ZMod p) * (r ^ 3 - r) + (B : ZMod p) = 0)
    (hfactor : 3 * (A : ZMod p) * r ≠ 0)
    (hns : ¬ IsSquare (r ^ 2 - 1)) (hphase : (n : ZMod p) = r - 2) :
    ∃ j : ℕ, j < 3 ∧ (u (n + j) : ℚ) ≠ P (n + j) := by sorry
