import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR9_PolynomialCorrections
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_WindowIncidence
import Mathlib
import Mathlib.Algebra.Ring.Basic
import Mathlib.Data.Rat.Defs
import Mathlib.Data.ZMod.Basic
import Mathlib.Data.ZMod.QuotientRing
import Mathlib.Tactic

/-!
# From actual modular cubic roots to the exceptional-set density

Rational profile coefficients are cleared over the
integers before reduction. There is deliberately no ring homomorphism from
`ℚ` to `ZMod p`. The final theorem is conditional on an actual divergent family
of good primes; producing that family from a number-field nonsquare remains a
separate global obligation, not a premise silently claimed to have been proved.
-/


open scoped BigOperators

open ErdosProblems.Erdos243.PaperCompleteR11

theorem ErdosProblems.Erdos243.PaperCompleteR11.cubic_three_window_hit {K : Type*} [Field K]
    (u v a : ℕ → K) (A B r : K) (T n : ℕ) (hn : T ≤ n)
    (hnum : ∀ j, T ≤ j → u (j + 1) = a j * u j - v j)
    (hden : ∀ j, T ≤ j → v (j + 1) = a j * v j)
    (hroot : A * (r ^ 3 - r) + B = 0)
    (hfactor : 3 * A * r ≠ 0) (hns : ¬ IsSquare (r ^ 2 - 1))
    (hphase : (n : K) = r - 2) :
    ∃ j : ℕ, j < 3 ∧ u (n + j) ≠
      A * ((((n + j : ℕ) : K) + 1) ^ 3 - (((n + j : ℕ) : K) + 1)) + B := by sorry
