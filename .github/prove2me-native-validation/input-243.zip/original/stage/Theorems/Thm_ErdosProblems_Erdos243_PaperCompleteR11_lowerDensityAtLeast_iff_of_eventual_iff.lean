import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR9_PolynomialCorrections
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_WindowIncidence
import Mathlib
import Mathlib.Algebra.Ring.Basic
import Mathlib.Data.Rat.Defs
import Mathlib.Data.ZMod.Basic
import Mathlib.Tactic

/-! Finite-prefix and constant transport for the literal
lower asymptotic density used throughout the R11 window arguments. -/


open ErdosProblems.Erdos243.PaperCompleteR9

open ErdosProblems.Erdos243.PaperCompleteR11

theorem ErdosProblems.Erdos243.PaperCompleteR11.lowerDensityAtLeast_iff_of_eventual_iff (E F : Set ℕ) (T : ℕ) (d : ℝ)
    (heq : ∀ n, T ≤ n → (n ∈ E ↔ n ∈ F)) :
    LowerDensityAtLeast E d ↔ LowerDensityAtLeast F d := by sorry
