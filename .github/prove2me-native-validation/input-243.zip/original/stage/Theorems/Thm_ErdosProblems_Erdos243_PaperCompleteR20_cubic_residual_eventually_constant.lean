import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR20_CubicRateFiniteDifference
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR20_CubicRateDifferenceLimits
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR20_CubicRateResidualStep
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR20_CubicRateDefect
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR20_CubicRateNormalisation
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR20_CubicRateQuotientIncrement
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR20_CubicRateQuotientBounded
import Mathlib
import Mathlib.Analysis.PSeries
import Mathlib.Analysis.SpecialFunctions.Log.Summable

/-!
# Erdős 243: exact eventual cubic profile

Once the integer third difference is constant, the residual's third
difference is constant as well.  Every positive-order difference of the
residual tends to zero, so descending through the differences makes the
residual itself eventually constant.
-/

noncomputable section


open Filter

open ErdosProblems.Erdos243.PaperCompleteR20

theorem ErdosProblems.Erdos243.PaperCompleteR20.cubic_residual_eventually_constant
    (C : ℕ → ℤ) (K : ℝ) (r : ℕ → ℝ) (N : ℕ)
    (hdecomp : (fun n : ℕ => (C n : ℝ)) = fun n : ℕ => K * risingCubic n + r n)
    (hr : Tendsto (realForwardDiff r) atTop (nhds 0))
    (hthird : ∀ n, N ≤ n →
      iterIntForwardDiff 3 C n = iterIntForwardDiff 3 C N) :
    ∃ N' : ℕ, ∀ n, N' ≤ n → r n = r N' := by sorry
