import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR20_CubicRateFiniteDifference
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR20_CubicRateDifferenceLimits
import Mathlib

/-!
# Erdős 243: limit transport for the cubic finite-difference extraction

The paper's analytic comparison produces a residual whose first forward
difference tends to zero.  This file proves that this is exactly enough for
the fourth difference of the integer numerator to tend to zero, because the
rising cubic has identically zero fourth difference.
-/

noncomputable section


open Filter

open ErdosProblems.Erdos243.PaperCompleteR20

@[simp] theorem ErdosProblems.Erdos243.PaperCompleteR20.iterRealForwardDiff_succ (k : ℕ) (u : ℕ → ℝ) :
    iterRealForwardDiff (k + 1) u = realForwardDiff (iterRealForwardDiff k u) := by sorry
