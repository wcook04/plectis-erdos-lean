import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR20_CubicRateFiniteDifference
import Mathlib

/-!
# Erdős 243: integer finite differences for the cubic-rate bridge

This file isolates the discrete integrality step in the proof of the paper's
cubic-rate theorem.  Once the analytic comparison with the rising-factorial
model shows that a sufficiently high finite difference tends to zero, its
integer values force it to vanish identically on a tail.
-/

noncomputable section


open Filter

open ErdosProblems.Erdos243.PaperCompleteR20

@[simp] theorem ErdosProblems.Erdos243.PaperCompleteR20.iterIntForwardDiff_succ (k : ℕ) (u : ℕ → ℤ) :
    iterIntForwardDiff (k + 1) u = intForwardDiff (iterIntForwardDiff k u) := by sorry
