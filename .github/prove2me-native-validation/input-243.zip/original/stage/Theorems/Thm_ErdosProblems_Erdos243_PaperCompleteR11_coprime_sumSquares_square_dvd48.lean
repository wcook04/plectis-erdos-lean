import Mathlib

namespace ErdosProblems.Erdos243.PaperCompleteR11
end ErdosProblems.Erdos243.PaperCompleteR11

/-! UNRUN. Exact coefficient and denominator arithmetic in the cubic
classification. These declarations do not construct a number-field basis or
supply a prime-specialisation theorem. -/

open ErdosProblems.Erdos243.PaperCompleteR11

theorem ErdosProblems.Erdos243.PaperCompleteR11.coprime_sumSquares_square_dvd48
    (r s : ℕ) (hr : 0 < r) (hs : 0 < s)
    (hcop : Nat.Coprime r s) (hd : (r ^ 2 + s ^ 2) ^ 2 ∣ 48) :
    r = 1 ∧ s = 1 := by sorry
