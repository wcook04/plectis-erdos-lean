import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR9_PolynomialCorrections
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_WindowIncidence
import Mathlib
import Mathlib.Algebra.Ring.Basic
import Mathlib.Data.Rat.Defs
import Mathlib.Data.ZMod.Basic
import Mathlib.Data.ZMod.QuotientRing
import Mathlib.Tactic

/-!
# From actual modular cubic roots to the exceptional-set density

Rational profile coefficients are cleared over the
integers before reduction. There is deliberately no ring homomorphism from
`ℚ` to `ZMod p`. The final theorem is conditional on an actual divergent family
of good primes; producing that family from a number-field nonsquare remains a
separate global obligation, not a premise silently claimed to have been proved.
-/


open scoped BigOperators

open ErdosProblems.Erdos243.PaperCompleteR11

theorem ErdosProblems.Erdos243.PaperCompleteR11.cubic_profile_integer_clearing (κ η : ℚ) :
    ∃ q A B : ℤ, 0 < q ∧
      (∀ n : ℕ, (q : ℚ) *
        (κ * (n : ℚ) * ((n : ℚ) + 1) * ((n : ℚ) + 2) + η) =
        (A : ℚ) * (n : ℚ) * ((n : ℚ) + 1) * ((n : ℚ) + 2) + (B : ℚ)) ∧
      (κ ≠ 0 → A ≠ 0) := by sorry
