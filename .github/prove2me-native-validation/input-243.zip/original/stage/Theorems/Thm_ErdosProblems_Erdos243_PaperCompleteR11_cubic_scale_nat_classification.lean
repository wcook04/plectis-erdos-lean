import Mathlib

namespace ErdosProblems.Erdos243.PaperCompleteR11
end ErdosProblems.Erdos243.PaperCompleteR11

/-! UNRUN. Exact coefficient and denominator arithmetic in the cubic
classification. These declarations do not construct a number-field basis or
supply a prime-specialisation theorem. -/

open ErdosProblems.Erdos243.PaperCompleteR11

theorem ErdosProblems.Erdos243.PaperCompleteR11.cubic_scale_nat_classification
    (m r s : ℕ) (hr : 0 < r) (hs : 0 < s) (hcop : Nat.Coprime r s)
    (heq : m * (r ^ 2 + s ^ 2) ^ 2 = 48 * r ^ 3 * s ∨
      m * (r ^ 2 + s ^ 2) ^ 2 = 48 * r * s ^ 3) :
    r = 1 ∧ s = 1 ∧ m = 12 := by sorry
