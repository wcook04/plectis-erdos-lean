import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR7_RealTail
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR7_CanonicalState
import Mathlib.Algebra.Order.BigOperators.GroupWithZero.Finset
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Data.Fin.Pigeonhole
import Mathlib.Data.Nat.ChineseRemainder
import Mathlib.Data.Nat.Find
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.ZMod.Basic
import Mathlib.Order.Filter.AtTopBot.Basic
import Mathlib.Tactic
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.InfiniteSum.NatInt

/-!
# The original-coordinate bounded-product-defect corollary

Compiled candidates.  This module supplies the analytic error dictionary
rather than assuming bounded centred error.  Finite upper limsup is stated
as eventual boundedness above by a real constant; the finite initial
segment is irrelevant.  Rationality is given by p/q and HasSum.

The proof avoids assuming a pre-existing double-exponential estimate:
P_n/a_n^2 tends to zero by its successive-ratio identity.  This suffices
for the exact two-term error dictionary.
-/


open Filter
open scoped BigOperators

open ErdosProblems.Erdos243.PaperCompleteR7

theorem ErdosProblems.Erdos243.PaperCompleteR7.positive_sequence_zero_of_ratio_zero
    (u : ℕ → ℝ) (hu : ∀ n, 0 < u n)
    (hratio : Tendsto (fun n ↦ u (n + 1) / u n) atTop (nhds 0)) :
    Tendsto u atTop (nhds 0) := by sorry
