import Definitions.Def_ErdosProblems_Erdos243_ReciprocalTailRigidity
import Definitions.Def_ErdosProblems_Erdos243_GlobalLcmHeight
import Definitions.Def_ErdosProblems_Erdos243_CumulativeLcmTransfer
import Definitions.Def_ErdosProblems_Erdos243_LcmRecordCrossing
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR7_Limits
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR7_RealTail
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR7_CanonicalState
import Definitions.Def_ErdosProblems_Erdos243_PrimitiveRecordBarrier
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_RecordDivisibility
import Mathlib
import Mathlib.Algebra.Order.BigOperators.GroupWithZero.Finset
import Mathlib.Algebra.Ring.Basic
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Data.Fin.Pigeonhole
import Mathlib.Data.Nat.ChineseRemainder
import Mathlib.Data.Nat.Factorization.Basic
import Mathlib.Data.Nat.Find
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.Rat.Defs
import Mathlib.Data.ZMod.Basic
import Mathlib.Order.Filter.AtTopBot.Basic
import Mathlib.Tactic
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.InfiniteSum.NatInt

/-!
# Record fences without primitivity


Unlike a source-jump fence, the result below charges the *record increment*.
It allows arbitrarily deep intervening drawdowns and does not assume that
numerator and denominator are coprime. It is a finite ingredient of the
inclusive log-log argument, not a declaration of that analytic endpoint.
-/


open scoped BigOperators

open ErdosProblems.Erdos243.PaperCompleteR11

theorem ErdosProblems.Erdos243.PaperCompleteR11.bounded_by_record_cover
    (U : ℕ → ℕ) (D a b : ℕ → ℤ) (T x B : ℕ)
    (hC : ∀ k, (U (k + 1) : ℤ) = a k * U k - b k * D k)
    (hD : ∀ k, D (k + 1) = a k * D k)
    (hprefix : runningMax U T < x)
    (hcover : ∀ j, T ≤ j → ∀ z : ℕ, x ≤ z → z < x + B →
      ∃ m : ℤ, (B : ℤ) < m ∧ m ∣ (z : ℤ) ∧ m ∣ D j)
    (hcap : ∀ n, T ≤ n → runningMax U n < x + B →
      runningMax U n < U (n + 1) →
      U (n + 1) - runningMax U n ≤ B) :
    ∀ k, U k < x + B := by sorry
