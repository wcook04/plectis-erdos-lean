import Mathlib

namespace ErdosProblems.Erdos243.PaperCompleteR11
end ErdosProblems.Erdos243.PaperCompleteR11

/-!
# From an actual rational parameter to the integer scale

The numerator and denominator are obtained from the rational itself. In
particular, coprimality and positivity are proved here, not supplied as
additional assumptions on a purported parametrisation.
-/

open ErdosProblems.Erdos243.PaperCompleteR11

theorem ErdosProblems.Erdos243.PaperCompleteR11.rational_abs_reduced_positive (w : ℚ) (hw : w ≠ 0) :
    0 < w.num.natAbs ∧ 0 < w.den ∧
      Nat.Coprime w.num.natAbs w.den ∧
      |w| = (w.num.natAbs : ℚ) / (w.den : ℚ) := by sorry
