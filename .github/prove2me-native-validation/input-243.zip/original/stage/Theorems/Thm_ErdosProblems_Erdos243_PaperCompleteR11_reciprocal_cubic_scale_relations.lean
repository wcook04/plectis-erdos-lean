import Mathlib

namespace ErdosProblems.Erdos243.PaperCompleteR11
end ErdosProblems.Erdos243.PaperCompleteR11

/-! UNRUN. Exact coefficient and denominator arithmetic in the cubic
classification. These declarations do not construct a number-field basis or
supply a prime-specialisation theorem. -/

open ErdosProblems.Erdos243.PaperCompleteR11

theorem ErdosProblems.Erdos243.PaperCompleteR11.reciprocal_cubic_scale_relations
    {K : Type*} [Field K] (b d w η : K)
    (h5 : b * w + d = 0)
    (h4 : d * w + b * d + b = -w)
    (h3 : w ^ 2 + 1 + b ^ 2 + d ^ 2 = 8 * η * w) :
    (w ^ 2 + 1) ^ 2 = 8 * η * w ^ 3 ∨
      (w ^ 2 + 1) ^ 2 = 8 * η * w := by sorry
