import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_CubicSquareCoordinates
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_CubicFieldCoordinates
import Mathlib
import Mathlib.FieldTheory.IntermediateField.Adjoin.Basic
import Mathlib.RingTheory.PowerBasis

/-!
# Scale twelve from the actual irreducible cubic root field

Candidate source. Lean elaboration and the axiom audit are UNRUN.
The root field is the actual intermediate field ℚ(α). Its power basis,
dimension, rational coordinates and reduced scale parameter are constructed
from the irreducible polynomial and square-root hypotheses. No Chebotarev
prime-production result is needed for this algebraic implication; obtaining
the square-root hypothesis from reductions is a separate endpoint.
-/


open Polynomial

noncomputable section

open ErdosProblems.Erdos243.PaperCompleteR11

theorem ErdosProblems.Erdos243.PaperCompleteR11.cubic_scale_twelve_of_square_in_adjoin
    {L : Type*} [Field L] [Algebra ℚ L]
    (m : ℕ) (c : ℚ) (hm : 0 < m) (hc : c = 1 ∨ c = -1)
    (α β : L)
    (hirr : Irreducible (cubicScalePolynomial (6*c/(m : ℚ))))
    (hroot : α^3 = α - algebraMap ℚ L (6*c/(m : ℚ)))
    (hβmem : β ∈ IntermediateField.adjoin ℚ ({α} : Set L))
    (hβ : β^2 = α^2 - 1) : m = 12 := by sorry
