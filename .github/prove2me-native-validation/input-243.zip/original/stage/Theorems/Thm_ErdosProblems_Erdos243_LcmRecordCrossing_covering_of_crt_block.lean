import Definitions.Def_ErdosProblems_Erdos243_ReciprocalTailRigidity
import Definitions.Def_ErdosProblems_Erdos243_LcmRecordCrossing
import Mathlib
import Mathlib.Algebra.Order.BigOperators.GroupWithZero.Finset
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.Data.Fin.Pigeonhole
import Mathlib.Data.Nat.ChineseRemainder
import Mathlib.Data.Nat.Find
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.ZMod.Basic
import Mathlib.Order.Filter.AtTopBot.Basic
import Mathlib.Tactic.Ring

namespace LcmRecordExcess
end LcmRecordExcess

/-!
# Counting the CRT heights crossed by one arithmetic step

The heights are the actual arithmetic progression `x + k * P`, not an
assumed cardinality bound. This supplies the finite local charging step in
the weighted-record argument of `LcmRecordExcess.md`. First-crossing existence,
uniqueness, and the finite partition across time require no monotonicity of
the numerator sequence. The existing CRT construction supplies the covering
from any finite family of sufficiently large pairwise-coprime old divisors.
Producing that family from an infinite canonical orbit and the analytic
divergence argument are not asserted by this module.
-/


open LcmRecordExcess

open ErdosProblems.Erdos243.LcmRecordCrossing

theorem ErdosProblems.Erdos243.LcmRecordCrossing.covering_of_crt_block {B : ℕ} (m : Fin B → ℕ)
    (x P k : ℕ) (L : ℤ)
    (hm : ∀ i, B < m i) (hmP : ∀ i, m i ∣ P)
    (hmL : ∀ i, (m i : ℤ) ∣ L)
    (hresidue : ∀ i, m i ∣ x + i.1) :
    ∀ z : ℤ, (x + B + k * P : ℕ) - (B : ℤ) ≤ z →
      z < (x + B + k * P : ℕ) →
      ∃ d : ℤ, (B : ℤ) < d ∧ d ∣ L ∧ d ∣ z := by sorry
