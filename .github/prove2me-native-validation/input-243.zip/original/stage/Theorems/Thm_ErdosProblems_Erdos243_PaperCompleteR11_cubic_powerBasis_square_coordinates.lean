import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_CubicSquareCoordinates
import Definitions.Def_ErdosProblems_Erdos243_PaperCompleteR11_CubicFieldCoordinates
import Mathlib
import Mathlib.RingTheory.PowerBasis

/-!
# Extracting the square-root coordinates from a cubic algebra

The power-basis representation is extracted from the actual square root.
The degree bound then forces all three rational coordinate equations.
No trace, norm, coordinate equation, or coefficient relation is assumed.
-/


open Polynomial
open scoped BigOperators

noncomputable section

open ErdosProblems.Erdos243.PaperCompleteR11

theorem ErdosProblems.Erdos243.PaperCompleteR11.cubic_powerBasis_square_coordinates
    {K : Type*} [CommRing K] [Nontrivial K] [Algebra ℚ K]
    (pb : PowerBasis ℚ K) (hdim : pb.dim = 3) (η : ℚ)
    (hroot : pb.gen^3 = pb.gen - algebraMap ℚ K η)
    (β : K) (hsquare : β^2 = pb.gen^2 - 1) :
    ∃ x y z : ℚ,
      β = algebraMap ℚ K x * pb.gen^2 + algebraMap ℚ K y * pb.gen +
        algebraMap ℚ K z ∧
      x^2 + 2*x*z + y^2 - 1 = 0 ∧
      2*x*y + 2*y*z - η*x^2 = 0 ∧
      z^2 - 2*η*x*y + 1 = 0 := by sorry
