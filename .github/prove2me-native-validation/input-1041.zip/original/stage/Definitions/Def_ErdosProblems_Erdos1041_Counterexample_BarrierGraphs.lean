import Definitions.Def_ErdosProblems_Erdos1041_Counterexample_BarrierAlgebra
import Mathlib
import Mathlib.Algebra.Polynomial.Derivative
import Mathlib.Algebra.Polynomial.Div
import Mathlib.Algebra.Polynomial.Roots
import Mathlib.Analysis.SpecialFunctions.Complex.Log
import Mathlib.Analysis.SpecialFunctions.Pow.Real
import Mathlib.Analysis.SpecialFunctions.Trigonometric.Basic
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Ring
import Mathlib.Topology.Connected.LocallyConnected
import Mathlib.Topology.EMetricSpace.BoundedVariation

/-! External source: ani, erdosproblems.com forum thread 1041, 7 Sept 2026.
Explicit separating barriers replacing the Riemann-Hurwitz step of Lemma 2.1, at `s = 10⁻⁶`. -/

noncomputable section
namespace Erdos1041.Counterexample.S7Proof

set_option maxRecDepth 10000
set_option maxHeartbeats 8000000

def l1_01 (x : ℝ) : ℝ := (955 / 3962) * x + (-31775 / 7924)
def l1_12 (x : ℝ) : ℝ := (-539296338829 / 44668564793666) * x + (4076722807313861 / 446685647936660)
def l1_23 (x : ℝ) : ℝ := (-1220013986006 / 25180573091109) * x + (47287422848540256709986673 / 5036114618221800000000000)
def l1_34 (x : ℝ) : ℝ := (-7548137935033 / 41210172423045) * x + (287305378858768 / 41210172423045)




def phi1 (x : ℝ) : ℝ :=
  max (-(3 / 14 : ℝ) * x)
    (max (l1_34 x) (max (l1_23 x) (max (l1_12 x) (min (l1_01 x) ((9 / 40 : ℝ) * x)))))
























































def Hcoord (x e : ℝ) : ℝ :=
  Hpoly ((-5 * x + 4 * e) / 41) ((4 * x + 5 * e) / 41)









end Erdos1041.Counterexample.S7Proof
