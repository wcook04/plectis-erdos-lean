import Mathlib
import Mathlib.Algebra.Polynomial.Derivative
import Mathlib.Algebra.Polynomial.Div
import Mathlib.Algebra.Polynomial.Roots
import Mathlib.Analysis.SpecialFunctions.Complex.Log
import Mathlib.Analysis.SpecialFunctions.Pow.Real
import Mathlib.Analysis.SpecialFunctions.Trigonometric.Basic
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Ring
import Mathlib.Topology.Connected.LocallyConnected
import Mathlib.Topology.EMetricSpace.BoundedVariation

/-! External source: ani, erdosproblems.com forum thread 1041, 7 Sept 2026.
Formalisation of Lemma 2.3 and Corollary 2.4 from `ani_degree7_counterexample.tex`. -/

/-!
This module owns slice S3 and declares `s3_bottleneck_length` at the interface
name and statement, with no `sorry`.

The proof isolates two topological hypotheses.  The covering hypothesis is
`s3_bottleneck_isCoveringMap`.  The
connectedness hypothesis is replaced by the sharper
`bottleneck_slit_preimage_near`: the holomorphic square root of `𝒜/â` supplies
the paper's quadratic coordinate `ψ`, its two branches `ψ = ±η` give two
preimages of each slit point next to `cc`, `hzeros` makes the covering
two-sheeted, and a third preimage anywhere in the component would produce a
third preimage of a nearby point of the slit disc.  So every slit preimage in
the component is one of the two local branches, hence inside the disk-criterion
radius.  Neither Rouché's theorem nor the argument principle is used; see
`bottleneck_ball_subset_image` and `bottleneck_sublevel_isPreconnected`.
-/

noncomputable section

open Topology

namespace Erdos1041.Counterexample

/-! ### Two `ℝ`-on-`ℂ` scalar-action instances

`StarConvex ℝ (0 : ℂ)` elaborates its `SMul ℝ ℂ` to `Algebra.toSMul` (through
`NormedAlgebra ℝ ℂ`), and for that particular instance path Mathlib v4.29.1 does
not resolve `ContinuousSMul ℝ ℂ` or `NormSMulClass ℝ ℂ` by typeclass search.
Both are true and are proved here from `Complex.real_smul`, which rewrites the
action to multiplication by the real coercion.  They are `private`: nothing
outside this file needs them. -/

private instance instContinuousSMulRealComplex : ContinuousSMul ℝ ℂ where
  continuous_smul := by
    have hfun : (fun p : ℝ × ℂ => p.1 • p.2) = fun p : ℝ × ℂ => (p.1 : ℂ) * p.2 := by
      funext p
      exact Complex.real_smul
    rw [hfun]
    exact (Complex.continuous_ofReal.comp continuous_fst).mul continuous_snd

private instance instNormSMulClassRealComplex : NormSMulClass ℝ ℂ where
  norm_smul r z := by
    rw [show r • z = (r : ℂ) * z from Complex.real_smul, norm_mul]
    simp

































































section Probe
end Probe

/-! ## Two complex-analysis tools

Mathlib v4.29.1 has neither Rouché's theorem nor the argument principle, and
`DiffContOnCl.ball_subset_image_closedBall` loses a factor of two that the
constants of Corollary 2.4 cannot afford.  Both tools are proved here instead
from the open mapping theorem and the maximum modulus principle. -/





/-! ## The quadratic coordinate `ψ` of Corollary 2.4

The paper's inverse quadratic coordinate `χ` is built from the holomorphic
square root of `𝒜(z)/â`, which exists because the disk criterion `hdisk` puts
that quotient in `closedBall 1 (1/4)`, well inside `Complex.slitPlane`. -/































/-! ## The two local preimages lie in the distinguished component

Both preimages produced by `bottleneck_two_preimages` sit inside the sublevel
set `‖ψ‖ < s`, on which `‖p - p cc‖ = ‖â‖ ‖ψ‖² < δ`, so that sublevel set lies
inside the lemniscate.  It is preconnected by the minimum-modulus tool, and it
contains `0`; so its translate by `cc` is a preconnected subset of `Ω(p)`
through `cc`, hence inside the component. -/







/-! ## The covering hypothesis, discharged

`hcover` in `bottleneck_length_of_covering_and_preconnected` is the statement
that `p` restricted to the slit complement inside the distinguished component is
a covering map over the slit disc.  `PROOF.md` §2 gives the argument: the
restriction is proper (a polynomial is a proper map, the component is relatively
closed in the lemniscate) and a local homeomorphism (`huniq` puts the only
critical point at `cc`, whose value `p cc` is removed with the slit), and a
proper local homeomorphism out of a Hausdorff space is a covering map, which is
slice S2's `s2_isCoveringMap_of_isProperMap_of_isLocalHomeomorph`. -/















/-! ## The fibres over the slit have at most two points

`hzeros` pins the fibre of the covering over `0` to `{b₁, b₂}`, so the covering
over the simply connected slit disc has exactly two sheets: the sections through
`b₁` and through `b₂`.  Points of the slit itself are limits of the slit disc,
so a third preimage there would produce a third preimage of a nearby point of
the slit disc through its inverse chart. -/













/-! ## Lemma 2.3 and Corollary 2.4

Both topological inputs of the conditional reduction are now discharged: the
covering by `s3_bottleneck_isCoveringMap`, and the localisation of the slit
preimage by `bottleneck_slit_preimage_near`, which replaces preconnectedness of
the whole slit preimage by the sharper statement that the two branches at `cc`
already exhaust each slit fibre. -/



end Erdos1041.Counterexample
