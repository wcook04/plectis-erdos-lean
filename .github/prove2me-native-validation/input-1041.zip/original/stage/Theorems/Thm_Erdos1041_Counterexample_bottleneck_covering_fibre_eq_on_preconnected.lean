import Definitions.Def_ErdosProblems_Erdos1041_Counterexample_Defs
import Definitions.Def_ErdosProblems_Erdos1041_Counterexample_Bottleneck
import Mathlib
import Mathlib.Algebra.Polynomial.Derivative
import Mathlib.Algebra.Polynomial.Div
import Mathlib.Algebra.Polynomial.Roots
import Mathlib.Analysis.SpecialFunctions.Complex.Log
import Mathlib.Analysis.SpecialFunctions.Pow.Real
import Mathlib.Analysis.SpecialFunctions.Trigonometric.Basic
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Ring
import Mathlib.Topology.Connected.LocallyConnected
import Mathlib.Topology.EMetricSpace.BoundedVariation

open Erdos1041
open Erdos1041.Counterexample
noncomputable section
open Topology

open Erdos1041.Counterexample

theorem Erdos1041.Counterexample.bottleneck_covering_fibre_eq_on_preconnected
    {E B T : Type*} [TopologicalSpace E] [T2Space E]
    [TopologicalSpace B] [TopologicalSpace T]
    [SimplyConnectedSpace B] [LocPathConnectedSpace B]
    (π : E → B) (hπ : IsCoveringMap π)
    (S : Set T) (hS : IsPreconnected S) (g : T → E) (hg : ContinuousOn g S)
    (a b : T) (ha : a ∈ S) (hb : b ∈ S) (hab : π (g a) = π (g b)) :
    g a = g b := by sorry
