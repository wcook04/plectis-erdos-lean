import Definitions.Def_ErdosProblems_Erdos1041_Counterexample_Defs
import Definitions.Def_ErdosProblems_Erdos1041_Counterexample_InstanceCritical
import Mathlib.Algebra.Polynomial.Derivative
import Mathlib.Algebra.Polynomial.Div
import Mathlib.Algebra.Polynomial.Roots
import Mathlib.Analysis.Real.Pi.Bounds
import Mathlib.Analysis.SpecialFunctions.Complex.Log
import Mathlib.Analysis.SpecialFunctions.Pow.Real
import Mathlib.Analysis.SpecialFunctions.Trigonometric.Basic
import Mathlib.Tactic
import Mathlib.Tactic.ComputeDegree
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Ring
import Mathlib.Topology.Connected.LocallyConnected
import Mathlib.Topology.EMetricSpace.BoundedVariation
import Mathlib.Topology.MetricSpace.Contracting
import Mathlib.Topology.Order.IntermediateValue

open Erdos1041
open Erdos1041.Counterexample
open Erdos1041.Counterexample.S4Proofs
noncomputable section
open scoped ComplexConjugate NNReal

open Erdos1041.Counterexample.S4Proofs

theorem Erdos1041.Counterexample.S4Proofs.Q_var_on_disk {v : ℂ} {rr g1 g2 g3 g4 g5 g6 g7 : ℝ} (hr : 0 ≤ rr)
    (h1 : ‖qT1 v‖ ≤ g1) (h2 : ‖qT2 v‖ ≤ g2) (h3 : ‖qT3 v‖ ≤ g3) (h4 : ‖qT4 v‖ ≤ g4)
    (h5 : ‖qT5 v‖ ≤ g5) (h6 : ‖qT6 v‖ ≤ g6) (h7 : ‖qT7‖ ≤ g7) :
    ∀ w : ℂ, ‖w - v‖ ≤ rr →
      ‖Q.eval w - qT0 v‖
        ≤ g1 * rr + g2 * rr ^ 2 + g3 * rr ^ 3 + g4 * rr ^ 4 + g5 * rr ^ 5 + g6 * rr ^ 6
          + g7 * rr ^ 7 := by sorry
