import Definitions.Def_ErdosProblems_Erdos1041_Counterexample_Defs
import Definitions.Def_ErdosProblems_Erdos1041_Counterexample_BarrierAlgebra
import Definitions.Def_ErdosProblems_Erdos1041_Counterexample_BarrierGraphs
import Definitions.Def_ErdosProblems_Erdos1041_Counterexample_BarrierSigns
import Definitions.Def_ErdosProblems_Erdos1041_Counterexample_Bottleneck
import Definitions.Def_ErdosProblems_Erdos1041_Counterexample_InstanceBarriers
import Definitions.Def_ErdosProblems_Erdos1041_Counterexample_InstanceCritical
import Definitions.Def_ErdosProblems_Erdos1041_Counterexample_InstanceConnectivity
import Mathlib
import Mathlib.Algebra.Polynomial.Derivative
import Mathlib.Algebra.Polynomial.Div
import Mathlib.Algebra.Polynomial.Roots
import Mathlib.Analysis.Calculus.Deriv.Polynomial
import Mathlib.Analysis.Real.Pi.Bounds
import Mathlib.Analysis.SpecialFunctions.Complex.Log
import Mathlib.Analysis.SpecialFunctions.Pow.Real
import Mathlib.Analysis.SpecialFunctions.Trigonometric.Basic
import Mathlib.Tactic
import Mathlib.Tactic.ComputeDegree
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Ring
import Mathlib.Topology.Connected.LocallyConnected
import Mathlib.Topology.Connected.PathConnected
import Mathlib.Topology.EMetricSpace.BoundedVariation
import Mathlib.Topology.MetricSpace.Contracting
import Mathlib.Topology.Order.IntermediateValue

namespace Erdos1041.Counterexample.AssemblyAux
end Erdos1041.Counterexample.AssemblyAux

open Erdos1041
open Erdos1041.Counterexample
open Erdos1041.Counterexample.AssemblyAux
noncomputable section
open scoped ComplexConjugate ENNReal

open Erdos1041.Counterexample.AssemblyAux

theorem Erdos1041.Counterexample.AssemblyAux.sqrt_le_scaled {r e δ M : ℝ} (hr : 0 < r) (he : 0 < e)
    (hδ : δ ≤ r ^ 7 * e ^ 7 * (36 / 5 / 10 ^ 6))
    (hM : 180 * r ^ 5 * e ^ 5 ≤ M) :
    Real.sqrt (δ / M) ≤ r * e / 5000 := by sorry
