import Definitions.Def_ErdosProblems_Erdos1041_Counterexample_Defs
import Definitions.Def_ErdosProblems_Erdos1041_Counterexample_Bottleneck
import Mathlib
import Mathlib.Algebra.Polynomial.Derivative
import Mathlib.Algebra.Polynomial.Div
import Mathlib.Algebra.Polynomial.Roots
import Mathlib.Analysis.SpecialFunctions.Complex.Log
import Mathlib.Analysis.SpecialFunctions.Pow.Real
import Mathlib.Analysis.SpecialFunctions.Trigonometric.Basic
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Ring
import Mathlib.Topology.Connected.LocallyConnected
import Mathlib.Topology.EMetricSpace.BoundedVariation

open Erdos1041
open Erdos1041.Counterexample
noncomputable section
open Topology

open Erdos1041.Counterexample

theorem Erdos1041.Counterexample.bottleneck_no_three_preimages (p : Polynomial ℂ) (cc : ℂ) (hv : p.eval cc ≠ 0)
    (hcover : IsCoveringMap (bottleneckSlitProjection p cc))
    (b₁ b₂ : ℂ)
    (hb₁ : b₁ ∈ connectedComponentIn (Omega p) cc)
    (hb₂ : b₂ ∈ connectedComponentIn (Omega p) cc)
    (hr₁ : p.IsRoot b₁) (hr₂ : p.IsRoot b₂)
    (hzeros : ∀ w ∈ connectedComponentIn (Omega p) cc, p.IsRoot w → w = b₁ ∨ w = b₂)
    (huniq : ∀ c' ∈ connectedComponentIn (Omega p) cc,
      (Polynomial.derivative p).IsRoot c' → c' = cc)
    (ξ : ℂ) (hξ : ξ ∈ bottleneckSlit (p.eval cc)) (hξv : ξ ≠ p.eval cc)
    (w₁ w₂ w₃ : ℂ)
    (hw₁ : w₁ ∈ connectedComponentIn (Omega p) cc)
    (hw₂ : w₂ ∈ connectedComponentIn (Omega p) cc)
    (hw₃ : w₃ ∈ connectedComponentIn (Omega p) cc)
    (hp₁ : p.eval w₁ = ξ) (hp₂ : p.eval w₂ = ξ) (hp₃ : p.eval w₃ = ξ)
    (n12 : w₁ ≠ w₂) (n13 : w₁ ≠ w₃) (n23 : w₂ ≠ w₃) : False := by sorry
