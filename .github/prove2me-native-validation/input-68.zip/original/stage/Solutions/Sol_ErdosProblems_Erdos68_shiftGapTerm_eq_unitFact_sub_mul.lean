import Definitions.Def_ErdosProblems_Erdos68_CanonicalFactorialDigits
import Definitions.Def_ErdosProblems_Erdos68_ChannelBreakpointRigidity
import Definitions.Def_ErdosProblems_Erdos68_ChannelIntegralCongruence
import Definitions.Def_ErdosProblems_Erdos68_PrimeUnitTranslator
import Definitions.Def_ErdosProblems_Erdos68_FactorialGapPlateauCore
import Definitions.Def_ErdosProblems_Erdos68_CompanionConstantBridge
import Definitions.Def_ErdosProblems_Erdos68_ConstantOnlyMissCertificates
import Definitions.Def_ErdosProblems_Erdos68_SecondLayerDigit
import Definitions.Def_ErdosProblems_Erdos68_CompanionOrbitRationality
import Definitions.Def_ErdosProblems_Erdos68_FactorialShiftFamilyOrbit
import Mathlib.Algebra.BigOperators.Fin
import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Algebra.GCDMonoid.FinsetLemmas
import Mathlib.Algebra.Order.Floor.Ring
import Mathlib.Algebra.Order.Round
import Mathlib.Algebra.Ring.GeomSum
import Mathlib.Analysis.Asymptotics.Defs
import Mathlib.Analysis.Complex.ExponentialBounds
import Mathlib.Analysis.Real.Pi.Bounds
import Mathlib.Analysis.SpecialFunctions.Stirling
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Data.Fin.VecNotation
import Mathlib.Data.Int.Basic
import Mathlib.Data.Nat.Cast.Field
import Mathlib.Data.Nat.Factorial.Basic
import Mathlib.Data.Nat.Factorial.BigOperators
import Mathlib.Data.Nat.ModEq
import Mathlib.Data.Nat.Multiplicity
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.Rat.Floor
import Mathlib.LinearAlgebra.Matrix.Adjugate
import Mathlib.LinearAlgebra.Vandermonde
import Mathlib.NumberTheory.Real.Irrational
import Mathlib.Tactic
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.FinCases
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.InfiniteSum.Basic
import Mathlib.Topology.Algebra.InfiniteSum.Ring

/-!
# Erdős's shifted-factorial family under one companion-orbit boundary

Erdős asked whether `S_t = ∑_{n≥2} 1/(n!+t)` is irrational for every integer
`t`; Problem #68 is the member `t = −1`.  The termwise identity

`1/(n!+t) = 1/n! − t/(n!(n!+t))`

writes every member as `S_t = (e − 2) − t·C_t` with the shifted companion
constant `C_t = ∑_{n≥2} 1/(n!(n!+t))`.  The generic fixed-orbit boundary of
`CompanionOrbitRationality` therefore applies uniformly: for every integer
`t ≥ −1`,

`S_t ∈ ℚ  ⟺  ⌈t·m!·C_t⌉ ≡ 2 (mod m)  for all sufficiently large m`,

equivalently `S_t ∉ ℚ` iff the ceiling escapes the residue `2` cofinally.
The member `t = −1` recovers `⌊m!·C⌋ ≡ −2 (mod m)`, and the member `t = 0`
has `C_0`-orbit `⌈0⌉ = 0`, which never lies in the residue class `2` for
`m ≥ 3`; this reproves the irrationality of `e`.

No member with `t ≠ 0` is decided here.  The theorem is the exact family
boundary, not an irrationality proof for any nonzero shift.
-/

namespace ErdosProblems.Erdos68
open scoped BigOperators









/-- For `t ≥ −1` and `n ≥ 2` the shifted denominator dominates `n! − 1 ≥ 1`. -/
private theorem factorial_sub_one_le_add_shift {t : ℤ} (ht : -1 ≤ t)
    {n : ℕ} (hn : 2 ≤ n) :
    (1 : ℝ) ≤ (n.factorial : ℝ) - 1 ∧
      (n.factorial : ℝ) - 1 ≤ (n.factorial : ℝ) + (t : ℝ) := by
  have hfac : (2 : ℕ) ≤ n.factorial := by
    calc
      2 = (2 : ℕ).factorial := by norm_num
      _ ≤ n.factorial := Nat.factorial_le hn
  have hfacR : (2 : ℝ) ≤ (n.factorial : ℝ) := by exact_mod_cast hfac
  have htR : (-1 : ℝ) ≤ (t : ℝ) := by exact_mod_cast ht
  constructor <;> linarith
end ErdosProblems.Erdos68

open scoped BigOperators
open ErdosProblems in
open ErdosProblems.Erdos68 in
theorem solution {t : ℤ} (ht : -1 ≤ t) (n : ℕ) :
    shiftGapTerm t n = unitFactTerm n - (t : ℝ) * shiftCompanionTerm t n := by
  by_cases hn : 2 ≤ n
  · rw [shiftGapTerm, if_pos hn, unitFactTerm, if_pos hn,
      shiftCompanionTerm, if_pos hn]
    obtain ⟨h1, h2⟩ := factorial_sub_one_le_add_shift ht hn
    have hF : (n.factorial : ℝ) ≠ 0 := by positivity
    have hFt : (n.factorial : ℝ) + (t : ℝ) ≠ 0 := by linarith
    field_simp
    ring
  · simp [shiftGapTerm, unitFactTerm, shiftCompanionTerm, hn]
