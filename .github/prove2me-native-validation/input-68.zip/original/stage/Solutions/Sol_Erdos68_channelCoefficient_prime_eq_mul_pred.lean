import Definitions.Def_ErdosProblems_Erdos68_ChannelBreakpointRigidity
import Definitions.Def_ErdosProblems_Erdos68_ChannelIntegralCongruence
import Definitions.Def_ErdosProblems_Erdos68_PrimeUnitTranslator
import Theorems.Thm_Erdos68_channel_coefficient_band
import Theorems.Thm_Erdos68_prime_pred_div_eq
import Mathlib.Algebra.BigOperators.Fin
import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Algebra.GCDMonoid.FinsetLemmas
import Mathlib.Algebra.Order.Round
import Mathlib.Algebra.Ring.GeomSum
import Mathlib.Analysis.Asymptotics.Defs
import Mathlib.Analysis.Complex.ExponentialBounds
import Mathlib.Analysis.Real.Pi.Bounds
import Mathlib.Analysis.SpecialFunctions.Stirling
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Data.Fin.VecNotation
import Mathlib.Data.Nat.Factorial.Basic
import Mathlib.Data.Nat.Factorial.BigOperators
import Mathlib.Data.Nat.ModEq
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.LinearAlgebra.Matrix.Adjugate
import Mathlib.LinearAlgebra.Vandermonde
import Mathlib.Tactic.FinCases
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.InfiniteSum.Basic
import Mathlib.Topology.Algebra.InfiniteSum.Ring

/-!
# Prime unit translator for Erdős problem 68

For a prime `p`, the coefficient pair `(p,-1)` on the indices `(p-1,p)` has
zero factorial moment and annihilates every channel except the `p`-channel.
At that channel its numerator is exactly `p!-1`; consequently its normalized
infinite residual is `1`.  Appending an integer multiple of this pair therefore
translates any finite-support residual by the same integer without changing
the lower channels or the factorial moment.

The module also classifies every finite-support residual modulo integers as
its factorial moment times the factorial-gap tail.  A Cramer construction on
an explicit factorial grid supplies, beyond any prescribed support threshold,
integer coefficient vectors with zero channels through a chosen cutoff and
nonzero factorial moment.  Appending a prime translator reduces their
residual to absolute value at most `1/2`.

The last reduction is not an irrationality argument by itself: the reduced
residual may be zero.  The strict version assumes that the original residual
is not an integer, and no theorem here proves that assumption for the Cramer
vectors.  There is also no coefficient-size estimate, no nonzero lower bound
for the reduced residual, and no irrationality theorem for the factorial-gap
series.
-/

open Erdos68 in
theorem solution
    {p d : ℕ} (hp : p.Prime) (hd2 : 2 ≤ d) (hdp : d < p) :
    p.factorial / d.factorial ^ (p / d) =
      p * ((p - 1).factorial / d.factorial ^ ((p - 1) / d)) := by
  have hq := prime_pred_div_eq hp hd2 hdp
  have hdpos : 0 < d := by omega
  have hp_hi : p < (p / d + 1) * d := by
    rw [← Nat.div_lt_iff_lt_mul hdpos]
    exact Nat.lt_succ_self _
  have hbandp := channel_coefficient_band
    (d := d) (i := p) (k := p / d) (Nat.div_mul_le_self p d) hp_hi
  have hpred_hi : p - 1 < ((p - 1) / d + 1) * d := by
    rw [← Nat.div_lt_iff_lt_mul hdpos]
    exact Nat.lt_succ_self _
  have hbandpred := channel_coefficient_band
    (d := d) (i := p - 1) (k := (p - 1) / d)
    (Nat.div_mul_le_self (p - 1) d) hpred_hi
  have hpstep : p.factorial = p * (p - 1).factorial := by
    calc
      p.factorial = ((p - 1) + 1).factorial := by congr 1; omega
      _ = ((p - 1) + 1) * (p - 1).factorial := Nat.factorial_succ _
      _ = p * (p - 1).factorial := by congr 1; omega
  have hmul :
      d.factorial ^ (p / d) *
          (p.factorial / d.factorial ^ (p / d)) =
        d.factorial ^ (p / d) *
          (p * ((p - 1).factorial / d.factorial ^ ((p - 1) / d))) := by
    calc
      d.factorial ^ (p / d) *
          (p.factorial / d.factorial ^ (p / d)) = p.factorial := hbandp
      _ = p * (p - 1).factorial := hpstep
      _ = p * (d.factorial ^ ((p - 1) / d) *
          ((p - 1).factorial / d.factorial ^ ((p - 1) / d))) := by rw [hbandpred]
      _ = d.factorial ^ (p / d) *
          (p * ((p - 1).factorial / d.factorial ^ ((p - 1) / d))) := by
            rw [hq]
            ring
  exact Nat.mul_left_cancel (by positivity) hmul
