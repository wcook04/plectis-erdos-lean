import Definitions.Def_ErdosProblems_Erdos68_ChannelBreakpointRigidity
import Definitions.Def_ErdosProblems_Erdos68_ChannelIntegralCongruence
import Definitions.Def_ErdosProblems_Erdos68_PrimeUnitTranslator
import Mathlib.Algebra.BigOperators.Fin
import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Algebra.GCDMonoid.FinsetLemmas
import Mathlib.Algebra.Order.Round
import Mathlib.Algebra.Ring.GeomSum
import Mathlib.Analysis.Asymptotics.Defs
import Mathlib.Analysis.Complex.ExponentialBounds
import Mathlib.Analysis.Real.Pi.Bounds
import Mathlib.Analysis.SpecialFunctions.Stirling
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Data.Fin.VecNotation
import Mathlib.Data.Nat.Factorial.Basic
import Mathlib.Data.Nat.Factorial.BigOperators
import Mathlib.Data.Nat.ModEq
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.LinearAlgebra.Matrix.Adjugate
import Mathlib.LinearAlgebra.Vandermonde
import Mathlib.Tactic.FinCases
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.InfiniteSum.Basic
import Mathlib.Topology.Algebra.InfiniteSum.Ring

/-!
# Prime unit translator for Erdős problem 68

For a prime `p`, the coefficient pair `(p,-1)` on the indices `(p-1,p)` has
zero factorial moment and annihilates every channel except the `p`-channel.
At that channel its numerator is exactly `p!-1`; consequently its normalized
infinite residual is `1`.  Appending an integer multiple of this pair therefore
translates any finite-support residual by the same integer without changing
the lower channels or the factorial moment.

The module also classifies every finite-support residual modulo integers as
its factorial moment times the factorial-gap tail.  A Cramer construction on
an explicit factorial grid supplies, beyond any prescribed support threshold,
integer coefficient vectors with zero channels through a chosen cutoff and
nonzero factorial moment.  Appending a prime translator reduces their
residual to absolute value at most `1/2`.

The last reduction is not an irrationality argument by itself: the reduced
residual may be zero.  The strict version assumes that the original residual
is not an integer, and no theorem here proves that assumption for the Cramer
vectors.  There is also no coefficient-size estimate, no nonzero lower bound
for the reduced residual, and no irrationality theorem for the factorial-gap
series.
-/

open Erdos68 in
theorem solution
    {p : ℕ} (hp : p.Prime) :
    channelNumerator (primeTranslatorCoeff p) (primeTranslatorIndex p) p =
      (p.factorial : ℤ) - 1 := by
  have hp0 : 0 < p := hp.pos
  have hpredlt : p - 1 < p := Nat.sub_lt hp0 (by decide)
  have hpred : (p - 1) / p = 0 := Nat.div_eq_of_lt hpredlt
  have hself : p / p = 1 := Nat.div_self hp0
  have hfac : p.factorial = p * (p - 1).factorial := by
    calc
      p.factorial = ((p - 1) + 1).factorial := by congr 1; omega
      _ = ((p - 1) + 1) * (p - 1).factorial := Nat.factorial_succ _
      _ = p * (p - 1).factorial := by congr 1; omega
  simp only [channelNumerator, primeTranslatorCoeff, primeTranslatorIndex,
    Fin.sum_univ_two, Matrix.cons_val_zero, Matrix.cons_val_one]
  rw [hpred, hself, pow_zero, pow_one, Nat.div_one,
    Nat.div_self (Nat.factorial_pos p)]
  norm_num
  rw [hfac]
  norm_cast
