import Definitions.Def_ErdosProblems_Erdos68_ChannelBreakpointRigidity
import Definitions.Def_ErdosProblems_Erdos68_ChannelIntegralCongruence
import Definitions.Def_ErdosProblems_Erdos68_PrimeUnitTranslator
import Definitions.Def_ErdosProblems_Erdos68_FactorialChannelCertificate
import Definitions.Def_ErdosProblems_Erdos68_DivisorChannelBasis
import Definitions.Def_ErdosProblems_Erdos68_PaperCompleteDivisorCoordinates
import Definitions.Def_ErdosProblems_Erdos68_PaperCompleteIntegerSpan
import Definitions.Def_ErdosProblems_Erdos68_PaperCompleteLowKernel
import Definitions.Def_ErdosProblems_Erdos68_PaperCompleteResidualIdentity
import Theorems.Thm_Erdos68_summable_factorialGapTailTerm
import Theorems.Thm_Erdos68_factorialGapSeries_eq_sum_add_tail
import Theorems.Thm_ErdosProblems_Erdos68_PaperComplete_residual_term_low_kernel
import Lean.Elab.Tactic.Omega
import Mathlib.Algebra.BigOperators.Fin
import Mathlib.Algebra.BigOperators.Finsupp.Basic
import Mathlib.Algebra.BigOperators.GroupWithZero.Action
import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Algebra.GCDMonoid.FinsetLemmas
import Mathlib.Algebra.Order.Round
import Mathlib.Algebra.Ring.GeomSum
import Mathlib.Analysis.Asymptotics.Defs
import Mathlib.Analysis.Complex.ExponentialBounds
import Mathlib.Analysis.Real.Pi.Bounds
import Mathlib.Analysis.SpecialFunctions.Stirling
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Data.Fin.VecNotation
import Mathlib.Data.Finsupp.Basic
import Mathlib.Data.Finsupp.SMul
import Mathlib.Data.Int.GCD
import Mathlib.Data.Int.ModEq
import Mathlib.Data.Nat.Choose.Multinomial
import Mathlib.Data.Nat.Factorial.Basic
import Mathlib.Data.Nat.Factorial.BigOperators
import Mathlib.Data.Nat.GCD.Prime
import Mathlib.Data.Nat.ModEq
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.Rat.Lemmas
import Mathlib.LinearAlgebra.Matrix.Adjugate
import Mathlib.LinearAlgebra.Vandermonde
import Mathlib.NumberTheory.Divisors
import Mathlib.RingTheory.Coprime.Lemmas
import Mathlib.Tactic.Abel
import Mathlib.Tactic.FinCases
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.NormNum.NatFactorial
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.InfiniteSum.Basic
import Mathlib.Topology.Algebra.InfiniteSum.Ring

   
                                                                           
                                                                      
                                             
  

namespace ErdosProblems.Erdos68.PaperComplete
open scoped BigOperators
open Finsupp









lemma tailCoordinateTerm_outside (z : ℕ →₀ ℤ) (d : ℕ)
    (hd : d ∉ z.support.image (fun j => j + 1)) : tailCoordinateTerm z d = 0 := by
  classical
  by_cases h : 1 < d
  · have hz : z (d - 1) = 0 := by
      by_contra hn
      apply hd
      exact Finset.mem_image.mpr ⟨d - 1, Finsupp.mem_support_iff.mpr hn, by omega⟩
    simp [tailCoordinateTerm, h, hz]
  · simp [tailCoordinateTerm, h]

lemma summable_tailCoordinateTerm (z : ℕ →₀ ℤ) : Summable (tailCoordinateTerm z) := by
  classical
  apply summable_of_ne_finset_zero (s := z.support.image (fun j => j + 1))
  exact tailCoordinateTerm_outside z

lemma tsum_tailCoordinateTerm {D : ℕ} (hD : 1 ≤ D)
    {z : ℕ →₀ ℤ} (hz : TailCoordinates D z) :
    (∑' d : ℕ, tailCoordinateTerm z d) = (coordinateMass z : ℝ) := by
  classical
  rw [tsum_eq_sum (s := z.support.image (fun j => j + 1))]
  · rw [Finset.sum_image]
    · have he : (∑ j ∈ z.support, tailCoordinateTerm z (j + 1)) =
          ∑ j ∈ z.support, (z j : ℝ) := by
        apply Finset.sum_congr rfl
        intro j hj
        have hjp : 0 < j := by
          by_contra h
          have hj0 : j = 0 := by omega
          subst j
          exact (Finsupp.mem_support_iff.mp hj) (hz 0 (by omega))
        simp [tailCoordinateTerm, show 1 < j + 1 by omega]
      rw [he]
      simp [coordinateMass, integerEvaluation, Finsupp.sum]
    · intro i hi j hj he
      dsimp only at he
      omega
  · exact tailCoordinateTerm_outside z





/-- Exact residual, including the integral translate and actual infinite tail. -/
theorem fullResidual_low_kernel {D : ℕ} (hD : 1 ≤ D) (t : ℤ)
    {z : ℕ →₀ ℤ} (hz : TailCoordinates D z) :
    fullResidual (t • canonicalKernel D + channelSynthesis z) =
      (t : ℝ) * (channelLCM D : ℝ) * _root_.Erdos68.factorialGapTail D +
        (coordinateMass z : ℝ) := by
  unfold fullResidual
  simp_rw [residual_term_low_kernel hD t hz]
  rw [((_root_.Erdos68.summable_factorialGapTailTerm D).mul_left
    ((t : ℝ) * (channelLCM D : ℝ))).tsum_add (summable_tailCoordinateTerm z)]
  rw [(_root_.Erdos68.summable_factorialGapTailTerm D).tsum_mul_left,
    tsum_tailCoordinateTerm hD hz]
  rfl
end ErdosProblems.Erdos68.PaperComplete

open scoped BigOperators
open Finsupp
open ErdosProblems in
open ErdosProblems.Erdos68 in
open ErdosProblems.Erdos68.PaperComplete in
theorem solution {D : ℕ} (hD : 2 ≤ D) (t : ℤ)
    {z : ℕ →₀ ℤ} (hz : TailCoordinates D z) :
    fullResidual (t • canonicalKernel D + channelSynthesis z) =
      (t : ℝ) * (channelLCM D : ℝ) *
        (_root_.Erdos68.factorialGapSeries - gapPrefixReal D) +
      (coordinateMass z : ℝ) := by
  rw [fullResidual_low_kernel (by omega) t hz]
  have hs := _root_.Erdos68.factorialGapSeries_eq_sum_add_tail hD
  change _root_.Erdos68.factorialGapSeries = gapPrefixReal D +
    _root_.Erdos68.factorialGapTail D at hs
  rw [hs]
  ring
