import Definitions.Def_ErdosProblems_Erdos68_CanonicalFactorialDigits
import Definitions.Def_ErdosProblems_Erdos68_ChannelBreakpointRigidity
import Definitions.Def_ErdosProblems_Erdos68_ChannelIntegralCongruence
import Definitions.Def_ErdosProblems_Erdos68_PrimeUnitTranslator
import Definitions.Def_ErdosProblems_Erdos68_FactorialGapPlateauCore
import Theorems.Thm_Erdos68_factorialGapSeries_eq_sum_add_tail
import Theorems.Thm_Erdos68_factorialGapTail_lt_one_div_factorial
import Theorems.Thm_Erdos68_factorialGapTail_pos
import Theorems.Thm_ErdosProblems_Erdos68_factorialGapPrefix_cast
import Theorems.Thm_ErdosProblems_Erdos68_factorialGrid_plateau
import Mathlib.Algebra.BigOperators.Fin
import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Algebra.GCDMonoid.FinsetLemmas
import Mathlib.Algebra.Order.Floor.Ring
import Mathlib.Algebra.Order.Round
import Mathlib.Algebra.Ring.GeomSum
import Mathlib.Analysis.Asymptotics.Defs
import Mathlib.Analysis.Complex.ExponentialBounds
import Mathlib.Analysis.Real.Pi.Bounds
import Mathlib.Analysis.SpecialFunctions.Stirling
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Data.Fin.VecNotation
import Mathlib.Data.Int.Basic
import Mathlib.Data.Nat.Factorial.Basic
import Mathlib.Data.Nat.Factorial.BigOperators
import Mathlib.Data.Nat.ModEq
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.LinearAlgebra.Matrix.Adjugate
import Mathlib.LinearAlgebra.Vandermonde
import Mathlib.NumberTheory.Real.Irrational
import Mathlib.Tactic
import Mathlib.Tactic.FinCases
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.InfiniteSum.Basic
import Mathlib.Topology.Algebra.InfiniteSum.Ring

/-!
# Erdős #68: factorial-gap plateau core

Lightweight core for the strict-successor recurrence, carry bounds, and the
exact divisibility criterion.  Heavy exact-index certificates live in
`FactorialZeroPlateauCertificates`; the full plateau file re-exports both.
-/

namespace ErdosProblems.Erdos68
/-! ## Factorial grid arithmetic -/



















/-! ## Exact prefixes and prime-power divisibility -/
end ErdosProblems.Erdos68

open ErdosProblems in
open ErdosProblems.Erdos68 in
theorem solution
    {n q : ℕ} {a : ℤ}
    (hn : 2 ≤ n)
    (hq : 0 < q)
    (hqfac : q ∣ n.factorial)
    (hseries :
      _root_.Erdos68.factorialGapSeries =
        (a : ℝ) / (q : ℝ)) :
    strictFacTop ((factorialGapPrefix n : ℚ) : ℝ) n =
      (((n.factorial / q : ℕ) : ℤ) * a : ℤ) := by
  have hdecomp :=
    _root_.Erdos68.factorialGapSeries_eq_sum_add_tail hn
  have hprefix := factorialGapPrefix_cast n
  have htailEq :
      (a : ℝ) / (q : ℝ) -
          ((factorialGapPrefix n : ℚ) : ℝ) =
        _root_.Erdos68.factorialGapTail n := by
    rw [← hseries, hdecomp, hprefix]
    ring
  have htailPos :=
    _root_.Erdos68.factorialGapTail_pos hn
  have hH :
      ((factorialGapPrefix n : ℚ) : ℝ) <
        (a : ℝ) / (q : ℝ) := by
    rw [sub_eq_iff_eq_add] at htailEq
    linarith
  have htailLt :=
    _root_.Erdos68.factorialGapTail_lt_one_div_factorial hn
  have hfacPos : (0 : ℝ) < n.factorial := by positivity
  have hscaled :
      (n.factorial : ℝ) *
          ((a : ℝ) / (q : ℝ) -
            ((factorialGapPrefix n : ℚ) : ℝ)) < 1 := by
    rw [htailEq]
    have hmul := mul_lt_mul_of_pos_left htailLt hfacPos
    simpa [ne_of_gt hfacPos] using hmul
  have hfac :
      q * (n.factorial / q) = n.factorial :=
    Nat.mul_div_cancel' hqfac
  have hfacR :
      (q : ℝ) * ((n.factorial / q : ℕ) : ℝ) =
        (n.factorial : ℝ) := by
    exact_mod_cast hfac
  have hgrid :
      (n.factorial : ℝ) * ((a : ℝ) / (q : ℝ)) =
        (((n.factorial / q : ℕ) : ℤ) * a : ℤ) := by
    calc
      (n.factorial : ℝ) * ((a : ℝ) / (q : ℝ)) =
          ((q : ℝ) * ((n.factorial / q : ℕ) : ℝ)) *
            ((a : ℝ) / (q : ℝ)) := by rw [hfacR]
      _ = ((n.factorial / q : ℕ) : ℝ) * (a : ℝ) := by
        field_simp
      _ = (((n.factorial / q : ℕ) : ℤ) * a : ℤ) := by
        simp only [Int.cast_mul, Int.cast_natCast]
  exact (factorialGrid_plateau hH le_rfl hscaled hgrid).1
