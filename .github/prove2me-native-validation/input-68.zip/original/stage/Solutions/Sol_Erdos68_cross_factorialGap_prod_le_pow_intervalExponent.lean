import Definitions.Def_ErdosProblems_Erdos68_ChannelBreakpointRigidity
import Definitions.Def_ErdosProblems_Erdos68_ChannelIntegralCongruence
import Theorems.Thm_Erdos68_gcd_factorial_sub_one_le_pow_gap
import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Algebra.GCDMonoid.FinsetLemmas
import Mathlib.Algebra.Ring.GeomSum
import Mathlib.Analysis.Asymptotics.Defs
import Mathlib.Analysis.Complex.ExponentialBounds
import Mathlib.Analysis.Real.Pi.Bounds
import Mathlib.Analysis.SpecialFunctions.Stirling
import Mathlib.Data.Nat.Factorial.Basic
import Mathlib.Data.Nat.Factorial.BigOperators
import Mathlib.Data.Nat.ModEq
import Mathlib.Tactic.Ring

/-!
# Integral channel congruence for Erdős problem 68

This module compares a channel numerator with the corresponding factorial
moment modulo `d! - 1`.  The congruence holds for every support index, so
simultaneous cancellation of the channels `2, ..., D` makes their least common
multiple divide the factorial moment.

The second part estimates that least common multiple.  Consecutive numbers
`m! - 1` are compared through their pairwise gcds; this gives an explicit
finite lower bound after the gcd losses are counted.  Consequently, if a
positive integer `M` is divisible by the channel lcm and is smaller than
`(R+1)! - 1`, then `R` must grow at least cubically along `D = 2t^2`.  A later
estimate improves the explicit constant to `R+1 > (3/2)t^3` for `t >= 2^32`.

All conclusions after the congruence theorem retain these stated hypotheses.
In particular, this file does not construct `M` or `R` from the series in
Erdős problem 68, prove that its channels vanish, or decide the rationality of
that series.
-/

namespace Erdos68
/-! ## Product versus lcm with explicit gcd loss -/











/-! ## Factorial-gap collision bounds -/







/-! ## Consecutive factorial-gap segments -/
end Erdos68

open Erdos68 in
theorem solution
    {m r k D : ℕ}
    (hm : 2 ≤ m) (hr : 1 ≤ r) (hmax : m + r + k ≤ D + 1) :
    ((factorialGapFrom (m + r) k).map
      (Nat.gcd (m.factorial - 1))).prod ≤
        D ^ intervalExponent r k := by
  induction k generalizing r with
  | zero => simp [factorialGapFrom, intervalExponent]
  | succ k ih =>
      rw [factorialGapFrom, List.map_cons, List.prod_cons, intervalExponent]
      have hmr : m < m + r := by omega
      have hhead0 :=
        gcd_factorial_sub_one_le_pow_gap hm hmr
      have hsub : m + r - m = r := by omega
      have hbase : m + r ≤ D := by omega
      have hhead :
          Nat.gcd (m.factorial - 1) ((m + r).factorial - 1) ≤ D ^ r := by
        calc
          Nat.gcd (m.factorial - 1) ((m + r).factorial - 1) ≤
              (m + r) ^ (m + r - m) := hhead0
          _ = (m + r) ^ r := by rw [hsub]
          _ ≤ D ^ r := Nat.pow_le_pow_left hbase _
      have htail := ih (r := r + 1) (by omega) (by omega)
      calc
        Nat.gcd (m.factorial - 1) ((m + r).factorial - 1) *
            ((factorialGapFrom (m + r + 1) k).map
              (Nat.gcd (m.factorial - 1))).prod ≤
            D ^ r * D ^ intervalExponent (r + 1) k :=
          Nat.mul_le_mul hhead htail
        _ = D ^ (r + intervalExponent (r + 1) k) := by
          rw [pow_add]
