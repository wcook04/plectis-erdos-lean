import Definitions.Def_ErdosProblems_Erdos68_CanonicalFactorialDigits
import Definitions.Def_ErdosProblems_Erdos68_ChannelBreakpointRigidity
import Definitions.Def_ErdosProblems_Erdos68_ChannelIntegralCongruence
import Definitions.Def_ErdosProblems_Erdos68_PrimeUnitTranslator
import Definitions.Def_ErdosProblems_Erdos68_FactorialGapPlateauCore
import Definitions.Def_ErdosProblems_Erdos68_FactorialChannelCertificate
import Definitions.Def_ErdosProblems_Erdos68_EndpointWeightedPrivateSupport
import Lean.Elab.Tactic.Omega
import Mathlib.Algebra.BigOperators.Fin
import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Algebra.GCDMonoid.FinsetLemmas
import Mathlib.Algebra.Order.Floor.Ring
import Mathlib.Algebra.Order.Round
import Mathlib.Algebra.Ring.GeomSum
import Mathlib.Analysis.Asymptotics.Defs
import Mathlib.Analysis.Complex.ExponentialBounds
import Mathlib.Analysis.Real.Pi.Bounds
import Mathlib.Analysis.SpecialFunctions.Stirling
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Data.Fin.VecNotation
import Mathlib.Data.Finsupp.Basic
import Mathlib.Data.Int.Basic
import Mathlib.Data.Int.ModEq
import Mathlib.Data.Nat.Choose.Multinomial
import Mathlib.Data.Nat.Factorial.Basic
import Mathlib.Data.Nat.Factorial.BigOperators
import Mathlib.Data.Nat.Factorization.Basic
import Mathlib.Data.Nat.GCD.BigOperators
import Mathlib.Data.Nat.ModEq
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.Nat.Prime.Factorial
import Mathlib.Data.Rat.Lemmas
import Mathlib.LinearAlgebra.Matrix.Adjugate
import Mathlib.LinearAlgebra.Vandermonde
import Mathlib.NumberTheory.Divisors
import Mathlib.NumberTheory.Real.Irrational
import Mathlib.Tactic
import Mathlib.Tactic.FinCases
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.NormNum.NatFactorial
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.InfiniteSum.Basic
import Mathlib.Topology.Algebra.InfiniteSum.Ring

/-!
# Erdős #68: collision cores, private residues, and factorial-block endpoints

For a finite denominator family, the pairwise collision core records the
prime powers shared by at least two denominators.  Dividing each denominator
by its part inside this core produces pairwise-coprime private quotients.
Their product is the private modulus `R`; a weighted leave-one-out numerator
is coprime to `R`, so the displayed endpoint numerator has a nonzero residue
whenever `R > 1`.

The abstract part of the file develops these finite gcd, lcm, CRT, and
projection identities.  The factorial-block specialization takes the
denominators `n! - 1` for `p ≤ n < 2p`, identifies the strict-successor
coefficient at `p - 1`, and defines an endpoint window.  Unit carries on the
whole interval `[p,2p]` force that window; so does any rational value whose
denominator is already cleared by `(p-1)!`.

The later theorems give several exact ways to refute the window: a large
private residue, unequal leave-one-out projections, coprime factor-pair
floors, or a uniquely supported prime with a sufficiently large residue.
Cofinal families of any of the stated certificates imply cofinally many
non-unit carries or rational-prefix divisibility failures, and hence imply
irrationality through the earlier carry criterion.

Every irrationality conclusion in this file is conditional.  No theorem
constructs the required cofinal certificate family, proves the needed
projection disagreement or size inequality for arbitrarily large blocks,
or supplies cofinally many uniquely supported factorial-gap primes.  The
finite CRT identities and endpoint reductions therefore do not by themselves
prove the irrationality of the factorial-gap series or solve Erdős #68.
-/

namespace ErdosProblems.Erdos68
/-! ## Collision cores for finite denominator families -/



















































































/-! ## Private quotients and weighted CRT numerators -/



































































/-! ## Endpoint residues and finite projection bounds -/



































































/-! ## The factorial-block endpoint window -/
end ErdosProblems.Erdos68

open ErdosProblems in
open ErdosProblems.Erdos68 in
theorem solution
    {p : ℕ}
    (hp : 2 ≤ p) :
    (1 : ℝ) / (((2 * p).factorial : ℝ) - 1) +
        1 / ((2 * p).factorial : ℝ) ≤
      (factorialBlockEndpointUpperBound p : ℝ) := by
  have htwoP : 2 ≤ 2 * p := by omega
  have hfacNat :
      (2 * p).factorial =
        2 * p * (2 * p - 1).factorial := by
    calc
      (2 * p).factorial =
          (2 * p - 1 + 1).factorial := by congr 1 <;> omega
      _ = (2 * p - 1 + 1) *
          (2 * p - 1).factorial := Nat.factorial_succ _
      _ = 2 * p * (2 * p - 1).factorial := by
        congr 1 <;> omega
  have hfacGeNat :
      p + 1 ≤ (2 * p).factorial := by
    calc
      p + 1 ≤ 2 * p := by omega
      _ ≤ (2 * p).factorial := Nat.self_le_factorial _
  have hpR : (0 : ℝ) < p := by exact_mod_cast (show 0 < p by omega)
  have hfacR : (0 : ℝ) < (2 * p).factorial := by positivity
  have hfacSubR : (0 : ℝ) < (2 * p).factorial - 1 := by
    have hfacGtNat : 1 < (2 * p).factorial :=
      Nat.one_lt_factorial.mpr htwoP
    have hfacGtR :
        (1 : ℝ) < ((2 * p).factorial : ℝ) := by
      exact_mod_cast hfacGtNat
    linarith
  have hfacGeR :
      (p : ℝ) + 1 ≤ ((2 * p).factorial : ℝ) := by
    exact_mod_cast hfacGeNat
  have hscaleEq :
      (factorialBlockScale p : ℝ) =
        (p : ℝ) * ((2 * p).factorial : ℝ) := by
    unfold factorialBlockScale
    rw [hfacNat]
    push_cast
    ring
  have hbudgetEq :
      (factorialBlockBudget p : ℝ) =
        2 * (p : ℝ) + 1 := by
    unfold factorialBlockBudget
    push_cast
    ring
  have hsumEq :
      (1 : ℝ) / (((2 * p).factorial : ℝ) - 1) +
          1 / ((2 * p).factorial : ℝ) =
        (2 * ((2 * p).factorial : ℝ) - 1) /
          ((((2 * p).factorial : ℝ) - 1) *
            ((2 * p).factorial : ℝ)) := by
    field_simp [ne_of_gt hfacR, ne_of_gt hfacSubR]
    ring
  have htwoTermLe :
      (1 : ℝ) / (((2 * p).factorial : ℝ) - 1) +
          1 / ((2 * p).factorial : ℝ) ≤
        (2 * (p : ℝ) + 1) /
          ((p : ℝ) * ((2 * p).factorial : ℝ)) := by
    rw [
      hsumEq,
      div_le_div_iff₀
        (mul_pos hfacSubR hfacR)
        (mul_pos hpR hfacR)
    ]
    nlinarith
  rw [show
    (factorialBlockEndpointUpperBound p : ℝ) =
      (factorialBlockBudget p : ℝ) /
        (factorialBlockScale p : ℝ) by
      unfold factorialBlockEndpointUpperBound
      push_cast
      rfl]
  rw [hscaleEq, hbudgetEq]
  exact htwoTermLe
