import Definitions.Def_ErdosProblems_Erdos68_CanonicalFactorialDigits
import Definitions.Def_ErdosProblems_Erdos68_ChannelBreakpointRigidity
import Definitions.Def_ErdosProblems_Erdos68_ChannelIntegralCongruence
import Definitions.Def_ErdosProblems_Erdos68_PrimeUnitTranslator
import Definitions.Def_ErdosProblems_Erdos68_FactorialGapPlateauCore
import Definitions.Def_ErdosProblems_Erdos68_CompanionConstantBridge
import Definitions.Def_ErdosProblems_Erdos68_ConstantOnlyMissCertificates
import Definitions.Def_ErdosProblems_Erdos68_SecondLayerDigit
import Definitions.Def_ErdosProblems_Erdos68_CompanionOrbitRationality
import Theorems.Thm_Erdos68_hasSum_factorial_telescope
import Theorems.Thm_ErdosProblems_Erdos68_summable_unitFactTerm
import Theorems.Thm_ErdosProblems_Erdos68_summable_canonicalDigitTerm
import Theorems.Thm_ErdosProblems_Erdos68_tsum_canonicalDigitTerm
import Mathlib.Algebra.BigOperators.Fin
import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Algebra.GCDMonoid.FinsetLemmas
import Mathlib.Algebra.Order.Floor.Ring
import Mathlib.Algebra.Order.Round
import Mathlib.Algebra.Ring.GeomSum
import Mathlib.Analysis.Asymptotics.Defs
import Mathlib.Analysis.Complex.ExponentialBounds
import Mathlib.Analysis.Real.Pi.Bounds
import Mathlib.Analysis.SpecialFunctions.Stirling
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Data.Fin.VecNotation
import Mathlib.Data.Int.Basic
import Mathlib.Data.Nat.Cast.Field
import Mathlib.Data.Nat.Factorial.Basic
import Mathlib.Data.Nat.Factorial.BigOperators
import Mathlib.Data.Nat.ModEq
import Mathlib.Data.Nat.Multiplicity
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.Rat.Floor
import Mathlib.LinearAlgebra.Matrix.Adjugate
import Mathlib.LinearAlgebra.Vandermonde
import Mathlib.NumberTheory.Real.Irrational
import Mathlib.Tactic
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.FinCases
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.InfiniteSum.Basic
import Mathlib.Topology.Algebra.InfiniteSum.Ring

/-!
# Erdős #68: full companion-orbit rationality boundary

This module promotes the pointwise companion-floor arithmetic to the infinite
rationality statement.  The fixed companion constant is

`C = ∑_{n≥2} 1/(n!(n!−1)) = S - (exp 1 - 2)`.

The target normal form is that `S` is rational exactly when
`⌊m! C⌋ ≡ -2 (mod m)` eventually.  The forward direction uses the positive
sub-unit remainder in the exponential series.  The reverse direction uses
the equivalent canonical digit tail `d_m(C)=m-2` and the telescoping identity

`∑_{m>N} ((m-2)+1)/m! = 1/N!`.

No cofinal escape claim is made here.
-/

namespace ErdosProblems.Erdos68
open scoped BigOperators











/-- The canonical factorial digits sum to the fractional part of `x`. -/
theorem hasSum_canonicalDigitTerm (x : ℝ) :
    HasSum (canonicalDigitTerm x) (x - (⌊x⌋ : ℝ)) := by
  rw [← tsum_canonicalDigitTerm x]
  exact (summable_canonicalDigitTerm x).hasSum





















private theorem canonicalDigitTerm_add_unitFactTerm_eq_telescope_of_digit_sub_two
    {x : ℝ} {m : ℕ} (hm : 3 ≤ m)
    (hdigit : canonicalDigit x m = (m : ℤ) - 2) :
    canonicalDigitTerm x m + unitFactTerm m =
      (1 : ℝ) / ((m - 1).factorial : ℝ) - 1 / (m.factorial : ℝ) := by
  rw [canonicalDigitTerm, if_pos (by omega), unitFactTerm, if_pos (by omega), hdigit]
  have hfacNat : m.factorial = m * (m - 1).factorial := by
    have hidx : m - 1 + 1 = m := by omega
    simpa only [hidx] using Nat.factorial_succ (m - 1)
  have hfac : (m.factorial : ℝ) =
      (m : ℝ) * ((m - 1).factorial : ℝ) := by
    exact_mod_cast hfacNat
  rw [hfac]
  push_cast
  field_simp
  ring
end ErdosProblems.Erdos68

open scoped BigOperators
open ErdosProblems in
open ErdosProblems.Erdos68 in
theorem solution
    (x : ℝ)
    (hdigits : ∃ M : ℕ, ∀ m : ℕ, M ≤ m → canonicalDigit x m = (m : ℤ) - 2) :
    ¬ Irrational (x + (∑' n : ℕ, unitFactTerm n)) := by
  obtain ⟨M, hM⟩ := hdigits
  let N : ℕ := max M 3
  have hMN : M ≤ N := by simp [N]
  have hN3 : 3 ≤ N := by simp [N]
  let f : ℕ → ℝ := fun m => canonicalDigitTerm x m + unitFactTerm m
  have hfHasSum :
      HasSum f ((x - (⌊x⌋ : ℝ)) + (∑' n : ℕ, unitFactTerm n)) := by
    exact (hasSum_canonicalDigitTerm x).add summable_unitFactTerm.hasSum
  have hf : Summable f := hfHasSum.summable
  have htail : (∑' k : ℕ, f (k + N)) =
      (1 : ℝ) / ((N - 1).factorial : ℝ) := by
    calc
      (∑' k : ℕ, f (k + N)) =
          ∑' k : ℕ, ((1 : ℝ) / (((N - 1) + k).factorial : ℝ) -
            1 / (((N - 1) + k + 1).factorial : ℝ)) := by
        apply tsum_congr
        intro k
        have hkn : 3 ≤ k + N := by omega
        have hMkn : M ≤ k + N := by omega
        have hd : canonicalDigit x (k + N) = (k + N : ℤ) - 2 :=
          hM (k + N) hMkn
        rw [show f (k + N) =
          canonicalDigitTerm x (k + N) + unitFactTerm (k + N) by rfl]
        rw [canonicalDigitTerm_add_unitFactTerm_eq_telescope_of_digit_sub_two hkn hd]
        have hi1 : k + N - 1 = (N - 1) + k := by omega
        have hi2 : k + N = (N - 1) + k + 1 := by omega
        rw [hi1, hi2]
      _ = (1 : ℝ) / ((N - 1).factorial : ℝ) :=
        (_root_.Erdos68.hasSum_factorial_telescope (N - 1)).tsum_eq
  have hsplit := hf.sum_add_tsum_nat_add N
  have htotal : (∑' m : ℕ, f m) =
      (∑ m ∈ Finset.range N, f m) +
        (1 : ℝ) / ((N - 1).factorial : ℝ) := by
    rw [← hsplit, htail]
  let q : ℚ := (⌊x⌋ : ℚ) +
    ∑ m ∈ Finset.range N,
      (if 2 ≤ m then (canonicalDigit x m : ℚ) / (m.factorial : ℚ) +
        1 / (m.factorial : ℚ) else 0) +
    1 / ((N - 1).factorial : ℚ)
  have hqcast : (q : ℝ) =
      (⌊x⌋ : ℝ) + (∑ m ∈ Finset.range N, f m) +
        (1 : ℝ) / ((N - 1).factorial : ℝ) := by
    unfold q f canonicalDigitTerm unitFactTerm
    push_cast
    apply congrArg (fun z : ℝ =>
      (⌊x⌋ : ℝ) + z + 1 / ((N - 1).factorial : ℝ))
    apply Finset.sum_congr rfl
    intro m hm
    by_cases h2 : 2 ≤ m <;> simp [h2]
  have hvalue : x + (∑' n : ℕ, unitFactTerm n) = (q : ℝ) := by
    have hsumValue := hfHasSum.tsum_eq
    rw [htotal] at hsumValue
    rw [hqcast]
    linarith
  rw [hvalue]
  exact Rat.not_irrational q
