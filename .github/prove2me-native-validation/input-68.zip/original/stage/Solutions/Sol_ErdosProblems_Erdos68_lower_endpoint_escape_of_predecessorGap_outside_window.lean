import Definitions.Def_ErdosProblems_Erdos68_CanonicalFactorialDigits
import Definitions.Def_ErdosProblems_Erdos68_ChannelBreakpointRigidity
import Definitions.Def_ErdosProblems_Erdos68_ChannelIntegralCongruence
import Definitions.Def_ErdosProblems_Erdos68_PrimeUnitTranslator
import Definitions.Def_ErdosProblems_Erdos68_FactorialGapPlateauCore
import Definitions.Def_ErdosProblems_Erdos68_FactorialChannelCertificate
import Definitions.Def_ErdosProblems_Erdos68_EndpointWeightedPrivateSupport
import Definitions.Def_ErdosProblems_Erdos68_PrimeZeroBranch
import Theorems.Thm_ErdosProblems_Erdos68_factorialGap_zero_branch_iff_lower_endpoint_cylinder
import Theorems.Thm_ErdosProblems_Erdos68_factorialGapScaledTail_lt_two_div
import Theorems.Thm_ErdosProblems_Erdos68_factorialGap_zero_branch_iff_predecessorGap_lower_window
import Lean.Elab.Tactic.Omega
import Mathlib.Algebra.BigOperators.Fin
import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Algebra.GCDMonoid.FinsetLemmas
import Mathlib.Algebra.Order.Floor.Ring
import Mathlib.Algebra.Order.Round
import Mathlib.Algebra.Ring.GeomSum
import Mathlib.Analysis.Asymptotics.Defs
import Mathlib.Analysis.Complex.ExponentialBounds
import Mathlib.Analysis.Real.Pi.Bounds
import Mathlib.Analysis.SpecialFunctions.Stirling
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Data.Fin.VecNotation
import Mathlib.Data.Finsupp.Basic
import Mathlib.Data.Int.Basic
import Mathlib.Data.Int.ModEq
import Mathlib.Data.Nat.Choose.Multinomial
import Mathlib.Data.Nat.Factorial.Basic
import Mathlib.Data.Nat.Factorial.BigOperators
import Mathlib.Data.Nat.Factorization.Basic
import Mathlib.Data.Nat.GCD.BigOperators
import Mathlib.Data.Nat.ModEq
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.Nat.Prime.Factorial
import Mathlib.Data.Nat.Prime.Infinite
import Mathlib.Data.Rat.Lemmas
import Mathlib.Data.ZMod.Factorial
import Mathlib.LinearAlgebra.Matrix.Adjugate
import Mathlib.LinearAlgebra.Vandermonde
import Mathlib.NumberTheory.Divisors
import Mathlib.NumberTheory.Real.Irrational
import Mathlib.NumberTheory.Wilson
import Mathlib.Tactic
import Mathlib.Tactic.FinCases
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.NormNum.NatFactorial
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.InfiniteSum.Basic
import Mathlib.Topology.Algebra.InfiniteSum.Ring

/-!
# Erdős #68: the shrinking-target normal form

The corpus already carries two exact normal forms for the irrationality of
`S = ∑ 1/(n! - 1)`: cofinal non-unit carries, and cofinal misses of the
strict-successor divisibility.  Both treat *every* unit carry as a failure.

A unit carry has two radically different causes: the canonical orbit sits in
the tiny lower endpoint cylinder, or the canonical digit is maximal.  The
second is harmless.  This module isolates that distinction and produces a
**third** exact normal form:

`S ∉ ℚ  ↔  ∀ B, ∃ m > B, factorialGapScaledTail m ≤ m · r_{m-1}`

(`irrational_factorialGapSeries_iff_cofinal_lower_endpoint_escape`), i.e.
irrationality is exactly *cofinal escape from the lower endpoint cylinder*.
Since `0 < factorialGapScaledTail m < 2/m`, the trapping radius is
`O(m⁻²)`: Erdős #68 is an explicit deterministic shrinking-target problem
for the factorial orbit, with a quadratically small target.

The escape target is strictly more permissive than the carry target
(`factorialGap_lower_endpoint_escape_iff_nonunit_or_maximal_digit`), and it
admits a completely **tail-free two-sided** consumer over the finite
predecessor gap (`irrational_factorialGapSeries_of_cofinal_predecessorGap_outside_window`).
The corpus previously exposed only the upper half of that window.

Erdős #68 remains open: no theorem here produces the cofinal escape events.
-/

namespace ErdosProblems.Erdos68
open scoped BigOperators
end ErdosProblems.Erdos68

open scoped BigOperators
open ErdosProblems in
open ErdosProblems.Erdos68 in
theorem solution
    {m : ℕ} (hm : 3 ≤ m)
    (hout :
      (m : ℝ) * factorialGapPredecessorGap m ≤ 1 + 1 / ((m.factorial : ℝ) - 1) ∨
        1 + 1 / ((m.factorial : ℝ) - 1) + 2 / (m : ℝ) ≤
          (m : ℝ) * factorialGapPredecessorGap m) :
    factorialGapScaledTail m ≤
      (m : ℝ) * canonicalRemainder _root_.Erdos68.factorialGapSeries (m - 1) := by
  by_contra hnot
  have htrap :
      (m : ℝ) * canonicalRemainder _root_.Erdos68.factorialGapSeries (m - 1) <
        factorialGapScaledTail m := lt_of_not_ge hnot
  have hzero := (factorialGap_zero_branch_iff_lower_endpoint_cylinder hm).2 htrap
  have hwindow := (factorialGap_zero_branch_iff_predecessorGap_lower_window hm).1 hzero
  rcases hout with hlow | hhigh
  · exact absurd hwindow.1 (not_lt.2 hlow)
  · have htail : factorialGapScaledTail m < 2 / (m : ℝ) :=
      factorialGapScaledTail_lt_two_div (by omega)
    linarith [hwindow.2]
