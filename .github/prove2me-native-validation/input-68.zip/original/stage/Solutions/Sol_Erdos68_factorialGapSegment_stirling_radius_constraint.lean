import Definitions.Def_ErdosProblems_Erdos68_ChannelBreakpointRigidity
import Definitions.Def_ErdosProblems_Erdos68_ChannelIntegralCongruence
import Theorems.Thm_Erdos68_factorialGapSegment_log_radius_constraint
import Theorems.Thm_Erdos68_log_factorial_sub_one_lower_bound
import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Algebra.GCDMonoid.FinsetLemmas
import Mathlib.Algebra.Ring.GeomSum
import Mathlib.Analysis.Asymptotics.Defs
import Mathlib.Analysis.Complex.ExponentialBounds
import Mathlib.Analysis.Real.Pi.Bounds
import Mathlib.Analysis.SpecialFunctions.Stirling
import Mathlib.Data.Nat.Factorial.Basic
import Mathlib.Data.Nat.Factorial.BigOperators
import Mathlib.Data.Nat.ModEq
import Mathlib.Tactic.Ring

/-!
# Integral channel congruence for Erdős problem 68

This module compares a channel numerator with the corresponding factorial
moment modulo `d! - 1`.  The congruence holds for every support index, so
simultaneous cancellation of the channels `2, ..., D` makes their least common
multiple divide the factorial moment.

The second part estimates that least common multiple.  Consecutive numbers
`m! - 1` are compared through their pairwise gcds; this gives an explicit
finite lower bound after the gcd losses are counted.  Consequently, if a
positive integer `M` is divisible by the channel lcm and is smaller than
`(R+1)! - 1`, then `R` must grow at least cubically along `D = 2t^2`.  A later
estimate improves the explicit constant to `R+1 > (3/2)t^3` for `t >= 2^32`.

All conclusions after the congruence theorem retain these stated hypotheses.
In particular, this file does not construct `M` or `R` from the series in
Erdős problem 68, prove that its channels vanish, or decide the rationality of
that series.
-/

namespace Erdos68
/-! ## Product versus lcm with explicit gcd loss -/











/-! ## Factorial-gap collision bounds -/







/-! ## Consecutive factorial-gap segments -/



















































/-- Elementary upper bound for a factorial gap: `log(n! - 1) ≤ n log n`. -/
theorem log_factorial_sub_one_upper_bound
    {n : ℕ} (hn : 2 ≤ n) :
    Real.log ((n.factorial - 1 : ℕ) : ℝ) ≤
      (n : ℝ) * Real.log (n : ℝ) := by
  have hgapPos : (0 : ℝ) < (n.factorial - 1 : ℕ) := by
    exact_mod_cast
      (Nat.sub_pos_of_lt (Nat.one_lt_factorial.mpr (by omega)))
  have hgapFac : n.factorial - 1 ≤ n.factorial := Nat.sub_le _ _
  have hfacPow : n.factorial ≤ n ^ n := Nat.factorial_le_pow n
  have hcast :
      ((n.factorial - 1 : ℕ) : ℝ) ≤ (n : ℝ) ^ n := by
    exact_mod_cast hgapFac.trans hfacPow
  have hlog := Real.log_le_log hgapPos hcast
  simpa [Real.log_pow] using hlog
end Erdos68

open Erdos68 in
theorem solution
    {D k M R : ℕ}
    (hkD : k < D)
    (hMpos : 0 < M)
    (hdiv : channelLCM D ∣ M)
    (hsmall : M < (R + 1).factorial - 1) :
    (k : ℝ) *
        (((D + 1 - k : ℕ) : ℝ) *
            Real.log ((D + 1 - k : ℕ) : ℝ) -
          (D + 1 - k : ℕ) - Real.log 2) <
      ((R + 1 : ℕ) : ℝ) * Real.log (R + 1 : ℝ) +
        (((k + 1).choose 3 : ℕ) : ℝ) * Real.log (D : ℝ) := by
  have hn : 2 ≤ D + 1 - k := by omega
  have hR : 2 ≤ R + 1 := by
    have : 0 < (R + 1).factorial - 1 := by omega
    exact (Nat.one_lt_factorial.mp (by omega))
  have hlower :=
    log_factorial_sub_one_lower_bound (n := D + 1 - k) hn
  have hupper :=
    log_factorial_sub_one_upper_bound (n := R + 1) hR
  have hmiddle :=
    factorialGapSegment_log_radius_constraint hkD hMpos hdiv hsmall
  have hkNonneg : (0 : ℝ) ≤ k := by positivity
  norm_num at hupper ⊢
  calc
    (k : ℝ) *
        ((↑(D + 1 - k) : ℝ) * Real.log (↑(D + 1 - k) : ℝ) -
          ↑(D + 1 - k) - Real.log 2) ≤
        (k : ℝ) *
          Real.log (((D + 1 - k).factorial - 1 : ℕ) : ℝ) :=
      mul_le_mul_of_nonneg_left hlower hkNonneg
    _ < Real.log (((R + 1).factorial - 1 : ℕ) : ℝ) +
          (((k + 1).choose 3 : ℕ) : ℝ) * Real.log (D : ℝ) :=
      hmiddle
    _ ≤ (↑R + 1) * Real.log (↑R + 1) +
          (((k + 1).choose 3 : ℕ) : ℝ) * Real.log (D : ℝ) :=
      by
        simpa [add_comm] using
          add_le_add_right hupper
            ((((k + 1).choose 3 : ℕ) : ℝ) * Real.log (D : ℝ))
