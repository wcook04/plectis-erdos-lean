import Definitions.Def_ErdosProblems_Erdos68_CanonicalFactorialDigits
import Definitions.Def_ErdosProblems_Erdos68_ChannelBreakpointRigidity
import Definitions.Def_ErdosProblems_Erdos68_ChannelIntegralCongruence
import Definitions.Def_ErdosProblems_Erdos68_PrimeUnitTranslator
import Definitions.Def_ErdosProblems_Erdos68_FactorialGapPlateauCore
import Definitions.Def_ErdosProblems_Erdos68_FactorialChannelCertificate
import Definitions.Def_ErdosProblems_Erdos68_EndpointWeightedPrivateSupport
import Definitions.Def_ErdosProblems_Erdos68_PrimeZeroBranch
import Theorems.Thm_Erdos68_factorialGapTail_lt_one_div_factorial
import Theorems.Thm_ErdosProblems_Erdos68_canonicalRemainder_lt_one
import Theorems.Thm_ErdosProblems_Erdos68_canonicalRemainder_nonneg
import Theorems.Thm_ErdosProblems_Erdos68_factorialGapScaledTail_pos
import Theorems.Thm_ErdosProblems_Erdos68_factorialGapStepCarry_eq_one_iff_zero_or_maximal_branch
import Theorems.Thm_ErdosProblems_Erdos68_factorialGapScaledTail_pred_recurrence
import Theorems.Thm_ErdosProblems_Erdos68_factorialGap_zero_branch_iff_lower_endpoint_cylinder
import Theorems.Thm_ErdosProblems_Erdos68_factorialGapPredecessorGap_eq_scaledTail_sub_remainder_add_flag
import Theorems.Thm_ErdosProblems_Erdos68_factorialGap_maximal_branch_iff_upper_endpoint_cylinder
import Lean.Elab.Tactic.Omega
import Mathlib.Algebra.BigOperators.Fin
import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Algebra.GCDMonoid.FinsetLemmas
import Mathlib.Algebra.Order.Floor.Ring
import Mathlib.Algebra.Order.Round
import Mathlib.Algebra.Ring.GeomSum
import Mathlib.Analysis.Asymptotics.Defs
import Mathlib.Analysis.Complex.ExponentialBounds
import Mathlib.Analysis.Real.Pi.Bounds
import Mathlib.Analysis.SpecialFunctions.Stirling
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Data.Fin.VecNotation
import Mathlib.Data.Finsupp.Basic
import Mathlib.Data.Int.Basic
import Mathlib.Data.Int.ModEq
import Mathlib.Data.Nat.Choose.Multinomial
import Mathlib.Data.Nat.Factorial.Basic
import Mathlib.Data.Nat.Factorial.BigOperators
import Mathlib.Data.Nat.Factorization.Basic
import Mathlib.Data.Nat.GCD.BigOperators
import Mathlib.Data.Nat.ModEq
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.Nat.Prime.Factorial
import Mathlib.Data.Nat.Prime.Infinite
import Mathlib.Data.Rat.Lemmas
import Mathlib.Data.ZMod.Factorial
import Mathlib.LinearAlgebra.Matrix.Adjugate
import Mathlib.LinearAlgebra.Vandermonde
import Mathlib.NumberTheory.Divisors
import Mathlib.NumberTheory.Real.Irrational
import Mathlib.NumberTheory.Wilson
import Mathlib.Tactic
import Mathlib.Tactic.FinCases
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.NormNum.NatFactorial
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.InfiniteSum.Basic
import Mathlib.Topology.Algebra.InfiniteSum.Ring

/-!
# Erdős #68: the prime zero branch

This module develops three linked layers of the factorial-gap series.

First, exact prefix identities express the step carry through a binary
endpoint flag and the canonical factorial digit.  A unit carry is therefore
equivalent to one of two endpoint cylinders: a zero digit with two zero
flags, or the maximal digit with two one flags.

Second, reduced predecessor fractions are followed prime by prime.  The
formalized arithmetic includes prefix-private prime powers, accumulated
denominator factors, collision and residual cofactors, and exact finite
records at the primes `107` and `971`.  In particular, prefix-private
factorial-gap hits occur cofinally and the corresponding numerator
projections are nonzero under the stated divisibility hypotheses.

Third, a family of conditional theorems shows that sufficiently large
predecessor residues, supplied cofinally, would force irrationality.  The
module does **not** prove those quantitative lower bounds: a nonzero residue
is not enough.  It therefore proves no unconditional irrationality theorem
and does not settle Erdős #68.
-/

namespace ErdosProblems.Erdos68
/-! ## Scaled tails and endpoint flags -/





/-- The scaled factorial-gap tail is strictly smaller than one. -/
theorem factorialGapScaledTail_lt_one
    {m : ℕ} (hm : 2 ≤ m) :
    factorialGapScaledTail m < 1 := by
  have htail :=
    _root_.Erdos68.factorialGapTail_lt_one_div_factorial hm
  have hfacPos : (0 : ℝ) < m.factorial := by positivity
  have hmul := mul_lt_mul_of_pos_left htail hfacPos
  simpa [factorialGapScaledTail, ne_of_gt hfacPos] using hmul













/-! ## The reduced rational predecessor state -/













































































/-! ## Prime-power persistence in consecutive denominators -/



















/-! ## Prefix-private moduli and finite CRT anchors -/























































/-! ## Accumulated private powers across finite intervals -/

























/-! ## Componentwise private-prime sources -/

































































/-! ## Cofinal private hits and reflected collisions -/







































/-! ## Killed multiplicities and residual-cofactor recurrences -/





























































































/-! ## Wilson quotients and finite repeated-prime records -/































/-! ## Repeated-birth amplification and interval persistence -/

















































/-! ## Endpoint cylinders and the exact carry dichotomy -/
end ErdosProblems.Erdos68

open ErdosProblems in
open ErdosProblems.Erdos68 in
theorem solution
    {m : ℕ} (hm : 3 ≤ m) :
    (canonicalDigit _root_.Erdos68.factorialGapSeries m = 0 ∧
        factorialGapEndpointFlag (m - 1) = 0 ∧
        factorialGapEndpointFlag m = 0) ↔
      1 + 1 / ((m.factorial : ℝ) - 1) <
          (m : ℝ) * factorialGapPredecessorGap m ∧
        (m : ℝ) * factorialGapPredecessorGap m ≤
          1 + 1 / ((m.factorial : ℝ) - 1) +
            factorialGapScaledTail m := by
  let S : ℝ := _root_.Erdos68.factorialGapSeries
  let θ : ℝ := canonicalRemainder S (m - 1)
  let Rprev : ℝ := factorialGapScaledTail (m - 1)
  let R : ℝ := factorialGapScaledTail m
  have hgap :=
    factorialGapPredecessorGap_eq_scaledTail_sub_remainder_add_flag hm
  have htailRec :=
    factorialGapScaledTail_pred_recurrence (m := m) hm
  have hθNonneg := canonicalRemainder_nonneg S (m - 1)
  constructor
  · rintro ⟨hdigit, hprev, hcurr⟩
    have hlower :=
      (factorialGap_zero_branch_iff_lower_endpoint_cylinder hm).mp
        ⟨hdigit, hprev, hcurr⟩
    change
      factorialGapPredecessorGap m =
        Rprev - θ + (factorialGapEndpointFlag (m - 1) : ℝ) at hgap
    rw [hprev] at hgap
    push_cast at hgap
    norm_num at hgap
    change (m : ℝ) * θ < R at hlower
    change
      (m : ℝ) * Rprev =
        1 + 1 / ((m.factorial : ℝ) - 1) + R at htailRec
    constructor
    · have hRPos := factorialGapScaledTail_pos (m := m) (by omega)
      rw [hgap]
      linarith
    · rw [hgap]
      nlinarith
  · rintro ⟨hlower, hupper⟩
    have hcarry : factorialGapStepCarry m = 1 := by
      have hRLt := factorialGapScaledTail_lt_one (m := m) (by omega)
      unfold factorialGapStepCarry
      have hfloor :
          ⌊1 + 1 / ((m.factorial : ℝ) - 1) -
              (m : ℝ) * factorialGapPredecessorGap m⌋ =
            (-1 : ℤ) := by
        apply Int.floor_eq_iff.mpr
        constructor
        · push_cast
          linarith
        · push_cast
          linarith
      rw [hfloor]
      norm_num
    rcases
        (factorialGapStepCarry_eq_one_iff_zero_or_maximal_branch hm).mp
          hcarry with hzero | hmax
    · exact hzero
    · exfalso
      have hlarge :=
        (factorialGap_maximal_branch_iff_upper_endpoint_cylinder hm).mp
          hmax
      obtain ⟨_hdigit, hprev, _hcurr⟩ := hmax
      change
        factorialGapPredecessorGap m =
          Rprev - θ + (factorialGapEndpointFlag (m - 1) : ℝ) at hgap
      rw [hprev] at hgap
      push_cast at hgap
      change ((m : ℝ) - 1) + R ≤ (m : ℝ) * θ at hlarge
      change
        (m : ℝ) * Rprev =
          1 + 1 / ((m.factorial : ℝ) - 1) + R at htailRec
      have hθLt := canonicalRemainder_lt_one S (m - 1)
      change θ < 1 at hθLt
      have hmPos : (0 : ℝ) < m := by positivity
      have hmθLt : (m : ℝ) * θ < (m : ℝ) := by
        simpa using mul_lt_mul_of_pos_left hθLt hmPos
      rw [hgap] at hupper
      linarith
