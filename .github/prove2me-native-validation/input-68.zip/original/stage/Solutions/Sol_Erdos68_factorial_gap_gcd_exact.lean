import Definitions.Def_ErdosProblems_Erdos68_ChannelBreakpointRigidity
import Definitions.Def_ErdosProblems_Erdos68_ChannelIntegralCongruence
import Theorems.Thm_Erdos68_gcd_factorial_sub_one_dvd_descFactorial_sub_one
import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Algebra.GCDMonoid.FinsetLemmas
import Mathlib.Algebra.Ring.GeomSum
import Mathlib.Analysis.Asymptotics.Defs
import Mathlib.Analysis.Complex.ExponentialBounds
import Mathlib.Analysis.Real.Pi.Bounds
import Mathlib.Analysis.SpecialFunctions.Stirling
import Mathlib.Data.Nat.Factorial.Basic
import Mathlib.Data.Nat.Factorial.BigOperators
import Mathlib.Data.Nat.ModEq
import Mathlib.Tactic.Ring

/-!
# Integral channel congruence for Erdős problem 68

This module compares a channel numerator with the corresponding factorial
moment modulo `d! - 1`.  The congruence holds for every support index, so
simultaneous cancellation of the channels `2, ..., D` makes their least common
multiple divide the factorial moment.

The second part estimates that least common multiple.  Consecutive numbers
`m! - 1` are compared through their pairwise gcds; this gives an explicit
finite lower bound after the gcd losses are counted.  Consequently, if a
positive integer `M` is divisible by the channel lcm and is smaller than
`(R+1)! - 1`, then `R` must grow at least cubically along `D = 2t^2`.  A later
estimate improves the explicit constant to `R+1 > (3/2)t^3` for `t >= 2^32`.

All conclusions after the congruence theorem retain these stated hypotheses.
In particular, this file does not construct `M` or `R` from the series in
Erdős problem 68, prove that its channels vanish, or decide the rationality of
that series.
-/

namespace Erdos68
/-! ## Product versus lcm with explicit gcd loss -/











/-! ## Factorial-gap collision bounds -/

theorem dvd_descFactorial_of_pos
    {n k : ℕ} (hk : 0 < k) (hkn : k ≤ n) :
    n ∣ n.descFactorial k := by
  cases n with
  | zero => omega
  | succ n =>
      cases k with
      | zero => omega
      | succ k =>
          rw [Nat.succ_descFactorial_succ]
          exact dvd_mul_right _ _





/-! ## Consecutive factorial-gap segments -/
























































































/-! Additive exact paper correspondence, source commit c129ac97dcbc6a8218ba5f736aeb525c1652f8a5. -/
end Erdos68

open Erdos68 in
theorem solution
    {m n : ℕ} (hm : 2 ≤ m) (hmn : m < n) :
    let g := Nat.gcd (m.factorial - 1) (n.factorial - 1)
    let Q := n.descFactorial (n - m)
    g ∣ Q - 1 ∧ g ≤ Q - 1 ∧ Q - 1 < n ^ (n - m) := by
  dsimp
  have hkpos : 0 < n - m := Nat.sub_pos_of_lt hmn
  have hk : n - m ≤ n := Nat.sub_le _ _
  have hndvd : n ∣ n.descFactorial (n - m) :=
    dvd_descFactorial_of_pos hkpos hk
  have hnQ : n ≤ n.descFactorial (n - m) :=
    Nat.le_of_dvd (Nat.descFactorial_pos.mpr hk) hndvd
  have hQsubpos : 0 < n.descFactorial (n - m) - 1 := by
    omega
  have hdvd := gcd_factorial_sub_one_dvd_descFactorial_sub_one hmn
  refine ⟨hdvd, Nat.le_of_dvd hQsubpos hdvd, ?_⟩
  have hpow : n.descFactorial (n - m) ≤ n ^ (n - m) :=
    Nat.descFactorial_le_pow _ _
  omega
