import Definitions.Def_ErdosProblems_Erdos68_ChannelBreakpointRigidity
import Definitions.Def_ErdosProblems_Erdos68_ChannelIntegralCongruence
import Definitions.Def_ErdosProblems_Erdos68_PrimeUnitTranslator
import Theorems.Thm_Erdos68_factorialGapTail_eq_shifted_tsum
import Theorems.Thm_Erdos68_hasSum_factorial_telescope
import Theorems.Thm_Erdos68_one_div_factorial_sub_one_lt_telescope
import Mathlib.Algebra.BigOperators.Fin
import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Algebra.GCDMonoid.FinsetLemmas
import Mathlib.Algebra.Order.Round
import Mathlib.Algebra.Ring.GeomSum
import Mathlib.Analysis.Asymptotics.Defs
import Mathlib.Analysis.Complex.ExponentialBounds
import Mathlib.Analysis.Real.Pi.Bounds
import Mathlib.Analysis.SpecialFunctions.Stirling
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Data.Fin.VecNotation
import Mathlib.Data.Nat.Factorial.Basic
import Mathlib.Data.Nat.Factorial.BigOperators
import Mathlib.Data.Nat.ModEq
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.LinearAlgebra.Matrix.Adjugate
import Mathlib.LinearAlgebra.Vandermonde
import Mathlib.Tactic.FinCases
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.InfiniteSum.Basic
import Mathlib.Topology.Algebra.InfiniteSum.Ring

/-!
# Prime unit translator for Erdős problem 68

For a prime `p`, the coefficient pair `(p,-1)` on the indices `(p-1,p)` has
zero factorial moment and annihilates every channel except the `p`-channel.
At that channel its numerator is exactly `p!-1`; consequently its normalized
infinite residual is `1`.  Appending an integer multiple of this pair therefore
translates any finite-support residual by the same integer without changing
the lower channels or the factorial moment.

The module also classifies every finite-support residual modulo integers as
its factorial moment times the factorial-gap tail.  A Cramer construction on
an explicit factorial grid supplies, beyond any prescribed support threshold,
integer coefficient vectors with zero channels through a chosen cutoff and
nonzero factorial moment.  Appending a prime translator reduces their
residual to absolute value at most `1/2`.

The last reduction is not an irrationality argument by itself: the reduced
residual may be zero.  The strict version assumes that the original residual
is not an integer, and no theorem here proves that assumption for the Cramer
vectors.  There is also no coefficient-size estimate, no nonzero lower bound
for the reduced residual, and no irrationality theorem for the factorial-gap
series.
-/

open Erdos68 in
theorem solution
    {D : ℕ} (hD : 2 ≤ D) :
    factorialGapTail D < (1 : ℝ) / (D.factorial : ℝ) := by
  let source : ℕ → ℝ := fun k =>
    (1 : ℝ) /
      ((((D + 1 + k).factorial : ℤ) - 1 : ℤ) : ℝ)
  let majorant : ℕ → ℝ := fun k =>
    (1 : ℝ) / ((D + k).factorial : ℝ) -
      1 / ((D + k + 1).factorial : ℝ)
  have hsource_nonneg : ∀ k, 0 ≤ source k := by
    intro k
    have hden :
        (0 : ℝ) <
          ((((D + 1 + k).factorial : ℤ) - 1 : ℤ) : ℝ) := by
      exact_mod_cast
        (show (0 : ℤ) <
            ((D + 1 + k).factorial : ℤ) - 1 by
          have : 1 < (D + 1 + k).factorial :=
            Nat.one_lt_factorial.mpr (by omega)
          omega)
    simp only [source]
    exact le_of_lt (one_div_pos.mpr hden)
  have hle : ∀ k, source k ≤ majorant k := by
    intro k
    have hterm :=
      one_div_factorial_sub_one_lt_telescope
        (m := D + 1 + k) (by omega)
    simp only [source, majorant]
    have hpred : D + 1 + k - 1 = D + k := by omega
    rw [hpred] at hterm
    simpa [Nat.add_assoc, Nat.add_comm, Nat.add_left_comm] using hterm.le
  have hstrict : source 0 < majorant 0 := by
    have hterm :=
      one_div_factorial_sub_one_lt_telescope
        (m := D + 1) (by omega)
    simpa [source, majorant] using hterm
  have hmajorant : Summable majorant :=
    (hasSum_factorial_telescope D).summable
  have hsum :=
    Summable.tsum_lt_tsum_of_nonneg (i := 0)
      hsource_nonneg hle hstrict hmajorant
  rw [factorialGapTail_eq_shifted_tsum]
  simpa [source, majorant] using
    hsum.trans_eq (hasSum_factorial_telescope D).tsum_eq
