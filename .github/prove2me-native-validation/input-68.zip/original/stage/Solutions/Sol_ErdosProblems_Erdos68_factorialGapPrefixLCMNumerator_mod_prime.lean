import Definitions.Def_ErdosProblems_Erdos68_CanonicalFactorialDigits
import Definitions.Def_ErdosProblems_Erdos68_ChannelBreakpointRigidity
import Definitions.Def_ErdosProblems_Erdos68_ChannelIntegralCongruence
import Definitions.Def_ErdosProblems_Erdos68_PrimeUnitTranslator
import Definitions.Def_ErdosProblems_Erdos68_FactorialGapPlateauCore
import Definitions.Def_ErdosProblems_Erdos68_FactorialChannelCertificate
import Definitions.Def_ErdosProblems_Erdos68_EndpointWeightedPrivateSupport
import Definitions.Def_ErdosProblems_Erdos68_PrimeZeroBranch
import Definitions.Def_ErdosProblems_Erdos68_PrimePoleCriterion
import Theorems.Thm_ErdosProblems_Erdos68_factorialGap_dvd_prefixLCM
import Theorems.Thm_ErdosProblems_Erdos68_finset_lcm_factorization_lt_of_all_lt
import Lean.Elab.Tactic.Omega
import Mathlib.Algebra.BigOperators.Fin
import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Algebra.GCDMonoid.FinsetLemmas
import Mathlib.Algebra.Order.Floor.Ring
import Mathlib.Algebra.Order.Round
import Mathlib.Algebra.Ring.GeomSum
import Mathlib.Analysis.Asymptotics.Defs
import Mathlib.Analysis.Complex.ExponentialBounds
import Mathlib.Analysis.Real.Pi.Bounds
import Mathlib.Analysis.SpecialFunctions.Stirling
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Data.Fin.VecNotation
import Mathlib.Data.Finsupp.Basic
import Mathlib.Data.Int.Basic
import Mathlib.Data.Int.ModEq
import Mathlib.Data.Nat.Choose.Multinomial
import Mathlib.Data.Nat.Factorial.Basic
import Mathlib.Data.Nat.Factorial.BigOperators
import Mathlib.Data.Nat.Factorization.Basic
import Mathlib.Data.Nat.GCD.BigOperators
import Mathlib.Data.Nat.ModEq
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.Nat.Prime.Factorial
import Mathlib.Data.Nat.Prime.Infinite
import Mathlib.Data.Rat.Lemmas
import Mathlib.Data.ZMod.Factorial
import Mathlib.LinearAlgebra.Matrix.Adjugate
import Mathlib.LinearAlgebra.Vandermonde
import Mathlib.NumberTheory.Divisors
import Mathlib.NumberTheory.Real.Irrational
import Mathlib.NumberTheory.Wilson
import Mathlib.Tactic
import Mathlib.Tactic.FinCases
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.NormNum.NatFactorial
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.InfiniteSum.Basic
import Mathlib.Topology.Algebra.InfiniteSum.Ring

/-!
# Erdős #68: finite prime-pole survival

This module isolates the exact finite cancellation law for a prime power in
the denominator of a factorial-gap prefix.  At the largest displayed
`q`-adic exponent, all lower-exponent summands vanish modulo `q`; the full
prime power survives prefix reduction precisely when the reciprocal sum of
the maximal-hit cofactors is nonzero.

The statement is deliberately finite.  It assigns no `q`-adic value to the
infinite real tail, and nonvanishing of one local residue is not by itself an
irrationality proof.
-/

namespace ErdosProblems.Erdos68
open scoped BigOperators









private theorem factorialGap_pos_of_mem_Icc
    {M n : ℕ} (hn : n ∈ Finset.Icc 2 M) :
    0 < n.factorial - 1 := by
  exact Nat.sub_pos_of_lt
    (Nat.one_lt_factorial.mpr (Finset.mem_Icc.mp hn).1)

/-- If `q^e` divides a positive common multiple but a positive divisor has
smaller `q`-valuation, the quotient by that divisor still contains `q`. -/
private theorem prime_dvd_div_of_factorization_lt
    {q e d L : ℕ}
    (hq : q.Prime)
    (hdPos : 0 < d)
    (hLPos : 0 < L)
    (hdL : d ∣ L)
    (hqeL : q ^ e ∣ L)
    (hdLt : d.factorization q < e) :
    q ∣ L / d := by
  have hLNe : L ≠ 0 := hLPos.ne'
  have hdNe : d ≠ 0 := hdPos.ne'
  have hquotPos : 0 < L / d :=
    Nat.div_pos (Nat.le_of_dvd hLPos hdL) hdPos
  have hLe : e ≤ L.factorization q :=
    (hq.pow_dvd_iff_le_factorization hLNe).1 hqeL
  have hfact :
      (L / d).factorization q =
        L.factorization q - d.factorization q := by
    simpa using DFunLike.congr_fun (Nat.factorization_div hdL) q
  apply (hq.dvd_iff_one_le_factorization hquotPos.ne').2
  rw [hfact]
  omega
end ErdosProblems.Erdos68

open scoped BigOperators
open ErdosProblems in
open ErdosProblems.Erdos68 in
theorem solution
    {q M e : ℕ}
    (hq : q.Prime)
    (he : 1 ≤ e)
    (hmax :
      ∀ n ∈ Finset.Icc 2 M,
        ¬q ^ (e + 1) ∣ n.factorial - 1)
    (hattain :
      ∃ n ∈ Finset.Icc 2 M,
        q ^ e ∣ n.factorial - 1) :
    (factorialGapPrefixLCMNumerator M : ZMod q) =
      ((factorialGapPrefixLCM M / q ^ e : ℕ) : ZMod q) *
        factorialGapPrincipalResidue q M e := by
  classical
  letI : Fact q.Prime := ⟨hq⟩
  let L := factorialGapPrefixLCM M
  let qe := q ^ e
  let W := L / qe
  have hgapPos :
      ∀ n ∈ Finset.Icc 2 M, 0 < n.factorial - 1 := by
    intro n hn
    exact factorialGap_pos_of_mem_Icc hn
  have hLPos : 0 < L := by
    apply Nat.pos_of_ne_zero
    apply (Finset.lcm_ne_zero_iff).2
    intro n hn
    exact (hgapPos n hn).ne'
  obtain ⟨a, ha, hqea⟩ := hattain
  have haL : a.factorial - 1 ∣ L :=
    factorialGap_dvd_prefixLCM ha
  have hqeL : qe ∣ L := hqea.trans haL
  have hqePos : 0 < qe := pow_pos hq.pos e
  have hqeMulW : qe * W = L := Nat.mul_div_cancel' hqeL
  have hWNotDvd : ¬q ∣ W := by
    intro hqW
    have hmul : qe * q ∣ qe * W := Nat.mul_dvd_mul_left qe hqW
    have hsuccL : q ^ (e + 1) ∣ L := by
      rw [pow_succ]
      simpa [hqeMulW] using hmul
    have hltEach :
        ∀ n ∈ Finset.Icc 2 M,
          (n.factorial - 1).factorization q < e + 1 := by
      intro n hn
      have hgapNe := (hgapPos n hn).ne'
      exact lt_of_not_ge fun hge =>
        hmax n hn ((hq.pow_dvd_iff_le_factorization hgapNe).2 hge)
    have hltL : L.factorization q < e + 1 := by
      exact finset_lcm_factorization_lt_of_all_lt
        (by omega) hgapPos hltEach
    have hgeL : e + 1 ≤ L.factorization q :=
      (hq.pow_dvd_iff_le_factorization hLPos.ne').1 hsuccL
    omega
  unfold factorialGapPrefixLCMNumerator factorialGapPrincipalResidue
  push_cast
  change
    (∑ n ∈ Finset.Icc 2 M,
        (L / (n.factorial - 1) : ℕ) : ZMod q) =
      (W : ZMod q) *
        ∑ n ∈ factorialGapMaxHits q M e,
          (((n.factorial - 1) / qe : ℕ) : ZMod q)⁻¹
  rw [Finset.mul_sum]
  unfold factorialGapMaxHits
  rw [Finset.sum_filter]
  refine Finset.sum_congr rfl fun n hn => ?_
  let d := n.factorial - 1
  have hdPos : 0 < d := hgapPos n hn
  have hdL : d ∣ L := factorialGap_dvd_prefixLCM hn
  have hnotSucc : ¬q ^ (e + 1) ∣ d := hmax n hn
  change
    ((L / d : ℕ) : ZMod q) =
      if qe ∣ d ∧ ¬q ^ (e + 1) ∣ d then
        (W : ZMod q) * (((d / qe : ℕ) : ZMod q)⁻¹)
      else 0
  by_cases hqeD : qe ∣ d
  · have hUNotDvd : ¬q ∣ d / qe := by
      intro hqU
      have hmul : qe * q ∣ qe * (d / qe) :=
        Nat.mul_dvd_mul_left qe hqU
      have hqeMul : qe * (d / qe) = d := Nat.mul_div_cancel' hqeD
      apply hnotSucc
      rw [pow_succ]
      simpa [hqeMul] using hmul
    have hUNe : ((d / qe : ℕ) : ZMod q) ≠ 0 := by
      simpa [ZMod.natCast_eq_zero_iff] using hUNotDvd
    have hdivIdentity :
        (d / qe) * (L / d) = W := by
      have hleft : qe * ((d / qe) * (L / d)) = L := by
        calc
          qe * ((d / qe) * (L / d)) =
              (qe * (d / qe)) * (L / d) := by ring
          _ = d * (L / d) := by rw [Nat.mul_div_cancel' hqeD]
          _ = L := Nat.mul_div_cancel' hdL
      have hright : qe * W = L := hqeMulW
      exact Nat.eq_of_mul_eq_mul_left hqePos (hleft.trans hright.symm)
    have hdivIdentityZ :
        ((d / qe : ℕ) : ZMod q) * (L / d : ℕ) = (W : ZMod q) := by
      simpa only [Nat.cast_mul] using
        congrArg (fun x : ℕ => (x : ZMod q)) hdivIdentity
    simp [hqeD, hnotSucc]
    rw [← hdivIdentityZ]
    field_simp
  · have hdLt : d.factorization q < e := by
      exact lt_of_not_ge fun hge =>
        hqeD ((hq.pow_dvd_iff_le_factorization hdPos.ne').2 hge)
    have hqQuot : q ∣ L / d :=
      prime_dvd_div_of_factorization_lt hq hdPos hLPos hdL hqeL hdLt
    have hcastZero : ((L / d : ℕ) : ZMod q) = 0 :=
      (ZMod.natCast_eq_zero_iff _ _).2 hqQuot
    simp [hqeD, hcastZero]
