import Definitions.Def_ErdosProblems_Erdos68_CanonicalFactorialDigits
import Definitions.Def_ErdosProblems_Erdos68_ChannelBreakpointRigidity
import Definitions.Def_ErdosProblems_Erdos68_ChannelIntegralCongruence
import Definitions.Def_ErdosProblems_Erdos68_PrimeUnitTranslator
import Definitions.Def_ErdosProblems_Erdos68_FactorialGapPlateauCore
import Definitions.Def_ErdosProblems_Erdos68_CompanionConstantBridge
import Theorems.Thm_ErdosProblems_Erdos68_summable_compConstTerm
import Theorems.Thm_ErdosProblems_Erdos68_summable_unitFactTerm
import Mathlib.Algebra.BigOperators.Fin
import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Algebra.GCDMonoid.FinsetLemmas
import Mathlib.Algebra.Order.Floor.Ring
import Mathlib.Algebra.Order.Round
import Mathlib.Algebra.Ring.GeomSum
import Mathlib.Analysis.Asymptotics.Defs
import Mathlib.Analysis.Complex.ExponentialBounds
import Mathlib.Analysis.Real.Pi.Bounds
import Mathlib.Analysis.SpecialFunctions.Stirling
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Data.Fin.VecNotation
import Mathlib.Data.Int.Basic
import Mathlib.Data.Nat.Factorial.Basic
import Mathlib.Data.Nat.Factorial.BigOperators
import Mathlib.Data.Nat.ModEq
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.LinearAlgebra.Matrix.Adjugate
import Mathlib.LinearAlgebra.Vandermonde
import Mathlib.NumberTheory.Real.Irrational
import Mathlib.Tactic
import Mathlib.Tactic.FinCases
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.InfiniteSum.Basic
import Mathlib.Topology.Algebra.InfiniteSum.Ring

/-!
# Erdős #68: companion-constant telescope and lower-window certificate

Two completions of the carry congruence normal form.

**Telescope.**  With `d_n = 1/(n!(n!−1))` for `n ≥ 2` and the factorial-gap
series `S = ∑_{n≥2} 1/(n!−1)`:

`(∑' d_n) + (∑' 1/n!) = S`,

via the pointwise identity `d_n + 1/n! = 1/(n!−1)`.  Naming the second
series `e − 2` analytically, this reads `C_∞ = S − (e − 2)`: the carry
congruence normal form tests congruences of one fixed constant whose
irrationality-flavor is tied to `e`.

**Lower-window certificate.**  The gap-scalar expansion gave an upper-jump
miss certificate from below-domination; here we add the symmetric
lower-cylinder one: if the finite weighted digit block through `m+k`
together with its explicit remainder weight stays `≤ (1+ε_m)/m`, then index
`m` cannot be a unit carry — also a frontier miss.  Together both windows
certify every non-unit carry from finitely many certified digits.

No cofinality claim is made here.
-/

namespace ErdosProblems.Erdos68
open scoped BigOperators
end ErdosProblems.Erdos68

open scoped BigOperators
open ErdosProblems in
open ErdosProblems.Erdos68 in
theorem solution :
    (∑' n : ℕ, compConstTerm n) + (∑' n : ℕ, unitFactTerm n)
      = _root_.Erdos68.factorialGapSeries := by
  classical
  rw [← summable_compConstTerm.tsum_add summable_unitFactTerm]
  refine tsum_congr fun n => ?_
  by_cases hn : 2 ≤ n
  · rw [compConstTerm, if_pos hn, unitFactTerm, if_pos hn]
    rw [_root_.Erdos68.factorialGapTailTerm, if_pos (by omega : 1 < n)]
    push_cast
    have hgap : (0 : ℝ) < (n.factorial : ℝ) - 1 := by
      have hfac : (1 : ℝ) < (n.factorial : ℝ) := by
        exact_mod_cast Nat.one_lt_factorial.mpr hn
      linarith
    field_simp [ne_of_gt hgap]
    ring
  · rw [compConstTerm, if_neg hn, unitFactTerm, if_neg hn]
    rw [_root_.Erdos68.factorialGapTailTerm, if_neg (by omega : ¬1 < n)]
    norm_num
