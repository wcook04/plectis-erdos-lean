import Definitions.Def_ErdosProblems_Erdos68_ChannelBreakpointRigidity
import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Data.Nat.Factorial.Basic

/-!
# Channel breakpoint rigidity for Erdős problem 68

For a finite coefficient family whose indices all lie in one quotient band
`[k d, (k + 1) d)`, every factorial coefficient is the same fixed multiple
`(d!)^k` of its `d`-channel coefficient.  Hence cancellation of that channel
forces cancellation of the factorial moment.  In the first band, a nonzero
factorial moment together with channel cancellation requires at least one
support index to reach the breakpoint `2d`.

The namespace `Erdos68` is the finite-family presentation; it is distinct
from the Finsupp presentation in `ErdosProblems.Erdos68`.  No declaration
constructs a cancelling coefficient family, treats several channels
simultaneously, estimates a residual, or decides rationality of the #68
series.
-/

open Erdos68 in
theorem solution (d k : ℕ) :
    d.factorial ^ k ∣ (k * d).factorial := by
  induction k with
  | zero => simp
  | succ k ih =>
      have hmul : d.factorial ^ k * d.factorial ∣
          (k * d).factorial * d.factorial := Nat.mul_dvd_mul ih (dvd_refl _)
      have hstep : (k * d).factorial * d.factorial ∣
          (k * d + d).factorial :=
        Nat.factorial_mul_factorial_dvd_factorial_add (k * d) d
      simpa [pow_succ, Nat.succ_mul] using hmul.trans hstep
