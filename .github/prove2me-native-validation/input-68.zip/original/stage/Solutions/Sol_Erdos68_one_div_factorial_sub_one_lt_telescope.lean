import Definitions.Def_ErdosProblems_Erdos68_ChannelBreakpointRigidity
import Definitions.Def_ErdosProblems_Erdos68_ChannelIntegralCongruence
import Definitions.Def_ErdosProblems_Erdos68_PrimeUnitTranslator
import Mathlib.Algebra.BigOperators.Fin
import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Algebra.GCDMonoid.FinsetLemmas
import Mathlib.Algebra.Order.Round
import Mathlib.Algebra.Ring.GeomSum
import Mathlib.Analysis.Asymptotics.Defs
import Mathlib.Analysis.Complex.ExponentialBounds
import Mathlib.Analysis.Real.Pi.Bounds
import Mathlib.Analysis.SpecialFunctions.Stirling
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Data.Fin.VecNotation
import Mathlib.Data.Nat.Factorial.Basic
import Mathlib.Data.Nat.Factorial.BigOperators
import Mathlib.Data.Nat.ModEq
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.LinearAlgebra.Matrix.Adjugate
import Mathlib.LinearAlgebra.Vandermonde
import Mathlib.Tactic.FinCases
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.InfiniteSum.Basic
import Mathlib.Topology.Algebra.InfiniteSum.Ring

/-!
# Prime unit translator for Erdős problem 68

For a prime `p`, the coefficient pair `(p,-1)` on the indices `(p-1,p)` has
zero factorial moment and annihilates every channel except the `p`-channel.
At that channel its numerator is exactly `p!-1`; consequently its normalized
infinite residual is `1`.  Appending an integer multiple of this pair therefore
translates any finite-support residual by the same integer without changing
the lower channels or the factorial moment.

The module also classifies every finite-support residual modulo integers as
its factorial moment times the factorial-gap tail.  A Cramer construction on
an explicit factorial grid supplies, beyond any prescribed support threshold,
integer coefficient vectors with zero channels through a chosen cutoff and
nonzero factorial moment.  Appending a prime translator reduces their
residual to absolute value at most `1/2`.

The last reduction is not an irrationality argument by itself: the reduced
residual may be zero.  The strict version assumes that the original residual
is not an integer, and no theorem here proves that assumption for the Cramer
vectors.  There is also no coefficient-size estimate, no nonzero lower bound
for the reduced residual, and no irrationality theorem for the factorial-gap
series.
-/

open Erdos68 in
theorem solution
    {m : ℕ} (hm : 3 ≤ m) :
    (1 : ℝ) / (((m.factorial : ℤ) - 1 : ℤ) : ℝ) <
      1 / ((m - 1).factorial : ℝ) -
        1 / (m.factorial : ℝ) := by
  have hfac : m.factorial = m * (m - 1).factorial := by
    calc
      m.factorial = ((m - 1) + 1).factorial := by
        congr 1
        omega
      _ = ((m - 1) + 1) * (m - 1).factorial :=
        Nat.factorial_succ _
      _ = m * (m - 1).factorial := by
        congr 1
        omega
  have hprednat : 2 ≤ (m - 1).factorial := by
    calc
      2 ≤ m - 1 := by omega
      _ ≤ (m - 1).factorial := Nat.self_le_factorial _
  have hden :
      (0 : ℝ) <
        (((m.factorial : ℤ) - 1 : ℤ) : ℝ) := by
    exact_mod_cast
      (show (0 : ℤ) < (m.factorial : ℤ) - 1 by
        have : 1 < m.factorial := Nat.one_lt_factorial.mpr (by omega)
        omega)
  have hmreal : (0 : ℝ) < m := by positivity
  have hpredreal : (0 : ℝ) < ((m - 1).factorial : ℝ) := by
    positivity
  simp only [Int.cast_sub, Int.cast_natCast, Int.cast_one]
  have hfacreal :
      (m.factorial : ℝ) =
        (m : ℝ) * ((m - 1).factorial : ℝ) := by
    exact_mod_cast hfac
  rw [hfacreal]
  have hprod :
      (0 : ℝ) < (m : ℝ) * ((m - 1).factorial : ℝ) :=
    mul_pos hmreal hpredreal
  have hrewrite :
      1 / ((m - 1).factorial : ℝ) -
          1 / ((m : ℝ) * ((m - 1).factorial : ℝ)) =
        ((m : ℝ) - 1) /
          ((m : ℝ) * ((m - 1).factorial : ℝ)) := by
    field_simp
  have hpredbound :
      (2 : ℝ) ≤ ((m - 1).factorial : ℝ) := by
    exact_mod_cast hprednat
  have hmbound : (3 : ℝ) ≤ m := by exact_mod_cast hm
  have hdenprod :
      (0 : ℝ) <
        (m : ℝ) * ((m - 1).factorial : ℝ) - 1 := by
    nlinarith
  rw [hrewrite, div_lt_div_iff₀ hdenprod hprod]
  nlinarith
