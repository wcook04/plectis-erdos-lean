import Definitions.Def_ErdosProblems_Erdos68_CanonicalFactorialDigits
import Definitions.Def_ErdosProblems_Erdos68_ChannelBreakpointRigidity
import Definitions.Def_ErdosProblems_Erdos68_ChannelIntegralCongruence
import Definitions.Def_ErdosProblems_Erdos68_PrimeUnitTranslator
import Definitions.Def_ErdosProblems_Erdos68_FactorialGapPlateauCore
import Mathlib.Algebra.BigOperators.Fin
import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Algebra.GCDMonoid.FinsetLemmas
import Mathlib.Algebra.Order.Floor.Ring
import Mathlib.Algebra.Order.Round
import Mathlib.Algebra.Ring.GeomSum
import Mathlib.Analysis.Asymptotics.Defs
import Mathlib.Analysis.Complex.ExponentialBounds
import Mathlib.Analysis.Real.Pi.Bounds
import Mathlib.Analysis.SpecialFunctions.Stirling
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Data.Fin.VecNotation
import Mathlib.Data.Int.Basic
import Mathlib.Data.Nat.Factorial.Basic
import Mathlib.Data.Nat.Factorial.BigOperators
import Mathlib.Data.Nat.ModEq
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.LinearAlgebra.Matrix.Adjugate
import Mathlib.LinearAlgebra.Vandermonde
import Mathlib.NumberTheory.Real.Irrational
import Mathlib.Tactic
import Mathlib.Tactic.FinCases
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.InfiniteSum.Basic
import Mathlib.Topology.Algebra.InfiniteSum.Ring

/-!
# Erdős #68: factorial-gap plateau core

Lightweight core for the strict-successor recurrence, carry bounds, and the
exact divisibility criterion.  Heavy exact-index certificates live in
`FactorialZeroPlateauCertificates`; the full plateau file re-exports both.
-/

namespace ErdosProblems.Erdos68
/-! ## Factorial grid arithmetic -/
end ErdosProblems.Erdos68

open ErdosProblems in
open ErdosProblems.Erdos68 in
theorem solution (x : ℝ) (n : ℕ) :
    x < (strictFacTop x n : ℝ) / (n.factorial : ℝ) ∧
      (strictFacTop x n : ℝ) / (n.factorial : ℝ) ≤
        x + 1 / (n.factorial : ℝ) := by
  have hfac : (0 : ℝ) < n.factorial := by positivity
  constructor
  · rw [lt_div_iff₀ hfac]
    unfold strictFacTop
    push_cast
    simpa [mul_comm] using
      Int.lt_floor_add_one ((n.factorial : ℝ) * x)
  · rw [div_le_iff₀ hfac]
    have hfloor := Int.floor_le ((n.factorial : ℝ) * x)
    calc
      (strictFacTop x n : ℝ) =
          (⌊(n.factorial : ℝ) * x⌋ : ℝ) + 1 := by
            unfold strictFacTop
            push_cast
            rfl
      _ ≤ (n.factorial : ℝ) * x + 1 := by linarith
      _ = (x + 1 / (n.factorial : ℝ)) *
          (n.factorial : ℝ) := by
            field_simp
