import Definitions.Def_ErdosProblems_Erdos68_CanonicalFactorialDigits
import Definitions.Def_ErdosProblems_Erdos68_ChannelBreakpointRigidity
import Definitions.Def_ErdosProblems_Erdos68_ChannelIntegralCongruence
import Definitions.Def_ErdosProblems_Erdos68_PrimeUnitTranslator
import Definitions.Def_ErdosProblems_Erdos68_FactorialGapPlateauCore
import Definitions.Def_ErdosProblems_Erdos68_FactorialChannelCertificate
import Definitions.Def_ErdosProblems_Erdos68_EndpointWeightedPrivateSupport
import Theorems.Thm_ErdosProblems_Erdos68_factorialBlock_addedTerm_add_gridCell_le_endpointUpperBound
import Theorems.Thm_ErdosProblems_Erdos68_factorialGapPrefix_eq_prev_add
import Theorems.Thm_ErdosProblems_Erdos68_strictFacTop_div_factorial_bounds
import Theorems.Thm_ErdosProblems_Erdos68_strictFacTop_factorialGapPrefix_div_factorial_step
import Theorems.Thm_ErdosProblems_Erdos68_strictFacTop_factorialGapPrefix_pos
import Lean.Elab.Tactic.Omega
import Mathlib.Algebra.BigOperators.Fin
import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Algebra.GCDMonoid.FinsetLemmas
import Mathlib.Algebra.Order.Floor.Ring
import Mathlib.Algebra.Order.Round
import Mathlib.Algebra.Ring.GeomSum
import Mathlib.Analysis.Asymptotics.Defs
import Mathlib.Analysis.Complex.ExponentialBounds
import Mathlib.Analysis.Real.Pi.Bounds
import Mathlib.Analysis.SpecialFunctions.Stirling
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Data.Fin.VecNotation
import Mathlib.Data.Finsupp.Basic
import Mathlib.Data.Int.Basic
import Mathlib.Data.Int.ModEq
import Mathlib.Data.Nat.Choose.Multinomial
import Mathlib.Data.Nat.Factorial.Basic
import Mathlib.Data.Nat.Factorial.BigOperators
import Mathlib.Data.Nat.Factorization.Basic
import Mathlib.Data.Nat.GCD.BigOperators
import Mathlib.Data.Nat.ModEq
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.Nat.Prime.Factorial
import Mathlib.Data.Rat.Lemmas
import Mathlib.LinearAlgebra.Matrix.Adjugate
import Mathlib.LinearAlgebra.Vandermonde
import Mathlib.NumberTheory.Divisors
import Mathlib.NumberTheory.Real.Irrational
import Mathlib.Tactic
import Mathlib.Tactic.FinCases
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.NormNum.NatFactorial
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.InfiniteSum.Basic
import Mathlib.Topology.Algebra.InfiniteSum.Ring

/-!
# Erdős #68: collision cores, private residues, and factorial-block endpoints

For a finite denominator family, the pairwise collision core records the
prime powers shared by at least two denominators.  Dividing each denominator
by its part inside this core produces pairwise-coprime private quotients.
Their product is the private modulus `R`; a weighted leave-one-out numerator
is coprime to `R`, so the displayed endpoint numerator has a nonzero residue
whenever `R > 1`.

The abstract part of the file develops these finite gcd, lcm, CRT, and
projection identities.  The factorial-block specialization takes the
denominators `n! - 1` for `p ≤ n < 2p`, identifies the strict-successor
coefficient at `p - 1`, and defines an endpoint window.  Unit carries on the
whole interval `[p,2p]` force that window; so does any rational value whose
denominator is already cleared by `(p-1)!`.

The later theorems give several exact ways to refute the window: a large
private residue, unequal leave-one-out projections, coprime factor-pair
floors, or a uniquely supported prime with a sufficiently large residue.
Cofinal families of any of the stated certificates imply cofinally many
non-unit carries or rational-prefix divisibility failures, and hence imply
irrationality through the earlier carry criterion.

Every irrationality conclusion in this file is conditional.  No theorem
constructs the required cofinal certificate family, proves the needed
projection disagreement or size inequality for arbitrarily large blocks,
or supplies cofinally many uniquely supported factorial-gap primes.  The
finite CRT identities and endpoint reductions therefore do not by themselves
prove the irrationality of the factorial-gap series or solve Erdős #68.
-/

namespace ErdosProblems.Erdos68
/-! ## Collision cores for finite denominator families -/



















































































/-! ## Private quotients and weighted CRT numerators -/



































































/-! ## Endpoint residues and finite projection bounds -/



































































/-! ## The factorial-block endpoint window -/



































































/-- Conversion to a natural coefficient does not alter the positive strict
successor at the predecessor prefix. -/
theorem factorialBlockCoefficient_cast_eq_strictFacTop
    {p : ℕ} :
    (factorialBlockCoefficient p : ℤ) =
      strictFacTop
        ((factorialGapPrefix (p - 1) : ℚ) : ℝ)
        (p - 1) := by
  unfold factorialBlockCoefficient
  simpa using Int.toNat_of_nonneg
    (strictFacTop_factorialGapPrefix_pos (p - 1)).le
end ErdosProblems.Erdos68

open ErdosProblems in
open ErdosProblems.Erdos68 in
theorem solution
    {p : ℕ}
    (hp : 3 ≤ p)
    (hunit :
      ∀ m ∈ Finset.Icc p (2 * p),
        factorialGapStepCarry m = 1) :
    factorialBlockEndpointWindow p := by
  let A : ℕ → ℝ := fun n =>
    (strictFacTop
          ((factorialGapPrefix n : ℚ) : ℝ) n : ℝ) /
      (n.factorial : ℝ)
  have hconstAux :
      ∀ k : ℕ, k ≤ p + 1 →
        A (p - 1 + k) = A (p - 1) := by
    intro k
    induction k with
    | zero =>
        intro _
        simp
    | succ k ih =>
        intro hk
        let m := p - 1 + (k + 1)
        have hm3 : 3 ≤ m := by
          dsimp [m]
          omega
        have hmMem : m ∈ Finset.Icc p (2 * p) := by
          apply Finset.mem_Icc.mpr
          dsimp [m]
          omega
        have hstep :=
          strictFacTop_factorialGapPrefix_div_factorial_step
            (m := m) hm3
        have hcarry := hunit m hmMem
        rw [hcarry] at hstep
        norm_num at hstep
        have hmPred :
            m - 1 = p - 1 + k := by
          dsimp [m]
        change A m = A (m - 1) at hstep
        rw [hmPred] at hstep
        exact hstep.trans (ih (by omega))
  have hAeq :
      A (2 * p) = A (p - 1) := by
    have h := hconstAux (p + 1) (by omega)
    have hindex : p - 1 + (p + 1) = 2 * p := by omega
    simpa [hindex] using h
  have hcoeffInt :=
    factorialBlockCoefficient_cast_eq_strictFacTop (p := p)
  have hcoeffReal :
      (factorialBlockCoefficient p : ℝ) =
        (strictFacTop
          ((factorialGapPrefix (p - 1) : ℚ) : ℝ)
          (p - 1) : ℝ) := by
    exact_mod_cast hcoeffInt
  have hgapReal :
      ((factorialBlockEndpointGap p : ℚ) : ℝ) =
        A (2 * p) -
          ((factorialGapPrefix (2 * p - 1) : ℚ) : ℝ) := by
    unfold factorialBlockEndpointGap factorialBlockBase
    push_cast
    rw [hcoeffReal]
    change
      A (p - 1) -
          ((factorialGapPrefix (2 * p - 1) : ℚ) : ℝ) =
        A (2 * p) -
          ((factorialGapPrefix (2 * p - 1) : ℚ) : ℝ)
    rw [hAeq]
  have htwoP : 2 ≤ 2 * p := by omega
  have hprefixStep :
      ((factorialGapPrefix (2 * p) : ℚ) : ℝ) =
        ((factorialGapPrefix (2 * p - 1) : ℚ) : ℝ) +
          1 / (((2 * p).factorial : ℝ) - 1) := by
    exact_mod_cast
      (factorialGapPrefix_eq_prev_add (τ := 2 * p) htwoP)
  have hbounds :=
    strictFacTop_div_factorial_bounds
      ((factorialGapPrefix (2 * p) : ℚ) : ℝ) (2 * p)
  change
    ((factorialGapPrefix (2 * p) : ℚ) : ℝ) < A (2 * p) ∧
      A (2 * p) ≤
        ((factorialGapPrefix (2 * p) : ℚ) : ℝ) +
          1 / ((2 * p).factorial : ℝ) at hbounds
  have hgapPosR :
      (0 : ℝ) <
        ((factorialBlockEndpointGap p : ℚ) : ℝ) := by
    have hbounds' := hbounds
    rw [hprefixStep] at hbounds'
    have hfacGt :
        (1 : ℝ) < ((2 * p).factorial : ℝ) := by
      exact_mod_cast
        (Nat.one_lt_factorial.mpr (show 2 ≤ 2 * p by omega))
    have htermPos :
        (0 : ℝ) <
          1 / (((2 * p).factorial : ℝ) - 1) :=
      one_div_pos.mpr (by linarith)
    rw [hgapReal]
    linarith [hbounds'.1, htermPos]
  have hgapUpperR :
      ((factorialBlockEndpointGap p : ℚ) : ℝ) ≤
        (factorialBlockEndpointUpperBound p : ℝ) := by
    have hbounds' := hbounds
    rw [hprefixStep] at hbounds'
    rw [hgapReal]
    exact
      (show
          A (2 * p) -
                ((factorialGapPrefix (2 * p - 1) : ℚ) : ℝ) ≤
                1 / (((2 * p).factorial : ℝ) - 1) +
                1 / ((2 * p).factorial : ℝ) by
            linarith [hbounds'.2]).trans
        (factorialBlock_addedTerm_add_gridCell_le_endpointUpperBound
          (p := p) (by omega))
  constructor
  · exact_mod_cast hgapPosR
  · exact_mod_cast hgapUpperR
