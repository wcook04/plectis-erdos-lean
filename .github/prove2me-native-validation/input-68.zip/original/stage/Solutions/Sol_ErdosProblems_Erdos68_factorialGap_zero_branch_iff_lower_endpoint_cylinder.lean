import Definitions.Def_ErdosProblems_Erdos68_CanonicalFactorialDigits
import Definitions.Def_ErdosProblems_Erdos68_ChannelBreakpointRigidity
import Definitions.Def_ErdosProblems_Erdos68_ChannelIntegralCongruence
import Definitions.Def_ErdosProblems_Erdos68_PrimeUnitTranslator
import Definitions.Def_ErdosProblems_Erdos68_FactorialGapPlateauCore
import Definitions.Def_ErdosProblems_Erdos68_FactorialChannelCertificate
import Definitions.Def_ErdosProblems_Erdos68_EndpointWeightedPrivateSupport
import Definitions.Def_ErdosProblems_Erdos68_PrimeZeroBranch
import Theorems.Thm_Erdos68_factorialGapTail_lt_one_div_factorial
import Theorems.Thm_ErdosProblems_Erdos68_canonicalDigit_eq_floor_mul_remainder
import Theorems.Thm_ErdosProblems_Erdos68_canonicalRemainder_nonneg
import Theorems.Thm_ErdosProblems_Erdos68_factorialGapScaledTail_pos
import Theorems.Thm_ErdosProblems_Erdos68_canonicalRemainder_recurrence
import Theorems.Thm_ErdosProblems_Erdos68_factorialGapScaledTail_pred_recurrence
import Lean.Elab.Tactic.Omega
import Mathlib.Algebra.BigOperators.Fin
import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Algebra.GCDMonoid.FinsetLemmas
import Mathlib.Algebra.Order.Floor.Ring
import Mathlib.Algebra.Order.Round
import Mathlib.Algebra.Ring.GeomSum
import Mathlib.Analysis.Asymptotics.Defs
import Mathlib.Analysis.Complex.ExponentialBounds
import Mathlib.Analysis.Real.Pi.Bounds
import Mathlib.Analysis.SpecialFunctions.Stirling
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Data.Fin.VecNotation
import Mathlib.Data.Finsupp.Basic
import Mathlib.Data.Int.Basic
import Mathlib.Data.Int.ModEq
import Mathlib.Data.Nat.Choose.Multinomial
import Mathlib.Data.Nat.Factorial.Basic
import Mathlib.Data.Nat.Factorial.BigOperators
import Mathlib.Data.Nat.Factorization.Basic
import Mathlib.Data.Nat.GCD.BigOperators
import Mathlib.Data.Nat.ModEq
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.Nat.Prime.Factorial
import Mathlib.Data.Nat.Prime.Infinite
import Mathlib.Data.Rat.Lemmas
import Mathlib.Data.ZMod.Factorial
import Mathlib.LinearAlgebra.Matrix.Adjugate
import Mathlib.LinearAlgebra.Vandermonde
import Mathlib.NumberTheory.Divisors
import Mathlib.NumberTheory.Real.Irrational
import Mathlib.NumberTheory.Wilson
import Mathlib.Tactic
import Mathlib.Tactic.FinCases
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.NormNum.NatFactorial
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.InfiniteSum.Basic
import Mathlib.Topology.Algebra.InfiniteSum.Ring

/-!
# Erdős #68: the prime zero branch

This module develops three linked layers of the factorial-gap series.

First, exact prefix identities express the step carry through a binary
endpoint flag and the canonical factorial digit.  A unit carry is therefore
equivalent to one of two endpoint cylinders: a zero digit with two zero
flags, or the maximal digit with two one flags.

Second, reduced predecessor fractions are followed prime by prime.  The
formalized arithmetic includes prefix-private prime powers, accumulated
denominator factors, collision and residual cofactors, and exact finite
records at the primes `107` and `971`.  In particular, prefix-private
factorial-gap hits occur cofinally and the corresponding numerator
projections are nonzero under the stated divisibility hypotheses.

Third, a family of conditional theorems shows that sufficiently large
predecessor residues, supplied cofinally, would force irrationality.  The
module does **not** prove those quantitative lower bounds: a nonzero residue
is not enough.  It therefore proves no unconditional irrationality theorem
and does not settle Erdős #68.
-/

namespace ErdosProblems.Erdos68
/-! ## Scaled tails and endpoint flags -/





/-- The scaled factorial-gap tail is strictly smaller than one. -/
theorem factorialGapScaledTail_lt_one
    {m : ℕ} (hm : 2 ≤ m) :
    factorialGapScaledTail m < 1 := by
  have htail :=
    _root_.Erdos68.factorialGapTail_lt_one_div_factorial hm
  have hfacPos : (0 : ℝ) < m.factorial := by positivity
  have hmul := mul_lt_mul_of_pos_left htail hfacPos
  simpa [factorialGapScaledTail, ne_of_gt hfacPos] using hmul







/-- A zero endpoint flag is exactly strict containment below the scaled
tail. -/
theorem factorialGapEndpointFlag_eq_zero_iff (m : ℕ) :
    factorialGapEndpointFlag m = 0 ↔
      canonicalRemainder _root_.Erdos68.factorialGapSeries m <
        factorialGapScaledTail m := by
  simp [factorialGapEndpointFlag, not_le]





/-! ## The reduced rational predecessor state -/













































































/-! ## Prime-power persistence in consecutive denominators -/



















/-! ## Prefix-private moduli and finite CRT anchors -/























































/-! ## Accumulated private powers across finite intervals -/

























/-! ## Componentwise private-prime sources -/

































































/-! ## Cofinal private hits and reflected collisions -/







































/-! ## Killed multiplicities and residual-cofactor recurrences -/





























































































/-! ## Wilson quotients and finite repeated-prime records -/































/-! ## Repeated-birth amplification and interval persistence -/

















































/-! ## Endpoint cylinders and the exact carry dichotomy -/
end ErdosProblems.Erdos68

open ErdosProblems in
open ErdosProblems.Erdos68 in
theorem solution
    {m : ℕ} (hm : 3 ≤ m) :
    (canonicalDigit _root_.Erdos68.factorialGapSeries m = 0 ∧
        factorialGapEndpointFlag (m - 1) = 0 ∧
        factorialGapEndpointFlag m = 0) ↔
      (m : ℝ) *
          canonicalRemainder
            _root_.Erdos68.factorialGapSeries (m - 1) <
        factorialGapScaledTail m := by
  let S : ℝ := _root_.Erdos68.factorialGapSeries
  change
    (canonicalDigit S m = 0 ∧
        factorialGapEndpointFlag (m - 1) = 0 ∧
        factorialGapEndpointFlag m = 0) ↔
      (m : ℝ) * canonicalRemainder S (m - 1) <
        factorialGapScaledTail m
  have hsucc : m - 1 + 1 = m := by omega
  have hcastSucc :
      ((m - 1 : ℕ) : ℝ) + 1 = (m : ℝ) := by
    exact_mod_cast hsucc
  have hrec := canonicalRemainder_recurrence S (m - 1)
  rw [hsucc, hcastSucc] at hrec
  have htailRec :=
    factorialGapScaledTail_pred_recurrence (m := m) hm
  have hRPos :=
    factorialGapScaledTail_pos (m := m) (by omega)
  have hRLt :=
    factorialGapScaledTail_lt_one (m := m) (by omega)
  constructor
  · rintro ⟨hdigit, _hprev, hcurr⟩
    have hcurrLt :=
      (factorialGapEndpointFlag_eq_zero_iff m).mp hcurr
    rw [hdigit] at hrec
    norm_num at hrec
    rw [hrec] at hcurrLt
    exact hcurrLt
  · intro hsmall
    have hdigit : canonicalDigit S m = 0 := by
      rw [canonicalDigit_eq_floor_mul_remainder S m (by omega)]
      apply Int.floor_eq_iff.mpr
      constructor
      · norm_num
        exact mul_nonneg (by positivity)
          (canonicalRemainder_nonneg S (m - 1))
      · norm_num
        exact hsmall.trans hRLt
    have hcurrRem :
        canonicalRemainder S m =
          (m : ℝ) * canonicalRemainder S (m - 1) := by
      rw [hdigit] at hrec
      norm_num at hrec
      exact hrec
    have hcurr : factorialGapEndpointFlag m = 0 := by
      apply (factorialGapEndpointFlag_eq_zero_iff m).mpr
      rw [hcurrRem]
      exact hsmall
    have hdenPos :
        0 < 1 / ((m.factorial : ℝ) - 1) := by
      apply one_div_pos.mpr
      have hfacGt : (1 : ℝ) < m.factorial := by
        exact_mod_cast Nat.one_lt_factorial.mpr (by omega : 2 ≤ m)
      linarith
    have hRltPred :
        factorialGapScaledTail m <
          (m : ℝ) * factorialGapScaledTail (m - 1) := by
      linarith
    have hmPos : (0 : ℝ) < m := by positivity
    have hprevLt :
        canonicalRemainder S (m - 1) <
          factorialGapScaledTail (m - 1) := by
      nlinarith
    have hprev :
        factorialGapEndpointFlag (m - 1) = 0 :=
      (factorialGapEndpointFlag_eq_zero_iff (m - 1)).mpr
        hprevLt
    exact ⟨hdigit, hprev, hcurr⟩
