import Definitions.Def_ErdosProblems_Erdos68_ChannelBreakpointRigidity
import Definitions.Def_ErdosProblems_Erdos68_ChannelIntegralCongruence
import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Algebra.GCDMonoid.FinsetLemmas
import Mathlib.Algebra.Ring.GeomSum
import Mathlib.Analysis.Asymptotics.Defs
import Mathlib.Analysis.Complex.ExponentialBounds
import Mathlib.Analysis.Real.Pi.Bounds
import Mathlib.Analysis.SpecialFunctions.Stirling
import Mathlib.Data.Nat.Factorial.Basic
import Mathlib.Data.Nat.Factorial.BigOperators
import Mathlib.Data.Nat.ModEq
import Mathlib.Tactic.Ring

/-!
# Integral channel congruence for Erdős problem 68

This module compares a channel numerator with the corresponding factorial
moment modulo `d! - 1`.  The congruence holds for every support index, so
simultaneous cancellation of the channels `2, ..., D` makes their least common
multiple divide the factorial moment.

The second part estimates that least common multiple.  Consecutive numbers
`m! - 1` are compared through their pairwise gcds; this gives an explicit
finite lower bound after the gcd losses are counted.  Consequently, if a
positive integer `M` is divisible by the channel lcm and is smaller than
`(R+1)! - 1`, then `R` must grow at least cubically along `D = 2t^2`.  A later
estimate improves the explicit constant to `R+1 > (3/2)t^3` for `t >= 2^32`.

All conclusions after the congruence theorem retain these stated hypotheses.
In particular, this file does not construct `M` or `R` from the series in
Erdős problem 68, prove that its channels vanish, or decide the rationality of
that series.
-/

namespace Erdos68
/-! ## Product versus lcm with explicit gcd loss -/











/-! ## Factorial-gap collision bounds -/
end Erdos68

open Erdos68 in
theorem solution
    {m n : ℕ} (hmn : m < n) :
    Nat.gcd (m.factorial - 1) (n.factorial - 1) ∣
      n.descFactorial (n - m) - 1 := by
  let g := Nat.gcd (m.factorial - 1) (n.factorial - 1)
  have hmfac : 1 ≤ m.factorial :=
    Nat.one_le_iff_ne_zero.mpr (Nat.factorial_ne_zero m)
  have hnfac : 1 ≤ n.factorial :=
    Nat.one_le_iff_ne_zero.mpr (Nat.factorial_ne_zero n)
  have hmMod : m.factorial ≡ 1 [MOD g] :=
    ((Nat.modEq_iff_dvd' hmfac).2 (Nat.gcd_dvd_left _ _)).symm
  have hnMod : n.factorial ≡ 1 [MOD g] :=
    ((Nat.modEq_iff_dvd' hnfac).2 (Nat.gcd_dvd_right _ _)).symm
  have hk : n - m ≤ n := Nat.sub_le _ _
  have hfactorial :
      m.factorial * n.descFactorial (n - m) = n.factorial := by
    have h := Nat.factorial_mul_descFactorial hk
    simpa [Nat.sub_sub_self (Nat.le_of_lt hmn)] using h
  have hfactorMod :
      n.factorial ≡ n.descFactorial (n - m) [MOD g] := by
    simpa [hfactorial] using
      hmMod.mul_right (n.descFactorial (n - m))
  have hQMod : n.descFactorial (n - m) ≡ 1 [MOD g] :=
    hfactorMod.symm.trans hnMod
  have hQpos : 1 ≤ n.descFactorial (n - m) := by
    exact Nat.one_le_iff_ne_zero.mpr
      (Nat.ne_of_gt (Nat.descFactorial_pos.mpr hk))
  exact (Nat.modEq_iff_dvd' hQpos).1 hQMod.symm
