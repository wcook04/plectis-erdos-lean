import Definitions.Def_ErdosProblems_Erdos68_ChannelBreakpointRigidity
import Definitions.Def_ErdosProblems_Erdos68_ChannelIntegralCongruence
import Definitions.Def_ErdosProblems_Erdos68_PaperCompleteAsymptotics
import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Algebra.GCDMonoid.FinsetLemmas
import Mathlib.Algebra.Ring.GeomSum
import Mathlib.Analysis.Asymptotics.Defs
import Mathlib.Analysis.Complex.ExponentialBounds
import Mathlib.Analysis.Real.Pi.Bounds
import Mathlib.Analysis.SpecialFunctions.Log.Basic
import Mathlib.Analysis.SpecialFunctions.Sqrt
import Mathlib.Analysis.SpecialFunctions.Stirling
import Mathlib.Data.Nat.Factorial.Basic
import Mathlib.Data.Nat.Factorial.BigOperators
import Mathlib.Data.Nat.ModEq
import Mathlib.Tactic
import Mathlib.Tactic.Ring
import Mathlib.Topology.Order.Basic

/-!
# End-to-end candidate for the two displayed sharp asymptotic constants

Long-record labels res:lcm-growth and res:radius-constant.

`LowerLimitAtLeast f c` is the epsilon/eventual formulation of liminf f >= c:
for every a<c, eventually a<f(n). It is deliberately used instead of a
real-valued `Filter.liminf`, whose default value is not an extended-real
infinity when the sequence diverges to +infinity. This representation places
no unproved upper-boundedness hypothesis on the lcm sequence.

The proof starts from the supplied finite product and Stirling inequalities.
It proves the optimising Nat.sqrt limit, the moving logarithm limit, and the
binomial normalisation, rather than assuming their asymptotic conclusions.

STATUS: compiled proof candidates. These are the largest API/elaboration
risks in the return. There are no admitted analytic facts or proof placeholders.
-/

namespace ErdosProblems.Erdos68.PaperComplete
open Filter
open scoped Topology BigOperators
end ErdosProblems.Erdos68.PaperComplete

open Filter
open scoped Topology BigOperators
open ErdosProblems in
open ErdosProblems.Erdos68 in
open ErdosProblems.Erdos68.PaperComplete in
theorem solution :
    Tendsto (fun n : ℕ => (Real.log (n : ℝ))⁻¹) atTop (𝓝 0) :=
  tendsto_inv_atTop_zero.comp (Real.tendsto_log_atTop.comp tendsto_natCast_atTop_atTop)
