import Definitions.Def_ErdosProblems_Erdos68_CanonicalFactorialDigits
import Definitions.Def_ErdosProblems_Erdos68_ChannelBreakpointRigidity
import Definitions.Def_ErdosProblems_Erdos68_ChannelIntegralCongruence
import Definitions.Def_ErdosProblems_Erdos68_PrimeUnitTranslator
import Definitions.Def_ErdosProblems_Erdos68_FactorialGapPlateauCore
import Definitions.Def_ErdosProblems_Erdos68_FactorialChannelCertificate
import Definitions.Def_ErdosProblems_Erdos68_EndpointWeightedPrivateSupport
import Definitions.Def_ErdosProblems_Erdos68_PrimeZeroBranch
import Theorems.Thm_ErdosProblems_Erdos68_canonicalRemainder_eq_zero_of_eq_rat
import Theorems.Thm_ErdosProblems_Erdos68_factorialGapScaledTail_pos
import Theorems.Thm_ErdosProblems_Erdos68_factorialGapStepCarry_eq_one_iff_zero_or_maximal_branch
import Theorems.Thm_ErdosProblems_Erdos68_factorialGap_zero_branch_iff_lower_endpoint_cylinder
import Theorems.Thm_ErdosProblems_Erdos68_not_irrational_factorialGapSeries_of_eventually_unit_carries
import Lean.Elab.Tactic.Omega
import Mathlib.Algebra.BigOperators.Fin
import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Algebra.GCDMonoid.FinsetLemmas
import Mathlib.Algebra.Order.Floor.Ring
import Mathlib.Algebra.Order.Round
import Mathlib.Algebra.Ring.GeomSum
import Mathlib.Analysis.Asymptotics.Defs
import Mathlib.Analysis.Complex.ExponentialBounds
import Mathlib.Analysis.Real.Pi.Bounds
import Mathlib.Analysis.SpecialFunctions.Stirling
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Data.Fin.VecNotation
import Mathlib.Data.Finsupp.Basic
import Mathlib.Data.Int.Basic
import Mathlib.Data.Int.ModEq
import Mathlib.Data.Nat.Choose.Multinomial
import Mathlib.Data.Nat.Factorial.Basic
import Mathlib.Data.Nat.Factorial.BigOperators
import Mathlib.Data.Nat.Factorization.Basic
import Mathlib.Data.Nat.GCD.BigOperators
import Mathlib.Data.Nat.ModEq
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.Nat.Prime.Factorial
import Mathlib.Data.Nat.Prime.Infinite
import Mathlib.Data.Rat.Lemmas
import Mathlib.Data.ZMod.Factorial
import Mathlib.LinearAlgebra.Matrix.Adjugate
import Mathlib.LinearAlgebra.Vandermonde
import Mathlib.NumberTheory.Divisors
import Mathlib.NumberTheory.Real.Irrational
import Mathlib.NumberTheory.Wilson
import Mathlib.Tactic
import Mathlib.Tactic.FinCases
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.NormNum.NatFactorial
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.InfiniteSum.Basic
import Mathlib.Topology.Algebra.InfiniteSum.Ring

/-!
# Erdős #68: the shrinking-target normal form

The corpus already carries two exact normal forms for the irrationality of
`S = ∑ 1/(n! - 1)`: cofinal non-unit carries, and cofinal misses of the
strict-successor divisibility.  Both treat *every* unit carry as a failure.

A unit carry has two radically different causes: the canonical orbit sits in
the tiny lower endpoint cylinder, or the canonical digit is maximal.  The
second is harmless.  This module isolates that distinction and produces a
**third** exact normal form:

`S ∉ ℚ  ↔  ∀ B, ∃ m > B, factorialGapScaledTail m ≤ m · r_{m-1}`

(`irrational_factorialGapSeries_iff_cofinal_lower_endpoint_escape`), i.e.
irrationality is exactly *cofinal escape from the lower endpoint cylinder*.
Since `0 < factorialGapScaledTail m < 2/m`, the trapping radius is
`O(m⁻²)`: Erdős #68 is an explicit deterministic shrinking-target problem
for the factorial orbit, with a quadratically small target.

The escape target is strictly more permissive than the carry target
(`factorialGap_lower_endpoint_escape_iff_nonunit_or_maximal_digit`), and it
admits a completely **tail-free two-sided** consumer over the finite
predecessor gap (`irrational_factorialGapSeries_of_cofinal_predecessorGap_outside_window`).
The corpus previously exposed only the upper half of that window.

Erdős #68 remains open: no theorem here produces the cofinal escape events.
-/

namespace ErdosProblems.Erdos68
open scoped BigOperators



/-- One escape at index `m` excludes every displayed rational denominator
below `m`.  Unlike the existing prime-indexed consumer, no primality
assumption is needed. -/
theorem factorialGap_rational_denominator_ge_of_lower_endpoint_escape
    {m q : ℕ} {a : ℤ} (hm : 2 ≤ m) (hq : 0 < q)
    (hseries : _root_.Erdos68.factorialGapSeries = (a : ℝ) / (q : ℝ))
    (hescape :
      factorialGapScaledTail m ≤
        (m : ℝ) * canonicalRemainder _root_.Erdos68.factorialGapSeries (m - 1)) :
    m ≤ q := by
  by_contra hmq
  have hqpred : q ≤ m - 1 := by omega
  have hzero : canonicalRemainder _root_.Erdos68.factorialGapSeries (m - 1) = 0 :=
    canonicalRemainder_eq_zero_of_eq_rat (q := q) (a := a) hq hqpred hseries
  have htail : 0 < factorialGapScaledTail m := factorialGapScaledTail_pos hm
  rw [hzero, mul_zero] at hescape
  linarith
end ErdosProblems.Erdos68

open scoped BigOperators
open ErdosProblems in
open ErdosProblems.Erdos68 in
theorem solution :
    Irrational _root_.Erdos68.factorialGapSeries ↔
      ∀ B : ℕ, ∃ m : ℕ, B < m ∧
        factorialGapScaledTail m ≤
          (m : ℝ) * canonicalRemainder _root_.Erdos68.factorialGapSeries (m - 1) := by
  constructor
  · intro hirr B
    by_contra hcofinal
    push_neg at hcofinal
    have htrap : ∀ m : ℕ, B < m →
        (m : ℝ) * canonicalRemainder _root_.Erdos68.factorialGapSeries (m - 1) <
          factorialGapScaledTail m := by
      intro m hmB
      exact lt_of_not_ge fun hge => absurd (hcofinal m hmB) (not_lt.2 hge)
    have hunit : ∃ M : ℕ, ∀ m : ℕ, M ≤ m → factorialGapStepCarry m = 1 := by
      refine ⟨max 3 (B + 1), fun m hm => ?_⟩
      have hm3 : 3 ≤ m := le_trans (le_max_left 3 (B + 1)) hm
      have hmB : B < m := by
        have := le_trans (le_max_right 3 (B + 1)) hm
        omega
      exact (factorialGapStepCarry_eq_one_iff_zero_or_maximal_branch hm3).2
        (Or.inl ((factorialGap_zero_branch_iff_lower_endpoint_cylinder hm3).2 (htrap m hmB)))
    exact (not_irrational_factorialGapSeries_of_eventually_unit_carries hunit) hirr
  · intro hescape
    by_contra hrat
    obtain ⟨r, hr⟩ := exists_rat_of_not_irrational hrat
    obtain ⟨m, hmLarge, hmEscape⟩ := hescape (max 2 (r.den + 1))
    have hm2 : 2 ≤ m := by
      have := le_max_left 2 (r.den + 1)
      omega
    have hmq : m ≤ r.den :=
      factorialGap_rational_denominator_ge_of_lower_endpoint_escape
        (m := m) (q := r.den) (a := r.num) hm2 r.den_pos (by rw [hr, Rat.cast_def]) hmEscape
    have := le_max_right 2 (r.den + 1)
    omega
