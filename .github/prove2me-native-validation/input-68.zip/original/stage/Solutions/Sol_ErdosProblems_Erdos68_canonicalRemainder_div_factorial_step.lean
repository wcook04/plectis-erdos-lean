import Definitions.Def_ErdosProblems_Erdos68_CanonicalFactorialDigits
import Mathlib.Algebra.Order.Floor.Ring
import Mathlib.Data.Nat.Factorial.Basic
import Mathlib.Tactic

/-!
# Erdős #68: canonical factorial digits

For the factorial-denominator series

`sum (n >= 2), 1 / (n! - 1)`.

the natural factorial-scale floors give a mixed-radix digit expansion.  This
module develops that expansion for an arbitrary real number: the digits lie
in their canonical ranges, the fractional remainders satisfy the radix
recurrence, and every finite truncation has an explicit remainder term.

The construction is independent of the particular series.  Applied to
Erdős #68, it reduces the digit approach to proving that the canonical
remainder never enters a terminal zero tail.
-/

namespace ErdosProblems.Erdos68
open scoped BigOperators







/-! ## Rational inputs

For a rational number `a / q`, factorial scaling is integral once `q ≤ n`.
Consequently the canonical digit at radix `n + 1` vanishes.  This is a
termination criterion for rational inputs; it does not assert that the Erdős
#68 series is rational or supply recurrence estimates for its partial sums. -/
end ErdosProblems.Erdos68

open scoped BigOperators
open ErdosProblems in
open ErdosProblems.Erdos68 in
theorem solution (x : ℝ) (m : ℕ) :
    canonicalRemainder x m / (m.factorial : ℝ) =
      (canonicalDigit x (m + 1) : ℝ) / ((m + 1).factorial : ℝ) +
        canonicalRemainder x (m + 1) / ((m + 1).factorial : ℝ) := by
  have hfacNat : (m + 1).factorial = (m + 1) * m.factorial :=
    Nat.factorial_succ m
  have hfac :
      ((m + 1).factorial : ℝ) =
        (m + 1 : ℝ) * (m.factorial : ℝ) := by
    exact_mod_cast hfacNat
  unfold canonicalRemainder canonicalDigit facFloor
  rw [Nat.add_sub_cancel]
  push_cast
  rw [hfac]
  field_simp
  ring
