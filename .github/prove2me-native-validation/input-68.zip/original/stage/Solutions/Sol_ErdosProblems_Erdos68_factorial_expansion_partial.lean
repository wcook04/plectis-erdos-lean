import Definitions.Def_ErdosProblems_Erdos68_CanonicalFactorialDigits
import Theorems.Thm_ErdosProblems_Erdos68_canonicalRemainder_div_factorial_step
import Mathlib.Algebra.Order.Floor.Ring
import Mathlib.Data.Nat.Factorial.Basic
import Mathlib.Tactic

/-!
# Erdős #68: canonical factorial digits

For the factorial-denominator series

`sum (n >= 2), 1 / (n! - 1)`.

the natural factorial-scale floors give a mixed-radix digit expansion.  This
module develops that expansion for an arbitrary real number: the digits lie
in their canonical ranges, the fractional remainders satisfy the radix
recurrence, and every finite truncation has an explicit remainder term.

The construction is independent of the particular series.  Applied to
Erdős #68, it reduces the digit approach to proving that the canonical
remainder never enters a terminal zero tail.
-/

namespace ErdosProblems.Erdos68
open scoped BigOperators







/-! ## Rational inputs

For a rational number `a / q`, factorial scaling is integral once `q ≤ n`.
Consequently the canonical digit at radix `n + 1` vanishes.  This is a
termination criterion for rational inputs; it does not assert that the Erdős
#68 series is rational or supply recurrence estimates for its partial sums. -/
end ErdosProblems.Erdos68

open scoped BigOperators
open ErdosProblems in
open ErdosProblems.Erdos68 in
theorem solution (x : ℝ) (N : ℕ) (hN : 1 ≤ N) :
    x =
      (⌊x⌋ : ℝ) +
        ∑ m ∈ Finset.Icc 2 N,
          (canonicalDigit x m : ℝ) / (m.factorial : ℝ) +
      canonicalRemainder x N / (N.factorial : ℝ) := by
  induction N, hN using Nat.le_induction with
  | base =>
      simp [canonicalRemainder, facFloor]
  | succ N hN ih =>
      have hIcc :
          Finset.Icc 2 (N + 1) =
            insert (N + 1) (Finset.Icc 2 N) := by
        ext m
        simp only [Finset.mem_Icc, Finset.mem_insert]
        omega
      calc
        x =
            (⌊x⌋ : ℝ) +
              ∑ m ∈ Finset.Icc 2 N,
                (canonicalDigit x m : ℝ) / (m.factorial : ℝ) +
            canonicalRemainder x N / (N.factorial : ℝ) := ih
        _ =
            (⌊x⌋ : ℝ) +
              ∑ m ∈ Finset.Icc 2 N,
                (canonicalDigit x m : ℝ) / (m.factorial : ℝ) +
            ((canonicalDigit x (N + 1) : ℝ) /
                ((N + 1).factorial : ℝ) +
              canonicalRemainder x (N + 1) /
                ((N + 1).factorial : ℝ)) := by
              rw [canonicalRemainder_div_factorial_step]
        _ =
            (⌊x⌋ : ℝ) +
              ((canonicalDigit x (N + 1) : ℝ) /
                  ((N + 1).factorial : ℝ) +
                ∑ m ∈ Finset.Icc 2 N,
                  (canonicalDigit x m : ℝ) / (m.factorial : ℝ)) +
            canonicalRemainder x (N + 1) /
              ((N + 1).factorial : ℝ) := by ring
        _ =
            (⌊x⌋ : ℝ) +
              ∑ m ∈ Finset.Icc 2 (N + 1),
                (canonicalDigit x m : ℝ) / (m.factorial : ℝ) +
            canonicalRemainder x (N + 1) /
              ((N + 1).factorial : ℝ) := by
              rw [hIcc, Finset.sum_insert (by simp)]
