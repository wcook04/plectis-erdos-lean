import Definitions.Def_ErdosProblems_Erdos68_CanonicalFactorialDigits
import Definitions.Def_ErdosProblems_Erdos68_ChannelBreakpointRigidity
import Definitions.Def_ErdosProblems_Erdos68_ChannelIntegralCongruence
import Definitions.Def_ErdosProblems_Erdos68_PrimeUnitTranslator
import Definitions.Def_ErdosProblems_Erdos68_FactorialGapPlateauCore
import Definitions.Def_ErdosProblems_Erdos68_FactorialChannelCertificate
import Definitions.Def_ErdosProblems_Erdos68_EndpointWeightedPrivateSupport
import Theorems.Thm_ErdosProblems_Erdos68_lcm_div_gcd_right_distrib
import Theorems.Thm_ErdosProblems_Erdos68_finset_lcm_div_gcd_right_distrib
import Theorems.Thm_ErdosProblems_Erdos68_privateQuotients_coprime_of_gcd_dvd_core
import Lean.Elab.Tactic.Omega
import Mathlib.Algebra.BigOperators.Fin
import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Algebra.GCDMonoid.FinsetLemmas
import Mathlib.Algebra.Order.Floor.Ring
import Mathlib.Algebra.Order.Round
import Mathlib.Algebra.Ring.GeomSum
import Mathlib.Analysis.Asymptotics.Defs
import Mathlib.Analysis.Complex.ExponentialBounds
import Mathlib.Analysis.Real.Pi.Bounds
import Mathlib.Analysis.SpecialFunctions.Stirling
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Data.Fin.VecNotation
import Mathlib.Data.Finsupp.Basic
import Mathlib.Data.Int.Basic
import Mathlib.Data.Int.ModEq
import Mathlib.Data.Nat.Choose.Multinomial
import Mathlib.Data.Nat.Factorial.Basic
import Mathlib.Data.Nat.Factorial.BigOperators
import Mathlib.Data.Nat.Factorization.Basic
import Mathlib.Data.Nat.GCD.BigOperators
import Mathlib.Data.Nat.ModEq
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.Nat.Prime.Factorial
import Mathlib.Data.Rat.Lemmas
import Mathlib.LinearAlgebra.Matrix.Adjugate
import Mathlib.LinearAlgebra.Vandermonde
import Mathlib.NumberTheory.Divisors
import Mathlib.NumberTheory.Real.Irrational
import Mathlib.Tactic
import Mathlib.Tactic.FinCases
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.NormNum.NatFactorial
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.InfiniteSum.Basic
import Mathlib.Topology.Algebra.InfiniteSum.Ring

/-!
# Erdős #68: collision cores, private residues, and factorial-block endpoints

For a finite denominator family, the pairwise collision core records the
prime powers shared by at least two denominators.  Dividing each denominator
by its part inside this core produces pairwise-coprime private quotients.
Their product is the private modulus `R`; a weighted leave-one-out numerator
is coprime to `R`, so the displayed endpoint numerator has a nonzero residue
whenever `R > 1`.

The abstract part of the file develops these finite gcd, lcm, CRT, and
projection identities.  The factorial-block specialization takes the
denominators `n! - 1` for `p ≤ n < 2p`, identifies the strict-successor
coefficient at `p - 1`, and defines an endpoint window.  Unit carries on the
whole interval `[p,2p]` force that window; so does any rational value whose
denominator is already cleared by `(p-1)!`.

The later theorems give several exact ways to refute the window: a large
private residue, unequal leave-one-out projections, coprime factor-pair
floors, or a uniquely supported prime with a sufficiently large residue.
Cofinal families of any of the stated certificates imply cofinally many
non-unit carries or rational-prefix divisibility failures, and hence imply
irrationality through the earlier carry criterion.

Every irrationality conclusion in this file is conditional.  No theorem
constructs the required cofinal certificate family, proves the needed
projection disagreement or size inequality for arbitrarily large blocks,
or supplies cofinally many uniquely supported factorial-gap primes.  The
finite CRT identities and endpoint reductions therefore do not by themselves
prove the irrationality of the factorial-gap series or solve Erdős #68.
-/

namespace ErdosProblems.Erdos68
/-! ## Collision cores for finite denominator families -/

































/-- The pairwise collision core of a positive denominator family is
positive, including for the empty family where the finite lcm is `1`. -/
theorem pairwiseCollisionCore_pos
    {ι : Type*} [DecidableEq ι]
    {s : Finset ι} {d : ι → ℕ}
    (hpos : ∀ i ∈ s, 0 < d i) :
    0 < pairwiseCollisionCore s d := by
  apply Nat.pos_of_ne_zero
  apply (Finset.lcm_ne_zero_iff).2
  intro i hi
  apply (Finset.lcm_ne_zero_iff).2
  intro j _
  exact (Nat.gcd_pos_of_pos_left (d j) (hpos i hi)).ne'



/-- Adjoining a positive distinguished base keeps the full collision core
positive. -/
theorem collisionCore_pos
    {ι : Type*} [DecidableEq ι]
    {base : ℕ} {s : Finset ι} {d : ι → ℕ}
    (hbase : 0 < base)
    (hpos : ∀ i ∈ s, 0 < d i) :
    0 < collisionCore base s d := by
  exact Nat.pos_of_ne_zero
    (Nat.lcm_ne_zero hbase.ne' (pairwiseCollisionCore_pos hpos).ne')

/-- Every pairwise collision factor already occurs in the lcm of the
denominator family. -/
theorem pairwiseCollisionCore_dvd_denominatorLcm
    {ι : Type*} [DecidableEq ι]
    {s : Finset ι} {d : ι → ℕ} :
    pairwiseCollisionCore s d ∣ s.lcm d := by
  unfold pairwiseCollisionCore
  apply Finset.lcm_dvd
  intro i hi
  apply Finset.lcm_dvd
  intro j _
  exact (Nat.gcd_dvd_left (d i) (d j)).trans
    (Finset.dvd_lcm hi)

/-- The full collision core divides the common endpoint denominator. -/
theorem collisionCore_dvd_endpointDenominatorLcm
    {ι : Type*} [DecidableEq ι]
    {base : ℕ} {s : Finset ι} {d : ι → ℕ} :
    collisionCore base s d ∣ endpointDenominatorLcm base s d := by
  unfold collisionCore endpointDenominatorLcm
  apply Nat.lcm_dvd
  · exact Nat.dvd_lcm_left base (s.lcm d)
  · exact (pairwiseCollisionCore_dvd_denominatorLcm
      (s := s) (d := d)).trans
        (Nat.dvd_lcm_right base (s.lcm d))

/-- Every off-diagonal pairwise gcd divides the finite pairwise collision
core. -/
theorem gcd_dvd_pairwiseCollisionCore
    {ι : Type*} [DecidableEq ι]
    {s : Finset ι} {d : ι → ℕ}
    {i j : ι}
    (hi : i ∈ s) (hj : j ∈ s) (hij : i ≠ j) :
    Nat.gcd (d i) (d j) ∣ pairwiseCollisionCore s d := by
  have hjErase : j ∈ s.erase i :=
    Finset.mem_erase.mpr ⟨hij.symm, hj⟩
  have hinner :
      Nat.gcd (d i) (d j) ∣
        (s.erase i).lcm fun k => Nat.gcd (d i) (d k) :=
    Finset.dvd_lcm hjErase
  exact hinner.trans (Finset.dvd_lcm hi)





























/-- Every off-diagonal pairwise gcd also divides the full collision core
after adjoining the distinguished base denominator. -/
theorem gcd_dvd_collisionCore
    {ι : Type*} [DecidableEq ι]
    {base : ℕ} {s : Finset ι} {d : ι → ℕ}
    {i j : ι}
    (hi : i ∈ s) (hj : j ∈ s) (hij : i ≠ j) :
    Nat.gcd (d i) (d j) ∣ collisionCore base s d := by
  exact Nat.dvd_lcm_of_dvd_right
    (gcd_dvd_pairwiseCollisionCore hi hj hij) base









/-! ## Private quotients and weighted CRT numerators -/

/-- Removing from every positive denominator the portion visible in the
finite collision core produces a pairwise-coprime family.  This is the
finite-family form of the private-support separation theorem. -/
theorem collisionCore_privateQuotients_pairwise_coprime
    {ι : Type*} [DecidableEq ι]
    {base : ℕ} {s : Finset ι} {d : ι → ℕ}
    (hpos : ∀ i ∈ s, 0 < d i) :
    (s : Set ι).Pairwise fun i j =>
      Nat.Coprime
        (d i / Nat.gcd (d i) (collisionCore base s d))
        (d j / Nat.gcd (d j) (collisionCore base s d)) := by
  intro i hi j hj hij
  apply privateQuotients_coprime_of_gcd_dvd_core
  · exact Nat.gcd_pos_of_pos_left (d j) (hpos i hi)
  · exact gcd_dvd_collisionCore hi hj hij







/-- The private modulus is also the lcm of the private quotients.  Pairwise
coprimality is exactly what converts the lcm into the product. -/
theorem privateQuotient_lcm_eq_privateModulus
    {ι : Type*} [DecidableEq ι]
    {base : ℕ} {s : Finset ι} {d : ι → ℕ}
    (hpos : ∀ i ∈ s, 0 < d i) :
    s.lcm (privateQuotient base s d) =
      privateModulus base s d := by
  unfold privateModulus
  apply Finset.lcm_eq_prod
  simpa [privateQuotient, Function.onFun] using
    (collisionCore_privateQuotients_pairwise_coprime
      (base := base) (s := s) (d := d) hpos)































/-- The canonical private modulus is exactly the denominator-family lcm
after deleting the prime-power support visible in the collision core. -/
theorem privateModulus_eq_lcm_div_gcd_collisionCore
    {ι : Type*} [DecidableEq ι]
    {base : ℕ} {s : Finset ι} {d : ι → ℕ}
    (hbase : 0 < base)
    (hpos : ∀ i ∈ s, 0 < d i) :
    privateModulus base s d =
      s.lcm d /
        Nat.gcd (s.lcm d) (collisionCore base s d) := by
  rw [← privateQuotient_lcm_eq_privateModulus hpos]
  simpa [privateQuotient] using
    (finset_lcm_div_gcd_right_distrib
      (C := collisionCore base s d)
      (collisionCore_pos hbase hpos) hpos)
end ErdosProblems.Erdos68

open ErdosProblems in
open ErdosProblems.Erdos68 in
theorem solution
    {ι : Type*} [DecidableEq ι]
    {base : ℕ} {s : Finset ι} {d : ι → ℕ}
    (hbase : 0 < base)
    (hpos : ∀ i ∈ s, 0 < d i) :
    privateModulus base s d =
      endpointDenominatorLcm base s d /
        collisionCore base s d := by
  have hDPos : 0 < s.lcm d :=
    Nat.pos_of_ne_zero ((Finset.lcm_ne_zero_iff).2
      (fun i hi => (hpos i hi).ne'))
  have hbaseCore :
      base ∣ collisionCore base s d := by
    exact Nat.dvd_lcm_left _ _
  have hcoreEndpoint :
      collisionCore base s d ∣
        endpointDenominatorLcm base s d :=
    collisionCore_dvd_endpointDenominatorLcm
  have hbinary :=
    lcm_div_gcd_right_distrib hbase hDPos
      (collisionCore_pos hbase hpos)
  have hbaseGcd :
      Nat.gcd base (collisionCore base s d) = base :=
    Nat.gcd_eq_left_iff_dvd.mpr hbaseCore
  have hendpointGcd :
      Nat.gcd (endpointDenominatorLcm base s d)
          (collisionCore base s d) =
        collisionCore base s d :=
    Nat.gcd_eq_right_iff_dvd.mpr hcoreEndpoint
  have hbaseDiv :
      base / Nat.gcd base (collisionCore base s d) = 1 := by
    rw [hbaseGcd]
    exact Nat.div_self hbase
  have hendpointGcd' :
      Nat.gcd (Nat.lcm base (s.lcm d))
          (collisionCore base s d) =
        collisionCore base s d := by
    simpa [endpointDenominatorLcm] using hendpointGcd
  rw [privateModulus_eq_lcm_div_gcd_collisionCore hbase hpos]
  rw [hbaseDiv, hendpointGcd'] at hbinary
  simpa [endpointDenominatorLcm] using hbinary
