import Definitions.Def_ErdosProblems_Erdos68_ChannelBreakpointRigidity
import Definitions.Def_ErdosProblems_Erdos68_ChannelIntegralCongruence
import Definitions.Def_ErdosProblems_Erdos68_PaperCompleteAsymptotics
import Theorems.Thm_ErdosProblems_Erdos68_PaperComplete_optimalWindow_lt
import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Algebra.GCDMonoid.FinsetLemmas
import Mathlib.Algebra.Ring.GeomSum
import Mathlib.Analysis.Asymptotics.Defs
import Mathlib.Analysis.Complex.ExponentialBounds
import Mathlib.Analysis.Real.Pi.Bounds
import Mathlib.Analysis.SpecialFunctions.Log.Basic
import Mathlib.Analysis.SpecialFunctions.Sqrt
import Mathlib.Analysis.SpecialFunctions.Stirling
import Mathlib.Data.Nat.Factorial.Basic
import Mathlib.Data.Nat.Factorial.BigOperators
import Mathlib.Data.Nat.ModEq
import Mathlib.Tactic
import Mathlib.Tactic.Ring
import Mathlib.Topology.Order.Basic

/-!
# End-to-end candidate for the two displayed sharp asymptotic constants

Long-record labels res:lcm-growth and res:radius-constant.

`LowerLimitAtLeast f c` is the epsilon/eventual formulation of liminf f >= c:
for every a<c, eventually a<f(n). It is deliberately used instead of a
real-valued `Filter.liminf`, whose default value is not an extended-real
infinity when the sequence diverges to +infinity. This representation places
no unproved upper-boundedness hypothesis on the lcm sequence.

The proof starts from the supplied finite product and Stirling inequalities.
It proves the optimising Nat.sqrt limit, the moving logarithm limit, and the
binomial normalisation, rather than assuming their asymptotic conclusions.

STATUS: compiled proof candidates. These are the largest API/elaboration
risks in the return. There are no admitted analytic facts or proof placeholders.
-/

namespace ErdosProblems.Erdos68.PaperComplete
open Filter
open scoped Topology BigOperators









lemma inv_nat_tendsto_zero :
    Tendsto (fun n : ℕ => (n : ℝ)⁻¹) atTop (𝓝 0) :=
  tendsto_inv_atTop_zero.comp tendsto_natCast_atTop_atTop

lemma inv_sqrt_nat_tendsto_zero :
    Tendsto (fun n : ℕ => (Real.sqrt (n : ℝ))⁻¹) atTop (𝓝 0) :=
  tendsto_inv_atTop_zero.comp (Real.tendsto_sqrt_atTop.comp tendsto_natCast_atTop_atTop)








lemma optimal_window_sandwich {N : ℕ} (hN : 0 < N) :
    Real.sqrt 2 - (Real.sqrt (N : ℝ))⁻¹ ≤
        (optimalWindow N : ℝ) / Real.sqrt (N : ℝ) ∧
    (optimalWindow N : ℝ) / Real.sqrt (N : ℝ) ≤ Real.sqrt 2 := by
  have hs : 0 < Real.sqrt (N : ℝ) := Real.sqrt_pos.mpr (by exact_mod_cast hN)
  have hs2 : 0 ≤ Real.sqrt (2 : ℝ) := Real.sqrt_nonneg _
  have hk0 : (0 : ℝ) ≤ optimalWindow N := by positivity
  have hlo : (optimalWindow N : ℝ) ^ 2 ≤ 2 * (N : ℝ) := by
    exact_mod_cast Nat.sqrt_le' (2 * N)
  have hhi : 2 * (N : ℝ) < ((optimalWindow N : ℝ) + 1) ^ 2 := by
    exact_mod_cast Nat.lt_succ_sqrt' (2 * N)
  have hsprod : (Real.sqrt 2 * Real.sqrt (N : ℝ)) ^ 2 = 2 * (N : ℝ) := by
    rw [mul_pow, Real.sq_sqrt (by norm_num), Real.sq_sqrt (by positivity)]
  have hkn : (optimalWindow N : ℝ) ≤ Real.sqrt 2 * Real.sqrt (N : ℝ) := by
    nlinarith [mul_nonneg hs2 hs.le]
  have hnk : Real.sqrt 2 * Real.sqrt (N : ℝ) < (optimalWindow N : ℝ) + 1 := by
    nlinarith [mul_nonneg hs2 hs.le]
  constructor
  · apply (le_div_iff₀ hs).mpr
    calc
      (Real.sqrt 2 - (Real.sqrt (N : ℝ))⁻¹) * Real.sqrt (N : ℝ)
          = Real.sqrt 2 * Real.sqrt (N : ℝ) - 1 := by
            field_simp [hs.ne']
            all_goals ring
      _ ≤ optimalWindow N := by linarith
  · exact (div_le_iff₀ hs).mpr hkn

lemma optimal_window_ratio_tendsto :
    Tendsto (fun N : ℕ => (optimalWindow N : ℝ) / Real.sqrt (N : ℝ))
      atTop (𝓝 (Real.sqrt 2)) := by
  have hlo : Tendsto (fun N : ℕ => Real.sqrt 2 - (Real.sqrt (N : ℝ))⁻¹)
      atTop (𝓝 (Real.sqrt 2)) := by
    simpa using tendsto_const_nhds.sub inv_sqrt_nat_tendsto_zero
  apply tendsto_of_tendsto_of_tendsto_of_le_of_le' hlo tendsto_const_nhds
  · filter_upwards [eventually_ge_atTop 1] with N hN
    exact (optimal_window_sandwich (by omega)).1
  · filter_upwards [eventually_ge_atTop 1] with N hN
    exact (optimal_window_sandwich (by omega)).2

lemma sqrt_division_identity {x s a : ℝ} (hsq : s ^ 2 = x) :
    a / x = (a / s) * s⁻¹ := by
  rw [← hsq]
  simp only [pow_two, div_eq_mul_inv, mul_inv_rev, mul_assoc]

lemma optimal_window_div_nat_tendsto_zero :
    Tendsto (fun N : ℕ => (optimalWindow N : ℝ) / (N : ℝ)) atTop (𝓝 0) := by
  have h := optimal_window_ratio_tendsto.mul inv_sqrt_nat_tendsto_zero
  have heq : (fun N : ℕ => (optimalWindow N : ℝ) / (N : ℝ)) =ᶠ[atTop]
      (fun N : ℕ => ((optimalWindow N : ℝ) / Real.sqrt (N : ℝ)) *
        (Real.sqrt (N : ℝ))⁻¹) := by
    filter_upwards [eventually_ge_atTop 1] with N hN
    have hs : Real.sqrt (N : ℝ) ≠ 0 :=
      (Real.sqrt_pos.mpr (by exact_mod_cast (show 0 < N by omega))).ne'
    have hsquare := Real.sq_sqrt (show (0 : ℝ) ≤ N by positivity)
    exact sqrt_division_identity hsquare
  have h0 : Tendsto (fun N : ℕ => ((optimalWindow N : ℝ) / Real.sqrt (N : ℝ)) *
      (Real.sqrt (N : ℝ))⁻¹) atTop (𝓝 0) := by simpa using h
  exact h0.congr' heq.symm
end ErdosProblems.Erdos68.PaperComplete

open Filter
open scoped Topology BigOperators
open ErdosProblems in
open ErdosProblems.Erdos68 in
open ErdosProblems.Erdos68.PaperComplete in
theorem solution :
    Tendsto (fun N : ℕ => (blockStart N : ℝ) / (N : ℝ)) atTop (𝓝 1) := by
  have h : Tendsto (fun N : ℕ => 1 + (N : ℝ)⁻¹ - (optimalWindow N : ℝ) / N)
      atTop (𝓝 1) := by
    simpa using (tendsto_const_nhds.add inv_nat_tendsto_zero).sub
      optimal_window_div_nat_tendsto_zero
  apply h.congr'
  filter_upwards [eventually_ge_atTop 3] with N hN
  have hk := optimalWindow_lt hN
  have hcast : (blockStart N : ℝ) = N + 1 - (optimalWindow N : ℝ) := by
    simp only [blockStart, Nat.cast_sub (by omega : optimalWindow N ≤ N + 1), Nat.cast_add,
      Nat.cast_one]
  have hne : (N : ℝ) ≠ 0 := by exact_mod_cast (show N ≠ 0 by omega)
  rw [hcast]
  field_simp [hne]
  all_goals ring
