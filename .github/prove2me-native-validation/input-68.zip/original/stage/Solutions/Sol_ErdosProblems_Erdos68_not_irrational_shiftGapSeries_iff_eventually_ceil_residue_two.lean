import Definitions.Def_ErdosProblems_Erdos68_CanonicalFactorialDigits
import Definitions.Def_ErdosProblems_Erdos68_ChannelBreakpointRigidity
import Definitions.Def_ErdosProblems_Erdos68_ChannelIntegralCongruence
import Definitions.Def_ErdosProblems_Erdos68_PrimeUnitTranslator
import Definitions.Def_ErdosProblems_Erdos68_FactorialGapPlateauCore
import Definitions.Def_ErdosProblems_Erdos68_CompanionConstantBridge
import Definitions.Def_ErdosProblems_Erdos68_ConstantOnlyMissCertificates
import Definitions.Def_ErdosProblems_Erdos68_SecondLayerDigit
import Definitions.Def_ErdosProblems_Erdos68_CompanionOrbitRationality
import Definitions.Def_ErdosProblems_Erdos68_FactorialShiftFamilyOrbit
import Theorems.Thm_ErdosProblems_Erdos68_summable_compConstTerm
import Theorems.Thm_ErdosProblems_Erdos68_summable_unitFactTerm
import Theorems.Thm_ErdosProblems_Erdos68_not_irrational_add_unitFact_iff_eventually_facFloor_mod_neg_two
import Theorems.Thm_ErdosProblems_Erdos68_shiftGapTerm_eq_unitFact_sub_mul
import Mathlib.Algebra.BigOperators.Fin
import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Algebra.GCDMonoid.FinsetLemmas
import Mathlib.Algebra.Order.Floor.Ring
import Mathlib.Algebra.Order.Round
import Mathlib.Algebra.Ring.GeomSum
import Mathlib.Analysis.Asymptotics.Defs
import Mathlib.Analysis.Complex.ExponentialBounds
import Mathlib.Analysis.Real.Pi.Bounds
import Mathlib.Analysis.SpecialFunctions.Stirling
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Data.Fin.VecNotation
import Mathlib.Data.Int.Basic
import Mathlib.Data.Nat.Cast.Field
import Mathlib.Data.Nat.Factorial.Basic
import Mathlib.Data.Nat.Factorial.BigOperators
import Mathlib.Data.Nat.ModEq
import Mathlib.Data.Nat.Multiplicity
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.Rat.Floor
import Mathlib.LinearAlgebra.Matrix.Adjugate
import Mathlib.LinearAlgebra.Vandermonde
import Mathlib.NumberTheory.Real.Irrational
import Mathlib.Tactic
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.FinCases
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.InfiniteSum.Basic
import Mathlib.Topology.Algebra.InfiniteSum.Ring

/-!
# Erdős's shifted-factorial family under one companion-orbit boundary

Erdős asked whether `S_t = ∑_{n≥2} 1/(n!+t)` is irrational for every integer
`t`; Problem #68 is the member `t = −1`.  The termwise identity

`1/(n!+t) = 1/n! − t/(n!(n!+t))`

writes every member as `S_t = (e − 2) − t·C_t` with the shifted companion
constant `C_t = ∑_{n≥2} 1/(n!(n!+t))`.  The generic fixed-orbit boundary of
`CompanionOrbitRationality` therefore applies uniformly: for every integer
`t ≥ −1`,

`S_t ∈ ℚ  ⟺  ⌈t·m!·C_t⌉ ≡ 2 (mod m)  for all sufficiently large m`,

equivalently `S_t ∉ ℚ` iff the ceiling escapes the residue `2` cofinally.
The member `t = −1` recovers `⌊m!·C⌋ ≡ −2 (mod m)`, and the member `t = 0`
has `C_0`-orbit `⌈0⌉ = 0`, which never lies in the residue class `2` for
`m ≥ 3`; this reproves the irrationality of `e`.

No member with `t ≠ 0` is decided here.  The theorem is the exact family
boundary, not an irrationality proof for any nonzero shift.
-/

namespace ErdosProblems.Erdos68
open scoped BigOperators









/-- For `t ≥ −1` and `n ≥ 2` the shifted denominator dominates `n! − 1 ≥ 1`. -/
private theorem factorial_sub_one_le_add_shift {t : ℤ} (ht : -1 ≤ t)
    {n : ℕ} (hn : 2 ≤ n) :
    (1 : ℝ) ≤ (n.factorial : ℝ) - 1 ∧
      (n.factorial : ℝ) - 1 ≤ (n.factorial : ℝ) + (t : ℝ) := by
  have hfac : (2 : ℕ) ≤ n.factorial := by
    calc
      2 = (2 : ℕ).factorial := by norm_num
      _ ≤ n.factorial := Nat.factorial_le hn
  have hfacR : (2 : ℝ) ≤ (n.factorial : ℝ) := by exact_mod_cast hfac
  have htR : (-1 : ℝ) ≤ (t : ℝ) := by exact_mod_cast ht
  constructor <;> linarith





theorem summable_shiftCompanionTerm {t : ℤ} (ht : -1 ≤ t) :
    Summable (shiftCompanionTerm t) := by
  refine Summable.of_nonneg_of_le (fun n => ?_) (fun n => ?_)
    summable_compConstTerm
  · by_cases hn : 2 ≤ n
    · rw [shiftCompanionTerm, if_pos hn]
      obtain ⟨h1, h2⟩ := factorial_sub_one_le_add_shift ht hn
      exact one_div_nonneg.mpr (mul_nonneg (by positivity) (by linarith))
    · simp [shiftCompanionTerm, hn]
  · by_cases hn : 2 ≤ n
    · rw [shiftCompanionTerm, if_pos hn, compConstTerm, if_pos hn]
      obtain ⟨h1, h2⟩ := factorial_sub_one_le_add_shift ht hn
      push_cast
      apply one_div_le_one_div_of_le
      · exact mul_pos (by positivity) (by linarith)
      · exact mul_le_mul_of_nonneg_left h2 (by positivity)
    · simp [shiftCompanionTerm, compConstTerm, hn]

/-- **Family decomposition.**  `S_t = (−t·C_t) + (e − 2)` in the anchored
form used by the generic companion-orbit boundary. -/
theorem shiftGapSeries_eq_neg_mul_companion_add_unitFact {t : ℤ} (ht : -1 ≤ t) :
    shiftGapSeries t =
      (-(t : ℝ) * shiftCompanionConstant t) + ∑' n : ℕ, unitFactTerm n := by
  unfold shiftGapSeries shiftCompanionConstant
  have hterm : shiftGapTerm t = fun n =>
      unitFactTerm n - (t : ℝ) * shiftCompanionTerm t n := by
    funext n
    exact shiftGapTerm_eq_unitFact_sub_mul ht n
  rw [hterm, summable_unitFactTerm.tsum_sub
    ((summable_shiftCompanionTerm ht).mul_left (t : ℝ)), tsum_mul_left]
  ring

/-- Pointwise translation between the floor residue of the generic boundary
and the ceiling residue of the shifted orbit. -/
theorem facFloor_neg_mul_add_two_emod_eq_zero_iff (t : ℤ) (K : ℝ) (m : ℕ) :
    ((facFloor (-(t : ℝ) * K) m + 2 : ℤ) % (m : ℤ)) = 0 ↔
      (m : ℤ) ∣ ⌈(t : ℝ) * (m.factorial : ℝ) * K⌉ - 2 := by
  have hrewrite : (m.factorial : ℝ) * (-(t : ℝ) * K) =
      -((t : ℝ) * (m.factorial : ℝ) * K) := by ring
  unfold facFloor
  rw [hrewrite, Int.floor_neg, ← Int.dvd_iff_emod_eq_zero]
  have hneg : -⌈(t : ℝ) * (m.factorial : ℝ) * K⌉ + 2 =
      -(⌈(t : ℝ) * (m.factorial : ℝ) * K⌉ - 2) := by ring
  rw [hneg, dvd_neg]
end ErdosProblems.Erdos68

open scoped BigOperators
open ErdosProblems in
open ErdosProblems.Erdos68 in
theorem solution
    {t : ℤ} (ht : -1 ≤ t) :
    ¬ Irrational (shiftGapSeries t) ↔
      ∃ M : ℕ, ∀ m : ℕ, M ≤ m →
        (m : ℤ) ∣ ⌈(t : ℝ) * (m.factorial : ℝ) * shiftCompanionConstant t⌉ - 2 := by
  rw [shiftGapSeries_eq_neg_mul_companion_add_unitFact ht,
    not_irrational_add_unitFact_iff_eventually_facFloor_mod_neg_two]
  constructor
  · rintro ⟨M, hM⟩
    exact ⟨M, fun m hm =>
      (facFloor_neg_mul_add_two_emod_eq_zero_iff t _ m).mp (hM m hm)⟩
  · rintro ⟨M, hM⟩
    exact ⟨M, fun m hm =>
      (facFloor_neg_mul_add_two_emod_eq_zero_iff t _ m).mpr (hM m hm)⟩
