import Definitions.Def_ErdosProblems_Erdos68_ChannelBreakpointRigidity
import Definitions.Def_ErdosProblems_Erdos68_ChannelIntegralCongruence
import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Algebra.GCDMonoid.FinsetLemmas
import Mathlib.Algebra.Ring.GeomSum
import Mathlib.Analysis.Asymptotics.Defs
import Mathlib.Analysis.Complex.ExponentialBounds
import Mathlib.Analysis.Real.Pi.Bounds
import Mathlib.Analysis.SpecialFunctions.Stirling
import Mathlib.Data.Nat.Factorial.Basic
import Mathlib.Data.Nat.Factorial.BigOperators
import Mathlib.Data.Nat.ModEq
import Mathlib.Tactic.Ring

/-!
# Integral channel congruence for Erdős problem 68

This module compares a channel numerator with the corresponding factorial
moment modulo `d! - 1`.  The congruence holds for every support index, so
simultaneous cancellation of the channels `2, ..., D` makes their least common
multiple divide the factorial moment.

The second part estimates that least common multiple.  Consecutive numbers
`m! - 1` are compared through their pairwise gcds; this gives an explicit
finite lower bound after the gcd losses are counted.  Consequently, if a
positive integer `M` is divisible by the channel lcm and is smaller than
`(R+1)! - 1`, then `R` must grow at least cubically along `D = 2t^2`.  A later
estimate improves the explicit constant to `R+1 > (3/2)t^3` for `t >= 2^32`.

All conclusions after the congruence theorem retain these stated hypotheses.
In particular, this file does not construct `M` or `R` from the series in
Erdős problem 68, prove that its channels vanish, or decide the rationality of
that series.
-/

namespace Erdos68
/-! ## Product versus lcm with explicit gcd loss -/











/-! ## Factorial-gap collision bounds -/







/-! ## Consecutive factorial-gap segments -/
end Erdos68

open Erdos68 in
theorem solution
    {n : ℕ} (hn : 2 ≤ n) :
    (n : ℝ) * Real.log (n : ℝ) - n - Real.log 2 ≤
      Real.log ((n.factorial - 1 : ℕ) : ℝ) := by
  have hfac2 : 2 ≤ n.factorial :=
    (Nat.factorial_le hn).trans' (by norm_num)
  have hfacPos : (0 : ℝ) < n.factorial := by positivity
  have hgapPos : (0 : ℝ) < (n.factorial - 1 : ℕ) := by
    exact_mod_cast (Nat.sub_pos_of_lt (by omega : 1 < n.factorial))
  have hhalfNat : n.factorial ≤ 2 * (n.factorial - 1) := by omega
  have hhalf :
      (n.factorial : ℝ) / 2 ≤ (n.factorial - 1 : ℕ) := by
    apply (div_le_iff₀ (by norm_num)).2
    exact_mod_cast (by simpa [Nat.mul_comm] using hhalfNat)
  have hlogHalf :
      Real.log ((n.factorial : ℝ) / 2) ≤
        Real.log ((n.factorial - 1 : ℕ) : ℝ) :=
    Real.log_le_log (by positivity) hhalf
  have hstirling := Stirling.le_log_factorial_stirling (n := n) (by omega)
  have hlogn : 0 ≤ Real.log (n : ℝ) :=
    Real.log_nonneg (by exact_mod_cast (show 1 ≤ n by omega))
  have hlogpi : 0 ≤ Real.log (2 * Real.pi) := by
    apply Real.log_nonneg
    nlinarith [Real.pi_gt_three]
  rw [Real.log_div (by positivity) (by norm_num)] at hlogHalf
  nlinarith
