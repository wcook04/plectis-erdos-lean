import Definitions.Def_ErdosProblems_Erdos68_CanonicalFactorialDigits
import Definitions.Def_ErdosProblems_Erdos68_ChannelBreakpointRigidity
import Definitions.Def_ErdosProblems_Erdos68_ChannelIntegralCongruence
import Definitions.Def_ErdosProblems_Erdos68_PrimeUnitTranslator
import Definitions.Def_ErdosProblems_Erdos68_FactorialGapPlateauCore
import Definitions.Def_ErdosProblems_Erdos68_FactorialChannelCertificate
import Definitions.Def_ErdosProblems_Erdos68_EndpointWeightedPrivateSupport
import Definitions.Def_ErdosProblems_Erdos68_PrimeZeroBranch
import Theorems.Thm_ErdosProblems_Erdos68_irrational_factorialGapSeries_iff_cofinal_lower_endpoint_escape
import Theorems.Thm_ErdosProblems_Erdos68_lower_endpoint_escape_of_predecessorGap_outside_window
import Lean.Elab.Tactic.Omega
import Mathlib.Algebra.BigOperators.Fin
import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Algebra.GCDMonoid.FinsetLemmas
import Mathlib.Algebra.Order.Floor.Ring
import Mathlib.Algebra.Order.Round
import Mathlib.Algebra.Ring.GeomSum
import Mathlib.Analysis.Asymptotics.Defs
import Mathlib.Analysis.Complex.ExponentialBounds
import Mathlib.Analysis.Real.Pi.Bounds
import Mathlib.Analysis.SpecialFunctions.Stirling
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Data.Fin.VecNotation
import Mathlib.Data.Finsupp.Basic
import Mathlib.Data.Int.Basic
import Mathlib.Data.Int.ModEq
import Mathlib.Data.Nat.Choose.Multinomial
import Mathlib.Data.Nat.Factorial.Basic
import Mathlib.Data.Nat.Factorial.BigOperators
import Mathlib.Data.Nat.Factorization.Basic
import Mathlib.Data.Nat.GCD.BigOperators
import Mathlib.Data.Nat.ModEq
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.Nat.Prime.Factorial
import Mathlib.Data.Nat.Prime.Infinite
import Mathlib.Data.Rat.Lemmas
import Mathlib.Data.ZMod.Factorial
import Mathlib.LinearAlgebra.Matrix.Adjugate
import Mathlib.LinearAlgebra.Vandermonde
import Mathlib.NumberTheory.Divisors
import Mathlib.NumberTheory.Real.Irrational
import Mathlib.NumberTheory.Wilson
import Mathlib.Tactic
import Mathlib.Tactic.FinCases
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.NormNum.NatFactorial
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.InfiniteSum.Basic
import Mathlib.Topology.Algebra.InfiniteSum.Ring

/-!
# Erdős #68: the shrinking-target normal form

The corpus already carries two exact normal forms for the irrationality of
`S = ∑ 1/(n! - 1)`: cofinal non-unit carries, and cofinal misses of the
strict-successor divisibility.  Both treat *every* unit carry as a failure.

A unit carry has two radically different causes: the canonical orbit sits in
the tiny lower endpoint cylinder, or the canonical digit is maximal.  The
second is harmless.  This module isolates that distinction and produces a
**third** exact normal form:

`S ∉ ℚ  ↔  ∀ B, ∃ m > B, factorialGapScaledTail m ≤ m · r_{m-1}`

(`irrational_factorialGapSeries_iff_cofinal_lower_endpoint_escape`), i.e.
irrationality is exactly *cofinal escape from the lower endpoint cylinder*.
Since `0 < factorialGapScaledTail m < 2/m`, the trapping radius is
`O(m⁻²)`: Erdős #68 is an explicit deterministic shrinking-target problem
for the factorial orbit, with a quadratically small target.

The escape target is strictly more permissive than the carry target
(`factorialGap_lower_endpoint_escape_iff_nonunit_or_maximal_digit`), and it
admits a completely **tail-free two-sided** consumer over the finite
predecessor gap (`irrational_factorialGapSeries_of_cofinal_predecessorGap_outside_window`).
The corpus previously exposed only the upper half of that window.

Erdős #68 remains open: no theorem here produces the cofinal escape events.
-/

namespace ErdosProblems.Erdos68
open scoped BigOperators
end ErdosProblems.Erdos68

open scoped BigOperators
open ErdosProblems in
open ErdosProblems.Erdos68 in
theorem solution
    (hout : ∀ B : ℕ, ∃ m : ℕ, 3 ≤ m ∧ B < m ∧
      ((m : ℝ) * factorialGapPredecessorGap m ≤ 1 + 1 / ((m.factorial : ℝ) - 1) ∨
        1 + 1 / ((m.factorial : ℝ) - 1) + 2 / (m : ℝ) ≤
          (m : ℝ) * factorialGapPredecessorGap m)) :
    Irrational _root_.Erdos68.factorialGapSeries := by
  rw [irrational_factorialGapSeries_iff_cofinal_lower_endpoint_escape]
  intro B
  obtain ⟨m, hm3, hmB, hmWindow⟩ := hout B
  exact ⟨m, hmB, lower_endpoint_escape_of_predecessorGap_outside_window hm3 hmWindow⟩
