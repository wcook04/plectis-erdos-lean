import Definitions.Def_ErdosProblems_Erdos68_ChannelBreakpointRigidity
import Definitions.Def_ErdosProblems_Erdos68_ChannelIntegralCongruence
import Definitions.Def_ErdosProblems_Erdos68_PrimeUnitTranslator
import Mathlib.Algebra.BigOperators.Fin
import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Algebra.GCDMonoid.FinsetLemmas
import Mathlib.Algebra.Order.Round
import Mathlib.Algebra.Ring.GeomSum
import Mathlib.Analysis.Asymptotics.Defs
import Mathlib.Analysis.Complex.ExponentialBounds
import Mathlib.Analysis.Real.Pi.Bounds
import Mathlib.Analysis.SpecialFunctions.Stirling
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Data.Fin.VecNotation
import Mathlib.Data.Nat.Factorial.Basic
import Mathlib.Data.Nat.Factorial.BigOperators
import Mathlib.Data.Nat.ModEq
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.LinearAlgebra.Matrix.Adjugate
import Mathlib.LinearAlgebra.Vandermonde
import Mathlib.Tactic.FinCases
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.InfiniteSum.Basic
import Mathlib.Topology.Algebra.InfiniteSum.Ring

/-!
# Prime unit translator for Erdős problem 68

For a prime `p`, the coefficient pair `(p,-1)` on the indices `(p-1,p)` has
zero factorial moment and annihilates every channel except the `p`-channel.
At that channel its numerator is exactly `p!-1`; consequently its normalized
infinite residual is `1`.  Appending an integer multiple of this pair therefore
translates any finite-support residual by the same integer without changing
the lower channels or the factorial moment.

The module also classifies every finite-support residual modulo integers as
its factorial moment times the factorial-gap tail.  A Cramer construction on
an explicit factorial grid supplies, beyond any prescribed support threshold,
integer coefficient vectors with zero channels through a chosen cutoff and
nonzero factorial moment.  Appending a prime translator reduces their
residual to absolute value at most `1/2`.

The last reduction is not an irrationality argument by itself: the reduced
residual may be zero.  The strict version assumes that the original residual
is not an integer, and no theorem here proves that assumption for the Cramer
vectors.  There is also no coefficient-size estimate, no nonzero lower bound
for the reduced residual, and no irrationality theorem for the factorial-gap
series.
-/

open Erdos68 in
theorem solution (D : ℕ) :
    factorialGapTail D =
      ∑' k : ℕ,
        (1 : ℝ) /
          ((((D + 1 + k).factorial : ℤ) - 1 : ℤ) : ℝ) := by
  let e : ℕ ≃ {d : ℕ // D < d} :=
    { toFun := fun k => ⟨D + 1 + k, by omega⟩
      invFun := fun d => d.1 - (D + 1)
      left_inv := by
        intro k
        exact Nat.add_sub_cancel_left (D + 1) k
      right_inv := by
        intro d
        apply Subtype.ext
        exact Nat.add_sub_of_le (by omega) }
  calc
    factorialGapTail D =
        ∑' d : ℕ,
          Set.indicator {d : ℕ | D < d}
            (fun d : ℕ =>
              (1 : ℝ) /
                (((d.factorial : ℤ) - 1 : ℤ) : ℝ)) d := by
      unfold factorialGapTail
      apply tsum_congr
      intro d
      by_cases hd : D < d <;>
        simp [factorialGapTailTerm, Set.indicator, hd]
    _ = ∑' d : {d : ℕ // D < d},
          (1 : ℝ) /
            (((d.1.factorial : ℤ) - 1 : ℤ) : ℝ) := by
      simpa using
        (tsum_subtype {d : ℕ | D < d}
          (fun d : ℕ =>
            (1 : ℝ) /
              (((d.factorial : ℤ) - 1 : ℤ) : ℝ))).symm
    _ = ∑' k : ℕ,
          (1 : ℝ) /
            ((((D + 1 + k).factorial : ℤ) - 1 : ℤ) : ℝ) := by
      simpa [e] using
        (e.tsum_eq (fun d : {d : ℕ // D < d} =>
          (1 : ℝ) /
            (((d.1.factorial : ℤ) - 1 : ℤ) : ℝ))).symm
