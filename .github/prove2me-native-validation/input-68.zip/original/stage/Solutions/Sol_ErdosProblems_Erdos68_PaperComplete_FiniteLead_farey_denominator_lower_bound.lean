import Definitions.Def_ErdosProblems_Erdos68_ChannelBreakpointRigidity
import Definitions.Def_ErdosProblems_Erdos68_ChannelIntegralCongruence
import Definitions.Def_ErdosProblems_Erdos68_PrimeUnitTranslator
import Definitions.Def_ErdosProblems_Erdos68_PaperCompleteDyadicEnclosure
import Definitions.Def_ErdosProblems_Erdos68_PaperCompleteFiniteLeadArithmetic
import Mathlib.Algebra.BigOperators.Fin
import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Algebra.GCDMonoid.FinsetLemmas
import Mathlib.Algebra.Order.BigOperators.Group.Finset
import Mathlib.Algebra.Order.Field.Basic
import Mathlib.Algebra.Order.Round
import Mathlib.Algebra.Ring.GeomSum
import Mathlib.Analysis.Asymptotics.Defs
import Mathlib.Analysis.Complex.ExponentialBounds
import Mathlib.Analysis.Real.Pi.Bounds
import Mathlib.Analysis.SpecialFunctions.Stirling
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Data.Fin.VecNotation
import Mathlib.Data.Nat.Factorial.Basic
import Mathlib.Data.Nat.Factorial.BigOperators
import Mathlib.Data.Nat.ModEq
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.LinearAlgebra.Matrix.Adjugate
import Mathlib.LinearAlgebra.Vandermonde
import Mathlib.Tactic
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.FinCases
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.InfiniteSum.Basic
import Mathlib.Topology.Algebra.InfiniteSum.Ring

/-!
# Round 8: sound finite arithmetic consumers

The Farey certificate replaces a long continued-fraction proof trace by two
bounding fractions with determinant one. Continued fractions are used only
by the producer to find these fractions; soundness does not depend on that
algorithm, on a quotient count, or on reducedness of the input `a/q`.
The factorial-grid certificate excludes one integer grid directly, without
requiring the historical full carry census.

All validity predicates are decidable finite integer arithmetic. This file
proves their consequences, but does not assert validity of the large data.
Status: proof text, not elaborated in the return environment.
-/

open ErdosProblems in
open ErdosProblems.Erdos68 in
open ErdosProblems.Erdos68.PaperComplete in
open ErdosProblems.Erdos68.PaperComplete.FiniteLead in
theorem solution
    (A B C E : ℕ) (hB : 0 < B) (hE : 0 < E)
    (hdet : B * C = A * E + 1)
    (a : ℤ) (q : ℕ) (hq : 0 < q)
    (hleft : (A : ℝ) / B < (a : ℝ) / q)
    (hright : (a : ℝ) / q < (C : ℝ) / E) : B + E ≤ q := by
  have hBR : (0 : ℝ) < B := by exact_mod_cast hB
  have hER : (0 : ℝ) < E := by exact_mod_cast hE
  have hqR : (0 : ℝ) < q := by exact_mod_cast hq
  -- Mathlib/Algebra/Order/GroupWithZero/Unbundled/Basic.lean,
  -- exposed by Mathlib/Algebra/Order/Field/Basic.lean.
  have hcrossL : (A : ℝ) * q < (a : ℝ) * B :=
    (div_lt_div_iff₀ hBR hqR).mp hleft
  have hcrossR : (a : ℝ) * E < (C : ℝ) * q :=
    (div_lt_div_iff₀ hqR hER).mp hright
  let u : ℤ := a * (B : ℤ) - (A : ℤ) * q
  let v : ℤ := (C : ℤ) * q - a * E
  have huR : (0 : ℝ) < (u : ℝ) := by
    dsimp [u]
    push_cast
    linarith only [hcrossL]
  have hvR : (0 : ℝ) < (v : ℝ) := by
    dsimp [v]
    push_cast
    linarith only [hcrossR]
  have huZ : (0 : ℤ) < u := by exact_mod_cast huR
  have hvZ : (0 : ℤ) < v := by exact_mod_cast hvR
  have hu : (1 : ℤ) ≤ u := by omega
  have hv : (1 : ℤ) ≤ v := by omega
  have hdetZ : (B : ℤ) * C = (A : ℤ) * E + 1 := by
    exact_mod_cast hdet
  have hdetq : ((B : ℤ) * C) * (q : ℤ) =
      ((A : ℤ) * E + 1) * (q : ℤ) :=
    congrArg (fun z : ℤ => z * (q : ℤ)) hdetZ
  have hid : (q : ℤ) = (E : ℤ) * u + (B : ℤ) * v := by
    dsimp [u, v]
    nlinarith only [hdetq]
  have hB0 : (0 : ℤ) ≤ B := by positivity
  have hE0 : (0 : ℤ) ≤ E := by positivity
  have hEu : (E : ℤ) * 1 ≤ (E : ℤ) * u :=
    mul_le_mul_of_nonneg_left hu hE0
  have hBv : (B : ℤ) * 1 ≤ (B : ℤ) * v :=
    mul_le_mul_of_nonneg_left hv hB0
  have hboundZ : (B : ℤ) + (E : ℤ) ≤ (q : ℤ) := by
    linarith only [hid, hEu, hBv]
  exact_mod_cast hboundZ
