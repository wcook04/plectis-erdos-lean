import Definitions.Def_ErdosProblems_Erdos68_ChannelBreakpointRigidity
import Definitions.Def_ErdosProblems_Erdos68_ChannelIntegralCongruence
import Definitions.Def_ErdosProblems_Erdos68_PrimeUnitTranslator
import Definitions.Def_ErdosProblems_Erdos68_FactorialChannelCertificate
import Definitions.Def_ErdosProblems_Erdos68_DivisorChannelBasis
import Definitions.Def_ErdosProblems_Erdos68_PaperCompleteDivisorCoordinates
import Definitions.Def_ErdosProblems_Erdos68_PaperCompleteIntegerSpan
import Definitions.Def_ErdosProblems_Erdos68_PaperCompleteLowKernel
import Definitions.Def_ErdosProblems_Erdos68_PaperCompleteResidualIdentity
import Theorems.Thm_Erdos68_summable_factorialGapTailTerm
import Theorems.Thm_ErdosProblems_Erdos68_PaperComplete_integerEvaluation_add
import Theorems.Thm_ErdosProblems_Erdos68_PaperComplete_integerEvaluation_single
import Theorems.Thm_ErdosProblems_Erdos68_PaperComplete_integerEvaluation_smul
import Theorems.Thm_ErdosProblems_Erdos68_PaperComplete_channelSynthesis_sub
import Theorems.Thm_ErdosProblems_Erdos68_PaperComplete_channelSynthesis_single
import Theorems.Thm_ErdosProblems_Erdos68_PaperComplete_canonicalKernel_expansion
import Theorems.Thm_ErdosProblems_Erdos68_PaperComplete_residual_term_low_kernel
import Lean.Elab.Tactic.Omega
import Mathlib.Algebra.BigOperators.Fin
import Mathlib.Algebra.BigOperators.Finsupp.Basic
import Mathlib.Algebra.BigOperators.GroupWithZero.Action
import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Algebra.GCDMonoid.FinsetLemmas
import Mathlib.Algebra.Order.Round
import Mathlib.Algebra.Ring.GeomSum
import Mathlib.Analysis.Asymptotics.Defs
import Mathlib.Analysis.Complex.ExponentialBounds
import Mathlib.Analysis.Real.Pi.Bounds
import Mathlib.Analysis.SpecialFunctions.Stirling
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Data.Fin.VecNotation
import Mathlib.Data.Finsupp.Basic
import Mathlib.Data.Finsupp.SMul
import Mathlib.Data.Int.GCD
import Mathlib.Data.Int.ModEq
import Mathlib.Data.Nat.Choose.Multinomial
import Mathlib.Data.Nat.Factorial.Basic
import Mathlib.Data.Nat.Factorial.BigOperators
import Mathlib.Data.Nat.GCD.Prime
import Mathlib.Data.Nat.ModEq
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.Rat.Lemmas
import Mathlib.LinearAlgebra.Matrix.Adjugate
import Mathlib.LinearAlgebra.Vandermonde
import Mathlib.NumberTheory.Divisors
import Mathlib.RingTheory.Coprime.Lemmas
import Mathlib.Tactic.Abel
import Mathlib.Tactic.FinCases
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.NormNum.NatFactorial
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.InfiniteSum.Basic
import Mathlib.Topology.Algebra.InfiniteSum.Ring

   
                                                                           
                                                                      
                                             
  

namespace ErdosProblems.Erdos68.PaperComplete
open scoped BigOperators
open Finsupp









lemma tailCoordinateTerm_outside (z : ℕ →₀ ℤ) (d : ℕ)
    (hd : d ∉ z.support.image (fun j => j + 1)) : tailCoordinateTerm z d = 0 := by
  classical
  by_cases h : 1 < d
  · have hz : z (d - 1) = 0 := by
      by_contra hn
      apply hd
      exact Finset.mem_image.mpr ⟨d - 1, Finsupp.mem_support_iff.mpr hn, by omega⟩
    simp [tailCoordinateTerm, h, hz]
  · simp [tailCoordinateTerm, h]

lemma summable_tailCoordinateTerm (z : ℕ →₀ ℤ) : Summable (tailCoordinateTerm z) := by
  classical
  apply summable_of_ne_finset_zero (s := z.support.image (fun j => j + 1))
  exact tailCoordinateTerm_outside z

lemma tsum_tailCoordinateTerm {D : ℕ} (hD : 1 ≤ D)
    {z : ℕ →₀ ℤ} (hz : TailCoordinates D z) :
    (∑' d : ℕ, tailCoordinateTerm z d) = (coordinateMass z : ℝ) := by
  classical
  rw [tsum_eq_sum (s := z.support.image (fun j => j + 1))]
  · rw [Finset.sum_image]
    · have he : (∑ j ∈ z.support, tailCoordinateTerm z (j + 1)) =
          ∑ j ∈ z.support, (z j : ℝ) := by
        apply Finset.sum_congr rfl
        intro j hj
        have hjp : 0 < j := by
          by_contra h
          have hj0 : j = 0 := by omega
          subst j
          exact (Finsupp.mem_support_iff.mp hj) (hz 0 (by omega))
        simp [tailCoordinateTerm, show 1 < j + 1 by omega]
      rw [he]
      simp [coordinateMass, integerEvaluation, Finsupp.sum]
    · intro i hi j hj he
      dsimp only at he
      omega
  · exact tailCoordinateTerm_outside z





/-- Exact residual, including the integral translate and actual infinite tail. -/
theorem fullResidual_low_kernel {D : ℕ} (hD : 1 ≤ D) (t : ℤ)
    {z : ℕ →₀ ℤ} (hz : TailCoordinates D z) :
    fullResidual (t • canonicalKernel D + channelSynthesis z) =
      (t : ℝ) * (channelLCM D : ℝ) * _root_.Erdos68.factorialGapTail D +
        (coordinateMass z : ℝ) := by
  unfold fullResidual
  simp_rw [residual_term_low_kernel hD t hz]
  rw [((_root_.Erdos68.summable_factorialGapTailTerm D).mul_left
    ((t : ℝ) * (channelLCM D : ℝ))).tsum_add (summable_tailCoordinateTerm z)]
  rw [(_root_.Erdos68.summable_factorialGapTailTerm D).tsum_mul_left,
    tsum_tailCoordinateTerm hD hz]
  rfl





lemma canonicalKernel_one : canonicalKernel 1 = single 1 1 := by
  rw [canonicalKernel_expansion]
  norm_num [channelLCM]

lemma coordinateMass_sub (a b : ℕ →₀ ℤ) :
    coordinateMass (a - b) = coordinateMass a - coordinateMass b := by
  have hn : integerEvaluation (fun _ => 1) (-b) =
      -integerEvaluation (fun _ => 1) b := by
    simpa using integerEvaluation_smul (fun _ => 1) (-1) b
  unfold coordinateMass
  rw [sub_eq_add_neg, integerEvaluation_add, hn, sub_eq_add_neg]
end ErdosProblems.Erdos68.PaperComplete

open scoped BigOperators
open Finsupp
open ErdosProblems in
open ErdosProblems.Erdos68 in
open ErdosProblems.Erdos68.PaperComplete in
theorem solution (a : ℕ →₀ ℤ) :
    fullResidual (channelSynthesis a) =
      (a 0 : ℝ) * _root_.Erdos68.factorialGapSeries +
      ((coordinateMass a - a 0 : ℤ) : ℝ) := by
  let z := a - single 0 (a 0)
  have hz : TailCoordinates 1 z := by
    intro j hj
    have : j = 0 := by omega
    subst j
    simp [z]
  have he : a 0 • canonicalKernel 1 + channelSynthesis z = channelSynthesis a := by
    dsimp [z]
    rw [canonicalKernel_one, channelSynthesis_sub, channelSynthesis_single]
    simp only [channelBasisColumn, if_pos rfl]
    simp [sub_eq_add_neg, add_comm, add_left_comm, add_assoc]
  have hr := fullResidual_low_kernel (D := 1) (by decide) (a 0) hz
  rw [he] at hr
  have hmass : coordinateMass z = coordinateMass a - a 0 := by
    dsimp [z]
    rw [coordinateMass_sub]
    simp [coordinateMass, integerEvaluation_single]
  simpa [channelLCM, _root_.Erdos68.factorialGapSeries, hmass] using hr
