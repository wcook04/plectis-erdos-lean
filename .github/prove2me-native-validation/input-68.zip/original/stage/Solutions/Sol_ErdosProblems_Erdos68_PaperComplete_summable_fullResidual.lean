import Definitions.Def_ErdosProblems_Erdos68_ChannelBreakpointRigidity
import Definitions.Def_ErdosProblems_Erdos68_ChannelIntegralCongruence
import Definitions.Def_ErdosProblems_Erdos68_PrimeUnitTranslator
import Definitions.Def_ErdosProblems_Erdos68_FactorialChannelCertificate
import Definitions.Def_ErdosProblems_Erdos68_DivisorChannelBasis
import Definitions.Def_ErdosProblems_Erdos68_PaperCompleteDivisorCoordinates
import Definitions.Def_ErdosProblems_Erdos68_PaperCompleteIntegerSpan
import Definitions.Def_ErdosProblems_Erdos68_PaperCompleteLowKernel
import Definitions.Def_ErdosProblems_Erdos68_PaperCompleteResidualIdentity
import Theorems.Thm_Erdos68_summable_factorialGapTailTerm
import Theorems.Thm_ErdosProblems_Erdos68_PaperComplete_channelSynthesis_sub
import Theorems.Thm_ErdosProblems_Erdos68_PaperComplete_channelSynthesis_single
import Theorems.Thm_ErdosProblems_Erdos68_PaperComplete_existsUnique_channel_coordinates
import Theorems.Thm_ErdosProblems_Erdos68_PaperComplete_canonicalKernel_expansion
import Theorems.Thm_ErdosProblems_Erdos68_PaperComplete_residual_term_low_kernel
import Lean.Elab.Tactic.Omega
import Mathlib.Algebra.BigOperators.Fin
import Mathlib.Algebra.BigOperators.Finsupp.Basic
import Mathlib.Algebra.BigOperators.GroupWithZero.Action
import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Algebra.GCDMonoid.FinsetLemmas
import Mathlib.Algebra.Order.Round
import Mathlib.Algebra.Ring.GeomSum
import Mathlib.Analysis.Asymptotics.Defs
import Mathlib.Analysis.Complex.ExponentialBounds
import Mathlib.Analysis.Real.Pi.Bounds
import Mathlib.Analysis.SpecialFunctions.Stirling
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Data.Fin.VecNotation
import Mathlib.Data.Finsupp.Basic
import Mathlib.Data.Finsupp.SMul
import Mathlib.Data.Int.GCD
import Mathlib.Data.Int.ModEq
import Mathlib.Data.Nat.Choose.Multinomial
import Mathlib.Data.Nat.Factorial.Basic
import Mathlib.Data.Nat.Factorial.BigOperators
import Mathlib.Data.Nat.GCD.Prime
import Mathlib.Data.Nat.ModEq
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.Rat.Lemmas
import Mathlib.LinearAlgebra.Matrix.Adjugate
import Mathlib.LinearAlgebra.Vandermonde
import Mathlib.NumberTheory.Divisors
import Mathlib.RingTheory.Coprime.Lemmas
import Mathlib.Tactic.Abel
import Mathlib.Tactic.FinCases
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.NormNum.NatFactorial
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.InfiniteSum.Basic
import Mathlib.Topology.Algebra.InfiniteSum.Ring

   
                                                                           
                                                                      
                                             
  

namespace ErdosProblems.Erdos68.PaperComplete
open scoped BigOperators
open Finsupp









lemma tailCoordinateTerm_outside (z : ℕ →₀ ℤ) (d : ℕ)
    (hd : d ∉ z.support.image (fun j => j + 1)) : tailCoordinateTerm z d = 0 := by
  classical
  by_cases h : 1 < d
  · have hz : z (d - 1) = 0 := by
      by_contra hn
      apply hd
      exact Finset.mem_image.mpr ⟨d - 1, Finsupp.mem_support_iff.mpr hn, by omega⟩
    simp [tailCoordinateTerm, h, hz]
  · simp [tailCoordinateTerm, h]

lemma summable_tailCoordinateTerm (z : ℕ →₀ ℤ) : Summable (tailCoordinateTerm z) := by
  classical
  apply summable_of_ne_finset_zero (s := z.support.image (fun j => j + 1))
  exact tailCoordinateTerm_outside z





lemma summable_fullResidual_low_kernel {D : ℕ} (hD : 1 ≤ D) (t : ℤ)
    {z : ℕ →₀ ℤ} (hz : TailCoordinates D z) :
    Summable (fullResidualTerm (t • canonicalKernel D + channelSynthesis z)) := by
  have h := ((_root_.Erdos68.summable_factorialGapTailTerm D).mul_left
    ((t : ℝ) * (channelLCM D : ℝ))).add (summable_tailCoordinateTerm z)
  exact h.congr (fun d => (residual_term_low_kernel hD t hz d).symm)







lemma canonicalKernel_one : canonicalKernel 1 = single 1 1 := by
  rw [canonicalKernel_expansion]
  norm_num [channelLCM]
end ErdosProblems.Erdos68.PaperComplete

open scoped BigOperators
open Finsupp
open ErdosProblems in
open ErdosProblems.Erdos68 in
open ErdosProblems.Erdos68.PaperComplete in
theorem solution {f : ℕ →₀ ℤ} (h0 : f 0 = 0) :
    Summable (fullResidualTerm f) := by
  obtain ⟨a, ha, _⟩ := existsUnique_channel_coordinates f h0
  let z := a - single 0 (a 0)
  have hz : TailCoordinates 1 z := by
    intro j hj
    have : j = 0 := by omega
    subst j
    simp [z]
  have he : a 0 • canonicalKernel 1 + channelSynthesis z = f := by
    dsimp [z]
    rw [canonicalKernel_one, channelSynthesis_sub, channelSynthesis_single]
    simp only [channelBasisColumn, if_pos rfl]
    rw [ha]
    simp [sub_eq_add_neg, add_comm, add_left_comm, add_assoc]
  rw [← he]
  exact summable_fullResidual_low_kernel (D := 1) (by decide) (a 0) hz
