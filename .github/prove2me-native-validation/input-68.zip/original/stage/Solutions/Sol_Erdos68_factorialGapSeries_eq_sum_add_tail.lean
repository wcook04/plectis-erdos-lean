import Definitions.Def_ErdosProblems_Erdos68_ChannelBreakpointRigidity
import Definitions.Def_ErdosProblems_Erdos68_ChannelIntegralCongruence
import Definitions.Def_ErdosProblems_Erdos68_PrimeUnitTranslator
import Theorems.Thm_Erdos68_summable_factorialGapTailTerm
import Mathlib.Algebra.BigOperators.Fin
import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Algebra.GCDMonoid.FinsetLemmas
import Mathlib.Algebra.Order.Round
import Mathlib.Algebra.Ring.GeomSum
import Mathlib.Analysis.Asymptotics.Defs
import Mathlib.Analysis.Complex.ExponentialBounds
import Mathlib.Analysis.Real.Pi.Bounds
import Mathlib.Analysis.SpecialFunctions.Stirling
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Data.Fin.VecNotation
import Mathlib.Data.Nat.Factorial.Basic
import Mathlib.Data.Nat.Factorial.BigOperators
import Mathlib.Data.Nat.ModEq
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.LinearAlgebra.Matrix.Adjugate
import Mathlib.LinearAlgebra.Vandermonde
import Mathlib.Tactic.FinCases
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.InfiniteSum.Basic
import Mathlib.Topology.Algebra.InfiniteSum.Ring

/-!
# Prime unit translator for Erdős problem 68

For a prime `p`, the coefficient pair `(p,-1)` on the indices `(p-1,p)` has
zero factorial moment and annihilates every channel except the `p`-channel.
At that channel its numerator is exactly `p!-1`; consequently its normalized
infinite residual is `1`.  Appending an integer multiple of this pair therefore
translates any finite-support residual by the same integer without changing
the lower channels or the factorial moment.

The module also classifies every finite-support residual modulo integers as
its factorial moment times the factorial-gap tail.  A Cramer construction on
an explicit factorial grid supplies, beyond any prescribed support threshold,
integer coefficient vectors with zero channels through a chosen cutoff and
nonzero factorial moment.  Appending a prime translator reduces their
residual to absolute value at most `1/2`.

The last reduction is not an irrationality argument by itself: the reduced
residual may be zero.  The strict version assumes that the original residual
is not an integer, and no theorem here proves that assumption for the Cramer
vectors.  There is also no coefficient-size estimate, no nonzero lower bound
for the reduced residual, and no irrationality theorem for the factorial-gap
series.
-/

open Erdos68 in
theorem solution
    {D : ℕ} (hD : 2 ≤ D) :
    factorialGapSeries =
      (∑ d ∈ Finset.Icc 2 D,
        (1 : ℝ) /
          ((((d.factorial : ℤ) - 1 : ℤ) : ℝ))) +
        factorialGapTail D := by
  let finitePart : ℕ → ℝ := fun d =>
    if d ∈ Finset.Icc 2 D then
      (1 : ℝ) /
        ((((d.factorial : ℤ) - 1 : ℤ) : ℝ))
    else 0
  have hfinite : Summable finitePart := by
    apply summable_of_ne_finset_zero (s := Finset.Icc 2 D)
    intro d hd
    simp only [finitePart, if_neg hd]
  calc
    factorialGapSeries =
        ∑' d : ℕ, (finitePart d + factorialGapTailTerm D d) := by
      unfold factorialGapSeries factorialGapTail
      apply tsum_congr
      intro d
      by_cases hd2 : 2 ≤ d
      · by_cases hdD : d ≤ D
        · have hdmem : d ∈ Finset.Icc 2 D := by
            simp [hd2, hdD]
          have hnot : ¬D < d := by omega
          simp only [factorialGapTailTerm, finitePart,
            if_pos (show 1 < d by omega), if_pos hdmem, if_neg hnot,
            add_zero]
        · have hdmem : d ∉ Finset.Icc 2 D := by
            simp [hd2, hdD]
          have htail : D < d := by omega
          simp only [factorialGapTailTerm, finitePart,
            if_pos (show 1 < d by omega), if_neg hdmem, if_pos htail,
            zero_add]
      · have hdmem : d ∉ Finset.Icc 2 D := by
          simp [hd2]
        have hnot : ¬D < d := by omega
        have hnot1 : ¬1 < d := by omega
        simp only [factorialGapTailTerm, finitePart, if_neg hnot1,
          if_neg hdmem, if_neg hnot, zero_add]
    _ = (∑' d : ℕ, finitePart d) + factorialGapTail D := by
      rw [hfinite.tsum_add (summable_factorialGapTailTerm D),
        factorialGapTail]
    _ = (∑ d ∈ Finset.Icc 2 D,
          (1 : ℝ) /
            ((((d.factorial : ℤ) - 1 : ℤ) : ℝ))) +
          factorialGapTail D := by
      congr 1
      rw [tsum_eq_sum (s := Finset.Icc 2 D)]
      · apply Finset.sum_congr rfl
        intro d hd
        simp only [finitePart, if_pos hd]
      · intro d hd
        simp only [finitePart, if_neg hd]
