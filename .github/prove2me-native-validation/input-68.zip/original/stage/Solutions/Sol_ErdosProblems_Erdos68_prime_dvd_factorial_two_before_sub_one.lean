import Definitions.Def_ErdosProblems_Erdos68_CanonicalFactorialDigits
import Definitions.Def_ErdosProblems_Erdos68_ChannelBreakpointRigidity
import Definitions.Def_ErdosProblems_Erdos68_ChannelIntegralCongruence
import Definitions.Def_ErdosProblems_Erdos68_PrimeUnitTranslator
import Definitions.Def_ErdosProblems_Erdos68_FactorialGapPlateauCore
import Definitions.Def_ErdosProblems_Erdos68_FactorialChannelCertificate
import Definitions.Def_ErdosProblems_Erdos68_EndpointWeightedPrivateSupport
import Definitions.Def_ErdosProblems_Erdos68_PrimeZeroBranch
import Lean.Elab.Tactic.Omega
import Mathlib.Algebra.BigOperators.Fin
import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Algebra.GCDMonoid.FinsetLemmas
import Mathlib.Algebra.Order.Floor.Ring
import Mathlib.Algebra.Order.Round
import Mathlib.Algebra.Ring.GeomSum
import Mathlib.Analysis.Asymptotics.Defs
import Mathlib.Analysis.Complex.ExponentialBounds
import Mathlib.Analysis.Real.Pi.Bounds
import Mathlib.Analysis.SpecialFunctions.Stirling
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Data.Fin.VecNotation
import Mathlib.Data.Finsupp.Basic
import Mathlib.Data.Int.Basic
import Mathlib.Data.Int.ModEq
import Mathlib.Data.Nat.Choose.Multinomial
import Mathlib.Data.Nat.Factorial.Basic
import Mathlib.Data.Nat.Factorial.BigOperators
import Mathlib.Data.Nat.Factorization.Basic
import Mathlib.Data.Nat.GCD.BigOperators
import Mathlib.Data.Nat.ModEq
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.Nat.Prime.Factorial
import Mathlib.Data.Nat.Prime.Infinite
import Mathlib.Data.Rat.Lemmas
import Mathlib.Data.ZMod.Factorial
import Mathlib.LinearAlgebra.Matrix.Adjugate
import Mathlib.LinearAlgebra.Vandermonde
import Mathlib.NumberTheory.Divisors
import Mathlib.NumberTheory.Real.Irrational
import Mathlib.NumberTheory.Wilson
import Mathlib.Tactic
import Mathlib.Tactic.FinCases
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.NormNum.NatFactorial
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.InfiniteSum.Basic
import Mathlib.Topology.Algebra.InfiniteSum.Ring

/-!
# Erdős #68: the prime zero branch

This module develops three linked layers of the factorial-gap series.

First, exact prefix identities express the step carry through a binary
endpoint flag and the canonical factorial digit.  A unit carry is therefore
equivalent to one of two endpoint cylinders: a zero digit with two zero
flags, or the maximal digit with two one flags.

Second, reduced predecessor fractions are followed prime by prime.  The
formalized arithmetic includes prefix-private prime powers, accumulated
denominator factors, collision and residual cofactors, and exact finite
records at the primes `107` and `971`.  In particular, prefix-private
factorial-gap hits occur cofinally and the corresponding numerator
projections are nonzero under the stated divisibility hypotheses.

Third, a family of conditional theorems shows that sufficiently large
predecessor residues, supplied cofinally, would force irrationality.  The
module does **not** prove those quantitative lower bounds: a nonzero residue
is not enough.  It therefore proves no unconditional irrationality theorem
and does not settle Erdős #68.
-/

namespace ErdosProblems.Erdos68
/-! ## Scaled tails and endpoint flags -/



















/-! ## The reduced rational predecessor state -/













































































/-! ## Prime-power persistence in consecutive denominators -/



















/-! ## Prefix-private moduli and finite CRT anchors -/























































/-! ## Accumulated private powers across finite intervals -/

























/-! ## Componentwise private-prime sources -/

































































/-! ## Cofinal private hits and reflected collisions -/
end ErdosProblems.Erdos68

open ErdosProblems in
open ErdosProblems.Erdos68 in
theorem solution
    {q : ℕ}
    (hq : q.Prime)
    (hq5 : 5 ≤ q) :
    q ∣ (q - 2).factorial - 1 := by
  letI : Fact q.Prime := ⟨hq⟩
  have hwilson :
      ((q - 1).factorial : ZMod q) = -1 :=
    ZMod.wilsons_lemma q
  have hfacNat :
      (q - 1).factorial =
        (q - 1) * (q - 2).factorial := by
    have hpred : q - 2 + 1 = q - 1 := by omega
    rw [← hpred]
    exact Nat.factorial_succ (q - 2)
  have hfacCast :
      ((q - 1 : ℕ) : ZMod q) *
          ((q - 2).factorial : ZMod q) = -1 := by
    rw [← Nat.cast_mul, ← hfacNat]
    exact hwilson
  have hpredCast :
      ((q - 1 : ℕ) : ZMod q) = -1 := by
    rw [Nat.cast_sub (by omega)]
    simp
  have htwoBeforeCast :
      ((q - 2).factorial : ZMod q) = 1 := by
    rw [hpredCast] at hfacCast
    calc
      ((q - 2).factorial : ZMod q) =
          -((-1 : ZMod q) * ((q - 2).factorial : ZMod q)) := by ring
      _ = -(-1) := by rw [hfacCast]
      _ = 1 := by ring
  have hmod :
      (q - 2).factorial ≡ 1 [MOD q] :=
    (ZMod.natCast_eq_natCast_iff _ _ _).1 (by
      simpa using htwoBeforeCast)
  have hone : 1 ≤ (q - 2).factorial :=
    Nat.one_le_iff_ne_zero.mpr (Nat.factorial_ne_zero _)
  exact (Nat.modEq_iff_dvd' hone).1 hmod.symm
