import Definitions.Def_ErdosProblems_Erdos68_CanonicalFactorialDigits
import Definitions.Def_ErdosProblems_Erdos68_ChannelBreakpointRigidity
import Definitions.Def_ErdosProblems_Erdos68_ChannelIntegralCongruence
import Definitions.Def_ErdosProblems_Erdos68_PrimeUnitTranslator
import Definitions.Def_ErdosProblems_Erdos68_FactorialGapPlateauCore
import Definitions.Def_ErdosProblems_Erdos68_FactorialChannelCertificate
import Definitions.Def_ErdosProblems_Erdos68_EndpointWeightedPrivateSupport
import Theorems.Thm_ErdosProblems_Erdos68_endpointTailNumerator_le_endpointBaseNumerator_of_gap_nonneg
import Theorems.Thm_ErdosProblems_Erdos68_factorialBlockEndpointNumerator_div_endpointLcm_eq_gap
import Lean.Elab.Tactic.Omega
import Mathlib.Algebra.BigOperators.Fin
import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Algebra.GCDMonoid.FinsetLemmas
import Mathlib.Algebra.Order.Floor.Ring
import Mathlib.Algebra.Order.Round
import Mathlib.Algebra.Ring.GeomSum
import Mathlib.Analysis.Asymptotics.Defs
import Mathlib.Analysis.Complex.ExponentialBounds
import Mathlib.Analysis.Real.Pi.Bounds
import Mathlib.Analysis.SpecialFunctions.Stirling
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Data.Fin.VecNotation
import Mathlib.Data.Finsupp.Basic
import Mathlib.Data.Int.Basic
import Mathlib.Data.Int.ModEq
import Mathlib.Data.Nat.Choose.Multinomial
import Mathlib.Data.Nat.Factorial.Basic
import Mathlib.Data.Nat.Factorial.BigOperators
import Mathlib.Data.Nat.Factorization.Basic
import Mathlib.Data.Nat.GCD.BigOperators
import Mathlib.Data.Nat.ModEq
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.Nat.Prime.Factorial
import Mathlib.Data.Rat.Lemmas
import Mathlib.LinearAlgebra.Matrix.Adjugate
import Mathlib.LinearAlgebra.Vandermonde
import Mathlib.NumberTheory.Divisors
import Mathlib.NumberTheory.Real.Irrational
import Mathlib.Tactic
import Mathlib.Tactic.FinCases
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.NormNum.NatFactorial
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.InfiniteSum.Basic
import Mathlib.Topology.Algebra.InfiniteSum.Ring

/-!
# Erdős #68: collision cores, private residues, and factorial-block endpoints

For a finite denominator family, the pairwise collision core records the
prime powers shared by at least two denominators.  Dividing each denominator
by its part inside this core produces pairwise-coprime private quotients.
Their product is the private modulus `R`; a weighted leave-one-out numerator
is coprime to `R`, so the displayed endpoint numerator has a nonzero residue
whenever `R > 1`.

The abstract part of the file develops these finite gcd, lcm, CRT, and
projection identities.  The factorial-block specialization takes the
denominators `n! - 1` for `p ≤ n < 2p`, identifies the strict-successor
coefficient at `p - 1`, and defines an endpoint window.  Unit carries on the
whole interval `[p,2p]` force that window; so does any rational value whose
denominator is already cleared by `(p-1)!`.

The later theorems give several exact ways to refute the window: a large
private residue, unequal leave-one-out projections, coprime factor-pair
floors, or a uniquely supported prime with a sufficiently large residue.
Cofinal families of any of the stated certificates imply cofinally many
non-unit carries or rational-prefix divisibility failures, and hence imply
irrationality through the earlier carry criterion.

Every irrationality conclusion in this file is conditional.  No theorem
constructs the required cofinal certificate family, proves the needed
projection disagreement or size inequality for arbitrarily large blocks,
or supplies cofinally many uniquely supported factorial-gap primes.  The
finite CRT identities and endpoint reductions therefore do not by themselves
prove the irrationality of the factorial-gap series or solve Erdős #68.
-/

namespace ErdosProblems.Erdos68
/-! ## Collision cores for finite denominator families -/





















/-- Positivity of every displayed denominator makes the full endpoint lcm
strictly positive. -/
theorem endpointDenominatorLcm_pos
    {ι : Type*} [DecidableEq ι]
    {base : ℕ} {s : Finset ι} {d : ι → ℕ}
    (hbase : 0 < base)
    (hpos : ∀ i ∈ s, 0 < d i) :
    0 < endpointDenominatorLcm base s d := by
  unfold endpointDenominatorLcm
  apply Nat.pos_of_ne_zero
  exact Nat.lcm_ne_zero hbase.ne'
    ((Finset.lcm_ne_zero_iff).2 fun i hi => (hpos i hi).ne')





























































/-! ## Private quotients and weighted CRT numerators -/



































































/-! ## Endpoint residues and finite projection bounds -/



































































/-! ## The factorial-block endpoint window -/









































































/-! ## Normalized collision arithmetic in a factorial block -/

/-- Casting a factorial-gap denominator into the rationals
recovers the denominator appearing in the Erdős #68 prefix. -/
theorem factorialGapDenominator_cast
    {n : ℕ} :
    (factorialGapDenominator n : ℚ) =
      (n.factorial : ℚ) - 1 := by
  unfold factorialGapDenominator
  rw [Nat.cast_sub (Nat.succ_le_of_lt (Nat.factorial_pos n))]
  norm_num

/-- The reciprocal sum over the literal prime block is exactly the actual
factorial-gap prefix through `2p-1`. -/
theorem factorialBlock_reciprocalSum_eq_factorialGapPrefix
    {p : ℕ} :
    (∑ n ∈ factorialBlockIndices p,
        1 / (factorialGapDenominator n : ℚ)) =
      factorialGapPrefix (2 * p - 1) := by
  unfold factorialBlockIndices factorialGapPrefix
  apply Finset.sum_congr rfl
  intro n _
  rw [factorialGapDenominator_cast]

/-- Every literal block denominator is positive. -/
theorem factorialGapDenominator_pos_of_mem
    {p n : ℕ}
    (hn : n ∈ factorialBlockIndices p) :
    0 < factorialGapDenominator n := by
  have hn2 : 2 ≤ n :=
    (Finset.mem_Icc.mp hn).1
  exact Nat.sub_pos_of_lt ((Nat.one_lt_factorial).2 hn2)































































/-! ## Leave-one-out and factor-pair projection bounds -/

































/-! ## Prime-power incidence and uniquely supported factors -/









































/-- A positive literal endpoint gap already supplies the natural
ordinary-subtraction side condition. -/
theorem factorialBlock_tail_le_baseNumerator_of_endpointGap_pos
    {p : ℕ}
    (hgap : 0 < factorialBlockEndpointGap p) :
    factorialBlockTailNumerator p ≤
      factorialBlockBaseNumerator p := by
  apply endpointTailNumerator_le_endpointBaseNumerator_of_gap_nonneg
    (K := factorialBlockCoefficient p)
    (base := factorialBlockBase p)
    (s := factorialBlockIndices p)
    (d := factorialGapDenominator)
  · exact Nat.factorial_pos _
  · intro n hn
    exact factorialGapDenominator_pos_of_mem hn
  · rw [factorialBlock_reciprocalSum_eq_factorialGapPrefix]
    exact hgap.le









/-! ## Endpoint-window exclusions and conditional irrationality criteria -/

/-- The scale in the endpoint window is positive for every
nonzero block parameter. -/
theorem factorialBlockScale_pos
    {p : ℕ} (hp : 0 < p) :
    0 < factorialBlockScale p := by
  unfold factorialBlockScale
  positivity
end ErdosProblems.Erdos68

open ErdosProblems in
open ErdosProblems.Erdos68 in
theorem solution
    {p : ℕ}
    (hp : 0 < p)
    (hwindow : factorialBlockEndpointWindow p) :
    factorialBlockScale p *
        factorialBlockEndpointNumerator p ≤
      factorialBlockBudget p *
        factorialBlockEndpointLcm p := by
  have htail :=
    factorialBlock_tail_le_baseNumerator_of_endpointGap_pos
      hwindow.1
  have hratio :=
    factorialBlockEndpointNumerator_div_endpointLcm_eq_gap
      htail
  have hLpos :
      0 < factorialBlockEndpointLcm p := by
    apply endpointDenominatorLcm_pos
      (base := factorialBlockBase p)
      (s := factorialBlockIndices p)
      (d := factorialGapDenominator)
    · exact Nat.factorial_pos _
    · intro n hn
      exact factorialGapDenominator_pos_of_mem hn
  have hLposQ :
      (0 : ℚ) < factorialBlockEndpointLcm p := by
    exact_mod_cast hLpos
  have hscalePosQ :
      (0 : ℚ) < factorialBlockScale p := by
    exact_mod_cast factorialBlockScale_pos hp
  have hgapUpper := hwindow.2
  rw [← hratio] at hgapUpper
  unfold factorialBlockEndpointUpperBound at hgapUpper
  rw [div_le_div_iff₀ hLposQ hscalePosQ] at hgapUpper
  exact_mod_cast (show
    (factorialBlockScale p : ℚ) *
          factorialBlockEndpointNumerator p ≤
        (factorialBlockBudget p : ℚ) *
          factorialBlockEndpointLcm p by
      simpa [mul_comm] using hgapUpper)
