import Definitions.Def_ErdosProblems_Erdos68_ChannelBreakpointRigidity
import Definitions.Def_ErdosProblems_Erdos68_ChannelIntegralCongruence
import Definitions.Def_ErdosProblems_Erdos68_PrimeUnitTranslator
import Mathlib.Algebra.BigOperators.Fin
import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Algebra.GCDMonoid.FinsetLemmas
import Mathlib.Algebra.Order.Round
import Mathlib.Algebra.Ring.GeomSum
import Mathlib.Analysis.Asymptotics.Defs
import Mathlib.Analysis.Complex.ExponentialBounds
import Mathlib.Analysis.Real.Pi.Bounds
import Mathlib.Analysis.SpecialFunctions.Stirling
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Data.Fin.VecNotation
import Mathlib.Data.Nat.Factorial.Basic
import Mathlib.Data.Nat.Factorial.BigOperators
import Mathlib.Data.Nat.ModEq
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.LinearAlgebra.Matrix.Adjugate
import Mathlib.LinearAlgebra.Vandermonde
import Mathlib.Tactic.FinCases
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.InfiniteSum.Basic
import Mathlib.Topology.Algebra.InfiniteSum.Ring

/-!
# Prime unit translator for Erdős problem 68

For a prime `p`, the coefficient pair `(p,-1)` on the indices `(p-1,p)` has
zero factorial moment and annihilates every channel except the `p`-channel.
At that channel its numerator is exactly `p!-1`; consequently its normalized
infinite residual is `1`.  Appending an integer multiple of this pair therefore
translates any finite-support residual by the same integer without changing
the lower channels or the factorial moment.

The module also classifies every finite-support residual modulo integers as
its factorial moment times the factorial-gap tail.  A Cramer construction on
an explicit factorial grid supplies, beyond any prescribed support threshold,
integer coefficient vectors with zero channels through a chosen cutoff and
nonzero factorial moment.  Appending a prime translator reduces their
residual to absolute value at most `1/2`.

The last reduction is not an irrationality argument by itself: the reduced
residual may be zero.  The strict version assumes that the original residual
is not an integer, and no theorem here proves that assumption for the Cramer
vectors.  There is also no coefficient-size estimate, no nonzero lower bound
for the reduced residual, and no irrationality theorem for the factorial-gap
series.
-/

open Erdos68 in
theorem solution :
    Summable (fun d : ℕ =>
      (1 : ℝ) / ((((d.factorial : ℤ) - 1 : ℤ)) : ℝ)) := by
  apply summable_of_ratio_norm_eventually_le
    (r := (1 : ℝ) / 2) (by norm_num)
  filter_upwards [Filter.eventually_atTop.2 ⟨2, fun n hn => hn⟩] with n hn
  have hfac : 1 < n.factorial :=
    Nat.one_lt_factorial.mpr hn
  have hnextfac : 1 < (n + 1).factorial :=
    Nat.one_lt_factorial.mpr (by omega)
  have hden :
      (0 : ℝ) < ((((n.factorial : ℤ) - 1 : ℤ)) : ℝ) := by
    exact_mod_cast (show (0 : ℤ) < (n.factorial : ℤ) - 1 by omega)
  have hnextden :
      (0 : ℝ) < (((((n + 1).factorial : ℤ) - 1 : ℤ)) : ℝ) := by
    exact_mod_cast
      (show (0 : ℤ) < ((n + 1).factorial : ℤ) - 1 by omega)
  have hgap :
      2 * ((((n.factorial : ℤ) - 1 : ℤ)) : ℝ) ≤
        (((((n + 1).factorial : ℤ) - 1 : ℤ)) : ℝ) := by
    have hstep : (n + 1).factorial = (n + 1) * n.factorial :=
      Nat.factorial_succ n
    exact_mod_cast
      (show (2 : ℤ) * ((n.factorial : ℤ) - 1) ≤
          (((n + 1).factorial : ℤ) - 1) by
        nlinarith)
  simp only [Real.norm_eq_abs,
    abs_of_pos (one_div_pos.mpr hden),
    abs_of_pos (one_div_pos.mpr hnextden)]
  calc
    (1 : ℝ) /
          (((((n + 1).factorial : ℤ) - 1 : ℤ)) : ℝ) ≤
        1 / (2 * ((((n.factorial : ℤ) - 1 : ℤ)) : ℝ)) :=
      one_div_le_one_div_of_le (by positivity) hgap
    _ = ((1 : ℝ) / 2) *
          (1 / ((((n.factorial : ℤ) - 1 : ℤ)) : ℝ)) := by
      field_simp [hden.ne']
