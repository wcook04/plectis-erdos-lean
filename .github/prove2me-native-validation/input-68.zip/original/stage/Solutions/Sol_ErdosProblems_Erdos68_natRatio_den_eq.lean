import Mathlib.Data.Nat.Factorization.Basic
import Mathlib.Data.Rat.Lemmas

namespace ErdosProblems.Erdos68
end ErdosProblems.Erdos68

/-!
# Prime powers surviving rational denominator reduction

For a positive common denominator `L`, reduction replaces it by `L / gcd B L`.
A prime divisor of `L` retains its full exponent exactly when it does not divide
the numerator `B`. This is the rational-denominator step in maximal-hit
cancellation for a factorial-gap prefix.
-/

open ErdosProblems in
open ErdosProblems.Erdos68 in
theorem solution (B : ℕ) {L : ℕ} (hL : 0 < L) :
    ((B : ℚ) / L).den = L / B.gcd L := by
  rw [Rat.natCast_div_eq_divInt, Rat.den_divInt]
  simp [hL.ne', Int.gcd, Nat.gcd_comm]
