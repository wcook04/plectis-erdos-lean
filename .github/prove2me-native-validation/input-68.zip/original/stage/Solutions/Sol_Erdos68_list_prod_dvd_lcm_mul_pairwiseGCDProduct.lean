import Definitions.Def_ErdosProblems_Erdos68_ChannelBreakpointRigidity
import Definitions.Def_ErdosProblems_Erdos68_ChannelIntegralCongruence
import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Algebra.GCDMonoid.FinsetLemmas
import Mathlib.Algebra.Ring.GeomSum
import Mathlib.Analysis.Asymptotics.Defs
import Mathlib.Analysis.Complex.ExponentialBounds
import Mathlib.Analysis.Real.Pi.Bounds
import Mathlib.Analysis.SpecialFunctions.Stirling
import Mathlib.Data.Nat.Factorial.Basic
import Mathlib.Data.Nat.Factorial.BigOperators
import Mathlib.Data.Nat.ModEq
import Mathlib.Tactic.Ring

/-!
# Integral channel congruence for Erdős problem 68

This module compares a channel numerator with the corresponding factorial
moment modulo `d! - 1`.  The congruence holds for every support index, so
simultaneous cancellation of the channels `2, ..., D` makes their least common
multiple divide the factorial moment.

The second part estimates that least common multiple.  Consecutive numbers
`m! - 1` are compared through their pairwise gcds; this gives an explicit
finite lower bound after the gcd losses are counted.  Consequently, if a
positive integer `M` is divisible by the channel lcm and is smaller than
`(R+1)! - 1`, then `R` must grow at least cubically along `D = 2t^2`.  A later
estimate improves the explicit constant to `R+1 > (3/2)t^3` for `t >= 2^32`.

All conclusions after the congruence theorem retain these stated hypotheses.
In particular, this file does not construct `M` or `R` from the series in
Erdős problem 68, prove that its channels vanish, or decide the rationality of
that series.
-/

namespace Erdos68
/-! ## Product versus lcm with explicit gcd loss -/





theorem listLCM_dvd_prod (values : List ℕ) :
    listLCM values ∣ values.prod := by
  induction values with
  | nil => simp [listLCM]
  | cons a tail ih =>
      rw [listLCM, List.prod_cons]
      exact Nat.lcm_dvd (dvd_mul_right a tail.prod)
        (ih.trans (dvd_mul_left tail.prod a))

theorem gcd_list_prod_dvd_prod_gcd (a : ℕ) (values : List ℕ) :
    Nat.gcd a values.prod ∣ (values.map (Nat.gcd a)).prod := by
  induction values with
  | nil => simp
  | cons b tail ih =>
      rw [List.prod_cons, List.map_cons, List.prod_cons]
      exact (gcd_mul_dvd_mul_gcd a b tail.prod).trans
        (mul_dvd_mul_left (Nat.gcd a b) ih)
end Erdos68

open Erdos68 in
theorem solution (values : List ℕ) :
    values.prod ∣ listLCM values * pairwiseGCDProduct values := by
  induction values with
  | nil => simp [listLCM, pairwiseGCDProduct]
  | cons a tail ih =>
      have hlcm : listLCM tail ∣ tail.prod := listLCM_dvd_prod tail
      have hgcd_lcm :
          Nat.gcd a (listLCM tail) ∣ Nat.gcd a tail.prod :=
        Nat.dvd_gcd (Nat.gcd_dvd_left _ _)
          ((Nat.gcd_dvd_right _ _).trans hlcm)
      have hgcd :
          Nat.gcd a (listLCM tail) ∣
            (tail.map (Nat.gcd a)).prod :=
        hgcd_lcm.trans (gcd_list_prod_dvd_prod_gcd a tail)
      rw [List.prod_cons, listLCM, pairwiseGCDProduct]
      calc
        a * tail.prod ∣ a * (listLCM tail * pairwiseGCDProduct tail) :=
          mul_dvd_mul_left a ih
        _ = (Nat.gcd a (listLCM tail) * Nat.lcm a (listLCM tail)) *
              pairwiseGCDProduct tail := by
                rw [Nat.gcd_mul_lcm]
                ring
        _ = Nat.lcm a (listLCM tail) *
              (Nat.gcd a (listLCM tail) * pairwiseGCDProduct tail) := by
                ring
        _ ∣ Nat.lcm a (listLCM tail) *
              ((tail.map (Nat.gcd a)).prod * pairwiseGCDProduct tail) := by
                exact mul_dvd_mul_left _ (mul_dvd_mul_right hgcd _)
