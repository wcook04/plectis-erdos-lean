import Definitions.Def_ErdosProblems_Erdos68_FactorialChannelCertificate
import Definitions.Def_ErdosProblems_Erdos68_DivisorChannelBasis
import Definitions.Def_ErdosProblems_Erdos68_PaperCompleteDivisorCoordinates
import Definitions.Def_ErdosProblems_Erdos68_PaperCompleteIntegerSpan
import Definitions.Def_ErdosProblems_Erdos68_PaperCompleteLowKernel
import Definitions.Def_ErdosProblems_Erdos68_PaperCompleteMomentHorizon
import Definitions.Def_ErdosProblems_Erdos68_PaperCompleteMomentIdeal
import Theorems.Thm_ErdosProblems_Erdos68_PaperComplete_finite_channel_moment_certificate
import Theorems.Thm_ErdosProblems_Erdos68_PaperComplete_attainable_moment_ideal
import Theorems.Thm_ErdosProblems_Erdos68_PaperComplete_gcd_quotient_pos
import Theorems.Thm_ErdosProblems_Erdos68_PaperComplete_local_channelLCM_pos
import Theorems.Thm_ErdosProblems_Erdos68_PaperComplete_minimum_positive_moment
import Lean.Elab.Tactic.Omega
import Mathlib.Algebra.BigOperators.Finsupp.Basic
import Mathlib.Algebra.BigOperators.GroupWithZero.Action
import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Combinatorics.Enumerative.Bell
import Mathlib.Data.Finsupp.Basic
import Mathlib.Data.Finsupp.SMul
import Mathlib.Data.Int.GCD
import Mathlib.Data.Int.ModEq
import Mathlib.Data.Nat.Choose.Multinomial
import Mathlib.Data.Nat.GCD.Prime
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.Rat.Lemmas
import Mathlib.NumberTheory.Divisors
import Mathlib.RingTheory.Coprime.Lemmas
import Mathlib.Tactic
import Mathlib.Tactic.Abel
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.NormNum.NatFactorial
import Mathlib.Tactic.Ring

   
                                                                            
                                                                              
                                                                              
  

namespace ErdosProblems.Erdos68.PaperComplete
open scoped BigOperators
open Finsupp



















lemma minimumMoment_pos {D p : ℕ} (hD : 2 ≤ D)
    (hp : p.Prime) (hDp : D / 2 < p) (hpD : p ≤ D) :
    0 < minimumMoment D p := by
  have hcert := finite_channel_moment_certificate hD hp hDp hpD
  unfold minimumMoment
  apply mul_pos
  · exact_mod_cast local_channelLCM_pos D
  · apply gcd_quotient_pos
    exact_mod_cast hcert.1

/-- The positive generator is attained, rather than just a necessary divisor. -/
theorem minimumMoment_attained {D p : ℕ} (hD : 2 ≤ D)
    (hp : p.Prime) (hDp : D / 2 < p) (hpD : p ≤ D) :
    AttainsMoment D (minimumMoment D p) :=
  (attainable_moment_ideal hD hp hDp hpD _).mpr (dvd_refl _)
end ErdosProblems.Erdos68.PaperComplete

open scoped BigOperators
open Finsupp
open ErdosProblems in
open ErdosProblems.Erdos68 in
open ErdosProblems.Erdos68.PaperComplete in
theorem solution {D p q : ℕ} (hD : 2 ≤ D)
    (hp : p.Prime) (hDp : D / 2 < p) (hpD : p ≤ D)
    (hq : q.Prime) (hDq : D / 2 < q) (hqD : q ≤ D) :
    minimumMoment D p = minimumMoment D q := by
  apply le_antisymm
  · exact minimum_positive_moment hD hp hDp hpD
      (minimumMoment_attained hD hq hDq hqD) (minimumMoment_pos hD hq hDq hqD)
  · exact minimum_positive_moment hD hq hDq hqD
      (minimumMoment_attained hD hp hDp hpD) (minimumMoment_pos hD hp hDp hpD)
