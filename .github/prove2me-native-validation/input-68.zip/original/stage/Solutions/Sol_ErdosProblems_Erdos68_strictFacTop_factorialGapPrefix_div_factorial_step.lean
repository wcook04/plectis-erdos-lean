import Definitions.Def_ErdosProblems_Erdos68_CanonicalFactorialDigits
import Definitions.Def_ErdosProblems_Erdos68_ChannelBreakpointRigidity
import Definitions.Def_ErdosProblems_Erdos68_ChannelIntegralCongruence
import Definitions.Def_ErdosProblems_Erdos68_PrimeUnitTranslator
import Definitions.Def_ErdosProblems_Erdos68_FactorialGapPlateauCore
import Theorems.Thm_ErdosProblems_Erdos68_strictFacTop_factorialGapPrefix_step
import Mathlib.Algebra.BigOperators.Fin
import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Algebra.GCDMonoid.FinsetLemmas
import Mathlib.Algebra.Order.Floor.Ring
import Mathlib.Algebra.Order.Round
import Mathlib.Algebra.Ring.GeomSum
import Mathlib.Analysis.Asymptotics.Defs
import Mathlib.Analysis.Complex.ExponentialBounds
import Mathlib.Analysis.Real.Pi.Bounds
import Mathlib.Analysis.SpecialFunctions.Stirling
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Data.Fin.VecNotation
import Mathlib.Data.Int.Basic
import Mathlib.Data.Nat.Factorial.Basic
import Mathlib.Data.Nat.Factorial.BigOperators
import Mathlib.Data.Nat.ModEq
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.LinearAlgebra.Matrix.Adjugate
import Mathlib.LinearAlgebra.Vandermonde
import Mathlib.NumberTheory.Real.Irrational
import Mathlib.Tactic
import Mathlib.Tactic.FinCases
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.InfiniteSum.Basic
import Mathlib.Topology.Algebra.InfiniteSum.Ring

/-!
# Erdős #68: factorial-gap plateau core

Lightweight core for the strict-successor recurrence, carry bounds, and the
exact divisibility criterion.  Heavy exact-index certificates live in
`FactorialZeroPlateauCertificates`; the full plateau file re-exports both.
-/

namespace ErdosProblems.Erdos68
/-! ## Factorial grid arithmetic -/



















/-! ## Exact prefixes and prime-power divisibility -/

















/-! ## The carry recurrence and the exact irrationality criterion -/
end ErdosProblems.Erdos68

open ErdosProblems in
open ErdosProblems.Erdos68 in
theorem solution
    {m : ℕ} (hm : 3 ≤ m) :
    (strictFacTop
          ((factorialGapPrefix m : ℚ) : ℝ) m : ℝ) /
        (m.factorial : ℝ) =
      (strictFacTop
            ((factorialGapPrefix (m - 1) : ℚ) : ℝ) (m - 1) : ℝ) /
          ((m - 1).factorial : ℝ) +
        ((1 - factorialGapStepCarry m : ℤ) : ℝ) /
          (m.factorial : ℝ) := by
  have hrec :=
    strictFacTop_factorialGapPrefix_step (m := m) (show 2 ≤ m by omega)
  have hfacNat :
      m.factorial = m * (m - 1).factorial := by
    have hmSucc : m - 1 + 1 = m := by omega
    simpa only [hmSucc] using Nat.factorial_succ (m - 1)
  have hfac :
      (m.factorial : ℝ) =
        (m : ℝ) * ((m - 1).factorial : ℝ) := by
    exact_mod_cast hfacNat
  rw [hrec, hfac]
  push_cast
  field_simp
  ring
