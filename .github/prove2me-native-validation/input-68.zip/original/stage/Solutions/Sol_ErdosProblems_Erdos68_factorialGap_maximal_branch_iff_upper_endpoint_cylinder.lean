import Definitions.Def_ErdosProblems_Erdos68_CanonicalFactorialDigits
import Definitions.Def_ErdosProblems_Erdos68_ChannelBreakpointRigidity
import Definitions.Def_ErdosProblems_Erdos68_ChannelIntegralCongruence
import Definitions.Def_ErdosProblems_Erdos68_PrimeUnitTranslator
import Definitions.Def_ErdosProblems_Erdos68_FactorialGapPlateauCore
import Definitions.Def_ErdosProblems_Erdos68_FactorialChannelCertificate
import Definitions.Def_ErdosProblems_Erdos68_EndpointWeightedPrivateSupport
import Definitions.Def_ErdosProblems_Erdos68_PrimeZeroBranch
import Theorems.Thm_ErdosProblems_Erdos68_canonicalDigit_eq_floor_mul_remainder
import Theorems.Thm_ErdosProblems_Erdos68_canonicalRemainder_lt_one
import Theorems.Thm_ErdosProblems_Erdos68_factorialGapScaledTail_pos
import Theorems.Thm_ErdosProblems_Erdos68_canonicalRemainder_recurrence
import Theorems.Thm_ErdosProblems_Erdos68_factorialGapScaledTail_pred_recurrence
import Lean.Elab.Tactic.Omega
import Mathlib.Algebra.BigOperators.Fin
import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Algebra.GCDMonoid.FinsetLemmas
import Mathlib.Algebra.Order.Floor.Ring
import Mathlib.Algebra.Order.Round
import Mathlib.Algebra.Ring.GeomSum
import Mathlib.Analysis.Asymptotics.Defs
import Mathlib.Analysis.Complex.ExponentialBounds
import Mathlib.Analysis.Real.Pi.Bounds
import Mathlib.Analysis.SpecialFunctions.Stirling
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Data.Fin.VecNotation
import Mathlib.Data.Finsupp.Basic
import Mathlib.Data.Int.Basic
import Mathlib.Data.Int.ModEq
import Mathlib.Data.Nat.Choose.Multinomial
import Mathlib.Data.Nat.Factorial.Basic
import Mathlib.Data.Nat.Factorial.BigOperators
import Mathlib.Data.Nat.Factorization.Basic
import Mathlib.Data.Nat.GCD.BigOperators
import Mathlib.Data.Nat.ModEq
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.Nat.Prime.Factorial
import Mathlib.Data.Nat.Prime.Infinite
import Mathlib.Data.Rat.Lemmas
import Mathlib.Data.ZMod.Factorial
import Mathlib.LinearAlgebra.Matrix.Adjugate
import Mathlib.LinearAlgebra.Vandermonde
import Mathlib.NumberTheory.Divisors
import Mathlib.NumberTheory.Real.Irrational
import Mathlib.NumberTheory.Wilson
import Mathlib.Tactic
import Mathlib.Tactic.FinCases
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.NormNum.NatFactorial
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.InfiniteSum.Basic
import Mathlib.Topology.Algebra.InfiniteSum.Ring

/-!
# Erdős #68: the prime zero branch

This module develops three linked layers of the factorial-gap series.

First, exact prefix identities express the step carry through a binary
endpoint flag and the canonical factorial digit.  A unit carry is therefore
equivalent to one of two endpoint cylinders: a zero digit with two zero
flags, or the maximal digit with two one flags.

Second, reduced predecessor fractions are followed prime by prime.  The
formalized arithmetic includes prefix-private prime powers, accumulated
denominator factors, collision and residual cofactors, and exact finite
records at the primes `107` and `971`.  In particular, prefix-private
factorial-gap hits occur cofinally and the corresponding numerator
projections are nonzero under the stated divisibility hypotheses.

Third, a family of conditional theorems shows that sufficiently large
predecessor residues, supplied cofinally, would force irrationality.  The
module does **not** prove those quantitative lower bounds: a nonzero residue
is not enough.  It therefore proves no unconditional irrationality theorem
and does not settle Erdős #68.
-/

namespace ErdosProblems.Erdos68
/-! ## Scaled tails and endpoint flags -/















/-- A one endpoint flag is exactly containment at or above the scaled
tail. -/
theorem factorialGapEndpointFlag_eq_one_iff (m : ℕ) :
    factorialGapEndpointFlag m = 1 ↔
      factorialGapScaledTail m ≤
        canonicalRemainder _root_.Erdos68.factorialGapSeries m := by
  simp [factorialGapEndpointFlag]



/-! ## The reduced rational predecessor state -/













































































/-! ## Prime-power persistence in consecutive denominators -/



















/-! ## Prefix-private moduli and finite CRT anchors -/























































/-! ## Accumulated private powers across finite intervals -/

























/-! ## Componentwise private-prime sources -/

































































/-! ## Cofinal private hits and reflected collisions -/







































/-! ## Killed multiplicities and residual-cofactor recurrences -/





























































































/-! ## Wilson quotients and finite repeated-prime records -/































/-! ## Repeated-birth amplification and interval persistence -/

















































/-! ## Endpoint cylinders and the exact carry dichotomy -/
end ErdosProblems.Erdos68

open ErdosProblems in
open ErdosProblems.Erdos68 in
theorem solution
    {m : ℕ} (hm : 3 ≤ m) :
    (canonicalDigit _root_.Erdos68.factorialGapSeries m =
          (m : ℤ) - 1 ∧
        factorialGapEndpointFlag (m - 1) = 1 ∧
        factorialGapEndpointFlag m = 1) ↔
      ((m : ℝ) - 1) + factorialGapScaledTail m ≤
        (m : ℝ) *
          canonicalRemainder
            _root_.Erdos68.factorialGapSeries (m - 1) := by
  let S : ℝ := _root_.Erdos68.factorialGapSeries
  change
    (canonicalDigit S m = (m : ℤ) - 1 ∧
        factorialGapEndpointFlag (m - 1) = 1 ∧
        factorialGapEndpointFlag m = 1) ↔
      ((m : ℝ) - 1) + factorialGapScaledTail m ≤
        (m : ℝ) * canonicalRemainder S (m - 1)
  have hsucc : m - 1 + 1 = m := by omega
  have hcastSucc :
      ((m - 1 : ℕ) : ℝ) + 1 = (m : ℝ) := by
    exact_mod_cast hsucc
  have hrec := canonicalRemainder_recurrence S (m - 1)
  rw [hsucc, hcastSucc] at hrec
  have htailRec :=
    factorialGapScaledTail_pred_recurrence (m := m) hm
  have hRPos :=
    factorialGapScaledTail_pos (m := m) (by omega)
  have hθLt :=
    canonicalRemainder_lt_one S (m - 1)
  constructor
  · rintro ⟨hdigit, _hprev, hcurr⟩
    have hcurrGe :=
      (factorialGapEndpointFlag_eq_one_iff m).mp hcurr
    rw [hdigit] at hrec
    push_cast at hrec
    rw [hrec] at hcurrGe
    linarith
  · intro hlarge
    have hdigit :
        canonicalDigit S m = (m : ℤ) - 1 := by
      rw [canonicalDigit_eq_floor_mul_remainder S m (by omega)]
      apply Int.floor_eq_iff.mpr
      constructor
      · push_cast
        linarith
      · push_cast
        have hmPos : (0 : ℝ) < m := by positivity
        nlinarith
    have hcurrRem :
        canonicalRemainder S m =
          (m : ℝ) * canonicalRemainder S (m - 1) -
            ((m : ℝ) - 1) := by
      rw [hdigit] at hrec
      push_cast at hrec
      exact hrec
    have hcurr : factorialGapEndpointFlag m = 1 := by
      apply (factorialGapEndpointFlag_eq_one_iff m).mpr
      rw [hcurrRem]
      linarith
    have hfacGtTwo : (2 : ℝ) < m.factorial := by
      have hfacSix : 6 ≤ m.factorial :=
        Nat.factorial_le (show 3 ≤ m by omega)
      exact_mod_cast (show 2 < m.factorial by omega)
    have hdenGtOne :
        (1 : ℝ) < (m.factorial : ℝ) - 1 := by
      linarith
    have hepsLtOne :
        1 / ((m.factorial : ℝ) - 1) < 1 := by
      simpa using
        (one_div_lt_one_div_of_lt
          (show (0 : ℝ) < 1 by norm_num) hdenGtOne)
    have hpredScaledLtThreshold :
        (m : ℝ) * factorialGapScaledTail (m - 1) <
          ((m : ℝ) - 1) + factorialGapScaledTail m := by
      have hmReal : (3 : ℝ) ≤ m := by exact_mod_cast hm
      linarith
    have hmPos : (0 : ℝ) < m := by positivity
    have hprevGe :
        factorialGapScaledTail (m - 1) ≤
          canonicalRemainder S (m - 1) := by
      nlinarith
    have hprev :
        factorialGapEndpointFlag (m - 1) = 1 :=
      (factorialGapEndpointFlag_eq_one_iff (m - 1)).mpr
        hprevGe
    exact ⟨hdigit, hprev, hcurr⟩
