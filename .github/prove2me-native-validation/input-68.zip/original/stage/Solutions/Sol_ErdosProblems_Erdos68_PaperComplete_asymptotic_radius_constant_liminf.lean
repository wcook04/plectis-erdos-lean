import Definitions.Def_ErdosProblems_Erdos68_ChannelBreakpointRigidity
import Definitions.Def_ErdosProblems_Erdos68_ChannelIntegralCongruence
import Definitions.Def_ErdosProblems_Erdos68_PaperCompleteAsymptotics
import Definitions.Def_ErdosProblems_Erdos68_PaperCompleteRadiusLimit
import Theorems.Thm_ErdosProblems_Erdos68_PaperComplete_asymptotic_radius_constant
import Theorems.Thm_ErdosProblems_Erdos68_PaperComplete_lowerLimitAtLeast_iff_ereal
import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Algebra.GCDMonoid.FinsetLemmas
import Mathlib.Algebra.Ring.GeomSum
import Mathlib.Analysis.Asymptotics.Defs
import Mathlib.Analysis.Complex.ExponentialBounds
import Mathlib.Analysis.Real.Pi.Bounds
import Mathlib.Analysis.SpecialFunctions.Log.Basic
import Mathlib.Analysis.SpecialFunctions.Pow.Real
import Mathlib.Analysis.SpecialFunctions.Sqrt
import Mathlib.Analysis.SpecialFunctions.Stirling
import Mathlib.Data.EReal.Basic
import Mathlib.Data.Nat.Factorial.Basic
import Mathlib.Data.Nat.Factorial.BigOperators
import Mathlib.Data.Nat.ModEq
import Mathlib.Order.LiminfLimsup
import Mathlib.Tactic
import Mathlib.Tactic.Ring
import Mathlib.Topology.Order.Basic

/-!
# Literal liminf statements, without silently assuming finite liminf values

The displayed asymptotic theorems allow the value +infinity. The wrappers use
EReal for the liminf and prove equivalence with the epsilon/eventual assertions
in the main proof files. Thus no unproved upper-boundedness assumption is
introduced merely to fit a real-valued liminf API.

-/

namespace ErdosProblems.Erdos68.PaperComplete
open Filter
open scoped Topology
end ErdosProblems.Erdos68.PaperComplete

open Filter
open scoped Topology
open ErdosProblems in
open ErdosProblems.Erdos68 in
open ErdosProblems.Erdos68.PaperComplete in
theorem solution (M R : ℕ → ℕ)
    (hH : ∃ T : ℕ, ∀ t : ℕ, T ≤ t →
      0 < M t ∧ _root_.Erdos68.channelLCM (2 * t ^ 2) ∣ M t ∧
      M t < (R t + 1).factorial - 1) :
    (((16 : ℝ) / 9) : EReal) ≤
      Filter.liminf (fun t : ℕ =>
        ((((R t + 1 : ℕ) : ℝ) / (t : ℝ) ^ 3 : ℝ) : EReal)) atTop := by
  apply (lowerLimitAtLeast_iff_ereal _ _).mp
  exact asymptotic_radius_constant M R (eventually_atTop.mpr hH)
