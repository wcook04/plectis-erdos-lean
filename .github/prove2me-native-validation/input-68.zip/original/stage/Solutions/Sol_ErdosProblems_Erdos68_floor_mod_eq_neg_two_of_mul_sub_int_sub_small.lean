import Definitions.Def_ErdosProblems_Erdos68_CanonicalFactorialDigits
import Definitions.Def_ErdosProblems_Erdos68_ChannelBreakpointRigidity
import Definitions.Def_ErdosProblems_Erdos68_ChannelIntegralCongruence
import Definitions.Def_ErdosProblems_Erdos68_PrimeUnitTranslator
import Definitions.Def_ErdosProblems_Erdos68_FactorialGapPlateauCore
import Definitions.Def_ErdosProblems_Erdos68_CompanionConstantBridge
import Definitions.Def_ErdosProblems_Erdos68_ConstantOnlyMissCertificates
import Mathlib.Algebra.BigOperators.Fin
import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Algebra.GCDMonoid.FinsetLemmas
import Mathlib.Algebra.Order.Floor.Ring
import Mathlib.Algebra.Order.Round
import Mathlib.Algebra.Ring.GeomSum
import Mathlib.Analysis.Asymptotics.Defs
import Mathlib.Analysis.Complex.ExponentialBounds
import Mathlib.Analysis.Real.Pi.Bounds
import Mathlib.Analysis.SpecialFunctions.Stirling
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Data.Fin.VecNotation
import Mathlib.Data.Int.Basic
import Mathlib.Data.Nat.Factorial.Basic
import Mathlib.Data.Nat.Factorial.BigOperators
import Mathlib.Data.Nat.ModEq
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.LinearAlgebra.Matrix.Adjugate
import Mathlib.LinearAlgebra.Vandermonde
import Mathlib.NumberTheory.Real.Irrational
import Mathlib.Tactic
import Mathlib.Tactic.FinCases
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.InfiniteSum.Basic
import Mathlib.Topology.Algebra.InfiniteSum.Ring

/-!
# Erdős #68: constant-only miss certificates

Let `C = ∑' n, compConstTerm n`.  The companion carrier has the form

`F_m = m! * C - δ_m`,

where `δ_m` is the positive scaled tail.  Once `0 < δ_m < 1`, subtracting the
tail can move the floor down by at most one.  The correct alternatives are

`⌊F_m⌋ = ⌊m! * C⌋`  or  `⌊F_m⌋ = ⌊m! * C⌋ - 1`.

Consequently it is enough to exclude the two adjacent residues `-2` and `-1`
for `⌊m! * C⌋` modulo `m`.  This formulation deliberately uses two floors of
the same fixed constant; it does not use a ceil, since `⌈J⌉ - 1 = ⌊J⌋` when
`J` is nonintegral and therefore misses the possible downward crossing.

The theorem below is the exact floor/congruence consumer.  A companion-tail
estimate may supply its `F_m = J - δ`, `0 < δ < 1` hypotheses without changing
the arithmetic proof.
-/

namespace ErdosProblems.Erdos68
open scoped BigOperators
end ErdosProblems.Erdos68

open scoped BigOperators
open ErdosProblems in
open ErdosProblems.Erdos68 in
theorem solution
    (m : ℕ) (K E : ℤ) (J r : ℝ)
    (hJ : J = (((m : ℤ) * K - E : ℤ) : ℝ) - r)
    (hrpos : 0 < r) (hrlt : r < 1)
    (hEmod : E % (m : ℤ) = 1) :
    ((⌊J⌋ + 2 : ℤ) % (m : ℤ)) = 0 := by
  have hfloor : ⌊J⌋ = (m : ℤ) * K - E - 1 := by
    rw [hJ]
    apply Int.floor_eq_iff.mpr
    push_cast
    constructor <;> linarith
  rw [hfloor]
  have hE : E = 1 + (m : ℤ) * (E / (m : ℤ)) := by
    have hdiv := Int.emod_add_mul_ediv E (m : ℤ)
    rw [hEmod] at hdiv
    omega
  rw [hE]
  ring_nf
  rw [← mul_sub]
  exact Int.mul_emod_right _ _
