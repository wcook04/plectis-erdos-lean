import Theorems.Thm_ErdosProblems_Erdos68_natRatio_den_eq
import Theorems.Thm_ErdosProblems_Erdos68_reducedDenominator_factorization_eq_iff
import Mathlib.Data.Nat.Factorization.Basic
import Mathlib.Data.Rat.Lemmas

namespace ErdosProblems.Erdos68
end ErdosProblems.Erdos68

/-!
# Prime powers surviving rational denominator reduction

For a positive common denominator `L`, reduction replaces it by `L / gcd B L`.
A prime divisor of `L` retains its full exponent exactly when it does not divide
the numerator `B`. This is the rational-denominator step in maximal-hit
cancellation for a factorial-gap prefix.
-/

open ErdosProblems in
open ErdosProblems.Erdos68 in
theorem solution
    {p B L : ℕ} (hp : p.Prime) (hL : 0 < L) (hpL : p ∣ L) :
    ((B : ℚ) / L).den.factorization p = L.factorization p ↔ ¬p ∣ B := by
  rw [natRatio_den_eq B hL]
  exact reducedDenominator_factorization_eq_iff hp hL hpL
