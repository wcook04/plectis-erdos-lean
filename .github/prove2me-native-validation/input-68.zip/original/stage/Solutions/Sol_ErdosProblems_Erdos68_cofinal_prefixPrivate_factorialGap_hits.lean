import Definitions.Def_ErdosProblems_Erdos68_CanonicalFactorialDigits
import Definitions.Def_ErdosProblems_Erdos68_ChannelBreakpointRigidity
import Definitions.Def_ErdosProblems_Erdos68_ChannelIntegralCongruence
import Definitions.Def_ErdosProblems_Erdos68_PrimeUnitTranslator
import Definitions.Def_ErdosProblems_Erdos68_FactorialGapPlateauCore
import Definitions.Def_ErdosProblems_Erdos68_FactorialChannelCertificate
import Definitions.Def_ErdosProblems_Erdos68_EndpointWeightedPrivateSupport
import Definitions.Def_ErdosProblems_Erdos68_PrimeZeroBranch
import Theorems.Thm_ErdosProblems_Erdos68_exists_large_prefix_private_factorialGap_hit
import Theorems.Thm_ErdosProblems_Erdos68_prime_dvd_factorial_two_before_sub_one
import Lean.Elab.Tactic.Omega
import Mathlib.Algebra.BigOperators.Fin
import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Algebra.GCDMonoid.FinsetLemmas
import Mathlib.Algebra.Order.Floor.Ring
import Mathlib.Algebra.Order.Round
import Mathlib.Algebra.Ring.GeomSum
import Mathlib.Analysis.Asymptotics.Defs
import Mathlib.Analysis.Complex.ExponentialBounds
import Mathlib.Analysis.Real.Pi.Bounds
import Mathlib.Analysis.SpecialFunctions.Stirling
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Data.Fin.VecNotation
import Mathlib.Data.Finsupp.Basic
import Mathlib.Data.Int.Basic
import Mathlib.Data.Int.ModEq
import Mathlib.Data.Nat.Choose.Multinomial
import Mathlib.Data.Nat.Factorial.Basic
import Mathlib.Data.Nat.Factorial.BigOperators
import Mathlib.Data.Nat.Factorization.Basic
import Mathlib.Data.Nat.GCD.BigOperators
import Mathlib.Data.Nat.ModEq
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.Nat.Prime.Factorial
import Mathlib.Data.Nat.Prime.Infinite
import Mathlib.Data.Rat.Lemmas
import Mathlib.Data.ZMod.Factorial
import Mathlib.LinearAlgebra.Matrix.Adjugate
import Mathlib.LinearAlgebra.Vandermonde
import Mathlib.NumberTheory.Divisors
import Mathlib.NumberTheory.Real.Irrational
import Mathlib.NumberTheory.Wilson
import Mathlib.Tactic
import Mathlib.Tactic.FinCases
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.NormNum.NatFactorial
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.InfiniteSum.Basic
import Mathlib.Topology.Algebra.InfiniteSum.Ring

/-!
# Erdős #68: the prime zero branch

This module develops three linked layers of the factorial-gap series.

First, exact prefix identities express the step carry through a binary
endpoint flag and the canonical factorial digit.  A unit carry is therefore
equivalent to one of two endpoint cylinders: a zero digit with two zero
flags, or the maximal digit with two one flags.

Second, reduced predecessor fractions are followed prime by prime.  The
formalized arithmetic includes prefix-private prime powers, accumulated
denominator factors, collision and residual cofactors, and exact finite
records at the primes `107` and `971`.  In particular, prefix-private
factorial-gap hits occur cofinally and the corresponding numerator
projections are nonzero under the stated divisibility hypotheses.

Third, a family of conditional theorems shows that sufficiently large
predecessor residues, supplied cofinally, would force irrationality.  The
module does **not** prove those quantitative lower bounds: a nonzero residue
is not enough.  It therefore proves no unconditional irrationality theorem
and does not settle Erdős #68.
-/

namespace ErdosProblems.Erdos68
/-! ## Scaled tails and endpoint flags -/



















/-! ## The reduced rational predecessor state -/













































































/-! ## Prime-power persistence in consecutive denominators -/



















/-! ## Prefix-private moduli and finite CRT anchors -/























































/-! ## Accumulated private powers across finite intervals -/

























/-! ## Componentwise private-prime sources -/

































































/-! ## Cofinal private hits and reflected collisions -/
end ErdosProblems.Erdos68

open ErdosProblems in
open ErdosProblems.Erdos68 in
theorem solution :
    ∀ B : ℕ, ∃ q m : ℕ,
      B < m ∧
        q.Prime ∧
        m < q ∧
        q ∣ m.factorial - 1 ∧
        ∀ k, 2 ≤ k → k < m →
          Nat.Coprime q (k.factorial - 1) := by
  intro B
  obtain ⟨q, hqLower, hq⟩ :=
    Nat.exists_infinite_primes (B.factorial + 5)
  have hq5 : 5 ≤ q := by
    omega
  have hqHit :
      q ∣ (q - 2).factorial - 1 :=
    prime_dvd_factorial_two_before_sub_one hq hq5
  obtain ⟨m, hm2, hmq, _hmqZero, hmHit, hprefix⟩ :=
    exists_large_prefix_private_factorialGap_hit
      (p := q) (n := q - 2) (C := 0)
      hq (by omega) hqHit (by simpa using hq.pos)
  have hBm : B < m := by
    by_contra hnot
    have hmB : m ≤ B :=
      Nat.le_of_not_gt hnot
    have hfacLe :
        m.factorial ≤ B.factorial :=
      Nat.factorial_le hmB
    have hgapPos :
        0 < m.factorial - 1 :=
      Nat.sub_pos_of_lt (Nat.one_lt_factorial.mpr hm2)
    have hqLe :
        q ≤ m.factorial - 1 :=
      Nat.le_of_dvd hgapPos hmHit
    omega
  exact
    ⟨q, m, hBm, hq, by omega, hmHit, hprefix⟩
