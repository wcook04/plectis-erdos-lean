import Definitions.Def_ErdosProblems_Erdos68_ChannelBreakpointRigidity
import Definitions.Def_ErdosProblems_Erdos68_ChannelIntegralCongruence
import Definitions.Def_ErdosProblems_Erdos68_PrimeUnitTranslator
import Definitions.Def_ErdosProblems_Erdos68_PaperCompleteKernelFloorAlgorithm
import Definitions.Def_ErdosProblems_Erdos68_PaperCompleteDyadicEnclosure
import Theorems.Thm_ErdosProblems_Erdos68_PaperComplete_FiniteLead_kernelFloorBlock_spec
import Init
import Mathlib.Algebra.BigOperators.Fin
import Mathlib.Algebra.BigOperators.Group.Finset.Basic
import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Algebra.GCDMonoid.FinsetLemmas
import Mathlib.Algebra.Order.BigOperators.Group.Finset
import Mathlib.Algebra.Order.Field.Basic
import Mathlib.Algebra.Order.Round
import Mathlib.Algebra.Ring.GeomSum
import Mathlib.Analysis.Asymptotics.Defs
import Mathlib.Analysis.Complex.ExponentialBounds
import Mathlib.Analysis.Real.Pi.Bounds
import Mathlib.Analysis.SpecialFunctions.Stirling
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Data.Fin.VecNotation
import Mathlib.Data.Nat.Factorial.Basic
import Mathlib.Data.Nat.Factorial.BigOperators
import Mathlib.Data.Nat.ModEq
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.LinearAlgebra.Matrix.Adjugate
import Mathlib.LinearAlgebra.Vandermonde
import Mathlib.Order.Interval.Finset.Nat
import Mathlib.Tactic
import Mathlib.Tactic.FinCases
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.InfiniteSum.Basic
import Mathlib.Topology.Algebra.InfiniteSum.Ring

/-!
# Soundness and composition of independently kernel-reduced blocks

All index shifts and interval endpoints are proved symbolically. In particular,
no program outside Lean chooses the terms of the finite sum without a theorem
connecting that choice to `floorPrefix`.

Status: supplied proof candidate; not elaborated in this environment.
-/

namespace ErdosProblems.Erdos68.PaperComplete.FiniteLead
open scoped BigOperators

-- Ascending-factorial APIs below: Mathlib/Data/Nat/Factorial/Basic.lean, pinned source.
end ErdosProblems.Erdos68.PaperComplete.FiniteLead

open scoped BigOperators
open ErdosProblems in
open ErdosProblems.Erdos68 in
open ErdosProblems.Erdos68.PaperComplete in
open ErdosProblems.Erdos68.PaperComplete.FiniteLead in
theorem solution (scale start a b : Nat) :
    kernelFloorBlock scale start (a + b) =
      kernelFloorBlock scale start a + kernelFloorBlock scale (start + a) b := by
  rw [kernelFloorBlock_spec, kernelFloorBlock_spec, kernelFloorBlock_spec]
  -- sum_range_add: Mathlib/Algebra/BigOperators/Group/Finset/Basic.lean.
  rw [Finset.sum_range_add]
  congr 1
  apply Finset.sum_congr rfl
  intro j _
  have hindex : start + (a + j) = start + a + j := (Nat.add_assoc start a j).symm
  rw [hindex]
