import Definitions.Def_ErdosProblems_Erdos68_CanonicalFactorialDigits
import Definitions.Def_ErdosProblems_Erdos68_ChannelBreakpointRigidity
import Definitions.Def_ErdosProblems_Erdos68_ChannelIntegralCongruence
import Definitions.Def_ErdosProblems_Erdos68_PrimeUnitTranslator
import Definitions.Def_ErdosProblems_Erdos68_FactorialGapPlateauCore
import Definitions.Def_ErdosProblems_Erdos68_FactorialChannelCertificate
import Definitions.Def_ErdosProblems_Erdos68_EndpointWeightedPrivateSupport
import Definitions.Def_ErdosProblems_Erdos68_PrimeZeroBranch
import Definitions.Def_ErdosProblems_Erdos68_PrimePoleCriterion
import Theorems.Thm_ErdosProblems_Erdos68_factorialGap_dvd_prefixLCM
import Theorems.Thm_ErdosProblems_Erdos68_finset_lcm_factorization_lt_of_all_lt
import Lean.Elab.Tactic.Omega
import Mathlib.Algebra.BigOperators.Fin
import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Algebra.GCDMonoid.FinsetLemmas
import Mathlib.Algebra.Order.Floor.Ring
import Mathlib.Algebra.Order.Round
import Mathlib.Algebra.Ring.GeomSum
import Mathlib.Analysis.Asymptotics.Defs
import Mathlib.Analysis.Complex.ExponentialBounds
import Mathlib.Analysis.Real.Pi.Bounds
import Mathlib.Analysis.SpecialFunctions.Stirling
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Data.Fin.VecNotation
import Mathlib.Data.Finsupp.Basic
import Mathlib.Data.Int.Basic
import Mathlib.Data.Int.ModEq
import Mathlib.Data.Nat.Choose.Multinomial
import Mathlib.Data.Nat.Factorial.Basic
import Mathlib.Data.Nat.Factorial.BigOperators
import Mathlib.Data.Nat.Factorization.Basic
import Mathlib.Data.Nat.GCD.BigOperators
import Mathlib.Data.Nat.ModEq
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.Nat.Prime.Factorial
import Mathlib.Data.Nat.Prime.Infinite
import Mathlib.Data.Rat.Lemmas
import Mathlib.Data.ZMod.Factorial
import Mathlib.LinearAlgebra.Matrix.Adjugate
import Mathlib.LinearAlgebra.Vandermonde
import Mathlib.NumberTheory.Divisors
import Mathlib.NumberTheory.Real.Irrational
import Mathlib.NumberTheory.Wilson
import Mathlib.Tactic
import Mathlib.Tactic.FinCases
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.NormNum.NatFactorial
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.InfiniteSum.Basic
import Mathlib.Topology.Algebra.InfiniteSum.Ring

namespace ErdosProblems.Erdos68.PaperComplete
end ErdosProblems.Erdos68.PaperComplete

/-!
# End-to-end maximal prime-power survival

Long-record label res:prime-pole. The supplied numerator identity and rational
reduction theorem are not by themselves the displayed theorem. This file
supplies the literal prefix/common-denominator equality, derives the maximum
and attainment hypotheses from the actual LCM, proves its cofactor a unit,
and joins the two existing results. No new analytic premise is used.

-/

namespace ErdosProblems.Erdos68.PaperComplete
open scoped BigOperators

lemma gap_pos {M n : ℕ} (hn : n ∈ Finset.Icc 2 M) :
    0 < n.factorial - 1 :=
  Nat.sub_pos_of_lt (Nat.one_lt_factorial.mpr (Finset.mem_Icc.mp hn).1)

lemma prefix_lcm_pos (M : ℕ) : 0 < factorialGapPrefixLCM M := by
  apply Nat.pos_of_ne_zero
  change (Finset.Icc 2 M).lcm (fun n => n.factorial - 1) ≠ 0
  exact Finset.lcm_ne_zero_iff.mpr (fun n hn => (gap_pos hn).ne')
end ErdosProblems.Erdos68.PaperComplete

open scoped BigOperators
open ErdosProblems in
open ErdosProblems.Erdos68 in
open ErdosProblems.Erdos68.PaperComplete in
theorem solution {M p : ℕ} (hp : p.Prime)
    (hpL : p ∣ factorialGapPrefixLCM M) :
    let e := (factorialGapPrefixLCM M).factorization p
    1 ≤ e ∧
    (∀ n ∈ Finset.Icc 2 M, ¬ p ^ (e + 1) ∣ n.factorial - 1) ∧
    (∃ n ∈ Finset.Icc 2 M, p ^ e ∣ n.factorial - 1) := by
  dsimp only
  let L := factorialGapPrefixLCM M
  let e := L.factorization p
  have hL : L ≠ 0 := (prefix_lcm_pos M).ne'
  have he : 1 ≤ e := (hp.dvd_iff_one_le_factorization hL).mp hpL
  have hmax : ∀ n ∈ Finset.Icc 2 M, ¬ p ^ (e + 1) ∣ n.factorial - 1 := by
    intro n hn hdiv
    have hge := (hp.pow_dvd_iff_le_factorization hL).mp
      (hdiv.trans (factorialGap_dvd_prefixLCM hn))
    change e + 1 ≤ e at hge
    omega
  refine ⟨he, hmax, ?_⟩
  by_contra hnone
  have hlt : ∀ n ∈ Finset.Icc 2 M, (n.factorial - 1).factorization p < e := by
    intro n hn
    apply lt_of_not_ge
    intro hge
    exact hnone ⟨n, hn, (hp.pow_dvd_iff_le_factorization (gap_pos hn).ne').mpr hge⟩
  have hbad := finset_lcm_factorization_lt_of_all_lt
    (show 0 < e by omega) (fun n hn => gap_pos hn) hlt
  change e < e at hbad
  exact (lt_irrefl e) hbad
