import Definitions.Def_ErdosProblems_Erdos68_ChannelBreakpointRigidity
import Definitions.Def_ErdosProblems_Erdos68_ChannelIntegralCongruence
import Definitions.Def_ErdosProblems_Erdos68_PrimeUnitTranslator
import Definitions.Def_ErdosProblems_Erdos68_PaperCompleteKernelFloorAlgorithm
import Definitions.Def_ErdosProblems_Erdos68_FiniteLeadBlocks_Size000
import Definitions.Def_ErdosProblems_Erdos68_FiniteLeadBlocks_Size001
import Definitions.Def_ErdosProblems_Erdos68_PaperCompleteDyadicEnclosure
import Definitions.Def_ErdosProblems_Erdos68_PaperCompleteFiniteLeadArithmetic
import Definitions.Def_ErdosProblems_Erdos68_PaperCompleteFiniteSizeData
import Theorems.Thm_ErdosProblems_Erdos68_PaperComplete_FiniteLead_denominator_bound_of_farey
import Theorems.Thm_ErdosProblems_Erdos68_PaperComplete_FiniteLead_denominator_bound_of_farey_sum
import Theorems.Thm_ErdosProblems_Erdos68_PaperComplete_FiniteLead_kernelFactorial_eq
import Theorems.Thm_ErdosProblems_Erdos68_PaperComplete_FiniteLead_size_floorPrefix_checked
import Init
import Mathlib.Algebra.BigOperators.Fin
import Mathlib.Algebra.BigOperators.Group.Finset.Basic
import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Algebra.GCDMonoid.FinsetLemmas
import Mathlib.Algebra.Order.BigOperators.Group.Finset
import Mathlib.Algebra.Order.Field.Basic
import Mathlib.Algebra.Order.Round
import Mathlib.Algebra.Ring.GeomSum
import Mathlib.Analysis.Asymptotics.Defs
import Mathlib.Analysis.Complex.ExponentialBounds
import Mathlib.Analysis.Real.Pi.Bounds
import Mathlib.Analysis.SpecialFunctions.Stirling
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Data.Fin.VecNotation
import Mathlib.Data.Nat.Factorial.Basic
import Mathlib.Data.Nat.Factorial.BigOperators
import Mathlib.Data.Nat.ModEq
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.LinearAlgebra.Matrix.Adjugate
import Mathlib.LinearAlgebra.Vandermonde
import Mathlib.Order.Interval.Finset.Nat
import Mathlib.Tactic
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.FinCases
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.InfiniteSum.Basic
import Mathlib.Topology.Algebra.InfiniteSum.Ring

namespace ErdosProblems.Erdos68.PaperComplete.FiniteLead.SizeOnly
end ErdosProblems.Erdos68.PaperComplete.FiniteLead.SizeOnly

/-!
# Size-only finite denominator certificate

This branch preserves the returned 80000-bit interval and Farey witnesses,
without importing the 300005-term grid computation. The two floor-block
leaves and each finite comparison below must elaborate before any numerical
exclusion is established. No certificate predicate is assumed by the final
theorem. These source candidates have not yet been kernel checked.
-/

set_option maxRecDepth 1000000
set_option maxHeartbeats 0

namespace ErdosProblems.Erdos68.PaperComplete.FiniteLead.SizeOnly
theorem tail_quotient_checked :
    (2 ^ 80000) / Nat.factorial 7053 = 3 := by
  have hchecked : (2 ^ 80000) / kernelFactorial 7053 = 3 := by decide +kernel
  exact (congrArg (fun d : ℕ => (2 ^ 80000) / d)
    (kernelFactorial_eq 7053).symm).trans hchecked


private theorem upper_eq_of_tail (L C T : ℕ) (hc : C = 7052) (ht : T = 3) :
    L + 7056 = L + C + T + 1 := by
  omega

theorem dyadic_valid_checked : sizeDyadic.Valid := by
  change 2 ≤ 7053 ∧ sizeLower = floorPrefix (2 ^ 80000) 7053 ∧
    sizeLower + 7056 = sizeLower + (Finset.Icc 2 7053).card +
      (2 ^ 80000) / Nat.factorial 7053 + 1
  exact And.intro (by decide) (And.intro size_floorPrefix_checked.symm
    (upper_eq_of_tail sizeLower (Finset.Icc 2 7053).card
      ((2 ^ 80000) / Nat.factorial 7053) (Nat.card_Icc 2 7053)
      tail_quotient_checked))


theorem farey_valid_checked : sizeFarey.Valid sizeDyadic (2 ^ 39990) := by
  decide +kernel





theorem decimal_bound_checked :
    (10 : ℕ) ^ 12040 < sizeFarey.leftDen + sizeFarey.rightDen := by
  decide +kernel
end ErdosProblems.Erdos68.PaperComplete.FiniteLead.SizeOnly

open ErdosProblems in
open ErdosProblems.Erdos68 in
open ErdosProblems.Erdos68.PaperComplete in
open ErdosProblems.Erdos68.PaperComplete.FiniteLead in
open ErdosProblems.Erdos68.PaperComplete.FiniteLead.SizeOnly in
theorem solution
    (a : ℤ) (q : ℕ) (hq : 0 < q)
    (hS : _root_.Erdos68.factorialGapSeries = (a : ℝ) / q) :
    (2 : ℕ) ^ 39990 ≤ q ∧
      sizeFarey.leftDen + sizeFarey.rightDen ≤ q ∧ (10 : ℕ) ^ 12040 < q := by
  have hexact := denominator_bound_of_farey_sum dyadic_valid_checked
    farey_valid_checked a q hq hS
  exact ⟨denominator_bound_of_farey dyadic_valid_checked farey_valid_checked a q hq hS,
    hexact, decimal_bound_checked.trans_le hexact⟩
