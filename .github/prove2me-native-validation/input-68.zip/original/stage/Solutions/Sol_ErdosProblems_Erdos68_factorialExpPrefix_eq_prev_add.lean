import Definitions.Def_ErdosProblems_Erdos68_CanonicalFactorialDigits
import Definitions.Def_ErdosProblems_Erdos68_ChannelBreakpointRigidity
import Definitions.Def_ErdosProblems_Erdos68_ChannelIntegralCongruence
import Definitions.Def_ErdosProblems_Erdos68_PrimeUnitTranslator
import Definitions.Def_ErdosProblems_Erdos68_FactorialGapPlateauCore
import Definitions.Def_ErdosProblems_Erdos68_SecondLayerDigit
import Mathlib.Algebra.BigOperators.Fin
import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Algebra.GCDMonoid.FinsetLemmas
import Mathlib.Algebra.Order.Floor.Ring
import Mathlib.Algebra.Order.Round
import Mathlib.Algebra.Ring.GeomSum
import Mathlib.Analysis.Asymptotics.Defs
import Mathlib.Analysis.Complex.ExponentialBounds
import Mathlib.Analysis.Real.Pi.Bounds
import Mathlib.Analysis.SpecialFunctions.Stirling
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Data.Fin.VecNotation
import Mathlib.Data.Int.Basic
import Mathlib.Data.Nat.Factorial.Basic
import Mathlib.Data.Nat.Factorial.BigOperators
import Mathlib.Data.Nat.ModEq
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.LinearAlgebra.Matrix.Adjugate
import Mathlib.LinearAlgebra.Vandermonde
import Mathlib.NumberTheory.Real.Irrational
import Mathlib.Tactic
import Mathlib.Tactic.FinCases
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.InfiniteSum.Basic
import Mathlib.Topology.Algebra.InfiniteSum.Ring

/-!
# Erdős #68: the exact finite second-layer digit

The elementary split

`1 / (n! - 1) = 1 / n! + 1 / (n! * (n! - 1))`

separates the factorial-gap prefix into the factorial expansion of `e - 2`
and a faster-decaying second layer.  This file proves the exact digit law for
the *finite* second-layer prefix:

`digit_m(prefix₂ m) = m - 1 - factorialGapStepCarry m`.

Passing from that finite prefix to the infinite second-layer sum requires a
separate floor-stability hypothesis at scales `m!` and `(m-1)!`.  Keeping that
hypothesis explicit prevents the invalid inference that a positive tail of
scaled size less than one can never cross the next integer.

The file also records the correct rational factorial-digit boundary: rational
numbers have eventually zero canonical digits, so they cannot have an
eventually maximal canonical tail.
-/

namespace ErdosProblems.Erdos68
open scoped BigOperators
end ErdosProblems.Erdos68

open scoped BigOperators
open ErdosProblems in
open ErdosProblems.Erdos68 in
theorem solution
    {m : ℕ} (hm : 2 ≤ m) :
    factorialExpPrefix m =
      factorialExpPrefix (m - 1) + 1 / (m.factorial : ℚ) := by
  have hset :
      Finset.Icc 2 m = insert m (Finset.Icc 2 (m - 1)) := by
    ext n
    simp only [Finset.mem_Icc, Finset.mem_insert]
    omega
  have hnotmem : m ∉ Finset.Icc 2 (m - 1) := by
    simp only [Finset.mem_Icc]
    omega
  rw [factorialExpPrefix, hset, Finset.sum_insert hnotmem,
    factorialExpPrefix]
  ring
