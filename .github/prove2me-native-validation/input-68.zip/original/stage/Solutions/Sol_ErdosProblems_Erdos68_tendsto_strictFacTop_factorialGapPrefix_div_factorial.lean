import Definitions.Def_ErdosProblems_Erdos68_CanonicalFactorialDigits
import Definitions.Def_ErdosProblems_Erdos68_ChannelBreakpointRigidity
import Definitions.Def_ErdosProblems_Erdos68_ChannelIntegralCongruence
import Definitions.Def_ErdosProblems_Erdos68_PrimeUnitTranslator
import Definitions.Def_ErdosProblems_Erdos68_FactorialGapPlateauCore
import Theorems.Thm_Erdos68_factorialGapSeries_eq_sum_add_tail
import Theorems.Thm_Erdos68_factorialGapTail_lt_one_div_factorial
import Theorems.Thm_Erdos68_factorialGapTail_pos
import Theorems.Thm_ErdosProblems_Erdos68_strictFacTop_div_factorial_bounds
import Theorems.Thm_ErdosProblems_Erdos68_factorialGapPrefix_cast
import Mathlib.Algebra.BigOperators.Fin
import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Algebra.GCDMonoid.FinsetLemmas
import Mathlib.Algebra.Order.Floor.Ring
import Mathlib.Algebra.Order.Round
import Mathlib.Algebra.Ring.GeomSum
import Mathlib.Analysis.Asymptotics.Defs
import Mathlib.Analysis.Complex.ExponentialBounds
import Mathlib.Analysis.Real.Pi.Bounds
import Mathlib.Analysis.SpecialFunctions.Stirling
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Data.Fin.VecNotation
import Mathlib.Data.Int.Basic
import Mathlib.Data.Nat.Factorial.Basic
import Mathlib.Data.Nat.Factorial.BigOperators
import Mathlib.Data.Nat.ModEq
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.LinearAlgebra.Matrix.Adjugate
import Mathlib.LinearAlgebra.Vandermonde
import Mathlib.NumberTheory.Real.Irrational
import Mathlib.Tactic
import Mathlib.Tactic.FinCases
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.InfiniteSum.Basic
import Mathlib.Topology.Algebra.InfiniteSum.Ring

/-!
# Erdős #68: factorial-gap plateau core

Lightweight core for the strict-successor recurrence, carry bounds, and the
exact divisibility criterion.  Heavy exact-index certificates live in
`FactorialZeroPlateauCertificates`; the full plateau file re-exports both.
-/

namespace ErdosProblems.Erdos68
/-! ## Factorial grid arithmetic -/



















/-! ## Exact prefixes and prime-power divisibility -/

















/-! ## The carry recurrence and the exact irrationality criterion -/
end ErdosProblems.Erdos68

open ErdosProblems in
open ErdosProblems.Erdos68 in
theorem solution :
    Filter.Tendsto
      (fun n : ℕ =>
        (strictFacTop
              ((factorialGapPrefix n : ℚ) : ℝ) n : ℝ) /
          (n.factorial : ℝ))
      Filter.atTop
      (nhds _root_.Erdos68.factorialGapSeries) := by
  have hfacTop :
      Filter.Tendsto (fun n : ℕ => (n.factorial : ℝ))
        Filter.atTop Filter.atTop :=
    tendsto_natCast_atTop_atTop.comp factorial_tendsto_atTop
  have hinv :
      Filter.Tendsto (fun n : ℕ => 1 / (n.factorial : ℝ))
        Filter.atTop (nhds 0) := by
    simpa only [one_div] using tendsto_inv_atTop_zero.comp hfacTop
  refine tendsto_of_tendsto_of_tendsto_of_le_of_le'
    (g := fun n : ℕ =>
      _root_.Erdos68.factorialGapSeries -
        1 / (n.factorial : ℝ))
    (h := fun n : ℕ =>
      _root_.Erdos68.factorialGapSeries +
        1 / (n.factorial : ℝ))
    ?_ ?_ ?_ ?_
  · simpa using tendsto_const_nhds.sub hinv
  · simpa using tendsto_const_nhds.add hinv
  · filter_upwards [Filter.eventually_ge_atTop (2 : ℕ)] with n hn
    have hdecomp :=
      _root_.Erdos68.factorialGapSeries_eq_sum_add_tail hn
    have hprefix := factorialGapPrefix_cast n
    rw [← hprefix] at hdecomp
    obtain ⟨hzLower, hzUpper⟩ :=
      strictFacTop_div_factorial_bounds
        (((factorialGapPrefix n : ℚ) : ℝ)) n
    have htailLt :=
      _root_.Erdos68.factorialGapTail_lt_one_div_factorial hn
    linarith
  · filter_upwards [Filter.eventually_ge_atTop (2 : ℕ)] with n hn
    have hdecomp :=
      _root_.Erdos68.factorialGapSeries_eq_sum_add_tail hn
    have hprefix := factorialGapPrefix_cast n
    rw [← hprefix] at hdecomp
    obtain ⟨hzLower, hzUpper⟩ :=
      strictFacTop_div_factorial_bounds
        (((factorialGapPrefix n : ℚ) : ℝ)) n
    have htailPos :=
      _root_.Erdos68.factorialGapTail_pos hn
    linarith
