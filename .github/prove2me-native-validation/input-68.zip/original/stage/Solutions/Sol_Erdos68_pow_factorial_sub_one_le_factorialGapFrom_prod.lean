import Definitions.Def_ErdosProblems_Erdos68_ChannelBreakpointRigidity
import Definitions.Def_ErdosProblems_Erdos68_ChannelIntegralCongruence
import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Algebra.GCDMonoid.FinsetLemmas
import Mathlib.Algebra.Ring.GeomSum
import Mathlib.Analysis.Asymptotics.Defs
import Mathlib.Analysis.Complex.ExponentialBounds
import Mathlib.Analysis.Real.Pi.Bounds
import Mathlib.Analysis.SpecialFunctions.Stirling
import Mathlib.Data.Nat.Factorial.Basic
import Mathlib.Data.Nat.Factorial.BigOperators
import Mathlib.Data.Nat.ModEq
import Mathlib.Tactic.Ring

/-!
# Integral channel congruence for Erdős problem 68

This module compares a channel numerator with the corresponding factorial
moment modulo `d! - 1`.  The congruence holds for every support index, so
simultaneous cancellation of the channels `2, ..., D` makes their least common
multiple divide the factorial moment.

The second part estimates that least common multiple.  Consecutive numbers
`m! - 1` are compared through their pairwise gcds; this gives an explicit
finite lower bound after the gcd losses are counted.  Consequently, if a
positive integer `M` is divisible by the channel lcm and is smaller than
`(R+1)! - 1`, then `R` must grow at least cubically along `D = 2t^2`.  A later
estimate improves the explicit constant to `R+1 > (3/2)t^3` for `t >= 2^32`.

All conclusions after the congruence theorem retain these stated hypotheses.
In particular, this file does not construct `M` or `R` from the series in
Erdős problem 68, prove that its channels vanish, or decide the rationality of
that series.
-/

namespace Erdos68
/-! ## Product versus lcm with explicit gcd loss -/











/-! ## Factorial-gap collision bounds -/







/-! ## Consecutive factorial-gap segments -/
end Erdos68

open Erdos68 in
theorem solution
    (m k : ℕ) :
    (m.factorial - 1) ^ k ≤ (factorialGapFrom m k).prod := by
  induction k generalizing m with
  | zero => simp [factorialGapFrom]
  | succ k ih =>
      rw [factorialGapFrom, List.prod_cons]
      have hfactorial : m.factorial ≤ (m + 1).factorial :=
        Nat.factorial_le (by omega)
      have hgap : m.factorial - 1 ≤ (m + 1).factorial - 1 :=
        Nat.sub_le_sub_right hfactorial 1
      calc
        (m.factorial - 1) ^ (k + 1) =
            (m.factorial - 1) * (m.factorial - 1) ^ k := by
              rw [pow_succ, Nat.mul_comm]
        _ ≤ (m.factorial - 1) * ((m + 1).factorial - 1) ^ k :=
          Nat.mul_le_mul_left _ (Nat.pow_le_pow_left hgap _)
        _ ≤ (m.factorial - 1) * (factorialGapFrom (m + 1) k).prod :=
          Nat.mul_le_mul_left _ (ih (m + 1))
