import Definitions.Def_ErdosProblems_Erdos68_CanonicalFactorialDigits
import Definitions.Def_ErdosProblems_Erdos68_ChannelBreakpointRigidity
import Definitions.Def_ErdosProblems_Erdos68_ChannelIntegralCongruence
import Definitions.Def_ErdosProblems_Erdos68_PrimeUnitTranslator
import Definitions.Def_ErdosProblems_Erdos68_FactorialGapPlateauCore
import Definitions.Def_ErdosProblems_Erdos68_CompanionConstantBridge
import Definitions.Def_ErdosProblems_Erdos68_ConstantOnlyMissCertificates
import Definitions.Def_ErdosProblems_Erdos68_SecondLayerDigit
import Definitions.Def_ErdosProblems_Erdos68_CompanionOrbitRationality
import Theorems.Thm_ErdosProblems_Erdos68_canonicalDigit_lt_radix
import Theorems.Thm_ErdosProblems_Erdos68_canonicalDigit_nonneg
import Mathlib.Algebra.BigOperators.Fin
import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Algebra.GCDMonoid.FinsetLemmas
import Mathlib.Algebra.Order.Floor.Ring
import Mathlib.Algebra.Order.Round
import Mathlib.Algebra.Ring.GeomSum
import Mathlib.Analysis.Asymptotics.Defs
import Mathlib.Analysis.Complex.ExponentialBounds
import Mathlib.Analysis.Real.Pi.Bounds
import Mathlib.Analysis.SpecialFunctions.Stirling
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Data.Fin.VecNotation
import Mathlib.Data.Int.Basic
import Mathlib.Data.Nat.Cast.Field
import Mathlib.Data.Nat.Factorial.Basic
import Mathlib.Data.Nat.Factorial.BigOperators
import Mathlib.Data.Nat.ModEq
import Mathlib.Data.Nat.Multiplicity
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.Rat.Floor
import Mathlib.LinearAlgebra.Matrix.Adjugate
import Mathlib.LinearAlgebra.Vandermonde
import Mathlib.NumberTheory.Real.Irrational
import Mathlib.Tactic
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.FinCases
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.InfiniteSum.Basic
import Mathlib.Topology.Algebra.InfiniteSum.Ring

/-!
# Erdős #68: full companion-orbit rationality boundary

This module promotes the pointwise companion-floor arithmetic to the infinite
rationality statement.  The fixed companion constant is

`C = ∑_{n≥2} 1/(n!(n!−1)) = S - (exp 1 - 2)`.

The target normal form is that `S` is rational exactly when
`⌊m! C⌋ ≡ -2 (mod m)` eventually.  The forward direction uses the positive
sub-unit remainder in the exponential series.  The reverse direction uses
the equivalent canonical digit tail `d_m(C)=m-2` and the telescoping identity

`∑_{m>N} ((m-2)+1)/m! = 1/N!`.

No cofinal escape claim is made here.
-/

namespace ErdosProblems.Erdos68
open scoped BigOperators
end ErdosProblems.Erdos68

open scoped BigOperators
open ErdosProblems in
open ErdosProblems.Erdos68 in
theorem solution (x : ℝ) :
    Summable (canonicalDigitTerm x) := by
  have hmajorant :
      Summable (fun m : ℕ => (m : ℝ) / (m.factorial : ℝ)) := by
    rw [← summable_nat_add_iff 1]
    convert Real.summable_pow_div_factorial 1 using 1
    funext n
    rw [Nat.factorial_succ]
    push_cast
    field_simp
    simp
  refine Summable.of_nonneg_of_le (fun m => ?_) (fun m => ?_) hmajorant
  · by_cases hm : 2 ≤ m
    · rw [canonicalDigitTerm, if_pos hm]
      exact div_nonneg
        (by exact_mod_cast canonicalDigit_nonneg x m (by omega))
        (by positivity)
    · simp [canonicalDigitTerm, hm]
  · by_cases hm : 2 ≤ m
    · rw [canonicalDigitTerm, if_pos hm]
      have hdigit : (canonicalDigit x m : ℝ) ≤ (m : ℝ) := by
        exact_mod_cast (canonicalDigit_lt_radix x m (by omega)).le
      exact div_le_div_of_nonneg_right hdigit (by positivity)
    · simp only [canonicalDigitTerm, if_neg hm]
      exact div_nonneg (by positivity) (by positivity)
