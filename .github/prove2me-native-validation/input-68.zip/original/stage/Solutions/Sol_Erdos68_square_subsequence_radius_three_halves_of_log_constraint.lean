import Definitions.Def_ErdosProblems_Erdos68_ChannelBreakpointRigidity
import Definitions.Def_ErdosProblems_Erdos68_ChannelIntegralCongruence
import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Algebra.GCDMonoid.FinsetLemmas
import Mathlib.Algebra.Ring.GeomSum
import Mathlib.Analysis.Asymptotics.Defs
import Mathlib.Analysis.Complex.ExponentialBounds
import Mathlib.Analysis.Real.Pi.Bounds
import Mathlib.Analysis.SpecialFunctions.Stirling
import Mathlib.Data.Nat.Factorial.Basic
import Mathlib.Data.Nat.Factorial.BigOperators
import Mathlib.Data.Nat.ModEq
import Mathlib.Tactic.Ring

/-!
# Integral channel congruence for Erdős problem 68

This module compares a channel numerator with the corresponding factorial
moment modulo `d! - 1`.  The congruence holds for every support index, so
simultaneous cancellation of the channels `2, ..., D` makes their least common
multiple divide the factorial moment.

The second part estimates that least common multiple.  Consecutive numbers
`m! - 1` are compared through their pairwise gcds; this gives an explicit
finite lower bound after the gcd losses are counted.  Consequently, if a
positive integer `M` is divisible by the channel lcm and is smaller than
`(R+1)! - 1`, then `R` must grow at least cubically along `D = 2t^2`.  A later
estimate improves the explicit constant to `R+1 > (3/2)t^3` for `t >= 2^32`.

All conclusions after the congruence theorem retain these stated hypotheses.
In particular, this file does not construct `M` or `R` from the series in
Erdős problem 68, prove that its channels vanish, or decide the rationality of
that series.
-/

namespace Erdos68
/-! ## Product versus lcm with explicit gcd loss -/











/-! ## Factorial-gap collision bounds -/







/-! ## Consecutive factorial-gap segments -/

































































/-- Cubic upper bound for the collision exponent on the exact square
subsequence `D = 2t²`, `k = 2t`. -/
theorem three_mul_choose_two_mul_add_one_le_four_mul_cube (t : ℕ) :
    3 * (2 * t + 1).choose 3 ≤ 4 * t ^ 3 := by
  cases t with
  | zero => norm_num [Nat.choose]
  | succ t =>
      have hdesc :=
        Nat.descFactorial_eq_factorial_mul_choose (2 * (t + 1) + 1) 3
      have hsub : 2 * (t + 1) + 1 - 2 = 2 * t + 1 := by omega
      norm_num [Nat.descFactorial, Nat.factorial, hsub] at hdesc
      nlinarith
end Erdos68

open Erdos68 in
set_option maxHeartbeats 800000 in

theorem solution
    {t R : ℕ} (ht : 2 ^ 32 ≤ t)
    (hconstraint :
      (2 * t : ℝ) *
          (((2 * t ^ 2 + 1 - 2 * t : ℕ) : ℝ) *
              Real.log ((2 * t ^ 2 + 1 - 2 * t : ℕ) : ℝ) -
            (2 * t ^ 2 + 1 - 2 * t : ℕ) - Real.log 2) <
        ((R + 1 : ℕ) : ℝ) * Real.log (R + 1 : ℝ) +
          (((2 * t + 1).choose 3 : ℕ) : ℝ) *
            Real.log ((2 * t ^ 2 : ℕ) : ℝ)) :
    3 * t ^ 3 < 2 * (R + 1) := by
  have ht32 : 32 ≤ t := by
    have : (32 : ℕ) ≤ 2 ^ 32 := by norm_num
    omega
  have htpos : 0 < t := by omega
  have htone : 1 ≤ t := by omega
  have htReal : (1 : ℝ) ≤ t := by exact_mod_cast htone
  have hlogt : 0 ≤ Real.log (t : ℝ) := Real.log_nonneg htReal
  have hnloNat :
      t ^ 2 ≤ 2 * t ^ 2 + 1 - 2 * t := by
    have : t ^ 2 + 2 * t ≤ 2 * t ^ 2 + 1 := by nlinarith
    omega
  have hnstrongNat :
      15 * t ^ 2 ≤ 8 * (2 * t ^ 2 + 1 - 2 * t) := by
    have : 15 * t ^ 2 + 16 * t ≤ 16 * t ^ 2 + 8 := by nlinarith
    omega
  have hnhiNat :
      2 * t ^ 2 + 1 - 2 * t ≤ 2 * t ^ 2 := by omega
  have hnlo :
      ((t ^ 2 : ℕ) : ℝ) ≤
        ((2 * t ^ 2 + 1 - 2 * t : ℕ) : ℝ) := by
    exact_mod_cast hnloNat
  have hnstrong :
      (15 : ℝ) / 8 * (t : ℝ) ^ 2 ≤
        ((2 * t ^ 2 + 1 - 2 * t : ℕ) : ℝ) := by
    have hcast :
        (15 : ℝ) * (t : ℝ) ^ 2 ≤
          8 * ((2 * t ^ 2 + 1 - 2 * t : ℕ) : ℝ) := by
      exact_mod_cast hnstrongNat
    nlinarith
  have hnhi :
      ((2 * t ^ 2 + 1 - 2 * t : ℕ) : ℝ) ≤
        2 * (t : ℝ) ^ 2 := by
    exact_mod_cast hnhiNat
  have hlogn :
      2 * Real.log (t : ℝ) ≤
        Real.log ((2 * t ^ 2 + 1 - 2 * t : ℕ) : ℝ) := by
    have h :=
      Real.log_le_log (by positivity : (0 : ℝ) < (t ^ 2 : ℕ)) hnlo
    simpa [Nat.cast_pow, Real.log_pow] using h
  have hnlogn :
      ((15 : ℝ) / 8 * (t : ℝ) ^ 2) *
          (2 * Real.log (t : ℝ)) ≤
        ((2 * t ^ 2 + 1 - 2 * t : ℕ) : ℝ) *
          Real.log ((2 * t ^ 2 + 1 - 2 * t : ℕ) : ℝ) := by
    exact mul_le_mul hnstrong hlogn (by positivity) (by positivity)
  have hchooseNat :=
    three_mul_choose_two_mul_add_one_le_four_mul_cube t
  have hchoose :
      (3 : ℝ) * (((2 * t + 1).choose 3 : ℕ) : ℝ) ≤
        4 * (t : ℝ) ^ 3 := by exact_mod_cast hchooseNat
  have hlogD :
      Real.log ((2 * t ^ 2 : ℕ) : ℝ) =
        Real.log 2 + 2 * Real.log (t : ℝ) := by
    norm_num [Nat.cast_mul, Nat.cast_pow, Real.log_mul, Real.log_pow,
      htpos.ne']
  have hlog2pos : 0 < Real.log 2 := Real.log_pos (by norm_num)
  have hlog2lo : (2 : ℝ) / 3 < Real.log 2 :=
    lt_trans (by norm_num) Real.log_two_gt_d9
  have hlog2hi : Real.log 2 < 1 := by
    nlinarith [Real.log_lt_sub_one_of_pos (by norm_num : (0 : ℝ) < 2)
      (by norm_num : (2 : ℝ) ≠ 1)]
  have hlogtlo : 32 * Real.log 2 ≤ Real.log (t : ℝ) := by
    have hpow :
        ((2 : ℝ) ^ 32) ≤ (t : ℝ) := by exact_mod_cast ht
    have h := Real.log_le_log
      (by positivity : (0 : ℝ) < (2 : ℝ) ^ 32) hpow
    simpa [Real.log_pow] using h
  by_contra hnot
  have hsmallNat : 2 * (R + 1) ≤ 3 * t ^ 3 := by omega
  have hsNat : R + 1 ≤ 2 * t ^ 3 := by omega
  have hs :
      ((R + 1 : ℕ) : ℝ) ≤ (3 : ℝ) / 2 * (t : ℝ) ^ 3 := by
    have hcast :
        (2 : ℝ) * ((R + 1 : ℕ) : ℝ) ≤
          3 * (t : ℝ) ^ 3 := by exact_mod_cast hsmallNat
    nlinarith
  have hlogs :
      Real.log (R + 1 : ℝ) ≤
        Real.log 2 + 3 * Real.log (t : ℝ) := by
    have hs' :
        ((R + 1 : ℕ) : ℝ) ≤ 2 * (t : ℝ) ^ 3 := by
      exact_mod_cast hsNat
    have h :=
      Real.log_le_log (by positivity : (0 : ℝ) < (R + 1 : ℕ)) hs'
    rw [Real.log_mul (by norm_num) (by positivity), Real.log_pow] at h
    norm_num at h ⊢
    exact h
  have hradius :
      ((R + 1 : ℕ) : ℝ) * Real.log (R + 1 : ℝ) ≤
        ((3 : ℝ) / 2 * (t : ℝ) ^ 3) *
          (Real.log 2 + 3 * Real.log (t : ℝ)) := by
    have hRone : (1 : ℝ) ≤ (R + 1 : ℝ) := by
      exact_mod_cast Nat.succ_le_succ (Nat.zero_le R)
    have hlogR : 0 ≤ Real.log (R + 1 : ℝ) :=
      Real.log_nonneg hRone
    exact mul_le_mul hs hlogs hlogR (by positivity)
  have hcollision :
      (((2 * t + 1).choose 3 : ℕ) : ℝ) *
          Real.log ((2 * t ^ 2 : ℕ) : ℝ) ≤
        (4 * (t : ℝ) ^ 3 / 3) *
          (Real.log 2 + 2 * Real.log (t : ℝ)) := by
    rw [hlogD]
    have hc :
        (((2 * t + 1).choose 3 : ℕ) : ℝ) ≤
          4 * (t : ℝ) ^ 3 / 3 := by nlinarith
    exact mul_le_mul_of_nonneg_right hc (by positivity)
  have hlhs :
      (15 : ℝ) / 2 * (t : ℝ) ^ 3 * Real.log (t : ℝ) -
          4 * (t : ℝ) ^ 3 - 2 * (t : ℝ) * Real.log 2 ≤
        (2 * t : ℝ) *
          (((2 * t ^ 2 + 1 - 2 * t : ℕ) : ℝ) *
              Real.log ((2 * t ^ 2 + 1 - 2 * t : ℕ) : ℝ) -
            (2 * t ^ 2 + 1 - 2 * t : ℕ) - Real.log 2) := by
    norm_num [Nat.cast_mul, Nat.cast_pow] at hnlogn hnhi ⊢
    nlinarith
  have htLeCube : (t : ℝ) ≤ (t : ℝ) ^ 3 := by
    nlinarith [show (1 : ℝ) ≤ t by exact_mod_cast htone]
  have hlogscaled :
      32 * Real.log 2 * (t : ℝ) ^ 3 ≤
        Real.log (t : ℝ) * (t : ℝ) ^ 3 :=
    mul_le_mul_of_nonneg_right hlogtlo (by positivity)
  have hlog2scaled :
      ((2 : ℝ) / 3) * (t : ℝ) ^ 3 <
        Real.log 2 * (t : ℝ) ^ 3 :=
    mul_lt_mul_of_pos_right hlog2lo (by positivity)
  have hlinear :
      (t : ℝ) * Real.log 2 ≤ (t : ℝ) ^ 3 := by
    have := mul_le_mul htLeCube (le_of_lt hlog2hi)
      (le_of_lt hlog2pos) (by positivity : (0 : ℝ) ≤ (t : ℝ) ^ 3)
    nlinarith
  rw [hlogD] at hcollision
  nlinarith
