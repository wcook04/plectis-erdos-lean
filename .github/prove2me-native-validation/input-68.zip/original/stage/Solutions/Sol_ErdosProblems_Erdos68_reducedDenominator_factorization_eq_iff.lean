import Mathlib.Data.Nat.Factorization.Basic
import Mathlib.Data.Rat.Lemmas

namespace ErdosProblems.Erdos68
end ErdosProblems.Erdos68

/-!
# Prime powers surviving rational denominator reduction

For a positive common denominator `L`, reduction replaces it by `L / gcd B L`.
A prime divisor of `L` retains its full exponent exactly when it does not divide
the numerator `B`. This is the rational-denominator step in maximal-hit
cancellation for a factorial-gap prefix.
-/

open ErdosProblems in
open ErdosProblems.Erdos68 in
theorem solution
    {p B L : ℕ} (hp : p.Prime) (hL : 0 < L) (hpL : p ∣ L) :
    (L / B.gcd L).factorization p = L.factorization p ↔ ¬p ∣ B := by
  have hg : 0 < B.gcd L := Nat.gcd_pos_of_pos_right B hL
  have he : 1 ≤ L.factorization p :=
    (hp.dvd_iff_one_le_factorization hL.ne').mp hpL
  have hdiv := congrArg (fun f : ℕ →₀ ℕ => f p)
    (Nat.factorization_div (Nat.gcd_dvd_right B L))
  change (L / B.gcd L).factorization p =
    L.factorization p - (B.gcd L).factorization p at hdiv
  rw [hdiv]
  have hsub : L.factorization p - (B.gcd L).factorization p =
      L.factorization p ↔ (B.gcd L).factorization p = 0 := by omega
  rw [hsub]
  simp [Nat.factorization_eq_zero_iff, hg.ne', hp, Nat.dvd_gcd_iff, hpL]
