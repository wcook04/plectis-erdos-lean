import Mathlib.Algebra.Order.Floor.Ring
import Mathlib.Data.Nat.Cast.Field
import Mathlib.Data.Nat.Multiplicity
import Mathlib.Data.Rat.Floor
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Ring

namespace ErdosProblems.Erdos68
end ErdosProblems.Erdos68

/-!
# Erdős #68: factorial digits and strict successors

Problem-owned landing surface for exact reductions around
`∑ n ≥ 2, 1 / (n! - 1)`.  No declaration in this module asserts the still-open
irrationality theorem.
-/

open ErdosProblems in
open ErdosProblems.Erdos68 in
theorem solution
    (a : ℤ) {q n : ℕ} (hq : 0 < q) (hqn : q ≤ n) :
    ((n.factorial : ℚ) * ((a : ℚ) / (q : ℚ))) =
      (((n.factorial / q : ℕ) : ℤ) * a : ℤ) := by
  have hqfac : q ∣ n.factorial := Nat.dvd_factorial hq hqn
  have hq0 : (q : ℚ) ≠ 0 := by
    exact Nat.cast_ne_zero.mpr (Nat.ne_of_gt hq)
  have hcastDiv : (((n.factorial / q : ℕ) : ℚ)) =
      (n.factorial : ℚ) / (q : ℚ) :=
    Nat.cast_div hqfac hq0
  calc
    ((n.factorial : ℚ) * ((a : ℚ) / (q : ℚ))) =
        (a : ℚ) * ((n.factorial : ℚ) / (q : ℚ)) := by
      field_simp [hq0]
    _ = (a : ℚ) * ((n.factorial / q : ℕ) : ℚ) := by
      rw [hcastDiv]
    _ = ((((n.factorial / q : ℕ) : ℤ) * a : ℤ) : ℚ) := by
      have h := congrArg (fun z : ℤ => (z : ℚ))
        (mul_comm a ((n.factorial / q : ℕ) : ℤ))
      simpa only [Int.cast_mul, Int.cast_natCast] using h
