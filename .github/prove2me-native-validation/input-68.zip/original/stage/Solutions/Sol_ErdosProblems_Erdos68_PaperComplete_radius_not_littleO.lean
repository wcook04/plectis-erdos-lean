import Definitions.Def_ErdosProblems_Erdos68_CanonicalFactorialDigits
import Definitions.Def_ErdosProblems_Erdos68_ChannelBreakpointRigidity
import Definitions.Def_ErdosProblems_Erdos68_ChannelIntegralCongruence
import Definitions.Def_ErdosProblems_Erdos68_PrimeUnitTranslator
import Definitions.Def_ErdosProblems_Erdos68_FactorialGapPlateauCore
import Definitions.Def_ErdosProblems_Erdos68_CompanionConstantBridge
import Definitions.Def_ErdosProblems_Erdos68_ConstantOnlyMissCertificates
import Definitions.Def_ErdosProblems_Erdos68_SecondLayerDigit
import Definitions.Def_ErdosProblems_Erdos68_CompanionOrbitRationality
import Definitions.Def_ErdosProblems_Erdos68_FactorialChannelCertificate
import Definitions.Def_ErdosProblems_Erdos68_EndpointWeightedPrivateSupport
import Definitions.Def_ErdosProblems_Erdos68_FactorialShiftFamilyOrbit
import Definitions.Def_ErdosProblems_Erdos68_PrimeZeroBranch
import Definitions.Def_ErdosProblems_Erdos68_PrimePoleCriterion
import Theorems.Thm_ErdosProblems_Erdos68_PaperComplete_square_subsequence_radius
import Lean.Elab.Tactic.Omega
import Mathlib.Algebra.BigOperators.Fin
import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Algebra.GCDMonoid.FinsetLemmas
import Mathlib.Algebra.Order.Floor.Ring
import Mathlib.Algebra.Order.Round
import Mathlib.Algebra.Ring.GeomSum
import Mathlib.Analysis.Asymptotics.Defs
import Mathlib.Analysis.Complex.ExponentialBounds
import Mathlib.Analysis.Real.Pi.Bounds
import Mathlib.Analysis.SpecialFunctions.Stirling
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Data.Fin.VecNotation
import Mathlib.Data.Finsupp.Basic
import Mathlib.Data.Int.Basic
import Mathlib.Data.Int.ModEq
import Mathlib.Data.Nat.Cast.Field
import Mathlib.Data.Nat.Choose.Multinomial
import Mathlib.Data.Nat.Factorial.Basic
import Mathlib.Data.Nat.Factorial.BigOperators
import Mathlib.Data.Nat.Factorization.Basic
import Mathlib.Data.Nat.GCD.BigOperators
import Mathlib.Data.Nat.ModEq
import Mathlib.Data.Nat.Multiplicity
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.Nat.Prime.Factorial
import Mathlib.Data.Nat.Prime.Infinite
import Mathlib.Data.Rat.Floor
import Mathlib.Data.Rat.Lemmas
import Mathlib.Data.ZMod.Factorial
import Mathlib.LinearAlgebra.Matrix.Adjugate
import Mathlib.LinearAlgebra.Vandermonde
import Mathlib.NumberTheory.Divisors
import Mathlib.NumberTheory.Real.Irrational
import Mathlib.NumberTheory.Wilson
import Mathlib.Tactic
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.FinCases
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.NormNum.NatFactorial
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.InfiniteSum.Basic
import Mathlib.Topology.Algebra.InfiniteSum.Ring

namespace ErdosProblems.Erdos68.PaperComplete
end ErdosProblems.Erdos68.PaperComplete

/-!
# Paper-complete assemblies for Erdős 68

These declarations group the exact displayed conclusions rather than citing
only one constituent lemma. All mathematical inputs are imported results.
No parent irrationality theorem without its explicit cofinal premise is added.

`¬ Irrational x` is the library's rationality predicate. `facFloor x m` is
`floor (m! * x)`; `strictFacTopRat (factorialGapPrefix m) m` is the paper's Z_m.
-/

namespace ErdosProblems.Erdos68.PaperComplete
open scoped BigOperators





































/-- The sequence conclusions in res:channel-radius require only EVENTUAL
hypotheses, not hypotheses beginning at the numerical threshold. -/
theorem radius_no_eventual_upper (M R : ℕ → ℕ)
    (hH : ∃ T : ℕ, ∀ t : ℕ, T ≤ t →
      0 < M t ∧ _root_.Erdos68.channelLCM (2 * t ^ 2) ∣ M t ∧
      M t < (R t + 1).factorial - 1) :
    ¬ ∃ T : ℕ, ∀ t : ℕ, T ≤ t → 2 * (R t + 1) ≤ 3 * t ^ 3 := by
  obtain ⟨T₀, hT₀⟩ := hH
  rintro ⟨T₁, hT₁⟩
  let t := max (max T₀ T₁) (2 ^ 32)
  have ht₀ : T₀ ≤ t := (Nat.le_max_left T₀ T₁).trans (Nat.le_max_left _ _)
  have ht₁ : T₁ ≤ t := (Nat.le_max_right T₀ T₁).trans (Nat.le_max_left _ _)
  obtain ⟨hpos, hdiv, hsmall⟩ := hT₀ t ht₀
  have hlower := square_subsequence_radius (Nat.le_max_right _ _) hpos hdiv hsmall
  exact (not_lt_of_ge (hT₁ t ht₁)) hlower
end ErdosProblems.Erdos68.PaperComplete

open scoped BigOperators
open ErdosProblems in
open ErdosProblems.Erdos68 in
open ErdosProblems.Erdos68.PaperComplete in
theorem solution (M R : ℕ → ℕ)
    (hH : ∃ T : ℕ, ∀ t : ℕ, T ≤ t →
      0 < M t ∧ _root_.Erdos68.channelLCM (2 * t ^ 2) ∣ M t ∧
      M t < (R t + 1).factorial - 1) :
    ¬ (fun t : ℕ => (R t : ℝ)) =o[Filter.atTop]
      (fun t : ℕ => (t : ℝ) ^ 3) := by
  intro hlittle
  have hbound := hlittle.def (show (0 : ℝ) < 1 / 2 by norm_num)
  have hnat : ∀ᶠ t : ℕ in Filter.atTop, 2 * (R t + 1) ≤ 3 * t ^ 3 := by
    filter_upwards [hbound, Filter.eventually_ge_atTop (1 : ℕ)] with t ht ht1
    have hR : |(R t : ℝ)| = (R t : ℝ) := abs_of_nonneg (by positivity)
    have ht3 : |(t : ℝ) ^ 3| = (t : ℝ) ^ 3 := abs_of_nonneg (by positivity)
    simp only [Real.norm_eq_abs, hR, ht3] at ht
    have hone : (1 : ℝ) ≤ (t : ℝ) ^ 3 := by
      have ht1R : (1 : ℝ) ≤ t := by exact_mod_cast ht1
      exact one_le_pow₀ ht1R
    have hh : (2 : ℝ) * ((R t : ℝ) + 1) ≤ 3 * (t : ℝ) ^ 3 := by nlinarith
    exact_mod_cast hh
  exact radius_no_eventual_upper M R hH (Filter.eventually_atTop.1 hnat)
