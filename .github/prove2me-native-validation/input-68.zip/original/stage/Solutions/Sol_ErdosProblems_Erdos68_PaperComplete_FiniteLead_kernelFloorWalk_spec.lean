import Definitions.Def_ErdosProblems_Erdos68_ChannelBreakpointRigidity
import Definitions.Def_ErdosProblems_Erdos68_ChannelIntegralCongruence
import Definitions.Def_ErdosProblems_Erdos68_PrimeUnitTranslator
import Definitions.Def_ErdosProblems_Erdos68_PaperCompleteKernelFloorAlgorithm
import Definitions.Def_ErdosProblems_Erdos68_PaperCompleteDyadicEnclosure
import Init
import Mathlib.Algebra.BigOperators.Fin
import Mathlib.Algebra.BigOperators.Group.Finset.Basic
import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Algebra.GCDMonoid.FinsetLemmas
import Mathlib.Algebra.Order.BigOperators.Group.Finset
import Mathlib.Algebra.Order.Field.Basic
import Mathlib.Algebra.Order.Round
import Mathlib.Algebra.Ring.GeomSum
import Mathlib.Analysis.Asymptotics.Defs
import Mathlib.Analysis.Complex.ExponentialBounds
import Mathlib.Analysis.Real.Pi.Bounds
import Mathlib.Analysis.SpecialFunctions.Stirling
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Data.Fin.VecNotation
import Mathlib.Data.Nat.Factorial.Basic
import Mathlib.Data.Nat.Factorial.BigOperators
import Mathlib.Data.Nat.ModEq
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.LinearAlgebra.Matrix.Adjugate
import Mathlib.LinearAlgebra.Vandermonde
import Mathlib.Order.Interval.Finset.Nat
import Mathlib.Tactic
import Mathlib.Tactic.FinCases
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.InfiniteSum.Basic
import Mathlib.Topology.Algebra.InfiniteSum.Ring

/-!
# Soundness and composition of independently kernel-reduced blocks

All index shifts and interval endpoints are proved symbolically. In particular,
no program outside Lean chooses the terms of the finite sum without a theorem
connecting that choice to `floorPrefix`.

Status: supplied proof candidate; not elaborated in this environment.
-/

namespace ErdosProblems.Erdos68.PaperComplete.FiniteLead
open scoped BigOperators

-- Ascending-factorial APIs below: Mathlib/Data/Nat/Factorial/Basic.lean, pinned source.
end ErdosProblems.Erdos68.PaperComplete.FiniteLead

open scoped BigOperators
open ErdosProblems in
open ErdosProblems.Erdos68 in
open ErdosProblems.Erdos68.PaperComplete in
open ErdosProblems.Erdos68.PaperComplete.FiniteLead in
theorem solution (scale count start : Nat) :
    kernelFloorWalk scale count start start.factorial =
      ∑ j ∈ Finset.range count, scale / ((start + j).factorial - 1) := by
  induction count generalizing start with
  | zero =>
      -- range_zero: Mathlib/Data/Finset/Range.lean.
      -- sum_empty: Mathlib/Algebra/BigOperators/Group/Finset/Defs.lean.
      simp only [kernelFloorWalk, Finset.range_zero, Finset.sum_empty]
  | succ count ih =>
      -- Nat.factorial_succ: Mathlib/Data/Nat/Factorial/Basic.lean.
      have hfac : (start + 1) * start.factorial = (start + 1).factorial :=
        (Nat.factorial_succ start).symm
      -- sum_range_succ': additive declaration generated from prod_range_succ',
      -- Mathlib/Algebra/BigOperators/Group/Finset/Basic.lean (pinned source).
      have hshift :
          (∑ j ∈ Finset.range count,
            scale / ((start + 1 + j).factorial - 1)) =
          ∑ j ∈ Finset.range count,
            scale / ((start + (j + 1)).factorial - 1) := by
        -- sum_congr: Mathlib/Algebra/BigOperators/Group/Finset/Basic.lean.
        apply Finset.sum_congr rfl
        intro j _
        have hindex : start + 1 + j = start + (j + 1) := by omega
        rw [hindex]
      calc
        kernelFloorWalk scale (count + 1) start start.factorial =
            scale / (start.factorial - 1) +
              kernelFloorWalk scale count (start + 1) ((start + 1) * start.factorial) := rfl
        _ = scale / (start.factorial - 1) +
              ∑ j ∈ Finset.range count,
                scale / ((start + (j + 1)).factorial - 1) := by
            rw [hfac, ih, hshift]
        _ = ∑ j ∈ Finset.range (count + 1),
              scale / ((start + j).factorial - 1) := by
            rw [Finset.sum_range_succ']
            simp only [Nat.add_zero, Nat.add_comm]
