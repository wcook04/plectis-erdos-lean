import Definitions.Def_ErdosProblems_Erdos68_CanonicalFactorialDigits
import Definitions.Def_ErdosProblems_Erdos68_ChannelBreakpointRigidity
import Definitions.Def_ErdosProblems_Erdos68_ChannelIntegralCongruence
import Definitions.Def_ErdosProblems_Erdos68_PrimeUnitTranslator
import Definitions.Def_ErdosProblems_Erdos68_FactorialGapPlateauCore
import Definitions.Def_ErdosProblems_Erdos68_CompanionConstantBridge
import Definitions.Def_ErdosProblems_Erdos68_ConstantOnlyMissCertificates
import Definitions.Def_ErdosProblems_Erdos68_SecondLayerDigit
import Definitions.Def_ErdosProblems_Erdos68_CompanionOrbitRationality
import Theorems.Thm_Erdos68_hasSum_factorial_telescope
import Theorems.Thm_ErdosProblems_Erdos68_summable_unitFactTerm
import Theorems.Thm_ErdosProblems_Erdos68_factorial_mul_expPrefix_eq_scaled
import Theorems.Thm_ErdosProblems_Erdos68_factorialExpScaled_step
import Theorems.Thm_ErdosProblems_Erdos68_factorial_scaled_rational_eq_intCast
import Theorems.Thm_ErdosProblems_Erdos68_floor_mod_eq_neg_two_of_mul_sub_int_sub_small
import Mathlib.Algebra.BigOperators.Fin
import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Algebra.GCDMonoid.FinsetLemmas
import Mathlib.Algebra.Order.Floor.Ring
import Mathlib.Algebra.Order.Round
import Mathlib.Algebra.Ring.GeomSum
import Mathlib.Analysis.Asymptotics.Defs
import Mathlib.Analysis.Complex.ExponentialBounds
import Mathlib.Analysis.Real.Pi.Bounds
import Mathlib.Analysis.SpecialFunctions.Stirling
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Data.Fin.VecNotation
import Mathlib.Data.Int.Basic
import Mathlib.Data.Nat.Cast.Field
import Mathlib.Data.Nat.Factorial.Basic
import Mathlib.Data.Nat.Factorial.BigOperators
import Mathlib.Data.Nat.ModEq
import Mathlib.Data.Nat.Multiplicity
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.Rat.Floor
import Mathlib.LinearAlgebra.Matrix.Adjugate
import Mathlib.LinearAlgebra.Vandermonde
import Mathlib.NumberTheory.Real.Irrational
import Mathlib.Tactic
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.FinCases
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.InfiniteSum.Basic
import Mathlib.Topology.Algebra.InfiniteSum.Ring

/-!
# Erdős #68: full companion-orbit rationality boundary

This module promotes the pointwise companion-floor arithmetic to the infinite
rationality statement.  The fixed companion constant is

`C = ∑_{n≥2} 1/(n!(n!−1)) = S - (exp 1 - 2)`.

The target normal form is that `S` is rational exactly when
`⌊m! C⌋ ≡ -2 (mod m)` eventually.  The forward direction uses the positive
sub-unit remainder in the exponential series.  The reverse direction uses
the equivalent canonical digit tail `d_m(C)=m-2` and the telescoping identity

`∑_{m>N} ((m-2)+1)/m! = 1/N!`.

No cofinal escape claim is made here.
-/

namespace ErdosProblems.Erdos68
open scoped BigOperators

















theorem summable_unitFactTail (m : ℕ) :
    Summable (fun k : ℕ => (1 : ℝ) / ((m + 1 + k).factorial : ℝ)) := by
  have h : Summable (fun n : ℕ => (1 : ℝ) / (n.factorial : ℝ)) := by
    simpa using Real.summable_pow_div_factorial 1
  have hs := (summable_nat_add_iff (m + 1)).2 h
  simpa [Nat.add_assoc, Nat.add_comm, Nat.add_left_comm] using hs

theorem unitFactTail_pos (m : ℕ) : 0 < unitFactTail m := by
  exact (summable_unitFactTail m).tsum_pos (fun k => by positivity) 0 (by positivity)

private theorem unitFactTail_term_lt_telescope {m k : ℕ} (hm : 2 ≤ m) :
    (1 : ℝ) / ((m + 1 + k).factorial : ℝ) <
      1 / ((m + k).factorial : ℝ) - 1 / ((m + k + 1).factorial : ℝ) := by
  have hidx : m + 1 + k = m + k + 1 := by omega
  rw [hidx]
  have hfacNat : (m + k + 1).factorial =
      (m + k + 1) * (m + k).factorial := Nat.factorial_succ (m + k)
  have hfac : ((m + k + 1).factorial : ℝ) =
      (m + k + 1 : ℝ) * ((m + k).factorial : ℝ) := by
    exact_mod_cast hfacNat
  rw [hfac]
  have hA : (0 : ℝ) < ((m + k).factorial : ℝ) := by positivity
  have hB : (0 : ℝ) < (m + k + 1 : ℝ) := by positivity
  have hmk : (2 : ℝ) ≤ m + k := by
    exact_mod_cast (show 2 ≤ m + k by omega)
  field_simp
  nlinarith

theorem unitFactTail_lt_one_div_factorial {m : ℕ} (hm : 2 ≤ m) :
    unitFactTail m < (1 : ℝ) / (m.factorial : ℝ) := by
  let source : ℕ → ℝ := fun k => (1 : ℝ) / ((m + 1 + k).factorial : ℝ)
  let majorant : ℕ → ℝ := fun k =>
    (1 : ℝ) / ((m + k).factorial : ℝ) - 1 / ((m + k + 1).factorial : ℝ)
  have hsource_nonneg : ∀ k, 0 ≤ source k := by
    intro k
    simp only [source]
    positivity
  have hle : ∀ k, source k ≤ majorant k := by
    intro k
    exact (unitFactTail_term_lt_telescope (m := m) (k := k) hm).le
  have hstrict : source 0 < majorant 0 :=
    unitFactTail_term_lt_telescope (m := m) (k := 0) hm
  have hmajorant : Summable majorant := by
    simpa [majorant, Nat.add_assoc] using
      (_root_.Erdos68.hasSum_factorial_telescope m).summable
  have hsum := Summable.tsum_lt_tsum_of_nonneg (i := 0)
    hsource_nonneg hle hstrict hmajorant
  have hmajValue : (∑' k, majorant k) = (1 : ℝ) / (m.factorial : ℝ) :=
    (_root_.Erdos68.hasSum_factorial_telescope m).tsum_eq
  rw [hmajValue] at hsum
  simpa [unitFactTail, source] using hsum

theorem unitFactScaledTail_pos_lt_one {m : ℕ} (hm : 2 ≤ m) :
    0 < unitFactScaledTail m ∧ unitFactScaledTail m < 1 := by
  have hfac : (0 : ℝ) < (m.factorial : ℝ) := by positivity
  constructor
  · exact mul_pos hfac (unitFactTail_pos m)
  · unfold unitFactScaledTail
    calc
      (m.factorial : ℝ) * unitFactTail m <
          (m.factorial : ℝ) * (1 / (m.factorial : ℝ)) :=
        mul_lt_mul_of_pos_left (unitFactTail_lt_one_div_factorial hm) hfac
      _ = 1 := by field_simp

theorem unitFact_tsum_eq_expPrefix_add_tail (m : ℕ) (hm : 2 ≤ m) :
    (∑' n : ℕ, unitFactTerm n) =
      (factorialExpPrefix m : ℝ) + unitFactTail m := by
  have hsplit := summable_unitFactTerm.sum_add_tsum_nat_add (m + 1)
  rw [← hsplit]
  congr 1
  · have hset : Finset.Icc 2 m =
        (Finset.range (m + 1)).filter (fun n => 2 ≤ n) := by
      ext n
      simp only [Finset.mem_Icc, Finset.mem_filter, Finset.mem_range]
      omega
    calc
      ∑ n ∈ Finset.range (m + 1), unitFactTerm n =
          ∑ n ∈ Finset.Icc 2 m, (1 : ℝ) / (n.factorial : ℝ) := by
        rw [hset, Finset.sum_filter]
        apply Finset.sum_congr rfl
        intro n hn
        by_cases h2 : 2 ≤ n
        · simp [unitFactTerm, h2]
        · simp [unitFactTerm, h2]
      _ = (factorialExpPrefix m : ℝ) := by
        unfold factorialExpPrefix
        push_cast
        rfl
  · unfold unitFactTail
    apply tsum_congr
    intro k
    have hk : 2 ≤ k + (m + 1) := by omega
    rw [unitFactTerm, if_pos hk]
    congr 3 <;> omega

theorem unitFact_tsum_scaled_decomposition (m : ℕ) (hm : 2 ≤ m) :
    (m.factorial : ℝ) * (∑' n : ℕ, unitFactTerm n) =
      (factorialExpScaled m : ℝ) + unitFactScaledTail m := by
  rw [unitFact_tsum_eq_expPrefix_add_tail m hm, mul_add]
  unfold unitFactScaledTail
  congr 1
  have h := factorial_mul_expPrefix_eq_scaled m
  exact_mod_cast h
end ErdosProblems.Erdos68

open scoped BigOperators
open ErdosProblems in
open ErdosProblems.Erdos68 in
theorem solution
    (x : ℝ) (hrat : ¬ Irrational (x + ∑' n, unitFactTerm n)) :
    ∃ M, ∀ m, M ≤ m → ((facFloor x m + 2 : ℤ) % (m : ℤ)) = 0 := by
  obtain ⟨r, hr⟩ := exists_rat_of_not_irrational hrat
  refine ⟨max 3 (r.den + 1), ?_⟩
  intro m hm
  have hm3 : 3 ≤ m := by omega
  have hqm1 : r.den ≤ m - 1 := by omega
  let K : ℤ := (((m - 1).factorial / r.den : ℕ) : ℤ) * r.num
  have hclearQ := factorial_scaled_rational_eq_intCast r.num r.den_pos hqm1
  have hpredScaled :
      ((m - 1).factorial : ℝ) * (x + ∑' n, unitFactTerm n) = (K : ℝ) := by
    rw [hr, Rat.cast_def]
    exact_mod_cast hclearQ
  have hfacNat : m.factorial = m * (m - 1).factorial := by
    have hi : m - 1 + 1 = m := by omega
    simpa only [hi] using Nat.factorial_succ (m - 1)
  have htotalScaled :
      (m.factorial : ℝ) * (x + ∑' n, unitFactTerm n) =
        (((m : ℤ) * K : ℤ) : ℝ) := by
    rw [show (m.factorial : ℝ) =
      (m : ℝ) * ((m - 1).factorial : ℝ) by exact_mod_cast hfacNat]
    push_cast
    rw [mul_assoc, hpredScaled]
  have hunitScaled := unitFact_tsum_scaled_decomposition m (by omega)
  have hJ :
      (m.factorial : ℝ) * x =
        (((m : ℤ) * K - (factorialExpScaled m : ℤ) : ℤ) : ℝ) -
          unitFactScaledTail m := by
    push_cast at htotalScaled hunitScaled ⊢
    linarith
  obtain ⟨hrpos, hrlt⟩ := unitFactScaledTail_pos_lt_one (m := m) (by omega)
  have hs := factorialExpScaled_step (m := m) (by omega)
  have hsZ : (factorialExpScaled m : ℤ) =
      (m : ℤ) * (factorialExpScaled (m - 1) : ℤ) + 1 := by
    exact_mod_cast hs
  have hEmod : (factorialExpScaled m : ℤ) % (m : ℤ) = 1 := by
    rw [hsZ]
    calc
      ((m : ℤ) * (factorialExpScaled (m - 1) : ℤ) + 1) % (m : ℤ) =
          (1 + (factorialExpScaled (m - 1) : ℤ) * (m : ℤ)) % (m : ℤ) := by
        congr 1
        ring
      _ = 1 % (m : ℤ) := by rw [Int.add_mul_emod_self_right]
      _ = 1 := Int.emod_eq_of_lt (by omega)
        (by exact_mod_cast (show 1 < m by omega))
  have h := floor_mod_eq_neg_two_of_mul_sub_int_sub_small m K
    (factorialExpScaled m : ℤ) ((m.factorial : ℝ) * x)
    (unitFactScaledTail m) hJ hrpos hrlt hEmod
  simpa [facFloor] using h
