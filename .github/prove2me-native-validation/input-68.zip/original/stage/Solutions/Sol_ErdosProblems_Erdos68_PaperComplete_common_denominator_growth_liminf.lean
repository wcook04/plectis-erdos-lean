import Definitions.Def_ErdosProblems_Erdos68_ChannelBreakpointRigidity
import Definitions.Def_ErdosProblems_Erdos68_ChannelIntegralCongruence
import Definitions.Def_ErdosProblems_Erdos68_PaperCompleteAsymptotics
import Definitions.Def_ErdosProblems_Erdos68_PaperCompleteRadiusLimit
import Theorems.Thm_ErdosProblems_Erdos68_PaperComplete_lowerLimitAtLeast_iff_ereal
import Theorems.Thm_ErdosProblems_Erdos68_PaperComplete_common_denominator_growth
import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Algebra.GCDMonoid.FinsetLemmas
import Mathlib.Algebra.Ring.GeomSum
import Mathlib.Analysis.Asymptotics.Defs
import Mathlib.Analysis.Complex.ExponentialBounds
import Mathlib.Analysis.Real.Pi.Bounds
import Mathlib.Analysis.SpecialFunctions.Log.Basic
import Mathlib.Analysis.SpecialFunctions.Pow.Real
import Mathlib.Analysis.SpecialFunctions.Sqrt
import Mathlib.Analysis.SpecialFunctions.Stirling
import Mathlib.Data.EReal.Basic
import Mathlib.Data.Nat.Factorial.Basic
import Mathlib.Data.Nat.Factorial.BigOperators
import Mathlib.Data.Nat.ModEq
import Mathlib.Order.LiminfLimsup
import Mathlib.Tactic
import Mathlib.Tactic.Ring
import Mathlib.Topology.Order.Basic

/-!
# Literal liminf statements, without silently assuming finite liminf values

The displayed asymptotic theorems allow the value +infinity. The wrappers use
EReal for the liminf and prove equivalence with the epsilon/eventual assertions
in the main proof files. Thus no unproved upper-boundedness assumption is
introduced merely to fit a real-valued liminf API.

-/

namespace ErdosProblems.Erdos68.PaperComplete
open Filter
open scoped Topology



lemma three_halves_power {x : ℝ} (hx : 0 < x) :
    x ^ ((3 : ℝ) / 2) = x * Real.sqrt x := by
  rw [show (3 : ℝ) / 2 = 1 + 1 / 2 by norm_num,
    Real.rpow_add hx, Real.rpow_one, ← Real.sqrt_eq_rpow]
end ErdosProblems.Erdos68.PaperComplete

open Filter
open scoped Topology
open ErdosProblems in
open ErdosProblems.Erdos68 in
open ErdosProblems.Erdos68.PaperComplete in
theorem solution :
    ((2 * Real.sqrt 2 / 3 : ℝ) : EReal) ≤
      Filter.liminf (fun N : ℕ =>
        ((Real.log (_root_.Erdos68.channelLCM N : ℝ) /
          ((N : ℝ) ^ ((3 : ℝ) / 2) * Real.log (N : ℝ)) : ℝ) : EReal)) atTop := by
  apply (lowerLimitAtLeast_iff_ereal _ _).mp
  intro a ha
  filter_upwards [common_denominator_growth a ha, eventually_ge_atTop 1] with N hN hpos
  have hn : (0 : ℝ) < N := by exact_mod_cast (show 0 < N by omega)
  rwa [three_halves_power hn]
