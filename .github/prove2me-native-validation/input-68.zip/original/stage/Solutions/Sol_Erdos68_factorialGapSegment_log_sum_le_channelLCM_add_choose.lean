import Definitions.Def_ErdosProblems_Erdos68_ChannelBreakpointRigidity
import Definitions.Def_ErdosProblems_Erdos68_ChannelIntegralCongruence
import Theorems.Thm_Erdos68_channelLCM_pos
import Theorems.Thm_Erdos68_factorialGapSegment_prod_le_channelLCM_mul_pow_choose
import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Algebra.GCDMonoid.FinsetLemmas
import Mathlib.Algebra.Ring.GeomSum
import Mathlib.Analysis.Asymptotics.Defs
import Mathlib.Analysis.Complex.ExponentialBounds
import Mathlib.Analysis.Real.Pi.Bounds
import Mathlib.Analysis.SpecialFunctions.Stirling
import Mathlib.Data.Nat.Factorial.Basic
import Mathlib.Data.Nat.Factorial.BigOperators
import Mathlib.Data.Nat.ModEq
import Mathlib.Tactic.Ring

/-!
# Integral channel congruence for Erdős problem 68

This module compares a channel numerator with the corresponding factorial
moment modulo `d! - 1`.  The congruence holds for every support index, so
simultaneous cancellation of the channels `2, ..., D` makes their least common
multiple divide the factorial moment.

The second part estimates that least common multiple.  Consecutive numbers
`m! - 1` are compared through their pairwise gcds; this gives an explicit
finite lower bound after the gcd losses are counted.  Consequently, if a
positive integer `M` is divisible by the channel lcm and is smaller than
`(R+1)! - 1`, then `R` must grow at least cubically along `D = 2t^2`.  A later
estimate improves the explicit constant to `R+1 > (3/2)t^3` for `t >= 2^32`.

All conclusions after the congruence theorem retain these stated hypotheses.
In particular, this file does not construct `M` or `R` from the series in
Erdős problem 68, prove that its channels vanish, or decide the rationality of
that series.
-/

namespace Erdos68
/-! ## Product versus lcm with explicit gcd loss -/











/-! ## Factorial-gap collision bounds -/







/-! ## Consecutive factorial-gap segments -/





















theorem factorialGapFrom_mem_pos
    {m k x : ℕ} (hm : 2 ≤ m) (hx : x ∈ factorialGapFrom m k) :
    0 < x := by
  induction k generalizing m with
  | zero => simp [factorialGapFrom] at hx
  | succ k ih =>
      simp only [factorialGapFrom, List.mem_cons] at hx
      rcases hx with rfl | hx
      · exact Nat.sub_pos_of_lt (Nat.one_lt_factorial.mpr (by omega))
      · exact ih (m := m + 1) (by omega) hx

theorem factorialGapFrom_prod_pos {m k : ℕ} (hm : 2 ≤ m) :
    0 < (factorialGapFrom m k).prod :=
  List.prod_pos (fun _ hx ↦ factorialGapFrom_mem_pos hm hx)
































































/-! Additive exact paper correspondence, source commit c129ac97dcbc6a8218ba5f736aeb525c1652f8a5. -/


theorem factorialGapFrom_prod_eq_prod_range (m k : ℕ) :
    (factorialGapFrom m k).prod =
      ∏ i ∈ Finset.range k, ((m + i).factorial - 1) := by
  induction k generalizing m with
  | zero => simp [factorialGapFrom]
  | succ k ih =>
      rw [factorialGapFrom, List.prod_cons, Finset.prod_range_succ']
      simpa [Nat.add_assoc, Nat.add_comm, Nat.add_left_comm, Nat.mul_comm] using
        congrArg (fun x => (m.factorial - 1) * x) (ih (m + 1))
end Erdos68

open Erdos68 in
theorem solution
    {D k : ℕ} (hkD : k < D) :
    (∑ n ∈ Finset.Ico (D + 1 - k) (D + 1),
      Real.log ((n.factorial - 1 : ℕ) : ℝ)) ≤
      Real.log (channelLCM D : ℝ) +
        (((k + 1).choose 3 : ℕ) : ℝ) * Real.log (D : ℝ) := by
  have hDpos : (0 : ℝ) < D := by exact_mod_cast (show 0 < D by omega)
  have hnat := factorialGapSegment_prod_le_channelLCM_mul_pow_choose hkD
  have hbase : 2 ≤ D + 1 - k := by omega
  have hpos := factorialGapFrom_prod_pos (k := k) hbase
  have hcast : ((factorialGapSegment D k).prod : ℝ) ≤
      (channelLCM D : ℝ) * (D : ℝ) ^ ((k + 1).choose 3) := by
    exact_mod_cast hnat
  have hlog := Real.log_le_log
    (by exact_mod_cast hpos : (0 : ℝ) < (factorialGapSegment D k).prod) hcast
  have hprod : ((factorialGapSegment D k).prod : ℝ) =
      ∏ i ∈ Finset.range k, (((D + 1 - k + i).factorial - 1 : ℕ) : ℝ) := by
    rw [factorialGapSegment, factorialGapFrom_prod_eq_prod_range, Nat.cast_prod]
  rw [hprod, Real.log_prod (fun i _ => by
    have hp : 0 < (D + 1 - k + i).factorial - 1 :=
      Nat.sub_pos_of_lt (Nat.one_lt_factorial.mpr (by omega))
    exact_mod_cast hp.ne'),
    Real.log_mul (by exact_mod_cast (channelLCM_pos D).ne') (by positivity),
    Real.log_pow] at hlog
  rw [Finset.sum_Ico_eq_sum_range]
  have hlen : D + 1 - (D + 1 - k) = k := by omega
  simpa only [hlen] using hlog
