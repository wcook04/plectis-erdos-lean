import Definitions.Def_ErdosProblems_Erdos68_CanonicalFactorialDigits
import Definitions.Def_ErdosProblems_Erdos68_ChannelBreakpointRigidity
import Definitions.Def_ErdosProblems_Erdos68_ChannelIntegralCongruence
import Definitions.Def_ErdosProblems_Erdos68_PrimeUnitTranslator
import Definitions.Def_ErdosProblems_Erdos68_FactorialGapPlateauCore
import Definitions.Def_ErdosProblems_Erdos68_FactorialChannelCertificate
import Definitions.Def_ErdosProblems_Erdos68_EndpointWeightedPrivateSupport
import Theorems.Thm_ErdosProblems_Erdos68_endpointNumerator_div_endpointDenominatorLcm
import Lean.Elab.Tactic.Omega
import Mathlib.Algebra.BigOperators.Fin
import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Algebra.GCDMonoid.FinsetLemmas
import Mathlib.Algebra.Order.Floor.Ring
import Mathlib.Algebra.Order.Round
import Mathlib.Algebra.Ring.GeomSum
import Mathlib.Analysis.Asymptotics.Defs
import Mathlib.Analysis.Complex.ExponentialBounds
import Mathlib.Analysis.Real.Pi.Bounds
import Mathlib.Analysis.SpecialFunctions.Stirling
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Data.Fin.VecNotation
import Mathlib.Data.Finsupp.Basic
import Mathlib.Data.Int.Basic
import Mathlib.Data.Int.ModEq
import Mathlib.Data.Nat.Choose.Multinomial
import Mathlib.Data.Nat.Factorial.Basic
import Mathlib.Data.Nat.Factorial.BigOperators
import Mathlib.Data.Nat.Factorization.Basic
import Mathlib.Data.Nat.GCD.BigOperators
import Mathlib.Data.Nat.ModEq
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.Nat.Prime.Factorial
import Mathlib.Data.Rat.Lemmas
import Mathlib.LinearAlgebra.Matrix.Adjugate
import Mathlib.LinearAlgebra.Vandermonde
import Mathlib.NumberTheory.Divisors
import Mathlib.NumberTheory.Real.Irrational
import Mathlib.Tactic
import Mathlib.Tactic.FinCases
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.NormNum.NatFactorial
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.InfiniteSum.Basic
import Mathlib.Topology.Algebra.InfiniteSum.Ring

/-!
# Erdős #68: collision cores, private residues, and factorial-block endpoints

For a finite denominator family, the pairwise collision core records the
prime powers shared by at least two denominators.  Dividing each denominator
by its part inside this core produces pairwise-coprime private quotients.
Their product is the private modulus `R`; a weighted leave-one-out numerator
is coprime to `R`, so the displayed endpoint numerator has a nonzero residue
whenever `R > 1`.

The abstract part of the file develops these finite gcd, lcm, CRT, and
projection identities.  The factorial-block specialization takes the
denominators `n! - 1` for `p ≤ n < 2p`, identifies the strict-successor
coefficient at `p - 1`, and defines an endpoint window.  Unit carries on the
whole interval `[p,2p]` force that window; so does any rational value whose
denominator is already cleared by `(p-1)!`.

The later theorems give several exact ways to refute the window: a large
private residue, unequal leave-one-out projections, coprime factor-pair
floors, or a uniquely supported prime with a sufficiently large residue.
Cofinal families of any of the stated certificates imply cofinally many
non-unit carries or rational-prefix divisibility failures, and hence imply
irrationality through the earlier carry criterion.

Every irrationality conclusion in this file is conditional.  No theorem
constructs the required cofinal certificate family, proves the needed
projection disagreement or size inequality for arbitrarily large blocks,
or supplies cofinally many uniquely supported factorial-gap primes.  The
finite CRT identities and endpoint reductions therefore do not by themselves
prove the irrationality of the factorial-gap series or solve Erdős #68.
-/

namespace ErdosProblems.Erdos68
/-! ## Collision cores for finite denominator families -/



















































































/-! ## Private quotients and weighted CRT numerators -/



































































/-! ## Endpoint residues and finite projection bounds -/



































































/-! ## The factorial-block endpoint window -/









































































/-! ## Normalized collision arithmetic in a factorial block -/

/-- Casting a factorial-gap denominator into the rationals
recovers the denominator appearing in the Erdős #68 prefix. -/
theorem factorialGapDenominator_cast
    {n : ℕ} :
    (factorialGapDenominator n : ℚ) =
      (n.factorial : ℚ) - 1 := by
  unfold factorialGapDenominator
  rw [Nat.cast_sub (Nat.succ_le_of_lt (Nat.factorial_pos n))]
  norm_num

/-- The reciprocal sum over the literal prime block is exactly the actual
factorial-gap prefix through `2p-1`. -/
theorem factorialBlock_reciprocalSum_eq_factorialGapPrefix
    {p : ℕ} :
    (∑ n ∈ factorialBlockIndices p,
        1 / (factorialGapDenominator n : ℚ)) =
      factorialGapPrefix (2 * p - 1) := by
  unfold factorialBlockIndices factorialGapPrefix
  apply Finset.sum_congr rfl
  intro n _
  rw [factorialGapDenominator_cast]

/-- Every literal block denominator is positive. -/
theorem factorialGapDenominator_pos_of_mem
    {p n : ℕ}
    (hn : n ∈ factorialBlockIndices p) :
    0 < factorialGapDenominator n := by
  have hn2 : 2 ≤ n :=
    (Finset.mem_Icc.mp hn).1
  exact Nat.sub_pos_of_lt ((Nat.one_lt_factorial).2 hn2)































































/-! ## Leave-one-out and factor-pair projection bounds -/

































/-! ## Prime-power incidence and uniquely supported factors -/
end ErdosProblems.Erdos68

open ErdosProblems in
open ErdosProblems.Erdos68 in
theorem solution
    {p : ℕ}
    (htail :
      factorialBlockTailNumerator p ≤
        factorialBlockBaseNumerator p) :
    (factorialBlockEndpointNumerator p : ℚ) /
        factorialBlockEndpointLcm p =
      factorialBlockEndpointGap p := by
  have hident :=
    endpointNumerator_div_endpointDenominatorLcm
      (K := factorialBlockCoefficient p)
      (base := factorialBlockBase p)
      (s := factorialBlockIndices p)
      (d := factorialGapDenominator)
      (Nat.factorial_pos _)
      (fun n hn => factorialGapDenominator_pos_of_mem hn)
      htail
  rw [factorialBlock_reciprocalSum_eq_factorialGapPrefix] at hident
  simpa [
    factorialBlockEndpointNumerator,
    factorialBlockEndpointLcm,
    factorialBlockEndpointGap
  ] using hident
