import Definitions.Def_ErdosProblems_Erdos68_ChannelBreakpointRigidity
import Definitions.Def_ErdosProblems_Erdos68_ChannelIntegralCongruence
import Definitions.Def_ErdosProblems_Erdos68_PrimeUnitTranslator
import Mathlib.Algebra.BigOperators.Fin
import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Algebra.GCDMonoid.FinsetLemmas
import Mathlib.Algebra.Order.Round
import Mathlib.Algebra.Ring.GeomSum
import Mathlib.Analysis.Asymptotics.Defs
import Mathlib.Analysis.Complex.ExponentialBounds
import Mathlib.Analysis.Real.Pi.Bounds
import Mathlib.Analysis.SpecialFunctions.Stirling
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Data.Fin.VecNotation
import Mathlib.Data.Nat.Factorial.Basic
import Mathlib.Data.Nat.Factorial.BigOperators
import Mathlib.Data.Nat.ModEq
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.LinearAlgebra.Matrix.Adjugate
import Mathlib.LinearAlgebra.Vandermonde
import Mathlib.Tactic.FinCases
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.InfiniteSum.Basic
import Mathlib.Topology.Algebra.InfiniteSum.Ring

/-!
# Prime unit translator for Erdős problem 68

For a prime `p`, the coefficient pair `(p,-1)` on the indices `(p-1,p)` has
zero factorial moment and annihilates every channel except the `p`-channel.
At that channel its numerator is exactly `p!-1`; consequently its normalized
infinite residual is `1`.  Appending an integer multiple of this pair therefore
translates any finite-support residual by the same integer without changing
the lower channels or the factorial moment.

The module also classifies every finite-support residual modulo integers as
its factorial moment times the factorial-gap tail.  A Cramer construction on
an explicit factorial grid supplies, beyond any prescribed support threshold,
integer coefficient vectors with zero channels through a chosen cutoff and
nonzero factorial moment.  Appending a prime translator reduces their
residual to absolute value at most `1/2`.

The last reduction is not an irrationality argument by itself: the reduced
residual may be zero.  The strict version assumes that the original residual
is not an integer, and no theorem here proves that assumption for the Cramer
vectors.  There is also no coefficient-size estimate, no nonzero lower bound
for the reduced residual, and no irrationality theorem for the factorial-gap
series.
-/

open Erdos68 in
theorem solution (D : ℕ) :
    HasSum
      (fun k : ℕ =>
        (1 : ℝ) / ((D + k).factorial : ℝ) -
          1 / ((D + k + 1).factorial : ℝ))
      (1 / (D.factorial : ℝ)) := by
  let f : ℕ → ℝ := fun k =>
    (1 : ℝ) / ((D + k).factorial : ℝ)
  have hall : Summable (fun n : ℕ =>
      (1 : ℝ) / (n.factorial : ℝ)) := by
    simpa using Real.summable_pow_div_factorial 1
  have hf : Summable f := by
    have hshift :=
      (summable_nat_add_iff D).2 hall
    simpa [f, Nat.add_comm] using hshift
  have hsucc : Summable (fun k : ℕ => f (k + 1)) :=
    (summable_nat_add_iff 1).2 hf
  have hdiff : Summable (fun k : ℕ => f k - f (k + 1)) :=
    hf.sub hsucc
  have hf_zero :
      Filter.Tendsto f Filter.atTop (nhds 0) := by
    apply squeeze_zero'
    · exact Filter.Eventually.of_forall (fun k => by
        simp [f])
    · filter_upwards [Filter.eventually_atTop.2
        ⟨1, fun k hk => hk⟩] with k hk
      have hnat : k ≤ (D + k).factorial := by
        calc
          k ≤ D + k := Nat.le_add_left k D
          _ ≤ (D + k).factorial := Nat.self_le_factorial _
      have hkreal : (0 : ℝ) < k := by exact_mod_cast hk
      have hfacreal : (0 : ℝ) < (D + k).factorial := by positivity
      exact one_div_le_one_div_of_le hkreal (by exact_mod_cast hnat)
    · simpa using
        (tendsto_one_div_atTop_nhds_zero_nat (𝕜 := ℝ))
  apply (hdiff.hasSum_iff_tendsto_nat).2
  have htend :
      Filter.Tendsto (fun n : ℕ => f 0 - f n) Filter.atTop
        (nhds (f 0 - 0)) :=
    hf_zero.const_sub (f 0)
  convert htend using 1
  · funext n
    exact Finset.sum_range_sub' f n
  · simp [f]
