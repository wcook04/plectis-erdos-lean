import Definitions.Def_ErdosProblems_Erdos68_CanonicalFactorialDigits
import Definitions.Def_ErdosProblems_Erdos68_ChannelBreakpointRigidity
import Definitions.Def_ErdosProblems_Erdos68_ChannelIntegralCongruence
import Definitions.Def_ErdosProblems_Erdos68_PrimeUnitTranslator
import Definitions.Def_ErdosProblems_Erdos68_FactorialGapPlateauCore
import Theorems.Thm_ErdosProblems_Erdos68_strictFacTop_factorialGapPrefix_div_factorial_step
import Theorems.Thm_ErdosProblems_Erdos68_tendsto_strictFacTop_factorialGapPrefix_div_factorial
import Mathlib.Algebra.BigOperators.Fin
import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Algebra.GCDMonoid.FinsetLemmas
import Mathlib.Algebra.Order.Floor.Ring
import Mathlib.Algebra.Order.Round
import Mathlib.Algebra.Ring.GeomSum
import Mathlib.Analysis.Asymptotics.Defs
import Mathlib.Analysis.Complex.ExponentialBounds
import Mathlib.Analysis.Real.Pi.Bounds
import Mathlib.Analysis.SpecialFunctions.Stirling
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Data.Fin.VecNotation
import Mathlib.Data.Int.Basic
import Mathlib.Data.Nat.Factorial.Basic
import Mathlib.Data.Nat.Factorial.BigOperators
import Mathlib.Data.Nat.ModEq
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.LinearAlgebra.Matrix.Adjugate
import Mathlib.LinearAlgebra.Vandermonde
import Mathlib.NumberTheory.Real.Irrational
import Mathlib.Tactic
import Mathlib.Tactic.FinCases
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.InfiniteSum.Basic
import Mathlib.Topology.Algebra.InfiniteSum.Ring

/-!
# Erdős #68: factorial-gap plateau core

Lightweight core for the strict-successor recurrence, carry bounds, and the
exact divisibility criterion.  Heavy exact-index certificates live in
`FactorialZeroPlateauCertificates`; the full plateau file re-exports both.
-/

namespace ErdosProblems.Erdos68
/-! ## Factorial grid arithmetic -/



















/-! ## Exact prefixes and prime-power divisibility -/

















/-! ## The carry recurrence and the exact irrationality criterion -/
end ErdosProblems.Erdos68

open ErdosProblems in
open ErdosProblems.Erdos68 in
theorem solution
    (hunit : ∃ M : ℕ, ∀ m : ℕ, M ≤ m →
      factorialGapStepCarry m = 1) :
    ¬Irrational _root_.Erdos68.factorialGapSeries := by
  obtain ⟨M, hunit⟩ := hunit
  let K : ℕ := max M 2
  let R : ℕ → ℝ := fun n =>
    (strictFacTop
          ((factorialGapPrefix n : ℚ) : ℝ) n : ℝ) /
      (n.factorial : ℝ)
  have hKTwo : 2 ≤ K := by simp [K]
  have hMK : M ≤ K := by simp [K]
  have hstationary : ∀ n : ℕ, K ≤ n → R n = R K := by
    intro n hn
    induction n, hn using Nat.le_induction with
    | base => rfl
    | succ n hKn ih =>
        have hcarry : factorialGapStepCarry (n + 1) = 1 :=
          hunit (n + 1) (by omega)
        have hstep :=
          strictFacTop_factorialGapPrefix_div_factorial_step
            (m := n + 1) (by omega)
        have hnext : R (n + 1) = R n := by
          simpa [R, hcarry] using hstep
        exact hnext.trans ih
  have heventually : R =ᶠ[Filter.atTop] fun _ => R K :=
    (Filter.eventually_ge_atTop K).mono hstationary
  have hlimitK : Filter.Tendsto R Filter.atTop (nhds (R K)) :=
    tendsto_const_nhds.congr' heventually.symm
  have hlimitSeries :
      Filter.Tendsto R Filter.atTop
        (nhds _root_.Erdos68.factorialGapSeries) := by
    simpa [R] using
      tendsto_strictFacTop_factorialGapPrefix_div_factorial
  have hseriesEq :
      _root_.Erdos68.factorialGapSeries = R K :=
    tendsto_nhds_unique hlimitSeries hlimitK
  let r : ℚ :=
    (strictFacTop
          ((factorialGapPrefix K : ℚ) : ℝ) K : ℚ) /
      (K.factorial : ℚ)
  have hr : (r : ℝ) = R K := by
    simp [r, R]
  rw [hseriesEq, ← hr]
  exact Rat.not_irrational r
