import Definitions.Def_ErdosProblems_Erdos68_CanonicalFactorialDigits
import Definitions.Def_ErdosProblems_Erdos68_ChannelBreakpointRigidity
import Definitions.Def_ErdosProblems_Erdos68_ChannelIntegralCongruence
import Definitions.Def_ErdosProblems_Erdos68_PrimeUnitTranslator
import Definitions.Def_ErdosProblems_Erdos68_FactorialGapPlateauCore
import Theorems.Thm_ErdosProblems_Erdos68_strictFacTop_factorialGapPrefix_step
import Theorems.Thm_ErdosProblems_Erdos68_strictFacTop_factorialGapPrefix_eq_cleared_rational_of_dvd
import Mathlib.Algebra.BigOperators.Fin
import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Algebra.GCDMonoid.FinsetLemmas
import Mathlib.Algebra.Order.Floor.Ring
import Mathlib.Algebra.Order.Round
import Mathlib.Algebra.Ring.GeomSum
import Mathlib.Analysis.Asymptotics.Defs
import Mathlib.Analysis.Complex.ExponentialBounds
import Mathlib.Analysis.Real.Pi.Bounds
import Mathlib.Analysis.SpecialFunctions.Stirling
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Data.Fin.VecNotation
import Mathlib.Data.Int.Basic
import Mathlib.Data.Nat.Factorial.Basic
import Mathlib.Data.Nat.Factorial.BigOperators
import Mathlib.Data.Nat.ModEq
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.LinearAlgebra.Matrix.Adjugate
import Mathlib.LinearAlgebra.Vandermonde
import Mathlib.NumberTheory.Real.Irrational
import Mathlib.Tactic
import Mathlib.Tactic.FinCases
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.InfiniteSum.Basic
import Mathlib.Topology.Algebra.InfiniteSum.Ring

/-!
# Erdős #68: factorial-gap plateau core

Lightweight core for the strict-successor recurrence, carry bounds, and the
exact divisibility criterion.  Heavy exact-index certificates live in
`FactorialZeroPlateauCertificates`; the full plateau file re-exports both.
-/

namespace ErdosProblems.Erdos68
/-! ## Factorial grid arithmetic -/



















/-! ## Exact prefixes and prime-power divisibility -/

















/-! ## The carry recurrence and the exact irrationality criterion -/
end ErdosProblems.Erdos68

open ErdosProblems in
open ErdosProblems.Erdos68 in
theorem solution
    {m q : ℕ} {a : ℤ}
    (hm : 3 ≤ m)
    (hq : 0 < q)
    (hqfac : q ∣ (m - 1).factorial)
    (hseries :
      _root_.Erdos68.factorialGapSeries =
        (a : ℝ) / (q : ℝ)) :
    factorialGapStepCarry m = 1 := by
  have hpredDvd : (m - 1).factorial ∣ m.factorial :=
    Nat.factorial_dvd_factorial (by omega)
  have hprev :=
    strictFacTop_factorialGapPrefix_eq_cleared_rational_of_dvd
      (n := m - 1) (q := q) (a := a)
      (by omega) hq hqfac hseries
  have hcurr :=
    strictFacTop_factorialGapPrefix_eq_cleared_rational_of_dvd
      (n := m) (q := q) (a := a)
      (by omega) hq (hqfac.trans hpredDvd) hseries
  have hfac :
      m.factorial = m * (m - 1).factorial := by
    have hmSucc : m - 1 + 1 = m := by omega
    simpa only [hmSucc] using Nat.factorial_succ (m - 1)
  have hquot :
      m.factorial / q = m * ((m - 1).factorial / q) := by
    rw [hfac]
    exact Nat.mul_div_assoc m hqfac
  have hscale :
      (((m.factorial / q : ℕ) : ℤ) * a : ℤ) =
        (m : ℤ) * ((((m - 1).factorial / q : ℕ) : ℤ) * a) := by
    rw [hquot]
    push_cast
    ring
  have hrec :=
    strictFacTop_factorialGapPrefix_step (show 2 ≤ m by omega)
  rw [hcurr, hprev, hscale] at hrec
  omega
