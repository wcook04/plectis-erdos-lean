import Definitions.Def_ErdosProblems_Erdos68_CanonicalFactorialDigits
import Definitions.Def_ErdosProblems_Erdos68_ChannelBreakpointRigidity
import Definitions.Def_ErdosProblems_Erdos68_ChannelIntegralCongruence
import Definitions.Def_ErdosProblems_Erdos68_PrimeUnitTranslator
import Definitions.Def_ErdosProblems_Erdos68_FactorialGapPlateauCore
import Definitions.Def_ErdosProblems_Erdos68_FactorialChannelCertificate
import Definitions.Def_ErdosProblems_Erdos68_EndpointWeightedPrivateSupport
import Lean.Elab.Tactic.Omega
import Mathlib.Algebra.BigOperators.Fin
import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Algebra.GCDMonoid.FinsetLemmas
import Mathlib.Algebra.Order.Floor.Ring
import Mathlib.Algebra.Order.Round
import Mathlib.Algebra.Ring.GeomSum
import Mathlib.Analysis.Asymptotics.Defs
import Mathlib.Analysis.Complex.ExponentialBounds
import Mathlib.Analysis.Real.Pi.Bounds
import Mathlib.Analysis.SpecialFunctions.Stirling
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Data.Fin.VecNotation
import Mathlib.Data.Finsupp.Basic
import Mathlib.Data.Int.Basic
import Mathlib.Data.Int.ModEq
import Mathlib.Data.Nat.Choose.Multinomial
import Mathlib.Data.Nat.Factorial.Basic
import Mathlib.Data.Nat.Factorial.BigOperators
import Mathlib.Data.Nat.Factorization.Basic
import Mathlib.Data.Nat.GCD.BigOperators
import Mathlib.Data.Nat.ModEq
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.Nat.Prime.Factorial
import Mathlib.Data.Rat.Lemmas
import Mathlib.LinearAlgebra.Matrix.Adjugate
import Mathlib.LinearAlgebra.Vandermonde
import Mathlib.NumberTheory.Divisors
import Mathlib.NumberTheory.Real.Irrational
import Mathlib.Tactic
import Mathlib.Tactic.FinCases
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.NormNum.NatFactorial
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.InfiniteSum.Basic
import Mathlib.Topology.Algebra.InfiniteSum.Ring

/-!
# Erdős #68: collision cores, private residues, and factorial-block endpoints

For a finite denominator family, the pairwise collision core records the
prime powers shared by at least two denominators.  Dividing each denominator
by its part inside this core produces pairwise-coprime private quotients.
Their product is the private modulus `R`; a weighted leave-one-out numerator
is coprime to `R`, so the displayed endpoint numerator has a nonzero residue
whenever `R > 1`.

The abstract part of the file develops these finite gcd, lcm, CRT, and
projection identities.  The factorial-block specialization takes the
denominators `n! - 1` for `p ≤ n < 2p`, identifies the strict-successor
coefficient at `p - 1`, and defines an endpoint window.  Unit carries on the
whole interval `[p,2p]` force that window; so does any rational value whose
denominator is already cleared by `(p-1)!`.

The later theorems give several exact ways to refute the window: a large
private residue, unequal leave-one-out projections, coprime factor-pair
floors, or a uniquely supported prime with a sufficiently large residue.
Cofinal families of any of the stated certificates imply cofinally many
non-unit carries or rational-prefix divisibility failures, and hence imply
irrationality through the earlier carry criterion.

Every irrationality conclusion in this file is conditional.  No theorem
constructs the required cofinal certificate family, proves the needed
projection disagreement or size inequality for arbitrarily large blocks,
or supplies cofinally many uniquely supported factorial-gap primes.  The
finite CRT identities and endpoint reductions therefore do not by themselves
prove the irrationality of the factorial-gap series or solve Erdős #68.
-/

namespace ErdosProblems.Erdos68
/-! ## Collision cores for finite denominator families -/



















































































/-! ## Private quotients and weighted CRT numerators -/



































































/-! ## Endpoint residues and finite projection bounds -/
end ErdosProblems.Erdos68

open ErdosProblems in
open ErdosProblems.Erdos68 in
theorem solution
    {Z R : ℕ}
    (hR : 1 < R)
    (hcop : Nat.Coprime Z R) :
    0 < projectedResidue Z R ∧
      projectedResidue Z R ≤ Z ∧
      projectedResidue Z R < R := by
  have hRPos : 0 < R := by omega
  have hresNe : Z % R ≠ 0 := by
    intro hzero
    have hRdvdZ : R ∣ Z :=
      Nat.dvd_iff_mod_eq_zero.mpr hzero
    have hgcdR : Nat.gcd Z R = R :=
      Nat.gcd_eq_right_iff_dvd.mpr hRdvdZ
    have hgcdOne : Nat.gcd Z R = 1 :=
      Nat.Coprime.gcd_eq_one hcop
    omega
  simpa [projectedResidue] using
    And.intro (Nat.pos_of_ne_zero hresNe)
      (And.intro (Nat.mod_le Z R) (Nat.mod_lt Z hRPos))
