import Definitions.Def_ErdosProblems_Erdos68_ChannelBreakpointRigidity
import Definitions.Def_ErdosProblems_Erdos68_ChannelIntegralCongruence
import Theorems.Thm_Erdos68_factorialGapSegment_base_pow_le_channelLCM_mul_pow_choose
import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Algebra.GCDMonoid.FinsetLemmas
import Mathlib.Algebra.Ring.GeomSum
import Mathlib.Analysis.Asymptotics.Defs
import Mathlib.Analysis.Complex.ExponentialBounds
import Mathlib.Analysis.Real.Pi.Bounds
import Mathlib.Analysis.SpecialFunctions.Stirling
import Mathlib.Data.Nat.Factorial.Basic
import Mathlib.Data.Nat.Factorial.BigOperators
import Mathlib.Data.Nat.ModEq
import Mathlib.Tactic.Ring

/-!
# Integral channel congruence for Erdős problem 68

This module compares a channel numerator with the corresponding factorial
moment modulo `d! - 1`.  The congruence holds for every support index, so
simultaneous cancellation of the channels `2, ..., D` makes their least common
multiple divide the factorial moment.

The second part estimates that least common multiple.  Consecutive numbers
`m! - 1` are compared through their pairwise gcds; this gives an explicit
finite lower bound after the gcd losses are counted.  Consequently, if a
positive integer `M` is divisible by the channel lcm and is smaller than
`(R+1)! - 1`, then `R` must grow at least cubically along `D = 2t^2`.  A later
estimate improves the explicit constant to `R+1 > (3/2)t^3` for `t >= 2^32`.

All conclusions after the congruence theorem retain these stated hypotheses.
In particular, this file does not construct `M` or `R` from the series in
Erdős problem 68, prove that its channels vanish, or decide the rationality of
that series.
-/

namespace Erdos68
/-! ## Product versus lcm with explicit gcd loss -/











/-! ## Factorial-gap collision bounds -/







/-! ## Consecutive factorial-gap segments -/











































/-- If a positive integer is a multiple of the channel lcm and is smaller
than the factorial gap at `R+1`, then the channel lcm is smaller than that gap
as well. -/
theorem channelLCM_lt_radiusFactorial_sub_one_of_dvd_of_lt
    {D M R : ℕ}
    (hMpos : 0 < M)
    (hdiv : channelLCM D ∣ M)
    (hsmall : M < (R + 1).factorial - 1) :
    channelLCM D < (R + 1).factorial - 1 :=
  lt_of_le_of_lt (Nat.le_of_dvd hMpos hdiv) hsmall

/-- Finite radius constraint obtained by combining divisibility by the
channel lcm with the final-block estimate. -/
theorem factorialGapSegment_base_pow_lt_radiusFactorial_mul_pow
    {D k M R : ℕ}
    (hkD : k < D)
    (hMpos : 0 < M)
    (hdiv : channelLCM D ∣ M)
    (hsmall : M < (R + 1).factorial - 1) :
    ((D + 1 - k).factorial - 1) ^ k <
      ((R + 1).factorial - 1) * D ^ ((k + 1).choose 3) := by
  have hQ :
      channelLCM D < (R + 1).factorial - 1 :=
    channelLCM_lt_radiusFactorial_sub_one_of_dvd_of_lt hMpos hdiv hsmall
  have hDpos : 0 < D ^ ((k + 1).choose 3) :=
    pow_pos (by omega) _
  exact lt_of_le_of_lt
    (factorialGapSegment_base_pow_le_channelLCM_mul_pow_choose hkD)
    (Nat.mul_lt_mul_of_pos_right hQ hDpos)
end Erdos68

open Erdos68 in
theorem solution
    {D k M R : ℕ}
    (hkD : k < D)
    (hMpos : 0 < M)
    (hdiv : channelLCM D ∣ M)
    (hsmall : M < (R + 1).factorial - 1) :
    (k : ℝ) * Real.log (((D + 1 - k).factorial - 1 : ℕ) : ℝ) <
      Real.log (((R + 1).factorial - 1 : ℕ) : ℝ) +
        (((k + 1).choose 3 : ℕ) : ℝ) * Real.log (D : ℝ) := by
  have hnat :=
    factorialGapSegment_base_pow_lt_radiusFactorial_mul_pow
      hkD hMpos hdiv hsmall
  have hbasePos : 0 < (D + 1 - k).factorial - 1 := by
    exact Nat.sub_pos_of_lt (Nat.one_lt_factorial.mpr (by omega))
  have hradiusPos : 0 < (R + 1).factorial - 1 := by
    omega
  have hDpos : 0 < D := by omega
  have hcast :
      ((((D + 1 - k).factorial - 1) ^ k : ℕ) : ℝ) <
        ((((R + 1).factorial - 1) * D ^ ((k + 1).choose 3) : ℕ) : ℝ) := by
    exact_mod_cast hnat
  have hlog :=
    Real.log_lt_log
      (by positivity :
        0 < ((((D + 1 - k).factorial - 1) ^ k : ℕ) : ℝ))
      hcast
  simpa [Nat.cast_pow, Nat.cast_mul, Real.log_pow, Real.log_mul,
    hbasePos.ne', hradiusPos.ne', hDpos.ne'] using hlog
