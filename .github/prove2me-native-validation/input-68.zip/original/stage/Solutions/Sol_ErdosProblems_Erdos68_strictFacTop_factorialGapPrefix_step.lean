import Definitions.Def_ErdosProblems_Erdos68_CanonicalFactorialDigits
import Definitions.Def_ErdosProblems_Erdos68_ChannelBreakpointRigidity
import Definitions.Def_ErdosProblems_Erdos68_ChannelIntegralCongruence
import Definitions.Def_ErdosProblems_Erdos68_PrimeUnitTranslator
import Definitions.Def_ErdosProblems_Erdos68_FactorialGapPlateauCore
import Theorems.Thm_ErdosProblems_Erdos68_factorialGapPrefix_eq_prev_add
import Mathlib.Algebra.BigOperators.Fin
import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Algebra.GCDMonoid.FinsetLemmas
import Mathlib.Algebra.Order.Floor.Ring
import Mathlib.Algebra.Order.Round
import Mathlib.Algebra.Ring.GeomSum
import Mathlib.Analysis.Asymptotics.Defs
import Mathlib.Analysis.Complex.ExponentialBounds
import Mathlib.Analysis.Real.Pi.Bounds
import Mathlib.Analysis.SpecialFunctions.Stirling
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Data.Fin.VecNotation
import Mathlib.Data.Int.Basic
import Mathlib.Data.Nat.Factorial.Basic
import Mathlib.Data.Nat.Factorial.BigOperators
import Mathlib.Data.Nat.ModEq
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.LinearAlgebra.Matrix.Adjugate
import Mathlib.LinearAlgebra.Vandermonde
import Mathlib.NumberTheory.Real.Irrational
import Mathlib.Tactic
import Mathlib.Tactic.FinCases
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.InfiniteSum.Basic
import Mathlib.Topology.Algebra.InfiniteSum.Ring

/-!
# Erdős #68: factorial-gap plateau core

Lightweight core for the strict-successor recurrence, carry bounds, and the
exact divisibility criterion.  Heavy exact-index certificates live in
`FactorialZeroPlateauCertificates`; the full plateau file re-exports both.
-/

namespace ErdosProblems.Erdos68
/-! ## Factorial grid arithmetic -/



















/-! ## Exact prefixes and prime-power divisibility -/

















/-! ## The carry recurrence and the exact irrationality criterion -/
end ErdosProblems.Erdos68

open ErdosProblems in
open ErdosProblems.Erdos68 in
theorem solution
    {m : ℕ} (hm : 2 ≤ m) :
    strictFacTop ((factorialGapPrefix m : ℚ) : ℝ) m =
      (m : ℤ) *
          strictFacTop
            ((factorialGapPrefix (m - 1) : ℚ) : ℝ) (m - 1) +
        1 - factorialGapStepCarry m := by
  have hfac :
      m.factorial = m * (m - 1).factorial := by
    calc
      m.factorial = ((m - 1) + 1).factorial := by congr 1 <;> omega
      _ = ((m - 1) + 1) * (m - 1).factorial := Nat.factorial_succ _
      _ = m * (m - 1).factorial := by congr 1 <;> omega
  have hfacOne : (1 : ℝ) < m.factorial := by
    exact_mod_cast Nat.one_lt_factorial.mpr hm
  have hden : ((m.factorial : ℝ) - 1) ≠ 0 := by linarith
  have hprefix :
      ((factorialGapPrefix m : ℚ) : ℝ) =
        ((factorialGapPrefix (m - 1) : ℚ) : ℝ) +
          1 / ((m.factorial : ℝ) - 1) := by
    exact_mod_cast factorialGapPrefix_eq_prev_add hm
  let H : ℝ := ((factorialGapPrefix (m - 1) : ℚ) : ℝ)
  let Z : ℤ := strictFacTop H (m - 1)
  have hscaled :
      (m.factorial : ℝ) *
          ((factorialGapPrefix m : ℚ) : ℝ) =
        (m : ℝ) * (Z : ℝ) +
          (1 + 1 / ((m.factorial : ℝ) - 1) -
            (m : ℝ) * factorialGapPredecessorGap m) := by
    calc
      (m.factorial : ℝ) *
          ((factorialGapPrefix m : ℚ) : ℝ) =
          (m.factorial : ℝ) *
            (H + 1 / ((m.factorial : ℝ) - 1)) := by
              rw [hprefix]
      _ = (m.factorial : ℝ) * H +
          (1 + 1 / ((m.factorial : ℝ) - 1)) := by
            field_simp [hden]
            ring
      _ = (m : ℝ) * (Z : ℝ) +
          (1 + 1 / ((m.factorial : ℝ) - 1) -
            (m : ℝ) * factorialGapPredecessorGap m) := by
              rw [hfac]
              simp only [Nat.cast_mul]
              unfold factorialGapPredecessorGap Z H strictFacTop
              push_cast
              ring
  unfold strictFacTop factorialGapStepCarry
  rw [hscaled]
  have hmZ :
      (m : ℝ) * (Z : ℝ) = (((m : ℤ) * Z : ℤ) : ℝ) := by
    push_cast
    rfl
  rw [hmZ, Int.floor_intCast_add]
  push_cast
  dsimp [Z, H, strictFacTop]
  ring
