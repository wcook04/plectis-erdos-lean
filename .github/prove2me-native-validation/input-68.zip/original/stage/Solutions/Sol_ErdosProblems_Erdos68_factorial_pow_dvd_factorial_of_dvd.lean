import Lean.Elab.Tactic.Omega
import Mathlib.Data.Int.ModEq
import Mathlib.Data.Nat.Choose.Multinomial
import Mathlib.Data.Rat.Lemmas
import Mathlib.NumberTheory.Divisors
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.NormNum

namespace ErdosProblems.Erdos68
end ErdosProblems.Erdos68

open scoped BigOperators

/-!
# Erdős #68: factorial carries and prime windows

For

`S = ∑ n ≥ 2, 1 / (n! - 1)`,

expanding each summand geometrically and regrouping by `m = n * j`
produces the integral coefficient

`C_m = ∑_{d ∣ m, 2 ≤ d} m! / (d!)^(m/d)`.

The multinomial divisibility proved below shows directly that every summand is
an integer.  The same arithmetic leads to a finite interval question at prime
dilations: an integral carry must lie in a prescribed residue class inside a
rational window.  A missed window therefore excludes that carry, and a window
of length less than one contains at most one possible integer.

These statements do not prove that the windows arising from the series are
missed for infinitely many primes, and they do not prove irrationality.
-/

open ErdosProblems in
open ErdosProblems.Erdos68 in
theorem solution
    {d m : ℕ} (hd : d ∣ m) :
    d.factorial ^ (m / d) ∣ m.factorial := by
  have h := Nat.prod_factorial_dvd_factorial_sum
    (Finset.range (m / d)) (fun _ : ℕ => d)
  simpa [Finset.prod_const, Finset.sum_const, Nat.div_mul_cancel hd] using h
