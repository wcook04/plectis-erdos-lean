import Definitions.Def_ErdosProblems_Erdos68_CanonicalFactorialDigits
import Definitions.Def_ErdosProblems_Erdos68_ChannelBreakpointRigidity
import Definitions.Def_ErdosProblems_Erdos68_ChannelIntegralCongruence
import Definitions.Def_ErdosProblems_Erdos68_PrimeUnitTranslator
import Definitions.Def_ErdosProblems_Erdos68_FactorialGapPlateauCore
import Definitions.Def_ErdosProblems_Erdos68_FactorialChannelCertificate
import Definitions.Def_ErdosProblems_Erdos68_EndpointWeightedPrivateSupport
import Theorems.Thm_ErdosProblems_Erdos68_privateQuotients_coprime_of_gcd_dvd_core
import Theorems.Thm_ErdosProblems_Erdos68_privateModulus_eq_endpointDenominatorLcm_div_collisionCore
import Theorems.Thm_ErdosProblems_Erdos68_coprime_left_of_add_modEq_zero
import Theorems.Thm_ErdosProblems_Erdos68_endpointDenominatorTerm_eq_privateWeight_mul_leaveOneOut
import Theorems.Thm_ErdosProblems_Erdos68_projectedResidue_bounds_of_coprime
import Theorems.Thm_ErdosProblems_Erdos68_weightedPrivateNumerator_coprime_product
import Lean.Elab.Tactic.Omega
import Mathlib.Algebra.BigOperators.Fin
import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Algebra.GCDMonoid.FinsetLemmas
import Mathlib.Algebra.Order.Floor.Ring
import Mathlib.Algebra.Order.Round
import Mathlib.Algebra.Ring.GeomSum
import Mathlib.Analysis.Asymptotics.Defs
import Mathlib.Analysis.Complex.ExponentialBounds
import Mathlib.Analysis.Real.Pi.Bounds
import Mathlib.Analysis.SpecialFunctions.Stirling
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Data.Fin.VecNotation
import Mathlib.Data.Finsupp.Basic
import Mathlib.Data.Int.Basic
import Mathlib.Data.Int.ModEq
import Mathlib.Data.Nat.Choose.Multinomial
import Mathlib.Data.Nat.Factorial.Basic
import Mathlib.Data.Nat.Factorial.BigOperators
import Mathlib.Data.Nat.Factorization.Basic
import Mathlib.Data.Nat.GCD.BigOperators
import Mathlib.Data.Nat.ModEq
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.Nat.Prime.Factorial
import Mathlib.Data.Rat.Lemmas
import Mathlib.LinearAlgebra.Matrix.Adjugate
import Mathlib.LinearAlgebra.Vandermonde
import Mathlib.NumberTheory.Divisors
import Mathlib.NumberTheory.Real.Irrational
import Mathlib.Tactic
import Mathlib.Tactic.FinCases
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.NormNum.NatFactorial
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.InfiniteSum.Basic
import Mathlib.Topology.Algebra.InfiniteSum.Ring

/-!
# Erdős #68: collision cores, private residues, and factorial-block endpoints

For a finite denominator family, the pairwise collision core records the
prime powers shared by at least two denominators.  Dividing each denominator
by its part inside this core produces pairwise-coprime private quotients.
Their product is the private modulus `R`; a weighted leave-one-out numerator
is coprime to `R`, so the displayed endpoint numerator has a nonzero residue
whenever `R > 1`.

The abstract part of the file develops these finite gcd, lcm, CRT, and
projection identities.  The factorial-block specialization takes the
denominators `n! - 1` for `p ≤ n < 2p`, identifies the strict-successor
coefficient at `p - 1`, and defines an endpoint window.  Unit carries on the
whole interval `[p,2p]` force that window; so does any rational value whose
denominator is already cleared by `(p-1)!`.

The later theorems give several exact ways to refute the window: a large
private residue, unequal leave-one-out projections, coprime factor-pair
floors, or a uniquely supported prime with a sufficiently large residue.
Cofinal families of any of the stated certificates imply cofinally many
non-unit carries or rational-prefix divisibility failures, and hence imply
irrationality through the earlier carry criterion.

Every irrationality conclusion in this file is conditional.  No theorem
constructs the required cofinal certificate family, proves the needed
projection disagreement or size inequality for arbitrarily large blocks,
or supplies cofinally many uniquely supported factorial-gap primes.  The
finite CRT identities and endpoint reductions therefore do not by themselves
prove the irrationality of the factorial-gap series or solve Erdős #68.
-/

namespace ErdosProblems.Erdos68
/-! ## Collision cores for finite denominator families -/







































/-- Every pairwise collision factor already occurs in the lcm of the
denominator family. -/
theorem pairwiseCollisionCore_dvd_denominatorLcm
    {ι : Type*} [DecidableEq ι]
    {s : Finset ι} {d : ι → ℕ} :
    pairwiseCollisionCore s d ∣ s.lcm d := by
  unfold pairwiseCollisionCore
  apply Finset.lcm_dvd
  intro i hi
  apply Finset.lcm_dvd
  intro j _
  exact (Nat.gcd_dvd_left (d i) (d j)).trans
    (Finset.dvd_lcm hi)

/-- The full collision core divides the common endpoint denominator. -/
theorem collisionCore_dvd_endpointDenominatorLcm
    {ι : Type*} [DecidableEq ι]
    {base : ℕ} {s : Finset ι} {d : ι → ℕ} :
    collisionCore base s d ∣ endpointDenominatorLcm base s d := by
  unfold collisionCore endpointDenominatorLcm
  apply Nat.lcm_dvd
  · exact Nat.dvd_lcm_left base (s.lcm d)
  · exact (pairwiseCollisionCore_dvd_denominatorLcm
      (s := s) (d := d)).trans
        (Nat.dvd_lcm_right base (s.lcm d))

/-- Every off-diagonal pairwise gcd divides the finite pairwise collision
core. -/
theorem gcd_dvd_pairwiseCollisionCore
    {ι : Type*} [DecidableEq ι]
    {s : Finset ι} {d : ι → ℕ}
    {i j : ι}
    (hi : i ∈ s) (hj : j ∈ s) (hij : i ≠ j) :
    Nat.gcd (d i) (d j) ∣ pairwiseCollisionCore s d := by
  have hjErase : j ∈ s.erase i :=
    Finset.mem_erase.mpr ⟨hij.symm, hj⟩
  have hinner :
      Nat.gcd (d i) (d j) ∣
        (s.erase i).lcm fun k => Nat.gcd (d i) (d k) :=
    Finset.dvd_lcm hjErase
  exact hinner.trans (Finset.dvd_lcm hi)





























/-- Every off-diagonal pairwise gcd also divides the full collision core
after adjoining the distinguished base denominator. -/
theorem gcd_dvd_collisionCore
    {ι : Type*} [DecidableEq ι]
    {base : ℕ} {s : Finset ι} {d : ι → ℕ}
    {i j : ι}
    (hi : i ∈ s) (hj : j ∈ s) (hij : i ≠ j) :
    Nat.gcd (d i) (d j) ∣ collisionCore base s d := by
  exact Nat.dvd_lcm_of_dvd_right
    (gcd_dvd_pairwiseCollisionCore hi hj hij) base









/-! ## Private quotients and weighted CRT numerators -/

/-- Removing from every positive denominator the portion visible in the
finite collision core produces a pairwise-coprime family.  This is the
finite-family form of the private-support separation theorem. -/
theorem collisionCore_privateQuotients_pairwise_coprime
    {ι : Type*} [DecidableEq ι]
    {base : ℕ} {s : Finset ι} {d : ι → ℕ}
    (hpos : ∀ i ∈ s, 0 < d i) :
    (s : Set ι).Pairwise fun i j =>
      Nat.Coprime
        (d i / Nat.gcd (d i) (collisionCore base s d))
        (d j / Nat.gcd (d j) (collisionCore base s d)) := by
  intro i hi j hj hij
  apply privateQuotients_coprime_of_gcd_dvd_core
  · exact Nat.gcd_pos_of_pos_left (d j) (hpos i hi)
  · exact gcd_dvd_collisionCore hi hj hij





























/-- A canonical collision-core weight is coprime to its private quotient.
Both are the standard gcd-reduced quotients of the core and the owned
denominator. -/
theorem privateWeight_coprime_privateQuotient
    {ι : Type*} [DecidableEq ι]
    {base : ℕ} {s : Finset ι} {d : ι → ℕ}
    {i : ι}
    (hpos : 0 < d i) :
    Nat.Coprime
      (privateWeight base s d i)
      (privateQuotient base s d i) := by
  have hgPos :
      0 < Nat.gcd (collisionCore base s d) (d i) :=
    Nat.gcd_pos_of_pos_right _ hpos
  simpa [privateWeight, privateQuotient, Nat.gcd_comm] using
    (Nat.coprime_div_gcd_div_gcd hgPos)



/-- Complete abstract private-support survival theorem for the canonical
collision core: its canonical weighted numerator is coprime to the entire
private modulus. -/
theorem collisionWeightedPrivateNumerator_coprime_privateModulus
    {ι : Type*} [DecidableEq ι]
    {base : ℕ} {s : Finset ι} {d : ι → ℕ}
    (hpos : ∀ i ∈ s, 0 < d i) :
    Nat.Coprime
      (collisionWeightedPrivateNumerator base s d)
      (privateModulus base s d) := by
  unfold collisionWeightedPrivateNumerator privateModulus
  apply weightedPrivateNumerator_coprime_product
  · simpa [privateQuotient] using
      (collisionCore_privateQuotients_pairwise_coprime
        (base := base) (s := s) (d := d) hpos)
  · intro i hi
    exact privateWeight_coprime_privateQuotient (hpos i hi)









/-- The private modulus divides the common-denominator multiplier of the
distinguished base. -/
theorem privateModulus_dvd_endpointDenominatorLcm_div_base
    {ι : Type*} [DecidableEq ι]
    {base : ℕ} {s : Finset ι} {d : ι → ℕ}
    (hbase : 0 < base)
    (hpos : ∀ i ∈ s, 0 < d i) :
    privateModulus base s d ∣
      endpointDenominatorLcm base s d / base := by
  rw [privateModulus_eq_endpointDenominatorLcm_div_collisionCore
    hbase hpos]
  exact Nat.div_dvd_div_left
    collisionCore_dvd_endpointDenominatorLcm
    (Nat.dvd_lcm_left base (pairwiseCollisionCore s d))

/-- Hence the private modulus divides the entire positive base
contribution, independently of the displayed coefficient `K`. -/
theorem privateModulus_dvd_endpointBaseNumerator
    {ι : Type*} [DecidableEq ι]
    {K base : ℕ} {s : Finset ι} {d : ι → ℕ}
    (hbase : 0 < base)
    (hpos : ∀ i ∈ s, 0 < d i) :
    privateModulus base s d ∣
      endpointBaseNumerator K base s d := by
  unfold endpointBaseNumerator
  exact dvd_mul_of_dvd_right
    (privateModulus_dvd_endpointDenominatorLcm_div_base
      hbase hpos) K



/-- The canonical collision-weighted numerator is literally the tail
numerator over the full endpoint common denominator. -/
theorem endpointTailNumerator_eq_collisionWeightedPrivateNumerator
    {ι : Type*} [DecidableEq ι]
    {base : ℕ} {s : Finset ι} {d : ι → ℕ}
    (hbase : 0 < base)
    (hpos : ∀ i ∈ s, 0 < d i) :
    endpointTailNumerator base s d =
      collisionWeightedPrivateNumerator base s d := by
  unfold endpointTailNumerator collisionWeightedPrivateNumerator
    weightedPrivateNumerator
  apply Finset.sum_congr rfl
  intro i hi
  exact endpointDenominatorTerm_eq_privateWeight_mul_leaveOneOut
    hbase hpos hi

/-- Under the positive-endpoint ordering, the displayed numerator plus its
tail numerator recovers the base contribution exactly. -/
theorem endpointNumerator_add_tail_eq_endpointBaseNumerator
    {ι : Type*} [DecidableEq ι]
    {K base : ℕ} {s : Finset ι} {d : ι → ℕ}
    (htail :
      endpointTailNumerator base s d ≤
        endpointBaseNumerator K base s d) :
    endpointNumerator K base s d +
        endpointTailNumerator base s d =
      endpointBaseNumerator K base s d := by
  unfold endpointNumerator
  exact Nat.sub_add_cancel htail

/-- Exact negative-residue transport for the displayed endpoint numerator:
`Z + T` is zero modulo the private modulus. -/
theorem endpointNumerator_add_tail_modEq_zero
    {ι : Type*} [DecidableEq ι]
    {K base : ℕ} {s : Finset ι} {d : ι → ℕ}
    (hbase : 0 < base)
    (hpos : ∀ i ∈ s, 0 < d i)
    (htail :
      endpointTailNumerator base s d ≤
        endpointBaseNumerator K base s d) :
    endpointNumerator K base s d +
        endpointTailNumerator base s d ≡
      0 [MOD privateModulus base s d] := by
  rw [endpointNumerator_add_tail_eq_endpointBaseNumerator htail]
  exact Nat.modEq_zero_iff_dvd.mpr
    (privateModulus_dvd_endpointBaseNumerator hbase hpos)

/-- The same negative-residue congruence stated with the canonical
collision-weighted CRT numerator. -/
theorem endpointNumerator_add_collisionWeightedPrivateNumerator_modEq_zero
    {ι : Type*} [DecidableEq ι]
    {K base : ℕ} {s : Finset ι} {d : ι → ℕ}
    (hbase : 0 < base)
    (hpos : ∀ i ∈ s, 0 < d i)
    (htail :
      endpointTailNumerator base s d ≤
        endpointBaseNumerator K base s d) :
    endpointNumerator K base s d +
        collisionWeightedPrivateNumerator base s d ≡
      0 [MOD privateModulus base s d] := by
  rw [← endpointTailNumerator_eq_collisionWeightedPrivateNumerator
    hbase hpos]
  exact endpointNumerator_add_tail_modEq_zero hbase hpos htail



/-- Complete private-support survival statement for the displayed endpoint:
under the positive-endpoint ordering, its numerator is coprime to the whole
private modulus. -/
theorem endpointNumerator_coprime_privateModulus
    {ι : Type*} [DecidableEq ι]
    {K base : ℕ} {s : Finset ι} {d : ι → ℕ}
    (hbase : 0 < base)
    (hpos : ∀ i ∈ s, 0 < d i)
    (htail :
      endpointTailNumerator base s d ≤
        endpointBaseNumerator K base s d) :
    Nat.Coprime
      (endpointNumerator K base s d)
      (privateModulus base s d) := by
  apply coprime_left_of_add_modEq_zero
    (endpointNumerator_add_collisionWeightedPrivateNumerator_modEq_zero
      hbase hpos htail)
  exact collisionWeightedPrivateNumerator_coprime_privateModulus hpos





/-! ## Endpoint residues and finite projection bounds -/

















/-- The actual displayed endpoint residue satisfies the same sharp natural
bounds once the private modulus is nontrivial. -/
theorem endpointPrivateResidue_bounds
    {ι : Type*} [DecidableEq ι]
    {K base : ℕ} {s : Finset ι} {d : ι → ℕ}
    (hbase : 0 < base)
    (hpos : ∀ i ∈ s, 0 < d i)
    (htail :
      endpointTailNumerator base s d ≤
        endpointBaseNumerator K base s d)
    (hR : 1 < privateModulus base s d) :
    0 < endpointPrivateResidue K base s d ∧
      endpointPrivateResidue K base s d ≤
        endpointNumerator K base s d ∧
      endpointPrivateResidue K base s d <
        privateModulus base s d := by
  exact projectedResidue_bounds_of_coprime hR
    (endpointNumerator_coprime_privateModulus hbase hpos htail)











/-- An upper bound on a scaled endpoint numerator is incompatible with a
strictly larger scaled least residue. -/
theorem scaled_endpoint_upper_bound_excluded_by_residue
    {ρ Z L scale budget : ℕ}
    (hρZ : ρ ≤ Z)
    (hupper : scale * Z ≤ budget * L)
    (hlarge : budget * L < scale * ρ) :
    False := by
  have hscaled : scale * ρ ≤ scale * Z :=
    Nat.mul_le_mul_left scale hρZ
  omega

/-- Collision-core specialization of the preceding incompatibility. -/
theorem endpoint_scaled_upper_bound_false_of_privateResidue
    {ι : Type*} [DecidableEq ι]
    {K base scale budget : ℕ}
    {s : Finset ι} {d : ι → ℕ}
    (hbase : 0 < base)
    (hpos : ∀ i ∈ s, 0 < d i)
    (htail :
      endpointTailNumerator base s d ≤
        endpointBaseNumerator K base s d)
    (hR : 1 < privateModulus base s d)
    (hupper :
      scale * endpointNumerator K base s d ≤
        budget * endpointDenominatorLcm base s d)
    (hlarge :
      budget * endpointDenominatorLcm base s d <
        scale * endpointPrivateResidue K base s d) :
    False := by
  exact scaled_endpoint_upper_bound_excluded_by_residue
    (endpointPrivateResidue_bounds hbase hpos htail hR).2.1
    hupper hlarge



































/-! ## The factorial-block endpoint window -/









































































/-! ## Normalized collision arithmetic in a factorial block -/





/-- Every literal block denominator is positive. -/
theorem factorialGapDenominator_pos_of_mem
    {p n : ℕ}
    (hn : n ∈ factorialBlockIndices p) :
    0 < factorialGapDenominator n := by
  have hn2 : 2 ≤ n :=
    (Finset.mem_Icc.mp hn).1
  exact Nat.sub_pos_of_lt ((Nat.one_lt_factorial).2 hn2)































































/-! ## Leave-one-out and factor-pair projection bounds -/

































/-! ## Prime-power incidence and uniquely supported factors -/



















































/-! ## Endpoint-window exclusions and conditional irrationality criteria -/
end ErdosProblems.Erdos68

open ErdosProblems in
open ErdosProblems.Erdos68 in
theorem solution
    {p : ℕ}
    (htail :
      factorialBlockTailNumerator p ≤
        factorialBlockBaseNumerator p)
    (hR : 1 < factorialBlockPrivateModulus p)
    (hupper :
      factorialBlockScale p *
          factorialBlockEndpointNumerator p ≤
        factorialBlockBudget p *
          factorialBlockEndpointLcm p)
    (hlarge :
      factorialBlockBudget p *
          factorialBlockEndpointLcm p <
        factorialBlockScale p *
          factorialBlockPrivateResidue p) :
    False := by
  apply endpoint_scaled_upper_bound_false_of_privateResidue
    (K := factorialBlockCoefficient p)
    (base := factorialBlockBase p)
    (s := factorialBlockIndices p)
    (d := factorialGapDenominator)
  · exact Nat.factorial_pos _
  · intro n hn
    exact factorialGapDenominator_pos_of_mem hn
  · exact htail
  · exact hR
  · exact hupper
  · exact hlarge
