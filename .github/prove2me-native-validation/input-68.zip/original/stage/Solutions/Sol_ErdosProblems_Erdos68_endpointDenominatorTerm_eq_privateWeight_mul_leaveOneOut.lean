import Definitions.Def_ErdosProblems_Erdos68_CanonicalFactorialDigits
import Definitions.Def_ErdosProblems_Erdos68_ChannelBreakpointRigidity
import Definitions.Def_ErdosProblems_Erdos68_ChannelIntegralCongruence
import Definitions.Def_ErdosProblems_Erdos68_PrimeUnitTranslator
import Definitions.Def_ErdosProblems_Erdos68_FactorialGapPlateauCore
import Definitions.Def_ErdosProblems_Erdos68_FactorialChannelCertificate
import Definitions.Def_ErdosProblems_Erdos68_EndpointWeightedPrivateSupport
import Theorems.Thm_ErdosProblems_Erdos68_privateModulus_eq_endpointDenominatorLcm_div_collisionCore
import Lean.Elab.Tactic.Omega
import Mathlib.Algebra.BigOperators.Fin
import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Algebra.GCDMonoid.FinsetLemmas
import Mathlib.Algebra.Order.Floor.Ring
import Mathlib.Algebra.Order.Round
import Mathlib.Algebra.Ring.GeomSum
import Mathlib.Analysis.Asymptotics.Defs
import Mathlib.Analysis.Complex.ExponentialBounds
import Mathlib.Analysis.Real.Pi.Bounds
import Mathlib.Analysis.SpecialFunctions.Stirling
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Data.Fin.VecNotation
import Mathlib.Data.Finsupp.Basic
import Mathlib.Data.Int.Basic
import Mathlib.Data.Int.ModEq
import Mathlib.Data.Nat.Choose.Multinomial
import Mathlib.Data.Nat.Factorial.Basic
import Mathlib.Data.Nat.Factorial.BigOperators
import Mathlib.Data.Nat.Factorization.Basic
import Mathlib.Data.Nat.GCD.BigOperators
import Mathlib.Data.Nat.ModEq
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.Nat.Prime.Factorial
import Mathlib.Data.Rat.Lemmas
import Mathlib.LinearAlgebra.Matrix.Adjugate
import Mathlib.LinearAlgebra.Vandermonde
import Mathlib.NumberTheory.Divisors
import Mathlib.NumberTheory.Real.Irrational
import Mathlib.Tactic
import Mathlib.Tactic.FinCases
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.NormNum.NatFactorial
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.InfiniteSum.Basic
import Mathlib.Topology.Algebra.InfiniteSum.Ring

/-!
# Erdős #68: collision cores, private residues, and factorial-block endpoints

For a finite denominator family, the pairwise collision core records the
prime powers shared by at least two denominators.  Dividing each denominator
by its part inside this core produces pairwise-coprime private quotients.
Their product is the private modulus `R`; a weighted leave-one-out numerator
is coprime to `R`, so the displayed endpoint numerator has a nonzero residue
whenever `R > 1`.

The abstract part of the file develops these finite gcd, lcm, CRT, and
projection identities.  The factorial-block specialization takes the
denominators `n! - 1` for `p ≤ n < 2p`, identifies the strict-successor
coefficient at `p - 1`, and defines an endpoint window.  Unit carries on the
whole interval `[p,2p]` force that window; so does any rational value whose
denominator is already cleared by `(p-1)!`.

The later theorems give several exact ways to refute the window: a large
private residue, unequal leave-one-out projections, coprime factor-pair
floors, or a uniquely supported prime with a sufficiently large residue.
Cofinal families of any of the stated certificates imply cofinally many
non-unit carries or rational-prefix divisibility failures, and hence imply
irrationality through the earlier carry criterion.

Every irrationality conclusion in this file is conditional.  No theorem
constructs the required cofinal certificate family, proves the needed
projection disagreement or size inequality for arbitrarily large blocks,
or supplies cofinally many uniquely supported factorial-gap primes.  The
finite CRT identities and endpoint reductions therefore do not by themselves
prove the irrationality of the factorial-gap series or solve Erdős #68.
-/

namespace ErdosProblems.Erdos68
/-! ## Collision cores for finite denominator families -/







































/-- Every pairwise collision factor already occurs in the lcm of the
denominator family. -/
theorem pairwiseCollisionCore_dvd_denominatorLcm
    {ι : Type*} [DecidableEq ι]
    {s : Finset ι} {d : ι → ℕ} :
    pairwiseCollisionCore s d ∣ s.lcm d := by
  unfold pairwiseCollisionCore
  apply Finset.lcm_dvd
  intro i hi
  apply Finset.lcm_dvd
  intro j _
  exact (Nat.gcd_dvd_left (d i) (d j)).trans
    (Finset.dvd_lcm hi)

/-- The full collision core divides the common endpoint denominator. -/
theorem collisionCore_dvd_endpointDenominatorLcm
    {ι : Type*} [DecidableEq ι]
    {base : ℕ} {s : Finset ι} {d : ι → ℕ} :
    collisionCore base s d ∣ endpointDenominatorLcm base s d := by
  unfold collisionCore endpointDenominatorLcm
  apply Nat.lcm_dvd
  · exact Nat.dvd_lcm_left base (s.lcm d)
  · exact (pairwiseCollisionCore_dvd_denominatorLcm
      (s := s) (d := d)).trans
        (Nat.dvd_lcm_right base (s.lcm d))









































/-! ## Private quotients and weighted CRT numerators -/
end ErdosProblems.Erdos68

open ErdosProblems in
open ErdosProblems.Erdos68 in
theorem solution
    {ι : Type*} [DecidableEq ι]
    {base : ℕ} {s : Finset ι} {d : ι → ℕ}
    {i : ι}
    (hbase : 0 < base)
    (hpos : ∀ j ∈ s, 0 < d j)
    (hi : i ∈ s) :
    endpointDenominatorLcm base s d / d i =
      privateWeight base s d i *
        (s.erase i).prod (privateQuotient base s d) := by
  have hciDvdD :
      Nat.gcd (d i) (collisionCore base s d) ∣ d i :=
    Nat.gcd_dvd_left _ _
  have hciDvdC :
      Nat.gcd (d i) (collisionCore base s d) ∣
        collisionCore base s d :=
    Nat.gcd_dvd_right _ _
  have hdFactor :
      Nat.gcd (d i) (collisionCore base s d) *
          privateQuotient base s d i =
        d i := by
    exact Nat.mul_div_cancel' hciDvdD
  have hcoreFactor :
      Nat.gcd (d i) (collisionCore base s d) *
          privateWeight base s d i =
        collisionCore base s d := by
    exact Nat.mul_div_cancel' hciDvdC
  have hprivateFactor :
      privateQuotient base s d i *
          (s.erase i).prod (privateQuotient base s d) =
        privateModulus base s d := by
    exact Finset.mul_prod_erase s (privateQuotient base s d) hi
  have hendpointFactor :
      collisionCore base s d * privateModulus base s d =
        endpointDenominatorLcm base s d := by
    rw [privateModulus_eq_endpointDenominatorLcm_div_collisionCore
      hbase hpos]
    exact Nat.mul_div_cancel'
      collisionCore_dvd_endpointDenominatorLcm
  have hmul :
      d i *
          (privateWeight base s d i *
            (s.erase i).prod (privateQuotient base s d)) =
        endpointDenominatorLcm base s d := by
    calc
      d i *
            (privateWeight base s d i *
              (s.erase i).prod (privateQuotient base s d)) =
          (Nat.gcd (d i) (collisionCore base s d) *
              privateQuotient base s d i) *
            (privateWeight base s d i *
              (s.erase i).prod (privateQuotient base s d)) := by
                rw [hdFactor]
      _ =
          (Nat.gcd (d i) (collisionCore base s d) *
              privateWeight base s d i) *
            (privateQuotient base s d i *
              (s.erase i).prod (privateQuotient base s d)) := by
                ac_rfl
      _ =
          collisionCore base s d * privateModulus base s d := by
            rw [hcoreFactor, hprivateFactor]
      _ = endpointDenominatorLcm base s d :=
        hendpointFactor
  exact (Nat.eq_div_of_mul_eq_right (hpos i hi).ne' hmul).symm
