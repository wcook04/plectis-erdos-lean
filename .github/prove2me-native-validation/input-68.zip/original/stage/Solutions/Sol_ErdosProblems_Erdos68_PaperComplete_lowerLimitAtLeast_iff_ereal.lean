import Definitions.Def_ErdosProblems_Erdos68_ChannelBreakpointRigidity
import Definitions.Def_ErdosProblems_Erdos68_ChannelIntegralCongruence
import Definitions.Def_ErdosProblems_Erdos68_PaperCompleteAsymptotics
import Definitions.Def_ErdosProblems_Erdos68_PaperCompleteRadiusLimit
import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Algebra.GCDMonoid.FinsetLemmas
import Mathlib.Algebra.Ring.GeomSum
import Mathlib.Analysis.Asymptotics.Defs
import Mathlib.Analysis.Complex.ExponentialBounds
import Mathlib.Analysis.Real.Pi.Bounds
import Mathlib.Analysis.SpecialFunctions.Log.Basic
import Mathlib.Analysis.SpecialFunctions.Pow.Real
import Mathlib.Analysis.SpecialFunctions.Sqrt
import Mathlib.Analysis.SpecialFunctions.Stirling
import Mathlib.Data.EReal.Basic
import Mathlib.Data.Nat.Factorial.Basic
import Mathlib.Data.Nat.Factorial.BigOperators
import Mathlib.Data.Nat.ModEq
import Mathlib.Order.LiminfLimsup
import Mathlib.Tactic
import Mathlib.Tactic.Ring
import Mathlib.Topology.Order.Basic

/-!
# Literal liminf statements, without silently assuming finite liminf values

The displayed asymptotic theorems allow the value +infinity. The wrappers use
EReal for the liminf and prove equivalence with the epsilon/eventual assertions
in the main proof files. Thus no unproved upper-boundedness assumption is
introduced merely to fit a real-valued liminf API.

-/

namespace ErdosProblems.Erdos68.PaperComplete
open Filter
open scoped Topology
end ErdosProblems.Erdos68.PaperComplete

open Filter
open scoped Topology
open ErdosProblems in
open ErdosProblems.Erdos68 in
open ErdosProblems.Erdos68.PaperComplete in
theorem solution (f : ℕ → ℝ) (c : ℝ) :
    LowerLimitAtLeast f c ↔
      (c : EReal) ≤ Filter.liminf (fun n : ℕ => (f n : EReal)) atTop := by
  rw [Filter.le_liminf_iff]
  constructor
  · intro h a ha
    cases a using EReal.rec with
    | bot => exact Eventually.of_forall (fun _ => by simp)
    | coe a =>
      have haa : a < c := by exact_mod_cast ha
      simpa only [EReal.coe_lt_coe_iff] using h a haa
    | top => simp at ha
  · intro h a ha
    have he := h (a : EReal) (by exact_mod_cast ha)
    simpa only [EReal.coe_lt_coe_iff] using he
