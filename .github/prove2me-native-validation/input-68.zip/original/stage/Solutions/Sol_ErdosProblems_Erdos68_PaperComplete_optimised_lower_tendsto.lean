import Definitions.Def_ErdosProblems_Erdos68_ChannelBreakpointRigidity
import Definitions.Def_ErdosProblems_Erdos68_ChannelIntegralCongruence
import Definitions.Def_ErdosProblems_Erdos68_PaperCompleteAsymptotics
import Theorems.Thm_ErdosProblems_Erdos68_PaperComplete_inv_log_nat_tendsto_zero
import Theorems.Thm_ErdosProblems_Erdos68_PaperComplete_optimalWindow_lt
import Theorems.Thm_ErdosProblems_Erdos68_PaperComplete_block_start_ratio_tendsto
import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Algebra.GCDMonoid.FinsetLemmas
import Mathlib.Algebra.Ring.GeomSum
import Mathlib.Analysis.Asymptotics.Defs
import Mathlib.Analysis.Complex.ExponentialBounds
import Mathlib.Analysis.Real.Pi.Bounds
import Mathlib.Analysis.SpecialFunctions.Log.Basic
import Mathlib.Analysis.SpecialFunctions.Sqrt
import Mathlib.Analysis.SpecialFunctions.Stirling
import Mathlib.Data.Nat.Factorial.Basic
import Mathlib.Data.Nat.Factorial.BigOperators
import Mathlib.Data.Nat.ModEq
import Mathlib.Tactic
import Mathlib.Tactic.Ring
import Mathlib.Topology.Order.Basic

/-!
# End-to-end candidate for the two displayed sharp asymptotic constants

Long-record labels res:lcm-growth and res:radius-constant.

`LowerLimitAtLeast f c` is the epsilon/eventual formulation of liminf f >= c:
for every a<c, eventually a<f(n). It is deliberately used instead of a
real-valued `Filter.liminf`, whose default value is not an extended-real
infinity when the sequence diverges to +infinity. This representation places
no unproved upper-boundedness hypothesis on the lcm sequence.

The proof starts from the supplied finite product and Stirling inequalities.
It proves the optimising Nat.sqrt limit, the moving logarithm limit, and the
binomial normalisation, rather than assuming their asymptotic conclusions.

STATUS: compiled proof candidates. These are the largest API/elaboration
risks in the return. There are no admitted analytic facts or proof placeholders.
-/

namespace ErdosProblems.Erdos68.PaperComplete
open Filter
open scoped Topology BigOperators









lemma inv_nat_tendsto_zero :
    Tendsto (fun n : ℕ => (n : ℝ)⁻¹) atTop (𝓝 0) :=
  tendsto_inv_atTop_zero.comp tendsto_natCast_atTop_atTop

lemma inv_sqrt_nat_tendsto_zero :
    Tendsto (fun n : ℕ => (Real.sqrt (n : ℝ))⁻¹) atTop (𝓝 0) :=
  tendsto_inv_atTop_zero.comp (Real.tendsto_sqrt_atTop.comp tendsto_natCast_atTop_atTop)








lemma optimal_window_sandwich {N : ℕ} (hN : 0 < N) :
    Real.sqrt 2 - (Real.sqrt (N : ℝ))⁻¹ ≤
        (optimalWindow N : ℝ) / Real.sqrt (N : ℝ) ∧
    (optimalWindow N : ℝ) / Real.sqrt (N : ℝ) ≤ Real.sqrt 2 := by
  have hs : 0 < Real.sqrt (N : ℝ) := Real.sqrt_pos.mpr (by exact_mod_cast hN)
  have hs2 : 0 ≤ Real.sqrt (2 : ℝ) := Real.sqrt_nonneg _
  have hk0 : (0 : ℝ) ≤ optimalWindow N := by positivity
  have hlo : (optimalWindow N : ℝ) ^ 2 ≤ 2 * (N : ℝ) := by
    exact_mod_cast Nat.sqrt_le' (2 * N)
  have hhi : 2 * (N : ℝ) < ((optimalWindow N : ℝ) + 1) ^ 2 := by
    exact_mod_cast Nat.lt_succ_sqrt' (2 * N)
  have hsprod : (Real.sqrt 2 * Real.sqrt (N : ℝ)) ^ 2 = 2 * (N : ℝ) := by
    rw [mul_pow, Real.sq_sqrt (by norm_num), Real.sq_sqrt (by positivity)]
  have hkn : (optimalWindow N : ℝ) ≤ Real.sqrt 2 * Real.sqrt (N : ℝ) := by
    nlinarith [mul_nonneg hs2 hs.le]
  have hnk : Real.sqrt 2 * Real.sqrt (N : ℝ) < (optimalWindow N : ℝ) + 1 := by
    nlinarith [mul_nonneg hs2 hs.le]
  constructor
  · apply (le_div_iff₀ hs).mpr
    calc
      (Real.sqrt 2 - (Real.sqrt (N : ℝ))⁻¹) * Real.sqrt (N : ℝ)
          = Real.sqrt 2 * Real.sqrt (N : ℝ) - 1 := by
            field_simp [hs.ne']
            all_goals ring
      _ ≤ optimalWindow N := by linarith
  · exact (div_le_iff₀ hs).mpr hkn

lemma optimal_window_ratio_tendsto :
    Tendsto (fun N : ℕ => (optimalWindow N : ℝ) / Real.sqrt (N : ℝ))
      atTop (𝓝 (Real.sqrt 2)) := by
  have hlo : Tendsto (fun N : ℕ => Real.sqrt 2 - (Real.sqrt (N : ℝ))⁻¹)
      atTop (𝓝 (Real.sqrt 2)) := by
    simpa using tendsto_const_nhds.sub inv_sqrt_nat_tendsto_zero
  apply tendsto_of_tendsto_of_tendsto_of_le_of_le' hlo tendsto_const_nhds
  · filter_upwards [eventually_ge_atTop 1] with N hN
    exact (optimal_window_sandwich (by omega)).1
  · filter_upwards [eventually_ge_atTop 1] with N hN
    exact (optimal_window_sandwich (by omega)).2







lemma moving_log_ratio_tendsto :
    Tendsto (fun N : ℕ => Real.log (blockStart N : ℝ) / Real.log (N : ℝ))
      atTop (𝓝 1) := by
  have hlog : Tendsto (fun N : ℕ => Real.log ((blockStart N : ℝ) / (N : ℝ)))
      atTop (𝓝 0) := by
    simpa using (Real.continuousAt_log (by norm_num : (1 : ℝ) ≠ 0)).tendsto.comp
      block_start_ratio_tendsto
  have h : Tendsto (fun N : ℕ => 1 +
      Real.log ((blockStart N : ℝ) / N) * (Real.log (N : ℝ))⁻¹)
      atTop (𝓝 1) := by
    simpa using tendsto_const_nhds.add (hlog.mul inv_log_nat_tendsto_zero)
  apply h.congr'
  filter_upwards [eventually_ge_atTop 3] with N hN
  have hstart : 2 ≤ blockStart N := by
    have hk := optimalWindow_lt hN
    dsimp [blockStart]
    omega
  have hb : (blockStart N : ℝ) ≠ 0 := by exact_mod_cast (show blockStart N ≠ 0 by omega)
  have hn : (N : ℝ) ≠ 0 := by exact_mod_cast (show N ≠ 0 by omega)
  have hln : Real.log (N : ℝ) ≠ 0 :=
    (Real.log_pos (by exact_mod_cast (show 1 < N by omega))).ne'
  rw [Real.log_div hb hn]
  field_simp [hln]
  ring

lemma choose_three_cast (k : ℕ) :
    ((k + 1).choose 3 : ℝ) = ((k : ℝ) ^ 3 - k) / 6 := by
  cases k with
  | zero => norm_num
  | succ k =>
    have h := Nat.descFactorial_eq_factorial_mul_choose (k + 2) 3
    norm_num [Nat.descFactorial, Nat.factorial] at h
    have hr := congrArg (fun z : ℕ => (z : ℝ)) h
    push_cast at hr ⊢
    nlinarith

lemma cubic_normalisation {x s a : ℝ} (hs : s ≠ 0) (hsq : s ^ 2 = x) :
    ((a ^ 3 - a) / 6) / (x * s) = ((a / s) ^ 3 - (a / s) / x) / 6 := by
  rw [← hsq]
  field_simp [hs]
  all_goals ring

lemma collision_ratio_tendsto :
    Tendsto (fun N : ℕ => ((optimalWindow N + 1).choose 3 : ℝ) /
      ((N : ℝ) * Real.sqrt (N : ℝ))) atTop (𝓝 ((Real.sqrt 2) ^ 3 / 6)) := by
  have h := ((optimal_window_ratio_tendsto.pow 3).sub
    (optimal_window_ratio_tendsto.mul inv_nat_tendsto_zero)).div_const 6
  have h0 : Tendsto (fun N : ℕ => (((optimalWindow N : ℝ) / Real.sqrt (N : ℝ)) ^ 3 -
      ((optimalWindow N : ℝ) / Real.sqrt (N : ℝ)) * (N : ℝ)⁻¹) / 6)
      atTop (𝓝 ((Real.sqrt 2) ^ 3 / 6)) := by simpa using h
  apply h0.congr'
  filter_upwards [eventually_ge_atTop 1] with N hN
  have hs : Real.sqrt (N : ℝ) ≠ 0 :=
    (Real.sqrt_pos.mpr (by exact_mod_cast (show 0 < N by omega))).ne'
  rw [choose_three_cast, cubic_normalisation hs (Real.sq_sqrt (by positivity))]
  simp only [div_eq_mul_inv]
end ErdosProblems.Erdos68.PaperComplete

open Filter
open scoped Topology BigOperators
open ErdosProblems in
open ErdosProblems.Erdos68 in
open ErdosProblems.Erdos68.PaperComplete in
theorem solution :
    Tendsto optimisedLogLower atTop (𝓝 (2 * Real.sqrt 2 / 3)) := by
  have hmain := (optimal_window_ratio_tendsto.mul block_start_ratio_tendsto).mul
    moving_log_ratio_tendsto
  have hlinear := (optimal_window_ratio_tendsto.mul block_start_ratio_tendsto).mul
    inv_log_nat_tendsto_zero
  have hconstant := ((optimal_window_ratio_tendsto.mul inv_nat_tendsto_zero).mul
    inv_log_nat_tendsto_zero).mul_const (Real.log 2)
  have h := ((hmain.sub hlinear).sub hconstant).sub collision_ratio_tendsto
  have hlim : Real.sqrt 2 - Real.sqrt 2 ^ 3 / 6 = 2 * Real.sqrt 2 / 3 := by
    have hs := Real.sq_sqrt (by norm_num : (0 : ℝ) ≤ 2)
    calc
      Real.sqrt 2 - Real.sqrt 2 ^ 3 / 6
          = Real.sqrt 2 - (Real.sqrt 2 ^ 2 * Real.sqrt 2) / 6 := by ring
      _ = 2 * Real.sqrt 2 / 3 := by rw [hs]; ring
  have h' : Tendsto
      (fun N : ℕ =>
        ((optimalWindow N : ℝ) / Real.sqrt (N : ℝ)) * ((blockStart N : ℝ) / N) *
          (Real.log (blockStart N : ℝ) / Real.log (N : ℝ)) -
        ((optimalWindow N : ℝ) / Real.sqrt (N : ℝ)) * ((blockStart N : ℝ) / N) *
          (Real.log (N : ℝ))⁻¹ -
        (((optimalWindow N : ℝ) / Real.sqrt (N : ℝ)) * (N : ℝ)⁻¹ *
          (Real.log (N : ℝ))⁻¹) * Real.log 2 -
        ((optimalWindow N + 1).choose 3 : ℝ) / ((N : ℝ) * Real.sqrt (N : ℝ)))
      atTop (𝓝 (2 * Real.sqrt 2 / 3)) := by
    simpa only [mul_one, mul_zero, zero_mul, sub_zero, hlim] using h
  apply h'.congr'
  filter_upwards [eventually_ge_atTop 3] with N hN
  have hn : (N : ℝ) ≠ 0 := by exact_mod_cast (show N ≠ 0 by omega)
  have hs : Real.sqrt (N : ℝ) ≠ 0 :=
    (Real.sqrt_pos.mpr (by exact_mod_cast (show 0 < N by omega))).ne'
  have hl : Real.log (N : ℝ) ≠ 0 :=
    (Real.log_pos (by exact_mod_cast (show 1 < N by omega))).ne'
  dsimp [optimisedLogLower, blockLogLower, blockStart]
  field_simp [hn, hs, hl]
  all_goals ring
