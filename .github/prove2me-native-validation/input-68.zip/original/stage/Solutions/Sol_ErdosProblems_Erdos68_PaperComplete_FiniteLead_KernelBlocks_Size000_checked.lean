import Definitions.Def_ErdosProblems_Erdos68_PaperCompleteKernelFloorAlgorithm
import Definitions.Def_ErdosProblems_Erdos68_FiniteLeadBlocks_Size000
import Init

/-! Generated untrusted witness, followed by an ordinary kernel computation.
The result below is NOT imported from C++ or from a Boolean log entry.
Lean v4.29.1 src/Lean/Elab/Tactic/Decide.lean implements `decide +kernel`
by adding and kernel-checking the complete decidable proof, without native trust.
This source was generated but could not be compiled in the return environment.
-/
set_option maxRecDepth 1000000
set_option maxHeartbeats 0

open ErdosProblems in
open ErdosProblems.Erdos68 in
open ErdosProblems.Erdos68.PaperComplete in
open ErdosProblems.Erdos68.PaperComplete.FiniteLead in
open ErdosProblems.Erdos68.PaperComplete.FiniteLead.KernelBlocks in
open ErdosProblems.Erdos68.PaperComplete.FiniteLead.KernelBlocks.Size000 in
theorem solution : kernelFloorBlock (2 ^ 80000) 2 4096 = value := by
  decide +kernel
