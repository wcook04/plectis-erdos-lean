import Definitions.Def_ErdosProblems_Erdos68_ChannelBreakpointRigidity
import Definitions.Def_ErdosProblems_Erdos68_ChannelIntegralCongruence
import Definitions.Def_ErdosProblems_Erdos68_PaperCompleteAsymptotics
import Theorems.Thm_Erdos68_channelLCM_pos
import Theorems.Thm_Erdos68_factorialGapSegment_base_pow_le_channelLCM_mul_pow_choose
import Theorems.Thm_Erdos68_log_factorial_sub_one_lower_bound
import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Algebra.GCDMonoid.FinsetLemmas
import Mathlib.Algebra.Ring.GeomSum
import Mathlib.Analysis.Asymptotics.Defs
import Mathlib.Analysis.Complex.ExponentialBounds
import Mathlib.Analysis.Real.Pi.Bounds
import Mathlib.Analysis.SpecialFunctions.Log.Basic
import Mathlib.Analysis.SpecialFunctions.Sqrt
import Mathlib.Analysis.SpecialFunctions.Stirling
import Mathlib.Data.Nat.Factorial.Basic
import Mathlib.Data.Nat.Factorial.BigOperators
import Mathlib.Data.Nat.ModEq
import Mathlib.Tactic
import Mathlib.Tactic.Ring
import Mathlib.Topology.Order.Basic

/-!
# End-to-end candidate for the two displayed sharp asymptotic constants

Long-record labels res:lcm-growth and res:radius-constant.

`LowerLimitAtLeast f c` is the epsilon/eventual formulation of liminf f >= c:
for every a<c, eventually a<f(n). It is deliberately used instead of a
real-valued `Filter.liminf`, whose default value is not an extended-real
infinity when the sequence diverges to +infinity. This representation places
no unproved upper-boundedness hypothesis on the lcm sequence.

The proof starts from the supplied finite product and Stirling inequalities.
It proves the optimising Nat.sqrt limit, the moving logarithm limit, and the
binomial normalisation, rather than assuming their asymptotic conclusions.

STATUS: compiled proof candidates. These are the largest API/elaboration
risks in the return. There are no admitted analytic facts or proof placeholders.
-/

namespace ErdosProblems.Erdos68.PaperComplete
open Filter
open scoped Topology BigOperators
end ErdosProblems.Erdos68.PaperComplete

open Filter
open scoped Topology BigOperators
open ErdosProblems in
open ErdosProblems.Erdos68 in
open ErdosProblems.Erdos68.PaperComplete in
theorem solution {N k : ℕ} (hk : k < N) :
    blockLogLower N k ≤ Real.log (_root_.Erdos68.channelLCM N : ℝ) := by
  have hn : 2 ≤ N + 1 - k := by omega
  have hN : 0 < N := by omega
  have hL : (0 : ℝ) < _root_.Erdos68.channelLCM N := by
    exact_mod_cast _root_.Erdos68.channelLCM_pos N
  have hgap : (0 : ℝ) < ((N + 1 - k).factorial - 1 : ℕ) := by
    exact_mod_cast Nat.sub_pos_of_lt (Nat.one_lt_factorial.mpr hn)
  have hnat := _root_.Erdos68.factorialGapSegment_base_pow_le_channelLCM_mul_pow_choose hk
  have hr : (((N + 1 - k).factorial - 1 : ℕ) : ℝ) ^ k ≤
      (_root_.Erdos68.channelLCM N : ℝ) * (N : ℝ) ^ ((k + 1).choose 3) := by
    exact_mod_cast hnat
  have hl := Real.log_le_log (pow_pos hgap _) hr
  rw [Real.log_pow, Real.log_mul hL.ne' (pow_ne_zero _ (by exact_mod_cast hN.ne')),
    Real.log_pow] at hl
  have hs := _root_.Erdos68.log_factorial_sub_one_lower_bound hn
  have hm := mul_le_mul_of_nonneg_left hs (by positivity : (0 : ℝ) ≤ k)
  unfold blockLogLower
  linarith
