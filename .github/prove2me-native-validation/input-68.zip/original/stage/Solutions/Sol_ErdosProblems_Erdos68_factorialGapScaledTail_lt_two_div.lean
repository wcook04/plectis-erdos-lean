import Definitions.Def_ErdosProblems_Erdos68_CanonicalFactorialDigits
import Definitions.Def_ErdosProblems_Erdos68_ChannelBreakpointRigidity
import Definitions.Def_ErdosProblems_Erdos68_ChannelIntegralCongruence
import Definitions.Def_ErdosProblems_Erdos68_PrimeUnitTranslator
import Definitions.Def_ErdosProblems_Erdos68_FactorialGapPlateauCore
import Definitions.Def_ErdosProblems_Erdos68_FactorialChannelCertificate
import Definitions.Def_ErdosProblems_Erdos68_EndpointWeightedPrivateSupport
import Definitions.Def_ErdosProblems_Erdos68_PrimeZeroBranch
import Theorems.Thm_Erdos68_factorialGapTail_lt_one_div_factorial
import Theorems.Thm_ErdosProblems_Erdos68_factorialGapTail_eq_next_add_tail
import Lean.Elab.Tactic.Omega
import Mathlib.Algebra.BigOperators.Fin
import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Algebra.GCDMonoid.FinsetLemmas
import Mathlib.Algebra.Order.Floor.Ring
import Mathlib.Algebra.Order.Round
import Mathlib.Algebra.Ring.GeomSum
import Mathlib.Analysis.Asymptotics.Defs
import Mathlib.Analysis.Complex.ExponentialBounds
import Mathlib.Analysis.Real.Pi.Bounds
import Mathlib.Analysis.SpecialFunctions.Stirling
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Data.Fin.VecNotation
import Mathlib.Data.Finsupp.Basic
import Mathlib.Data.Int.Basic
import Mathlib.Data.Int.ModEq
import Mathlib.Data.Nat.Choose.Multinomial
import Mathlib.Data.Nat.Factorial.Basic
import Mathlib.Data.Nat.Factorial.BigOperators
import Mathlib.Data.Nat.Factorization.Basic
import Mathlib.Data.Nat.GCD.BigOperators
import Mathlib.Data.Nat.ModEq
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.Nat.Prime.Factorial
import Mathlib.Data.Nat.Prime.Infinite
import Mathlib.Data.Rat.Lemmas
import Mathlib.Data.ZMod.Factorial
import Mathlib.LinearAlgebra.Matrix.Adjugate
import Mathlib.LinearAlgebra.Vandermonde
import Mathlib.NumberTheory.Divisors
import Mathlib.NumberTheory.Real.Irrational
import Mathlib.NumberTheory.Wilson
import Mathlib.Tactic
import Mathlib.Tactic.FinCases
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.NormNum.NatFactorial
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.InfiniteSum.Basic
import Mathlib.Topology.Algebra.InfiniteSum.Ring

/-!
# Erdős #68: the prime zero branch

This module develops three linked layers of the factorial-gap series.

First, exact prefix identities express the step carry through a binary
endpoint flag and the canonical factorial digit.  A unit carry is therefore
equivalent to one of two endpoint cylinders: a zero digit with two zero
flags, or the maximal digit with two one flags.

Second, reduced predecessor fractions are followed prime by prime.  The
formalized arithmetic includes prefix-private prime powers, accumulated
denominator factors, collision and residual cofactors, and exact finite
records at the primes `107` and `971`.  In particular, prefix-private
factorial-gap hits occur cofinally and the corresponding numerator
projections are nonzero under the stated divisibility hypotheses.

Third, a family of conditional theorems shows that sufficiently large
predecessor residues, supplied cofinally, would force irrationality.  The
module does **not** prove those quantitative lower bounds: a nonzero residue
is not enough.  It therefore proves no unconditional irrationality theorem
and does not settle Erdős #68.
-/

namespace ErdosProblems.Erdos68
/-! ## Scaled tails and endpoint flags -/
end ErdosProblems.Erdos68

open ErdosProblems in
open ErdosProblems.Erdos68 in
theorem solution
    {m : ℕ} (hm : 2 ≤ m) :
    factorialGapScaledTail m < 2 / (m : ℝ) := by
  have hsplit := factorialGapTail_eq_next_add_tail m
  have hnextTail :=
    _root_.Erdos68.factorialGapTail_lt_one_div_factorial
      (D := m + 1) (by omega)
  have hfacNat :
      (m + 1).factorial = (m + 1) * m.factorial :=
    Nat.factorial_succ m
  have hfac :
      ((m + 1).factorial : ℝ) =
        ((m + 1 : ℕ) : ℝ) * (m.factorial : ℝ) := by
    exact_mod_cast hfacNat
  have hsuccCast :
      ((m + 1 : ℕ) : ℝ) = (m : ℝ) + 1 := by
    norm_num
  have hfacGt : (1 : ℝ) < m.factorial := by
    exact_mod_cast Nat.one_lt_factorial.mpr hm
  have hfacPos : (0 : ℝ) < m.factorial := by positivity
  have hmPos : (0 : ℝ) < m := by positivity
  have hsuccPos : (0 : ℝ) < (m + 1 : ℕ) := by positivity
  have hcast :
      (((((m + 1).factorial : ℤ) - 1 : ℤ)) : ℝ) =
        ((m + 1).factorial : ℝ) - 1 := by
    norm_num
  rw [hcast] at hsplit
  have hdenPos :
      (0 : ℝ) < ((m + 1).factorial : ℝ) - 1 := by
    have hsuccOne : (1 : ℝ) ≤ (m + 1 : ℕ) := by
      exact_mod_cast (show 1 ≤ m + 1 by omega)
    have hprodGt :
        (1 : ℝ) <
          ((m + 1 : ℕ) : ℝ) * (m.factorial : ℝ) := by
      calc
        (1 : ℝ) < (m.factorial : ℝ) := hfacGt
        _ = 1 * (m.factorial : ℝ) := by ring
        _ ≤ ((m + 1 : ℕ) : ℝ) * (m.factorial : ℝ) :=
          mul_le_mul_of_nonneg_right hsuccOne hfacPos.le
    rw [hfac]
    linarith
  have hfirst :
      (m.factorial : ℝ) /
          (((m + 1).factorial : ℝ) - 1) <
        1 / (m : ℝ) := by
    rw [div_lt_div_iff₀ hdenPos hmPos, hfac, hsuccCast]
    ring_nf
    nlinarith
  have hsecond :
      (m.factorial : ℝ) *
          _root_.Erdos68.factorialGapTail (m + 1) <
        1 / ((m + 1 : ℕ) : ℝ) := by
    have hmul := mul_lt_mul_of_pos_left hnextTail hfacPos
    calc
      (m.factorial : ℝ) *
            _root_.Erdos68.factorialGapTail (m + 1) <
          (m.factorial : ℝ) /
            ((m + 1).factorial : ℝ) := by
              simpa [div_eq_mul_inv] using hmul
      _ = 1 / ((m + 1 : ℕ) : ℝ) := by
        rw [hfac]
        field_simp
  have hsimple :
      1 / (m : ℝ) + 1 / ((m + 1 : ℕ) : ℝ) <
        2 / (m : ℝ) := by
    rw [hsuccCast]
    field_simp
    nlinarith
  unfold factorialGapScaledTail
  rw [hsplit]
  calc
    (m.factorial : ℝ) *
          (1 / (((m + 1).factorial : ℝ) - 1) +
            _root_.Erdos68.factorialGapTail (m + 1)) =
        (m.factorial : ℝ) /
            (((m + 1).factorial : ℝ) - 1) +
          (m.factorial : ℝ) *
            _root_.Erdos68.factorialGapTail (m + 1) := by ring
    _ < 1 / (m : ℝ) + 1 / ((m + 1 : ℕ) : ℝ) :=
      add_lt_add hfirst hsecond
    _ < 2 / (m : ℝ) := hsimple
