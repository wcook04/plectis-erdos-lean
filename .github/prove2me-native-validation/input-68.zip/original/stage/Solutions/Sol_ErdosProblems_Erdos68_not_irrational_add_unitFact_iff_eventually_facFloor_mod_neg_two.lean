import Definitions.Def_ErdosProblems_Erdos68_CanonicalFactorialDigits
import Definitions.Def_ErdosProblems_Erdos68_ChannelBreakpointRigidity
import Definitions.Def_ErdosProblems_Erdos68_ChannelIntegralCongruence
import Definitions.Def_ErdosProblems_Erdos68_PrimeUnitTranslator
import Definitions.Def_ErdosProblems_Erdos68_FactorialGapPlateauCore
import Definitions.Def_ErdosProblems_Erdos68_CompanionConstantBridge
import Definitions.Def_ErdosProblems_Erdos68_ConstantOnlyMissCertificates
import Definitions.Def_ErdosProblems_Erdos68_SecondLayerDigit
import Definitions.Def_ErdosProblems_Erdos68_CompanionOrbitRationality
import Theorems.Thm_ErdosProblems_Erdos68_canonicalDigit_eq_sub_two_of_facFloor_mod_eq_neg_two
import Theorems.Thm_ErdosProblems_Erdos68_eventually_facFloor_mod_neg_two_of_not_irrational_add_unitFact
import Theorems.Thm_ErdosProblems_Erdos68_facFloor_mod_eq_neg_two_of_canonicalDigit_eq_sub_two
import Theorems.Thm_ErdosProblems_Erdos68_not_irrational_add_unitFact_of_eventually_canonicalDigit_eq_sub_two
import Mathlib.Algebra.BigOperators.Fin
import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Algebra.GCDMonoid.FinsetLemmas
import Mathlib.Algebra.Order.Floor.Ring
import Mathlib.Algebra.Order.Round
import Mathlib.Algebra.Ring.GeomSum
import Mathlib.Analysis.Asymptotics.Defs
import Mathlib.Analysis.Complex.ExponentialBounds
import Mathlib.Analysis.Real.Pi.Bounds
import Mathlib.Analysis.SpecialFunctions.Stirling
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Data.Fin.VecNotation
import Mathlib.Data.Int.Basic
import Mathlib.Data.Nat.Cast.Field
import Mathlib.Data.Nat.Factorial.Basic
import Mathlib.Data.Nat.Factorial.BigOperators
import Mathlib.Data.Nat.ModEq
import Mathlib.Data.Nat.Multiplicity
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.Rat.Floor
import Mathlib.LinearAlgebra.Matrix.Adjugate
import Mathlib.LinearAlgebra.Vandermonde
import Mathlib.NumberTheory.Real.Irrational
import Mathlib.Tactic
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.FinCases
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.InfiniteSum.Basic
import Mathlib.Topology.Algebra.InfiniteSum.Ring

/-!
# Erdős #68: full companion-orbit rationality boundary

This module promotes the pointwise companion-floor arithmetic to the infinite
rationality statement.  The fixed companion constant is

`C = ∑_{n≥2} 1/(n!(n!−1)) = S - (exp 1 - 2)`.

The target normal form is that `S` is rational exactly when
`⌊m! C⌋ ≡ -2 (mod m)` eventually.  The forward direction uses the positive
sub-unit remainder in the exponential series.  The reverse direction uses
the equivalent canonical digit tail `d_m(C)=m-2` and the telescoping identity

`∑_{m>N} ((m-2)+1)/m! = 1/N!`.

No cofinal escape claim is made here.
-/

namespace ErdosProblems.Erdos68
open scoped BigOperators





































/-- Eventual exceptional floor residues are exactly eventual exceptional
canonical digits. -/
theorem eventually_facFloor_mod_neg_two_iff_eventually_canonicalDigit_eq_sub_two
    (x : ℝ) :
    (∃ M, ∀ m, M ≤ m → ((facFloor x m + 2 : ℤ) % (m : ℤ)) = 0) ↔
      (∃ M, ∀ m, M ≤ m → canonicalDigit x m = (m : ℤ) - 2) := by
  constructor
  · rintro ⟨M, hM⟩
    refine ⟨max M 3, ?_⟩
    intro m hm
    apply canonicalDigit_eq_sub_two_of_facFloor_mod_eq_neg_two x (by omega)
    exact hM m (by omega)
  · rintro ⟨M, hM⟩
    exact ⟨M, fun m hm =>
      facFloor_mod_eq_neg_two_of_canonicalDigit_eq_sub_two x m (hM m hm)⟩

/-- The generic fixed-orbit rationality boundary in canonical-digit form. -/
theorem not_irrational_add_unitFact_iff_eventually_canonicalDigit_eq_sub_two
    (x : ℝ) :
    ¬ Irrational (x + ∑' n, unitFactTerm n) ↔
      ∃ M, ∀ m, M ≤ m → canonicalDigit x m = (m : ℤ) - 2 := by
  constructor
  · intro hrat
    exact (eventually_facFloor_mod_neg_two_iff_eventually_canonicalDigit_eq_sub_two x).mp
      (eventually_facFloor_mod_neg_two_of_not_irrational_add_unitFact x hrat)
  · exact not_irrational_add_unitFact_of_eventually_canonicalDigit_eq_sub_two x
end ErdosProblems.Erdos68

open scoped BigOperators
open ErdosProblems in
open ErdosProblems.Erdos68 in
theorem solution
    (x : ℝ) :
    ¬ Irrational (x + ∑' n, unitFactTerm n) ↔
      ∃ M, ∀ m, M ≤ m → ((facFloor x m + 2 : ℤ) % (m : ℤ)) = 0 := by
  rw [not_irrational_add_unitFact_iff_eventually_canonicalDigit_eq_sub_two]
  exact (eventually_facFloor_mod_neg_two_iff_eventually_canonicalDigit_eq_sub_two x).symm
