import Definitions.Def_ErdosProblems_Erdos68_CanonicalFactorialDigits
import Definitions.Def_ErdosProblems_Erdos68_ChannelBreakpointRigidity
import Definitions.Def_ErdosProblems_Erdos68_ChannelIntegralCongruence
import Definitions.Def_ErdosProblems_Erdos68_PrimeUnitTranslator
import Definitions.Def_ErdosProblems_Erdos68_FactorialGapPlateauCore
import Definitions.Def_ErdosProblems_Erdos68_CompanionConstantBridge
import Definitions.Def_ErdosProblems_Erdos68_ConstantOnlyMissCertificates
import Definitions.Def_ErdosProblems_Erdos68_SecondLayerDigit
import Definitions.Def_ErdosProblems_Erdos68_CompanionOrbitRationality
import Theorems.Thm_ErdosProblems_Erdos68_summable_canonicalDigitTerm
import Theorems.Thm_ErdosProblems_Erdos68_factorial_expansion_partial
import Theorems.Thm_ErdosProblems_Erdos68_sum_range_succ_canonicalDigitTerm
import Theorems.Thm_ErdosProblems_Erdos68_tendsto_canonicalRemainder_div_factorial_zero
import Mathlib.Algebra.BigOperators.Fin
import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Algebra.GCDMonoid.FinsetLemmas
import Mathlib.Algebra.Order.Floor.Ring
import Mathlib.Algebra.Order.Round
import Mathlib.Algebra.Ring.GeomSum
import Mathlib.Analysis.Asymptotics.Defs
import Mathlib.Analysis.Complex.ExponentialBounds
import Mathlib.Analysis.Real.Pi.Bounds
import Mathlib.Analysis.SpecialFunctions.Stirling
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Data.Fin.VecNotation
import Mathlib.Data.Int.Basic
import Mathlib.Data.Nat.Cast.Field
import Mathlib.Data.Nat.Factorial.Basic
import Mathlib.Data.Nat.Factorial.BigOperators
import Mathlib.Data.Nat.ModEq
import Mathlib.Data.Nat.Multiplicity
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.Rat.Floor
import Mathlib.LinearAlgebra.Matrix.Adjugate
import Mathlib.LinearAlgebra.Vandermonde
import Mathlib.NumberTheory.Real.Irrational
import Mathlib.Tactic
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.FinCases
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.InfiniteSum.Basic
import Mathlib.Topology.Algebra.InfiniteSum.Ring

/-!
# Erdős #68: full companion-orbit rationality boundary

This module promotes the pointwise companion-floor arithmetic to the infinite
rationality statement.  The fixed companion constant is

`C = ∑_{n≥2} 1/(n!(n!−1)) = S - (exp 1 - 2)`.

The target normal form is that `S` is rational exactly when
`⌊m! C⌋ ≡ -2 (mod m)` eventually.  The forward direction uses the positive
sub-unit remainder in the exponential series.  The reverse direction uses
the equivalent canonical digit tail `d_m(C)=m-2` and the telescoping identity

`∑_{m>N} ((m-2)+1)/m! = 1/N!`.

No cofinal escape claim is made here.
-/

namespace ErdosProblems.Erdos68
open scoped BigOperators
end ErdosProblems.Erdos68

open scoped BigOperators
open ErdosProblems in
open ErdosProblems.Erdos68 in
theorem solution (x : ℝ) :
    (∑' m : ℕ, canonicalDigitTerm x m) = x - (⌊x⌋ : ℝ) := by
  have hpartial :
      Filter.Tendsto
        (fun N : ℕ =>
          ∑ m ∈ Finset.Icc 2 N,
            (canonicalDigit x m : ℝ) / (m.factorial : ℝ))
        Filter.atTop (nhds (x - (⌊x⌋ : ℝ))) := by
    have hrem := tendsto_canonicalRemainder_div_factorial_zero x
    have hconst :
        Filter.Tendsto (fun _ : ℕ => x - (⌊x⌋ : ℝ))
          Filter.atTop (nhds (x - (⌊x⌋ : ℝ))) :=
      tendsto_const_nhds
    have htarget :
        Filter.Tendsto
          (fun N : ℕ =>
            (x - (⌊x⌋ : ℝ)) -
              canonicalRemainder x N / (N.factorial : ℝ))
          Filter.atTop (nhds (x - (⌊x⌋ : ℝ))) := by
      simpa using hconst.sub hrem
    apply htarget.congr'
    filter_upwards [Filter.eventually_ge_atTop (1 : ℕ)] with N hN
    have hexpansion := factorial_expansion_partial x N hN
    linarith
  have hseries := summable_canonicalDigitTerm x
  have hsumLimit := hseries.hasSum.tendsto_sum_nat
  have hshifted := hsumLimit.comp (Filter.tendsto_add_atTop_nat 1)
  have hpartialRange :
      Filter.Tendsto
        (fun N : ℕ => ∑ m ∈ Finset.range (N + 1), canonicalDigitTerm x m)
        Filter.atTop (nhds (x - (⌊x⌋ : ℝ))) := by
    apply hpartial.congr'
    exact Filter.Eventually.of_forall fun N =>
      (sum_range_succ_canonicalDigitTerm x N).symm
  exact tendsto_nhds_unique hshifted hpartialRange
