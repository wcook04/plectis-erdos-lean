import Definitions.Def_ErdosProblems_Erdos68_CanonicalFactorialDigits
import Definitions.Def_ErdosProblems_Erdos68_ChannelBreakpointRigidity
import Definitions.Def_ErdosProblems_Erdos68_ChannelIntegralCongruence
import Definitions.Def_ErdosProblems_Erdos68_PrimeUnitTranslator
import Definitions.Def_ErdosProblems_Erdos68_FactorialGapPlateauCore
import Definitions.Def_ErdosProblems_Erdos68_FactorialChannelCertificate
import Definitions.Def_ErdosProblems_Erdos68_EndpointWeightedPrivateSupport
import Definitions.Def_ErdosProblems_Erdos68_PrimeZeroBranch
import Theorems.Thm_ErdosProblems_Erdos68_canonicalRemainder_eq_fract
import Lean.Elab.Tactic.Omega
import Mathlib.Algebra.BigOperators.Fin
import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Algebra.GCDMonoid.FinsetLemmas
import Mathlib.Algebra.Order.Floor.Ring
import Mathlib.Algebra.Order.Round
import Mathlib.Algebra.Ring.GeomSum
import Mathlib.Analysis.Asymptotics.Defs
import Mathlib.Analysis.Complex.ExponentialBounds
import Mathlib.Analysis.Real.Pi.Bounds
import Mathlib.Analysis.SpecialFunctions.Stirling
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Data.Fin.VecNotation
import Mathlib.Data.Finsupp.Basic
import Mathlib.Data.Int.Basic
import Mathlib.Data.Int.ModEq
import Mathlib.Data.Nat.Choose.Multinomial
import Mathlib.Data.Nat.Factorial.Basic
import Mathlib.Data.Nat.Factorial.BigOperators
import Mathlib.Data.Nat.Factorization.Basic
import Mathlib.Data.Nat.GCD.BigOperators
import Mathlib.Data.Nat.ModEq
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.Nat.Prime.Factorial
import Mathlib.Data.Nat.Prime.Infinite
import Mathlib.Data.Rat.Lemmas
import Mathlib.Data.ZMod.Factorial
import Mathlib.LinearAlgebra.Matrix.Adjugate
import Mathlib.LinearAlgebra.Vandermonde
import Mathlib.NumberTheory.Divisors
import Mathlib.NumberTheory.Real.Irrational
import Mathlib.NumberTheory.Wilson
import Mathlib.Tactic
import Mathlib.Tactic.FinCases
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.NormNum.NatFactorial
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.InfiniteSum.Basic
import Mathlib.Topology.Algebra.InfiniteSum.Ring

/-!
# Erdős #68: the prime zero branch

This module develops three linked layers of the factorial-gap series.

First, exact prefix identities express the step carry through a binary
endpoint flag and the canonical factorial digit.  A unit carry is therefore
equivalent to one of two endpoint cylinders: a zero digit with two zero
flags, or the maximal digit with two one flags.

Second, reduced predecessor fractions are followed prime by prime.  The
formalized arithmetic includes prefix-private prime powers, accumulated
denominator factors, collision and residual cofactors, and exact finite
records at the primes `107` and `971`.  In particular, prefix-private
factorial-gap hits occur cofinally and the corresponding numerator
projections are nonzero under the stated divisibility hypotheses.

Third, a family of conditional theorems shows that sufficiently large
predecessor residues, supplied cofinally, would force irrationality.  The
module does **not** prove those quantitative lower bounds: a nonzero residue
is not enough.  It therefore proves no unconditional irrationality theorem
and does not settle Erdős #68.
-/

namespace ErdosProblems.Erdos68
/-! ## Scaled tails and endpoint flags -/



















/-! ## The reduced rational predecessor state -/













































































/-! ## Prime-power persistence in consecutive denominators -/



















/-! ## Prefix-private moduli and finite CRT anchors -/























































/-! ## Accumulated private powers across finite intervals -/

























/-! ## Componentwise private-prime sources -/

































































/-! ## Cofinal private hits and reflected collisions -/







































/-! ## Killed multiplicities and residual-cofactor recurrences -/





























































































/-! ## Wilson quotients and finite repeated-prime records -/































/-! ## Repeated-birth amplification and interval persistence -/

















































/-! ## Endpoint cylinders and the exact carry dichotomy -/
end ErdosProblems.Erdos68

open ErdosProblems in
open ErdosProblems.Erdos68 in
theorem solution
    {x : ℝ} {n q : ℕ} {a : ℤ}
    (hq : 0 < q)
    (hqn : q ≤ n)
    (hx : x = (a : ℝ) / (q : ℝ)) :
    canonicalRemainder x n = 0 := by
  have hqfac : q ∣ n.factorial :=
    Nat.dvd_factorial hq hqn
  have hfac :
      q * (n.factorial / q) = n.factorial :=
    Nat.mul_div_cancel' hqfac
  have hfacR :
      (q : ℝ) * ((n.factorial / q : ℕ) : ℝ) =
        (n.factorial : ℝ) := by
    exact_mod_cast hfac
  have hgrid :
      (n.factorial : ℝ) * x =
        (((n.factorial / q : ℕ) : ℤ) * a : ℤ) := by
    rw [hx, ← hfacR]
    have hqR : (q : ℝ) ≠ 0 := by
      exact_mod_cast (Nat.ne_of_gt hq)
    calc
      ((q : ℝ) * ((n.factorial / q : ℕ) : ℝ)) *
          ((a : ℝ) / (q : ℝ)) =
          ((n.factorial / q : ℕ) : ℝ) *
            ((q : ℝ) * ((a : ℝ) / (q : ℝ))) := by ring
      _ = ((n.factorial / q : ℕ) : ℝ) * (a : ℝ) := by
        rw [mul_div_cancel₀ _ hqR]
      _ = (((n.factorial / q : ℕ) : ℤ) * a : ℤ) := by
        rw [Int.cast_mul, Int.cast_natCast]
  rw [canonicalRemainder_eq_fract, hgrid]
  exact Int.fract_intCast _
