import Definitions.Def_ErdosProblems_Erdos68_FactorialChannelCertificate
import Definitions.Def_ErdosProblems_Erdos68_DivisorChannelBasis
import Definitions.Def_ErdosProblems_Erdos68_PaperCompleteDivisorCoordinates
import Theorems.Thm_ErdosProblems_Erdos68_PaperComplete_synthesis_moment
import Theorems.Thm_ErdosProblems_Erdos68_PaperComplete_synthesis_channel
import Lean.Elab.Tactic.Omega
import Mathlib.Algebra.BigOperators.Finsupp.Basic
import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Data.Finsupp.Basic
import Mathlib.Data.Finsupp.SMul
import Mathlib.Data.Int.ModEq
import Mathlib.Data.Nat.Choose.Multinomial
import Mathlib.Data.Nat.GCD.Prime
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.Rat.Lemmas
import Mathlib.NumberTheory.Divisors
import Mathlib.RingTheory.Coprime.Lemmas
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.NormNum.NatFactorial
import Mathlib.Tactic.Ring

/-!
# Full integral coordinate theorem

Short label res:divisor-channel-coordinates. The supplied library proves the
isolated moment/channel values, but does not prove spanning and uniqueness.
Here the auxiliary index 1 is represented by coordinate 0, and coordinate j>0
represents U_(j+1). Thus coordinates have type ℕ →₀ ℤ with no constrained
coordinate. The target coefficient vectors satisfy f 0 = 0, exactly the
paper's index convention n≥1 before its later restriction to n≥2.

The proof supplies spanning by triangular elimination, independence by the
moment/channel observables, and the explicit coefficient formula. This is
stronger than checking finitely many example matrices.
STATUS: compiled proof candidate. No axioms or proof placeholders.
-/

namespace ErdosProblems.Erdos68.PaperComplete
open scoped BigOperators
open Finsupp
end ErdosProblems.Erdos68.PaperComplete

open scoped BigOperators
open Finsupp
open ErdosProblems in
open ErdosProblems.Erdos68 in
open ErdosProblems.Erdos68.PaperComplete in
theorem solution (a f : ℕ →₀ ℤ)
    (ha : channelSynthesis a = f) :
    a 0 = factorialMoment f ∧
    ∀ d : ℕ, 2 ≤ d →
      a (d - 1) = (channelNumerator f d - factorialMoment f) /
        ((d.factorial : ℤ) - 1) := by
  have hm : a 0 = factorialMoment f := by
    rw [← ha, synthesis_moment]
  refine ⟨hm, ?_⟩
  intro d hd
  have hc := synthesis_channel a d hd
  rw [ha, hm] at hc
  have hfac : (1 : ℤ) < d.factorial := by
    exact_mod_cast Nat.one_lt_factorial.mpr hd
  have hne : (d.factorial : ℤ) - 1 ≠ 0 := by omega
  have hnum : channelNumerator f d - factorialMoment f =
      ((d.factorial : ℤ) - 1) * a (d - 1) := by omega
  have hdiv : ((d.factorial : ℤ) - 1) ∣
      channelNumerator f d - factorialMoment f := ⟨a (d - 1), hnum⟩
  symm
  apply (Int.ediv_eq_iff_eq_mul_left hne hdiv).mpr
  rw [hnum]
  ring
