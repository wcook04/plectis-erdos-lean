import Definitions.Def_ErdosProblems_Erdos68_ChannelBreakpointRigidity
import Definitions.Def_ErdosProblems_Erdos68_ChannelIntegralCongruence
import Theorems.Thm_Erdos68_channelLCM_pos
import Theorems.Thm_Erdos68_list_prod_dvd_lcm_mul_pairwiseGCDProduct
import Theorems.Thm_Erdos68_pairwiseGCDProduct_factorialGapFrom_le
import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Algebra.GCDMonoid.FinsetLemmas
import Mathlib.Algebra.Ring.GeomSum
import Mathlib.Analysis.Asymptotics.Defs
import Mathlib.Analysis.Complex.ExponentialBounds
import Mathlib.Analysis.Real.Pi.Bounds
import Mathlib.Analysis.SpecialFunctions.Stirling
import Mathlib.Data.Nat.Factorial.Basic
import Mathlib.Data.Nat.Factorial.BigOperators
import Mathlib.Data.Nat.ModEq
import Mathlib.Tactic.Ring

/-!
# Integral channel congruence for Erdős problem 68

This module compares a channel numerator with the corresponding factorial
moment modulo `d! - 1`.  The congruence holds for every support index, so
simultaneous cancellation of the channels `2, ..., D` makes their least common
multiple divide the factorial moment.

The second part estimates that least common multiple.  Consecutive numbers
`m! - 1` are compared through their pairwise gcds; this gives an explicit
finite lower bound after the gcd losses are counted.  Consequently, if a
positive integer `M` is divisible by the channel lcm and is smaller than
`(R+1)! - 1`, then `R` must grow at least cubically along `D = 2t^2`.  A later
estimate improves the explicit constant to `R+1 > (3/2)t^3` for `t >= 2^32`.

All conclusions after the congruence theorem retain these stated hypotheses.
In particular, this file does not construct `M` or `R` from the series in
Erdős problem 68, prove that its channels vanish, or decide the rationality of
that series.
-/

namespace Erdos68
/-! ## Product versus lcm with explicit gcd loss -/











/-! ## Factorial-gap collision bounds -/







/-! ## Consecutive factorial-gap segments -/



















/-- Every consecutive factorial-gap segment lcm divides the ambient
`channelLCM`. -/
theorem listLCM_factorialGapFrom_dvd_channelLCM
    {m k D : ℕ} (hm : 2 ≤ m) (hmax : m + k ≤ D + 1) :
    listLCM (factorialGapFrom m k) ∣ channelLCM D := by
  induction k generalizing m with
  | zero => simp [factorialGapFrom, listLCM]
  | succ k ih =>
      rw [factorialGapFrom, listLCM]
      apply Nat.lcm_dvd
      · apply Finset.dvd_lcm
        rw [Finset.mem_Icc]
        omega
      · exact ih (m := m + 1) (by omega) (by omega)







theorem listLCM_factorialGapFrom_pos {m k : ℕ} (hm : 2 ≤ m) :
    0 < listLCM (factorialGapFrom m k) := by
  induction k generalizing m with
  | zero => simp [factorialGapFrom, listLCM]
  | succ k ih =>
      rw [factorialGapFrom, listLCM]
      apply Nat.pos_of_ne_zero
      exact Nat.lcm_ne_zero
        (Nat.ne_of_gt (Nat.sub_pos_of_lt
          (Nat.one_lt_factorial.mpr (by omega))))
        (Nat.ne_of_gt (ih (m := m + 1) (by omega)))

theorem pairwiseGCDProduct_factorialGapFrom_pos
    {m k : ℕ} (hm : 2 ≤ m) :
    0 < pairwiseGCDProduct (factorialGapFrom m k) := by
  induction k generalizing m with
  | zero => simp [factorialGapFrom, pairwiseGCDProduct]
  | succ k ih =>
      rw [factorialGapFrom, pairwiseGCDProduct]
      apply Nat.mul_pos
      · apply List.prod_pos
        intro g hg
        rw [List.mem_map] at hg
        rcases hg with ⟨x, hx, rfl⟩
        exact Nat.gcd_pos_of_pos_left _
          (Nat.sub_pos_of_lt (Nat.one_lt_factorial.mpr (by omega)))
      · exact ih (m := m + 1) (by omega)
end Erdos68

open Erdos68 in
theorem solution
    {m k D : ℕ} (hm : 2 ≤ m) (hmax : m + k ≤ D + 1) :
    (factorialGapFrom m k).prod ≤
      channelLCM D * D ^ pairDistanceExponent k := by
  have hdiv :=
    list_prod_dvd_lcm_mul_pairwiseGCDProduct (factorialGapFrom m k)
  have hmidpos :
      0 < listLCM (factorialGapFrom m k) *
        pairwiseGCDProduct (factorialGapFrom m k) :=
    Nat.mul_pos (listLCM_factorialGapFrom_pos hm)
      (pairwiseGCDProduct_factorialGapFrom_pos hm)
  have hlcm :=
    listLCM_factorialGapFrom_dvd_channelLCM hm hmax
  have hlcm_le :
      listLCM (factorialGapFrom m k) ≤ channelLCM D :=
    Nat.le_of_dvd (channelLCM_pos D) hlcm
  have hpairs :=
    pairwiseGCDProduct_factorialGapFrom_le hm hmax
  calc
    (factorialGapFrom m k).prod ≤
        listLCM (factorialGapFrom m k) *
          pairwiseGCDProduct (factorialGapFrom m k) :=
      Nat.le_of_dvd hmidpos hdiv
    _ ≤ channelLCM D * D ^ pairDistanceExponent k :=
      Nat.mul_le_mul hlcm_le hpairs
