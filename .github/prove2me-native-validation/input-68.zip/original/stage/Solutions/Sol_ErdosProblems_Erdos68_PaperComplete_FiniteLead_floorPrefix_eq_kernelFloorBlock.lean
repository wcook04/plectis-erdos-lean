import Definitions.Def_ErdosProblems_Erdos68_ChannelBreakpointRigidity
import Definitions.Def_ErdosProblems_Erdos68_ChannelIntegralCongruence
import Definitions.Def_ErdosProblems_Erdos68_PrimeUnitTranslator
import Definitions.Def_ErdosProblems_Erdos68_PaperCompleteKernelFloorAlgorithm
import Definitions.Def_ErdosProblems_Erdos68_PaperCompleteDyadicEnclosure
import Theorems.Thm_ErdosProblems_Erdos68_PaperComplete_FiniteLead_kernelFloorBlock_spec
import Init
import Mathlib.Algebra.BigOperators.Fin
import Mathlib.Algebra.BigOperators.Group.Finset.Basic
import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Algebra.GCDMonoid.FinsetLemmas
import Mathlib.Algebra.Order.BigOperators.Group.Finset
import Mathlib.Algebra.Order.Field.Basic
import Mathlib.Algebra.Order.Round
import Mathlib.Algebra.Ring.GeomSum
import Mathlib.Analysis.Asymptotics.Defs
import Mathlib.Analysis.Complex.ExponentialBounds
import Mathlib.Analysis.Real.Pi.Bounds
import Mathlib.Analysis.SpecialFunctions.Stirling
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Data.Fin.VecNotation
import Mathlib.Data.Nat.Factorial.Basic
import Mathlib.Data.Nat.Factorial.BigOperators
import Mathlib.Data.Nat.ModEq
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.LinearAlgebra.Matrix.Adjugate
import Mathlib.LinearAlgebra.Vandermonde
import Mathlib.Order.Interval.Finset.Nat
import Mathlib.Tactic
import Mathlib.Tactic.FinCases
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.InfiniteSum.Basic
import Mathlib.Topology.Algebra.InfiniteSum.Ring

/-!
# Soundness and composition of independently kernel-reduced blocks

All index shifts and interval endpoints are proved symbolically. In particular,
no program outside Lean chooses the terms of the finite sum without a theorem
connecting that choice to `floorPrefix`.

Status: supplied proof candidate; not elaborated in this environment.
-/

namespace ErdosProblems.Erdos68.PaperComplete.FiniteLead
open scoped BigOperators

-- Ascending-factorial APIs below: Mathlib/Data/Nat/Factorial/Basic.lean, pinned source.
end ErdosProblems.Erdos68.PaperComplete.FiniteLead

open scoped BigOperators
open ErdosProblems in
open ErdosProblems.Erdos68 in
open ErdosProblems.Erdos68.PaperComplete in
open ErdosProblems.Erdos68.PaperComplete.FiniteLead in
theorem solution (scale cutoff : Nat) (hc : 2 ≤ cutoff) :
    floorPrefix scale cutoff = kernelFloorBlock scale 2 (cutoff - 1) := by
  rw [kernelFloorBlock_spec]
  unfold floorPrefix
  symm
  -- sum_bij: Mathlib/Algebra/BigOperators/Group/Finset/Defs.lean.
  -- mem_Icc: Mathlib/Order/Interval/Finset/Defs.lean.
  refine Finset.sum_bij (fun j _ => 2 + j) ?_ ?_ ?_ ?_
  · intro j hj
    -- mem_range: Mathlib/Data/Finset/Range.lean.
    dsimp only
    have hjlt : j < cutoff - 1 := Finset.mem_range.mp hj
    exact Finset.mem_Icc.mpr ⟨by omega, by omega⟩
  · intro j hj k hk heq
    dsimp only at heq
    omega
  · intro n hn
    obtain ⟨hn2, hnN⟩ := Finset.mem_Icc.mp hn
    refine ⟨n - 2, Finset.mem_range.mpr (by omega), ?_⟩
    dsimp only
    omega
  · intro j _
    rfl
