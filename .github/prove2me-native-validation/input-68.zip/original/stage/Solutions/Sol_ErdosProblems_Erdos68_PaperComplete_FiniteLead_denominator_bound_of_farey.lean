import Definitions.Def_ErdosProblems_Erdos68_ChannelBreakpointRigidity
import Definitions.Def_ErdosProblems_Erdos68_ChannelIntegralCongruence
import Definitions.Def_ErdosProblems_Erdos68_PrimeUnitTranslator
import Definitions.Def_ErdosProblems_Erdos68_PaperCompleteDyadicEnclosure
import Definitions.Def_ErdosProblems_Erdos68_PaperCompleteFiniteLeadArithmetic
import Theorems.Thm_ErdosProblems_Erdos68_PaperComplete_FiniteLead_DyadicData_sound
import Theorems.Thm_ErdosProblems_Erdos68_PaperComplete_FiniteLead_farey_denominator_lower_bound
import Mathlib.Algebra.BigOperators.Fin
import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Algebra.GCDMonoid.FinsetLemmas
import Mathlib.Algebra.Order.BigOperators.Group.Finset
import Mathlib.Algebra.Order.Field.Basic
import Mathlib.Algebra.Order.Round
import Mathlib.Algebra.Ring.GeomSum
import Mathlib.Analysis.Asymptotics.Defs
import Mathlib.Analysis.Complex.ExponentialBounds
import Mathlib.Analysis.Real.Pi.Bounds
import Mathlib.Analysis.SpecialFunctions.Stirling
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Data.Fin.VecNotation
import Mathlib.Data.Nat.Factorial.Basic
import Mathlib.Data.Nat.Factorial.BigOperators
import Mathlib.Data.Nat.ModEq
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.LinearAlgebra.Matrix.Adjugate
import Mathlib.LinearAlgebra.Vandermonde
import Mathlib.Tactic
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.FinCases
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.InfiniteSum.Basic
import Mathlib.Topology.Algebra.InfiniteSum.Ring

/-!
# Round 8: sound finite arithmetic consumers

The Farey certificate replaces a long continued-fraction proof trace by two
bounding fractions with determinant one. Continued fractions are used only
by the producer to find these fractions; soundness does not depend on that
algorithm, on a quotient count, or on reducedness of the input `a/q`.
The factorial-grid certificate excludes one integer grid directly, without
requiring the historical full carry census.

All validity predicates are decidable finite integer arithmetic. This file
proves their consequences, but does not assert validity of the large data.
Status: proof text, not elaborated in the return environment.
-/

open ErdosProblems in
open ErdosProblems.Erdos68 in
open ErdosProblems.Erdos68.PaperComplete in
open ErdosProblems.Erdos68.PaperComplete.FiniteLead in
theorem solution
    {c : DyadicData} {f : FareyData} {bound : ℕ}
    (hc : c.Valid) (hf : f.Valid c bound)
    (a : ℤ) (q : ℕ) (hq : 0 < q)
    (hS : _root_.Erdos68.factorialGapSeries = (a : ℝ) / q) : bound ≤ q := by
  obtain ⟨hB, hE, hdet, hleft, hright, hbound⟩ := hf
  obtain ⟨hlo, hhi⟩ := DyadicData.sound hc
  have hBR : (0 : ℝ) < f.leftDen := by exact_mod_cast hB
  have hER : (0 : ℝ) < f.rightDen := by exact_mod_cast hE
  have hscale : (0 : ℝ) < (2 ^ c.bits : ℕ) := by positivity
  have hleftR : (f.leftNum : ℝ) * (2 ^ c.bits : ℕ) ≤
      (c.lower : ℝ) * f.leftDen := by exact_mod_cast hleft
  have hrightR : (c.upper : ℝ) * f.rightDen ≤
      (f.rightNum : ℝ) * (2 ^ c.bits : ℕ) := by exact_mod_cast hright
  have hleftEnd : (f.leftNum : ℝ) / f.leftDen ≤
      (c.lower : ℝ) / (2 ^ c.bits : ℕ) :=
    (div_le_div_iff₀ hBR hscale).mpr hleftR
  have hrightEnd : (c.upper : ℝ) / (2 ^ c.bits : ℕ) ≤
      (f.rightNum : ℝ) / f.rightDen :=
    (div_le_div_iff₀ hscale hER).mpr hrightR
  have hleftInside : (f.leftNum : ℝ) / f.leftDen < (a : ℝ) / q := by
    rw [← hS]
    exact hleftEnd.trans_lt hlo
  have hrightInside : (a : ℝ) / q < (f.rightNum : ℝ) / f.rightDen := by
    rw [← hS]
    exact hhi.trans_le hrightEnd
  exact hbound.trans (farey_denominator_lower_bound
    f.leftNum f.leftDen f.rightNum f.rightDen hB hE hdet a q hq
    hleftInside hrightInside)
