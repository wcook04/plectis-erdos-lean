import Definitions.Def_ErdosProblems_Erdos68_CanonicalFactorialDigits
import Definitions.Def_ErdosProblems_Erdos68_ChannelBreakpointRigidity
import Definitions.Def_ErdosProblems_Erdos68_ChannelIntegralCongruence
import Definitions.Def_ErdosProblems_Erdos68_PrimeUnitTranslator
import Definitions.Def_ErdosProblems_Erdos68_FactorialGapPlateauCore
import Definitions.Def_ErdosProblems_Erdos68_FactorialChannelCertificate
import Definitions.Def_ErdosProblems_Erdos68_EndpointWeightedPrivateSupport
import Definitions.Def_ErdosProblems_Erdos68_PrimeZeroBranch
import Definitions.Def_ErdosProblems_Erdos68_PrimePoleCriterion
import Theorems.Thm_ErdosProblems_Erdos68_PaperComplete_factorialGapPrefix_eq_lcm_ratio
import Theorems.Thm_ErdosProblems_Erdos68_PaperComplete_lcm_maximal_cofactor_not_dvd
import Theorems.Thm_ErdosProblems_Erdos68_PaperComplete_lcm_prime_maximum
import Theorems.Thm_ErdosProblems_Erdos68_factorialGapPrefixLCMNumerator_mod_prime
import Theorems.Thm_ErdosProblems_Erdos68_natRatio_den_factorization_eq_iff
import Lean.Elab.Tactic.Omega
import Mathlib.Algebra.BigOperators.Fin
import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Algebra.GCDMonoid.FinsetLemmas
import Mathlib.Algebra.Order.Floor.Ring
import Mathlib.Algebra.Order.Round
import Mathlib.Algebra.Ring.GeomSum
import Mathlib.Analysis.Asymptotics.Defs
import Mathlib.Analysis.Complex.ExponentialBounds
import Mathlib.Analysis.Real.Pi.Bounds
import Mathlib.Analysis.SpecialFunctions.Stirling
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Data.Fin.VecNotation
import Mathlib.Data.Finsupp.Basic
import Mathlib.Data.Int.Basic
import Mathlib.Data.Int.ModEq
import Mathlib.Data.Nat.Choose.Multinomial
import Mathlib.Data.Nat.Factorial.Basic
import Mathlib.Data.Nat.Factorial.BigOperators
import Mathlib.Data.Nat.Factorization.Basic
import Mathlib.Data.Nat.GCD.BigOperators
import Mathlib.Data.Nat.ModEq
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.Nat.Prime.Factorial
import Mathlib.Data.Nat.Prime.Infinite
import Mathlib.Data.Rat.Lemmas
import Mathlib.Data.ZMod.Factorial
import Mathlib.LinearAlgebra.Matrix.Adjugate
import Mathlib.LinearAlgebra.Vandermonde
import Mathlib.NumberTheory.Divisors
import Mathlib.NumberTheory.Real.Irrational
import Mathlib.NumberTheory.Wilson
import Mathlib.Tactic
import Mathlib.Tactic.FinCases
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.NormNum.NatFactorial
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.InfiniteSum.Basic
import Mathlib.Topology.Algebra.InfiniteSum.Ring

namespace ErdosProblems.Erdos68.PaperComplete
end ErdosProblems.Erdos68.PaperComplete

/-!
# End-to-end maximal prime-power survival

Long-record label res:prime-pole. The supplied numerator identity and rational
reduction theorem are not by themselves the displayed theorem. This file
supplies the literal prefix/common-denominator equality, derives the maximum
and attainment hypotheses from the actual LCM, proves its cofactor a unit,
and joins the two existing results. No new analytic premise is used.

-/

namespace ErdosProblems.Erdos68.PaperComplete
open scoped BigOperators

lemma gap_pos {M n : ℕ} (hn : n ∈ Finset.Icc 2 M) :
    0 < n.factorial - 1 :=
  Nat.sub_pos_of_lt (Nat.one_lt_factorial.mpr (Finset.mem_Icc.mp hn).1)

lemma prefix_lcm_pos (M : ℕ) : 0 < factorialGapPrefixLCM M := by
  apply Nat.pos_of_ne_zero
  change (Finset.Icc 2 M).lcm (fun n => n.factorial - 1) ≠ 0
  exact Finset.lcm_ne_zero_iff.mpr (fun n hn => (gap_pos hn).ne')







lemma maximal_hits_eq_valuation_filter {M p e : ℕ} (hp : p.Prime) :
    factorialGapMaxHits p M e =
      (Finset.Icc 2 M).filter (fun n => (n.factorial - 1).factorization p = e) := by
  classical
  ext n
  simp only [factorialGapMaxHits, Finset.mem_filter]
  constructor
  · rintro ⟨hn, he, hnext⟩
    have hle := (hp.pow_dvd_iff_le_factorization (gap_pos hn).ne').mp he
    have hnot := (hp.pow_dvd_iff_le_factorization (k := e + 1) (gap_pos hn).ne')
    have hlt : (n.factorial - 1).factorization p < e + 1 := by
      exact lt_of_not_ge (fun h => hnext (hnot.mpr h))
    exact ⟨hn, by omega⟩
  · rintro ⟨hn, he⟩
    refine ⟨hn, ?_, ?_⟩
    · apply (hp.pow_dvd_iff_le_factorization (gap_pos hn).ne').mpr
      omega
    · intro h
      have := (hp.pow_dvd_iff_le_factorization (gap_pos hn).ne').mp h
      omega
end ErdosProblems.Erdos68.PaperComplete

open scoped BigOperators
open ErdosProblems in
open ErdosProblems.Erdos68 in
open ErdosProblems.Erdos68.PaperComplete in
theorem solution {M p : ℕ} (_hM : 2 ≤ M)
    (hp : p.Prime) (hpL : p ∣ factorialGapPrefixLCM M) :
    (factorialGapPrefix M).den.factorization p =
        (factorialGapPrefixLCM M).factorization p ↔
      (∑ n ∈ (Finset.Icc 2 M).filter
          (fun n => (n.factorial - 1).factorization p =
            (factorialGapPrefixLCM M).factorization p),
        (((n.factorial - 1) /
          p ^ (factorialGapPrefixLCM M).factorization p : ℕ) : ZMod p)⁻¹) ≠ 0 := by
  classical
  letI : Fact p.Prime := ⟨hp⟩
  obtain ⟨he, hmax, hattain⟩ := lcm_prime_maximum hp hpL
  have hnum := factorialGapPrefixLCMNumerator_mod_prime hp he hmax hattain
  have hunit : ((factorialGapPrefixLCM M /
      p ^ (factorialGapPrefixLCM M).factorization p : ℕ) : ZMod p) ≠ 0 := by
    rw [Ne, ZMod.natCast_eq_zero_iff]
    exact lcm_maximal_cofactor_not_dvd (M := M) hp
  rw [factorialGapPrefix_eq_lcm_ratio,
    natRatio_den_factorization_eq_iff hp (prefix_lcm_pos M) hpL]
  have hcriterion : (¬ p ∣ factorialGapPrefixLCMNumerator M) ↔
      factorialGapPrincipalResidue p M
        ((factorialGapPrefixLCM M).factorization p) ≠ 0 := by
    rw [← ZMod.natCast_eq_zero_iff (factorialGapPrefixLCMNumerator M) p, hnum]
    simp only [mul_eq_zero, hunit, false_or]
  simpa only [factorialGapPrincipalResidue, maximal_hits_eq_valuation_filter hp] using hcriterion
