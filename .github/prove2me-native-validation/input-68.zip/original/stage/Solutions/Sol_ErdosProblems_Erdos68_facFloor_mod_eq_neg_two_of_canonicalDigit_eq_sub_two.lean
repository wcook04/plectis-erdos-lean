import Definitions.Def_ErdosProblems_Erdos68_CanonicalFactorialDigits
import Definitions.Def_ErdosProblems_Erdos68_ChannelBreakpointRigidity
import Definitions.Def_ErdosProblems_Erdos68_ChannelIntegralCongruence
import Definitions.Def_ErdosProblems_Erdos68_PrimeUnitTranslator
import Definitions.Def_ErdosProblems_Erdos68_FactorialGapPlateauCore
import Definitions.Def_ErdosProblems_Erdos68_CompanionConstantBridge
import Definitions.Def_ErdosProblems_Erdos68_ConstantOnlyMissCertificates
import Mathlib.Algebra.BigOperators.Fin
import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Algebra.GCDMonoid.FinsetLemmas
import Mathlib.Algebra.Order.Floor.Ring
import Mathlib.Algebra.Order.Round
import Mathlib.Algebra.Ring.GeomSum
import Mathlib.Analysis.Asymptotics.Defs
import Mathlib.Analysis.Complex.ExponentialBounds
import Mathlib.Analysis.Real.Pi.Bounds
import Mathlib.Analysis.SpecialFunctions.Stirling
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Data.Fin.VecNotation
import Mathlib.Data.Int.Basic
import Mathlib.Data.Nat.Factorial.Basic
import Mathlib.Data.Nat.Factorial.BigOperators
import Mathlib.Data.Nat.ModEq
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.LinearAlgebra.Matrix.Adjugate
import Mathlib.LinearAlgebra.Vandermonde
import Mathlib.NumberTheory.Real.Irrational
import Mathlib.Tactic
import Mathlib.Tactic.FinCases
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.InfiniteSum.Basic
import Mathlib.Topology.Algebra.InfiniteSum.Ring

/-!
# Erdős #68: constant-only miss certificates

Let `C = ∑' n, compConstTerm n`.  The companion carrier has the form

`F_m = m! * C - δ_m`,

where `δ_m` is the positive scaled tail.  Once `0 < δ_m < 1`, subtracting the
tail can move the floor down by at most one.  The correct alternatives are

`⌊F_m⌋ = ⌊m! * C⌋`  or  `⌊F_m⌋ = ⌊m! * C⌋ - 1`.

Consequently it is enough to exclude the two adjacent residues `-2` and `-1`
for `⌊m! * C⌋` modulo `m`.  This formulation deliberately uses two floors of
the same fixed constant; it does not use a ceil, since `⌈J⌉ - 1 = ⌊J⌋` when
`J` is nonintegral and therefore misses the possible downward crossing.

The theorem below is the exact floor/congruence consumer.  A companion-tail
estimate may supply its `F_m = J - δ`, `0 < δ < 1` hypotheses without changing
the arithmetic proof.
-/

namespace ErdosProblems.Erdos68
open scoped BigOperators







/-- A factorial-scale floor and its canonical radix digit have the same
residue modulo the current radix, even after the `+2` normalization used by
the companion orbit. -/
theorem facFloor_add_two_emod_eq_canonicalDigit_add_two_emod
    (x : ℝ) (m : ℕ) :
    ((facFloor x m + 2 : ℤ) % (m : ℤ)) =
      ((canonicalDigit x m + 2 : ℤ) % (m : ℤ)) := by
  unfold canonicalDigit
  simp [Int.add_emod, Int.sub_emod]
end ErdosProblems.Erdos68

open scoped BigOperators
open ErdosProblems in
open ErdosProblems.Erdos68 in
theorem solution
    (x : ℝ) (m : ℕ)
    (hdigit : canonicalDigit x m = (m : ℤ) - 2) :
    ((facFloor x m + 2 : ℤ) % (m : ℤ)) = 0 := by
  rw [facFloor_add_two_emod_eq_canonicalDigit_add_two_emod, hdigit]
  simpa only [sub_add_cancel] using (Int.emod_self : (m : ℤ) % (m : ℤ) = 0)
