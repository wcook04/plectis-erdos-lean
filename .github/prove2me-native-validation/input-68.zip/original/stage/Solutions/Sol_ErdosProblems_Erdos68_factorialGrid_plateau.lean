import Definitions.Def_ErdosProblems_Erdos68_CanonicalFactorialDigits
import Definitions.Def_ErdosProblems_Erdos68_ChannelBreakpointRigidity
import Definitions.Def_ErdosProblems_Erdos68_ChannelIntegralCongruence
import Definitions.Def_ErdosProblems_Erdos68_PrimeUnitTranslator
import Definitions.Def_ErdosProblems_Erdos68_FactorialGapPlateauCore
import Mathlib.Algebra.BigOperators.Fin
import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Algebra.GCDMonoid.FinsetLemmas
import Mathlib.Algebra.Order.Floor.Ring
import Mathlib.Algebra.Order.Round
import Mathlib.Algebra.Ring.GeomSum
import Mathlib.Analysis.Asymptotics.Defs
import Mathlib.Analysis.Complex.ExponentialBounds
import Mathlib.Analysis.Real.Pi.Bounds
import Mathlib.Analysis.SpecialFunctions.Stirling
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Data.Fin.VecNotation
import Mathlib.Data.Int.Basic
import Mathlib.Data.Nat.Factorial.Basic
import Mathlib.Data.Nat.Factorial.BigOperators
import Mathlib.Data.Nat.ModEq
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.LinearAlgebra.Matrix.Adjugate
import Mathlib.LinearAlgebra.Vandermonde
import Mathlib.NumberTheory.Real.Irrational
import Mathlib.Tactic
import Mathlib.Tactic.FinCases
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.InfiniteSum.Basic
import Mathlib.Topology.Algebra.InfiniteSum.Ring

/-!
# Erdős #68: factorial-gap plateau core

Lightweight core for the strict-successor recurrence, carry bounds, and the
exact divisibility criterion.  Heavy exact-index certificates live in
`FactorialZeroPlateauCertificates`; the full plateau file re-exports both.
-/

namespace ErdosProblems.Erdos68
/-! ## Factorial grid arithmetic -/
end ErdosProblems.Erdos68

open ErdosProblems in
open ErdosProblems.Erdos68 in
theorem solution
    {n : ℕ} {H G S : ℝ} {z : ℤ}
    (hHG : H < G)
    (hGS : G ≤ S)
    (htail : (n.factorial : ℝ) * (S - H) < 1)
    (hgrid : (n.factorial : ℝ) * G = (z : ℝ)) :
    strictFacTop H n = z ∧ facFloor S n = z := by
  have hfacPos : (0 : ℝ) < n.factorial := by positivity
  have hscaledHG : (n.factorial : ℝ) * H < (z : ℝ) := by
    rw [← hgrid]
    exact mul_lt_mul_of_pos_left hHG hfacPos
  have hgridGap :
      (n.factorial : ℝ) * (G - H) < 1 := by
    have hGHle : G - H ≤ S - H := by linarith
    have hmul :
        (n.factorial : ℝ) * (G - H) ≤
          (n.factorial : ℝ) * (S - H) :=
      mul_le_mul_of_nonneg_left hGHle hfacPos.le
    linarith
  have hscaledHLower :
      ((z - 1 : ℤ) : ℝ) ≤ (n.factorial : ℝ) * H := by
    push_cast
    rw [← hgrid]
    nlinarith
  have hfloorH :
      ⌊(n.factorial : ℝ) * H⌋ = z - 1 := by
    exact Int.floor_eq_iff.mpr ⟨hscaledHLower, by
      push_cast
      simpa using hscaledHG⟩
  have hscaledSLower :
      (z : ℝ) ≤ (n.factorial : ℝ) * S := by
    rw [← hgrid]
    exact mul_le_mul_of_nonneg_left hGS hfacPos.le
  have hscaledSUpper :
      (n.factorial : ℝ) * S < (z : ℝ) + 1 := by
    rw [← hgrid]
    nlinarith
  constructor
  · simp [strictFacTop, hfloorH]
  · unfold facFloor
    exact Int.floor_eq_iff.mpr ⟨hscaledSLower, hscaledSUpper⟩
