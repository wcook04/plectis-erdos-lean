import Definitions.Def_ErdosProblems_Erdos68_CanonicalFactorialDigits
import Definitions.Def_ErdosProblems_Erdos68_ChannelBreakpointRigidity
import Definitions.Def_ErdosProblems_Erdos68_ChannelIntegralCongruence
import Definitions.Def_ErdosProblems_Erdos68_PrimeUnitTranslator
import Definitions.Def_ErdosProblems_Erdos68_FactorialGapPlateauCore
import Definitions.Def_ErdosProblems_Erdos68_CompanionConstantBridge
import Definitions.Def_ErdosProblems_Erdos68_ConstantOnlyMissCertificates
import Definitions.Def_ErdosProblems_Erdos68_SecondLayerDigit
import Definitions.Def_ErdosProblems_Erdos68_CompanionOrbitRationality
import Theorems.Thm_ErdosProblems_Erdos68_summable_unitFactTerm
import Mathlib.Algebra.BigOperators.Fin
import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Algebra.GCDMonoid.FinsetLemmas
import Mathlib.Algebra.Order.Floor.Ring
import Mathlib.Algebra.Order.Round
import Mathlib.Algebra.Ring.GeomSum
import Mathlib.Analysis.Asymptotics.Defs
import Mathlib.Analysis.Complex.ExponentialBounds
import Mathlib.Analysis.Real.Pi.Bounds
import Mathlib.Analysis.SpecialFunctions.Stirling
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Data.Fin.VecNotation
import Mathlib.Data.Int.Basic
import Mathlib.Data.Nat.Cast.Field
import Mathlib.Data.Nat.Factorial.Basic
import Mathlib.Data.Nat.Factorial.BigOperators
import Mathlib.Data.Nat.ModEq
import Mathlib.Data.Nat.Multiplicity
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.Rat.Floor
import Mathlib.LinearAlgebra.Matrix.Adjugate
import Mathlib.LinearAlgebra.Vandermonde
import Mathlib.NumberTheory.Real.Irrational
import Mathlib.Tactic
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.FinCases
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.InfiniteSum.Basic
import Mathlib.Topology.Algebra.InfiniteSum.Ring

/-!
# Erdős #68: full companion-orbit rationality boundary

This module promotes the pointwise companion-floor arithmetic to the infinite
rationality statement.  The fixed companion constant is

`C = ∑_{n≥2} 1/(n!(n!−1)) = S - (exp 1 - 2)`.

The target normal form is that `S` is rational exactly when
`⌊m! C⌋ ≡ -2 (mod m)` eventually.  The forward direction uses the positive
sub-unit remainder in the exponential series.  The reverse direction uses
the equivalent canonical digit tail `d_m(C)=m-2` and the telescoping identity

`∑_{m>N} ((m-2)+1)/m! = 1/N!`.

No cofinal escape claim is made here.
-/

namespace ErdosProblems.Erdos68
open scoped BigOperators
end ErdosProblems.Erdos68

open scoped BigOperators
open ErdosProblems in
open ErdosProblems.Erdos68 in
theorem solution :
    (∑' n : ℕ, unitFactTerm n) = Real.exp 1 - 2 := by
  let u : ℕ → ℝ := fun n => (1 : ℝ) / (n.factorial : ℝ)
  have hu : Summable u := by
    have h :=
      NormedSpace.expSeries_summable' (𝕂 := ℝ) (𝔸 := ℝ) (1 : ℝ)
    simpa [u, div_eq_mul_inv] using h
  have hexp : Real.exp 1 = ∑' n : ℕ, (1 : ℝ) / (n.factorial : ℝ) := by
    rw [Real.exp_eq_exp_ℝ, NormedSpace.exp_eq_tsum_div]
    simp only [one_pow]
  let low : ℕ → ℝ := fun n => if n < 2 then u n else 0
  have hlow : Summable low := by
    refine Summable.of_nonneg_of_le (fun n => ?_) (fun n => ?_) hu
    · simp only [low]
      split <;> positivity
    · simp only [low]
      split
      · exact le_rfl
      · positivity
  have hlowValue : (∑' n : ℕ, low n) = 2 := by
    rw [tsum_eq_sum (s := Finset.range 2)]
    · norm_num [Finset.sum_range_succ, low, u]
    · intro n hn
      simp only [Finset.mem_range, not_lt] at hn
      simp only [low]
      rw [if_neg (by omega)]
  have hdecomp :
      (∑' n : ℕ, unitFactTerm n) + (∑' n : ℕ, low n) =
        ∑' n : ℕ, u n := by
    rw [← summable_unitFactTerm.tsum_add hlow]
    apply tsum_congr
    intro n
    by_cases hn : 2 ≤ n
    · rw [unitFactTerm, if_pos hn]
      simp only [low, u]
      rw [if_neg (by omega)]
      ring
    · have hlt : n < 2 := by omega
      rw [unitFactTerm, if_neg hn]
      simp only [low, u]
      rw [if_pos hlt]
      simp
  rw [hlowValue] at hdecomp
  rw [show (∑' n : ℕ, u n) = Real.exp 1 by simpa [u] using hexp.symm]
    at hdecomp
  linarith
