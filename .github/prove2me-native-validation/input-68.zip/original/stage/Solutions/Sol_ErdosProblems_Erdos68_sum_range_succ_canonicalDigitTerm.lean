import Definitions.Def_ErdosProblems_Erdos68_CanonicalFactorialDigits
import Definitions.Def_ErdosProblems_Erdos68_ChannelBreakpointRigidity
import Definitions.Def_ErdosProblems_Erdos68_ChannelIntegralCongruence
import Definitions.Def_ErdosProblems_Erdos68_PrimeUnitTranslator
import Definitions.Def_ErdosProblems_Erdos68_FactorialGapPlateauCore
import Definitions.Def_ErdosProblems_Erdos68_CompanionConstantBridge
import Definitions.Def_ErdosProblems_Erdos68_ConstantOnlyMissCertificates
import Definitions.Def_ErdosProblems_Erdos68_SecondLayerDigit
import Definitions.Def_ErdosProblems_Erdos68_CompanionOrbitRationality
import Mathlib.Algebra.BigOperators.Fin
import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Algebra.GCDMonoid.FinsetLemmas
import Mathlib.Algebra.Order.Floor.Ring
import Mathlib.Algebra.Order.Round
import Mathlib.Algebra.Ring.GeomSum
import Mathlib.Analysis.Asymptotics.Defs
import Mathlib.Analysis.Complex.ExponentialBounds
import Mathlib.Analysis.Real.Pi.Bounds
import Mathlib.Analysis.SpecialFunctions.Stirling
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Data.Fin.VecNotation
import Mathlib.Data.Int.Basic
import Mathlib.Data.Nat.Cast.Field
import Mathlib.Data.Nat.Factorial.Basic
import Mathlib.Data.Nat.Factorial.BigOperators
import Mathlib.Data.Nat.ModEq
import Mathlib.Data.Nat.Multiplicity
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.Rat.Floor
import Mathlib.LinearAlgebra.Matrix.Adjugate
import Mathlib.LinearAlgebra.Vandermonde
import Mathlib.NumberTheory.Real.Irrational
import Mathlib.Tactic
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.FinCases
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.InfiniteSum.Basic
import Mathlib.Topology.Algebra.InfiniteSum.Ring

/-!
# Erdős #68: full companion-orbit rationality boundary

This module promotes the pointwise companion-floor arithmetic to the infinite
rationality statement.  The fixed companion constant is

`C = ∑_{n≥2} 1/(n!(n!−1)) = S - (exp 1 - 2)`.

The target normal form is that `S` is rational exactly when
`⌊m! C⌋ ≡ -2 (mod m)` eventually.  The forward direction uses the positive
sub-unit remainder in the exponential series.  The reverse direction uses
the equivalent canonical digit tail `d_m(C)=m-2` and the telescoping identity

`∑_{m>N} ((m-2)+1)/m! = 1/N!`.

No cofinal escape claim is made here.
-/

namespace ErdosProblems.Erdos68
open scoped BigOperators
end ErdosProblems.Erdos68

open scoped BigOperators
open ErdosProblems in
open ErdosProblems.Erdos68 in
theorem solution (x : ℝ) (N : ℕ) :
    (∑ m ∈ Finset.range (N + 1), canonicalDigitTerm x m) =
      ∑ m ∈ Finset.Icc 2 N,
        (canonicalDigit x m : ℝ) / (m.factorial : ℝ) := by
  calc
    (∑ m ∈ Finset.range (N + 1), canonicalDigitTerm x m) =
        ∑ m ∈ Finset.Icc 2 N, canonicalDigitTerm x m := by
      symm
      apply Finset.sum_subset
      · intro m hm
        simp only [Finset.mem_Icc, Finset.mem_range] at hm ⊢
        omega
      · intro m hmRange hmIcc
        have hmSmall : ¬2 ≤ m := by
          intro hmTwo
          apply hmIcc
          simp only [Finset.mem_Icc]
          have hmLt : m < N + 1 := Finset.mem_range.mp hmRange
          omega
        simp [canonicalDigitTerm, hmSmall]
    _ = ∑ m ∈ Finset.Icc 2 N,
          (canonicalDigit x m : ℝ) / (m.factorial : ℝ) := by
      apply Finset.sum_congr rfl
      intro m hm
      rw [canonicalDigitTerm, if_pos (Finset.mem_Icc.mp hm).1]
