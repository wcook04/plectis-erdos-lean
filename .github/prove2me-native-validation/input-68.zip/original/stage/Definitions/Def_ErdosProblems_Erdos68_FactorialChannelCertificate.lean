import Lean.Elab.Tactic.Omega
import Mathlib.Data.Finsupp.Basic
import Mathlib.Data.Int.ModEq
import Mathlib.Data.Nat.Choose.Multinomial
import Mathlib.Data.Rat.Lemmas
import Mathlib.NumberTheory.Divisors
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.NormNum.NatFactorial
import Mathlib.Tactic.Ring

/-!
# Erdős #68: factorial-channel certificates

For each divisor channel `d`, the weight

`i! / (d!)^(⌊i/d⌋)`

is integral, and consecutive weights obey the factorial recurrence except at
indices divisible by `d`.  The coefficient vector `λ = 2e₃ - e₄` then gives
an explicit finite certificate: its channel values and factorial moment can be
computed exactly, and the stated elementary enclosure for the remaining tail
places its residual strictly between `-1` and `0`.

This is a single finite certificate.  It does not supply a cofinal family of
nonzero residuals or prove irrationality of the Erdős #68 series.
-/

namespace ErdosProblems.Erdos68



/-- Integral weight of index `i` in the divisor channel `d`. -/
def channelWeight (i d : ℕ) : ℕ :=
  i.factorial / (d.factorial ^ (i / d))



/-- Finite-support integer numerator in channel `d`. -/
def channelNumerator (lam : ℕ →₀ ℤ) (d : ℕ) : ℤ :=
  lam.sum fun i z => z * (channelWeight i d : ℤ)

/-- The factorial moment of a finite-support coefficient vector. -/
def factorialMoment (lam : ℕ →₀ ℤ) : ℤ :=
  lam.sum fun i z => z * (i.factorial : ℤ)

/-- Sparse recurrence event between consecutive channel columns. -/
def channelEvent (d n : ℕ) : ℤ :=
  n * (channelWeight (n - 1) d : ℤ) -
    (channelWeight n d : ℤ)























end ErdosProblems.Erdos68
