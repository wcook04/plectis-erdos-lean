import Definitions.Def_ErdosProblems_Erdos68_ChannelBreakpointRigidity
import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Algebra.GCDMonoid.FinsetLemmas
import Mathlib.Algebra.Ring.GeomSum
import Mathlib.Analysis.Asymptotics.Defs
import Mathlib.Analysis.Complex.ExponentialBounds
import Mathlib.Analysis.Real.Pi.Bounds
import Mathlib.Analysis.SpecialFunctions.Stirling
import Mathlib.Data.Nat.Factorial.Basic
import Mathlib.Data.Nat.Factorial.BigOperators
import Mathlib.Data.Nat.ModEq
import Mathlib.Tactic.Ring

/-!
# Integral channel congruence for Erdős problem 68

This module compares a channel numerator with the corresponding factorial
moment modulo `d! - 1`.  The congruence holds for every support index, so
simultaneous cancellation of the channels `2, ..., D` makes their least common
multiple divide the factorial moment.

The second part estimates that least common multiple.  Consecutive numbers
`m! - 1` are compared through their pairwise gcds; this gives an explicit
finite lower bound after the gcd losses are counted.  Consequently, if a
positive integer `M` is divisible by the channel lcm and is smaller than
`(R+1)! - 1`, then `R` must grow at least cubically along `D = 2t^2`.  A later
estimate improves the explicit constant to `R+1 > (3/2)t^3` for `t >= 2^32`.

All conclusions after the congruence theorem retain these stated hypotheses.
In particular, this file does not construct `M` or `R` from the series in
Erdős problem 68, prove that its channels vanish, or decide the rationality of
that series.
-/

namespace Erdos68

/-- The least common multiple of the channel moduli through `D`. -/
def channelLCM (D : ℕ) : ℕ :=
  (Finset.Icc 2 D).lcm (fun d => d.factorial - 1)













/-! ## Product versus lcm with explicit gcd loss -/

/-- Product of all pairwise gcd collision terms in a list, with each
unordered pair counted once. -/
def pairwiseGCDProduct : List ℕ → ℕ
  | [] => 1
  | a :: tail =>
      (tail.map (Nat.gcd a)).prod * pairwiseGCDProduct tail

/-- Recursive lcm of a list, normalized to `1` on the empty list. -/
def listLCM : List ℕ → ℕ
  | [] => 1
  | a :: tail => Nat.lcm a (listLCM tail)







/-! ## Factorial-gap collision bounds -/







/-! ## Consecutive factorial-gap segments -/

/-- The `k` consecutive factorial gaps beginning at `m`. -/
def factorialGapFrom : ℕ → ℕ → List ℕ
  | _, 0 => []
  | m, k + 1 => (m.factorial - 1) :: factorialGapFrom (m + 1) k

/-- Sum `r + (r+1) + ... + (r+k-1)`.  This recursive form keeps the
collision proof free of natural-number division. -/
def intervalExponent : ℕ → ℕ → ℕ
  | _, 0 => 0
  | r, k + 1 => r + intervalExponent (r + 1) k

/-- Triangular collision exponent `1+...+k`. -/
def triangularExponent (k : ℕ) : ℕ :=
  intervalExponent 1 k

/-- Total pair-distance exponent for a segment of length `k`. -/
def pairDistanceExponent : ℕ → ℕ
  | 0 => 0
  | k + 1 => triangularExponent k + pairDistanceExponent k



























/-- The final `k` factorial gaps ending at `D`, listed from low to high. -/
def factorialGapSegment (D k : ℕ) : List ℕ :=
  factorialGapFrom (D + 1 - k) k



















/-- Optimizing block length from the elementary lcm argument. -/
def radiusOptimizationWindow (D : ℕ) : ℕ :=
  Nat.sqrt (2 * D)
































/-! Additive exact paper correspondence, source commit c129ac97dcbc6a8218ba5f736aeb525c1652f8a5. -/







end Erdos68
