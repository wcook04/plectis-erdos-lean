import Definitions.Def_ErdosProblems_Erdos68_ChannelBreakpointRigidity
import Definitions.Def_ErdosProblems_Erdos68_ChannelIntegralCongruence
import Definitions.Def_ErdosProblems_Erdos68_PaperCompleteAsymptotics
import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Algebra.GCDMonoid.FinsetLemmas
import Mathlib.Algebra.Ring.GeomSum
import Mathlib.Analysis.Asymptotics.Defs
import Mathlib.Analysis.Complex.ExponentialBounds
import Mathlib.Analysis.Real.Pi.Bounds
import Mathlib.Analysis.SpecialFunctions.Log.Basic
import Mathlib.Analysis.SpecialFunctions.Sqrt
import Mathlib.Analysis.SpecialFunctions.Stirling
import Mathlib.Data.Nat.Factorial.Basic
import Mathlib.Data.Nat.Factorial.BigOperators
import Mathlib.Data.Nat.ModEq
import Mathlib.Tactic
import Mathlib.Tactic.Ring
import Mathlib.Topology.Order.Basic

/-!
# The sharp 16/9 radius constant

Long-record label res:radius-constant. Hypotheses are eventual, exactly as on
paper. The proof uses the actual optimised factorial segment, proves its
square-subsequence limiting scale, and rules out every subcritical radius.
It does not replace 16/9 by the already compiled finite 3/2 bound.

STATUS: compiled end-to-end proof candidate; no new axioms or placeholders.
-/
namespace ErdosProblems.Erdos68.PaperComplete

open Filter
open scoped Topology





noncomputable def squareBlockNormalised (t : ℕ) : ℝ :=
  blockLogLower (2 * t ^ 2) (optimalWindow (2 * t ^ 2)) /
    ((t : ℝ) ^ 3 * Real.log (t : ℝ))











end ErdosProblems.Erdos68.PaperComplete
