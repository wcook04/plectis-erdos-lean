import Definitions.Def_ErdosProblems_Erdos68_ChannelBreakpointRigidity
import Definitions.Def_ErdosProblems_Erdos68_ChannelIntegralCongruence
import Definitions.Def_ErdosProblems_Erdos68_PrimeUnitTranslator
import Definitions.Def_ErdosProblems_Erdos68_PaperCompleteDyadicEnclosure
import Mathlib.Algebra.BigOperators.Fin
import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Algebra.GCDMonoid.FinsetLemmas
import Mathlib.Algebra.Order.BigOperators.Group.Finset
import Mathlib.Algebra.Order.Field.Basic
import Mathlib.Algebra.Order.Round
import Mathlib.Algebra.Ring.GeomSum
import Mathlib.Analysis.Asymptotics.Defs
import Mathlib.Analysis.Complex.ExponentialBounds
import Mathlib.Analysis.Real.Pi.Bounds
import Mathlib.Analysis.SpecialFunctions.Stirling
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Data.Fin.VecNotation
import Mathlib.Data.Nat.Factorial.Basic
import Mathlib.Data.Nat.Factorial.BigOperators
import Mathlib.Data.Nat.ModEq
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.LinearAlgebra.Matrix.Adjugate
import Mathlib.LinearAlgebra.Vandermonde
import Mathlib.Tactic
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.FinCases
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.InfiniteSum.Basic
import Mathlib.Topology.Algebra.InfiniteSum.Ring

/-!
# Round 8: sound finite arithmetic consumers

The Farey certificate replaces a long continued-fraction proof trace by two
bounding fractions with determinant one. Continued fractions are used only
by the producer to find these fractions; soundness does not depend on that
algorithm, on a quotient count, or on reducedness of the input `a/q`.
The factorial-grid certificate excludes one integer grid directly, without
requiring the historical full carry census.

All validity predicates are decidable finite integer arithmetic. This file
proves their consequences, but does not assert validity of the large data.
Status: proof text, not elaborated in the return environment.
-/

namespace ErdosProblems.Erdos68.PaperComplete.FiniteLead






structure FareyData where
  leftNum : ℕ
  leftDen : ℕ
  rightNum : ℕ
  rightDen : ℕ
  deriving Repr

/-- The exact finite Farey predicate; the interval contains no hypotheses
about a hypothetical rational denominator. -/
def FareyData.Valid (f : FareyData) (c : DyadicData) (bound : ℕ) : Prop :=
  0 < f.leftDen ∧ 0 < f.rightDen ∧
  f.leftDen * f.rightNum = f.leftNum * f.rightDen + 1 ∧
  f.leftNum * (2 ^ c.bits) ≤ c.lower * f.leftDen ∧
  c.upper * f.rightDen ≤ f.rightNum * (2 ^ c.bits) ∧
  bound ≤ f.leftDen + f.rightDen

instance (f : FareyData) (c : DyadicData) (bound : ℕ) :
    Decidable (f.Valid c bound) := inferInstanceAs
  (Decidable (0 < f.leftDen ∧ 0 < f.rightDen ∧
    f.leftDen * f.rightNum = f.leftNum * f.rightDen + 1 ∧
    f.leftNum * (2 ^ c.bits) ≤ c.lower * f.leftDen ∧
    c.upper * f.rightDen ≤ f.rightNum * (2 ^ c.bits) ∧
    bound ≤ f.leftDen + f.rightDen))





/-- `n!` times the entire dyadic interval is strictly inside one open unit cell.
The cell is computed from the lower endpoint, not supplied as a real premise. -/
def GridCellTarget (c : DyadicData) (n : ℕ) : Prop :=
  let k := n.factorial * c.lower / (2 ^ c.bits)
  k * (2 ^ c.bits) < n.factorial * c.lower ∧
  n.factorial * c.upper < (k + 1) * (2 ^ c.bits)

instance (c : DyadicData) (n : ℕ) : Decidable (GridCellTarget c n) :=
  inferInstanceAs (Decidable
    ((n.factorial * c.lower / (2 ^ c.bits)) * (2 ^ c.bits) < n.factorial * c.lower ∧
      n.factorial * c.upper <
        (n.factorial * c.lower / (2 ^ c.bits) + 1) * (2 ^ c.bits)))






/-- Two additional integer comparisons exhibit the mediant strictly inside
an open dyadic interval. Together with `Valid`, they certify that the sum of
the Farey denominators is the EXACT minimum, not just a lower bound. -/
def FareyData.Sharp (f : FareyData) (c : DyadicData) : Prop :=
  c.lower * (f.leftDen + f.rightDen) <
      (f.leftNum + f.rightNum) * (2 ^ c.bits) ∧
    (f.leftNum + f.rightNum) * (2 ^ c.bits) <
      c.upper * (f.leftDen + f.rightDen)

instance (f : FareyData) (c : DyadicData) : Decidable (f.Sharp c) :=
  inferInstanceAs (Decidable
    (c.lower * (f.leftDen + f.rightDen) <
        (f.leftNum + f.rightNum) * (2 ^ c.bits) ∧
      (f.leftNum + f.rightNum) * (2 ^ c.bits) <
        c.upper * (f.leftDen + f.rightDen)))





end ErdosProblems.Erdos68.PaperComplete.FiniteLead
