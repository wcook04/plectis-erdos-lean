import Definitions.Def_ErdosProblems_Erdos68_CanonicalFactorialDigits
import Definitions.Def_ErdosProblems_Erdos68_ChannelBreakpointRigidity
import Definitions.Def_ErdosProblems_Erdos68_ChannelIntegralCongruence
import Definitions.Def_ErdosProblems_Erdos68_PrimeUnitTranslator
import Definitions.Def_ErdosProblems_Erdos68_FactorialGapPlateauCore
import Definitions.Def_ErdosProblems_Erdos68_CompanionConstantBridge
import Definitions.Def_ErdosProblems_Erdos68_ConstantOnlyMissCertificates
import Definitions.Def_ErdosProblems_Erdos68_SecondLayerDigit
import Definitions.Def_ErdosProblems_Erdos68_CompanionOrbitRationality
import Mathlib.Algebra.BigOperators.Fin
import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Algebra.GCDMonoid.FinsetLemmas
import Mathlib.Algebra.Order.Floor.Ring
import Mathlib.Algebra.Order.Round
import Mathlib.Algebra.Ring.GeomSum
import Mathlib.Analysis.Asymptotics.Defs
import Mathlib.Analysis.Complex.ExponentialBounds
import Mathlib.Analysis.Real.Pi.Bounds
import Mathlib.Analysis.SpecialFunctions.Stirling
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Data.Fin.VecNotation
import Mathlib.Data.Int.Basic
import Mathlib.Data.Nat.Cast.Field
import Mathlib.Data.Nat.Factorial.Basic
import Mathlib.Data.Nat.Factorial.BigOperators
import Mathlib.Data.Nat.ModEq
import Mathlib.Data.Nat.Multiplicity
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.Rat.Floor
import Mathlib.LinearAlgebra.Matrix.Adjugate
import Mathlib.LinearAlgebra.Vandermonde
import Mathlib.NumberTheory.Real.Irrational
import Mathlib.Tactic
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.FinCases
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.InfiniteSum.Basic
import Mathlib.Topology.Algebra.InfiniteSum.Ring

/-!
# Erdős's shifted-factorial family under one companion-orbit boundary

Erdős asked whether `S_t = ∑_{n≥2} 1/(n!+t)` is irrational for every integer
`t`; Problem #68 is the member `t = −1`.  The termwise identity

`1/(n!+t) = 1/n! − t/(n!(n!+t))`

writes every member as `S_t = (e − 2) − t·C_t` with the shifted companion
constant `C_t = ∑_{n≥2} 1/(n!(n!+t))`.  The generic fixed-orbit boundary of
`CompanionOrbitRationality` therefore applies uniformly: for every integer
`t ≥ −1`,

`S_t ∈ ℚ  ⟺  ⌈t·m!·C_t⌉ ≡ 2 (mod m)  for all sufficiently large m`,

equivalently `S_t ∉ ℚ` iff the ceiling escapes the residue `2` cofinally.
The member `t = −1` recovers `⌊m!·C⌋ ≡ −2 (mod m)`, and the member `t = 0`
has `C_0`-orbit `⌈0⌉ = 0`, which never lies in the residue class `2` for
`m ≥ 3`; this reproves the irrationality of `e`.

No member with `t ≠ 0` is decided here.  The theorem is the exact family
boundary, not an irrationality proof for any nonzero shift.
-/

namespace ErdosProblems.Erdos68

open scoped BigOperators

/-- The shifted factorial-gap term `1/(n!+t)`, anchored at `n ≥ 2`. -/
noncomputable def shiftGapTerm (t : ℤ) (n : ℕ) : ℝ :=
  if 2 ≤ n then 1 / ((n.factorial : ℝ) + (t : ℝ)) else 0

/-- The shifted companion term `1/(n!(n!+t))`, anchored at `n ≥ 2`. -/
noncomputable def shiftCompanionTerm (t : ℤ) (n : ℕ) : ℝ :=
  if 2 ≤ n then 1 / ((n.factorial : ℝ) * ((n.factorial : ℝ) + (t : ℝ))) else 0

/-- Erdős's shifted series `S_t = ∑_{n≥2} 1/(n!+t)`. -/
noncomputable def shiftGapSeries (t : ℤ) : ℝ :=
  ∑' n : ℕ, shiftGapTerm t n

/-- The shifted companion constant `C_t = ∑_{n≥2} 1/(n!(n!+t))`. -/
noncomputable def shiftCompanionConstant (t : ℤ) : ℝ :=
  ∑' n : ℕ, shiftCompanionTerm t n


























end ErdosProblems.Erdos68
