import Definitions.Def_ErdosProblems_Erdos68_ChannelBreakpointRigidity
import Definitions.Def_ErdosProblems_Erdos68_ChannelIntegralCongruence
import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Algebra.GCDMonoid.FinsetLemmas
import Mathlib.Algebra.Ring.GeomSum
import Mathlib.Analysis.Asymptotics.Defs
import Mathlib.Analysis.Complex.ExponentialBounds
import Mathlib.Analysis.Real.Pi.Bounds
import Mathlib.Analysis.SpecialFunctions.Log.Basic
import Mathlib.Analysis.SpecialFunctions.Sqrt
import Mathlib.Analysis.SpecialFunctions.Stirling
import Mathlib.Data.Nat.Factorial.Basic
import Mathlib.Data.Nat.Factorial.BigOperators
import Mathlib.Data.Nat.ModEq
import Mathlib.Tactic
import Mathlib.Tactic.Ring
import Mathlib.Topology.Order.Basic

/-!
# End-to-end candidate for the two displayed sharp asymptotic constants

Long-record labels res:lcm-growth and res:radius-constant.

`LowerLimitAtLeast f c` is the epsilon/eventual formulation of liminf f >= c:
for every a<c, eventually a<f(n). It is deliberately used instead of a
real-valued `Filter.liminf`, whose default value is not an extended-real
infinity when the sequence diverges to +infinity. This representation places
no unproved upper-boundedness hypothesis on the lcm sequence.

The proof starts from the supplied finite product and Stirling inequalities.
It proves the optimising Nat.sqrt limit, the moving logarithm limit, and the
binomial normalisation, rather than assuming their asymptotic conclusions.

STATUS: compiled proof candidates. These are the largest API/elaboration
risks in the return. There are no admitted analytic facts or proof placeholders.
-/
namespace ErdosProblems.Erdos68.PaperComplete

open Filter
open scoped Topology BigOperators

/-- Standard extended-real lower-limit assertion, stated without boundedness
side conditions or a choice of infinity representation. -/
def LowerLimitAtLeast (f : ℕ → ℝ) (c : ℝ) : Prop :=
  ∀ a : ℝ, a < c → ∀ᶠ n : ℕ in atTop, a < f n

noncomputable def blockLogLower (N k : ℕ) : ℝ :=
  (k : ℝ) *
    (((N + 1 - k : ℕ) : ℝ) * Real.log ((N + 1 - k : ℕ) : ℝ) -
      (N + 1 - k : ℕ) - Real.log 2) -
    ((k + 1).choose 3 : ℝ) * Real.log (N : ℝ)











noncomputable def optimalWindow (N : ℕ) : ℕ := Nat.sqrt (2 * N)
noncomputable def blockStart (N : ℕ) : ℕ := N + 1 - optimalWindow N





















noncomputable def optimisedLogLower (N : ℕ) : ℝ :=
  blockLogLower N (optimalWindow N) /
    ((N : ℝ) * Real.sqrt (N : ℝ) * Real.log (N : ℝ))





end ErdosProblems.Erdos68.PaperComplete
