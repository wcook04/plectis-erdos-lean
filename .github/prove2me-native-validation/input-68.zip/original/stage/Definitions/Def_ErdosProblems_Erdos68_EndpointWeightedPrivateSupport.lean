import Definitions.Def_ErdosProblems_Erdos68_CanonicalFactorialDigits
import Definitions.Def_ErdosProblems_Erdos68_ChannelBreakpointRigidity
import Definitions.Def_ErdosProblems_Erdos68_ChannelIntegralCongruence
import Definitions.Def_ErdosProblems_Erdos68_PrimeUnitTranslator
import Definitions.Def_ErdosProblems_Erdos68_FactorialGapPlateauCore
import Definitions.Def_ErdosProblems_Erdos68_FactorialChannelCertificate
import Lean.Elab.Tactic.Omega
import Mathlib.Algebra.BigOperators.Fin
import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Algebra.GCDMonoid.FinsetLemmas
import Mathlib.Algebra.Order.Floor.Ring
import Mathlib.Algebra.Order.Round
import Mathlib.Algebra.Ring.GeomSum
import Mathlib.Analysis.Asymptotics.Defs
import Mathlib.Analysis.Complex.ExponentialBounds
import Mathlib.Analysis.Real.Pi.Bounds
import Mathlib.Analysis.SpecialFunctions.Stirling
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Data.Fin.VecNotation
import Mathlib.Data.Finsupp.Basic
import Mathlib.Data.Int.Basic
import Mathlib.Data.Int.ModEq
import Mathlib.Data.Nat.Choose.Multinomial
import Mathlib.Data.Nat.Factorial.Basic
import Mathlib.Data.Nat.Factorial.BigOperators
import Mathlib.Data.Nat.Factorization.Basic
import Mathlib.Data.Nat.GCD.BigOperators
import Mathlib.Data.Nat.ModEq
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.Nat.Prime.Factorial
import Mathlib.Data.Rat.Lemmas
import Mathlib.LinearAlgebra.Matrix.Adjugate
import Mathlib.LinearAlgebra.Vandermonde
import Mathlib.NumberTheory.Divisors
import Mathlib.NumberTheory.Real.Irrational
import Mathlib.Tactic
import Mathlib.Tactic.FinCases
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.NormNum.NatFactorial
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.InfiniteSum.Basic
import Mathlib.Topology.Algebra.InfiniteSum.Ring

/-!
# Erdős #68: collision cores, private residues, and factorial-block endpoints

For a finite denominator family, the pairwise collision core records the
prime powers shared by at least two denominators.  Dividing each denominator
by its part inside this core produces pairwise-coprime private quotients.
Their product is the private modulus `R`; a weighted leave-one-out numerator
is coprime to `R`, so the displayed endpoint numerator has a nonzero residue
whenever `R > 1`.

The abstract part of the file develops these finite gcd, lcm, CRT, and
projection identities.  The factorial-block specialization takes the
denominators `n! - 1` for `p ≤ n < 2p`, identifies the strict-successor
coefficient at `p - 1`, and defines an endpoint window.  Unit carries on the
whole interval `[p,2p]` force that window; so does any rational value whose
denominator is already cleared by `(p-1)!`.

The later theorems give several exact ways to refute the window: a large
private residue, unequal leave-one-out projections, coprime factor-pair
floors, or a uniquely supported prime with a sufficiently large residue.
Cofinal families of any of the stated certificates imply cofinally many
non-unit carries or rational-prefix divisibility failures, and hence imply
irrationality through the earlier carry criterion.

Every irrationality conclusion in this file is conditional.  No theorem
constructs the required cofinal certificate family, proves the needed
projection disagreement or size inequality for arbitrarily large blocks,
or supplies cofinally many uniquely supported factorial-gap primes.  The
finite CRT identities and endpoint reductions therefore do not by themselves
prove the irrationality of the factorial-gap series or solve Erdős #68.
-/

namespace ErdosProblems.Erdos68

/-! ## Collision cores for finite denominator families -/









/-- Lcm of all off-diagonal pairwise gcds in a finite denominator family.
Each index is omitted from its own inner lcm, so diagonal terms do not erase
the private support. -/
def pairwiseCollisionCore
    {ι : Type*} [DecidableEq ι]
    (s : Finset ι) (d : ι → ℕ) : ℕ :=
  s.lcm fun i =>
    (s.erase i).lcm fun j => Nat.gcd (d i) (d j)

/-- The collision core used by the endpoint decomposition also contains a
distinguished base denominator. -/
def collisionCore
    {ι : Type*} [DecidableEq ι]
    (base : ℕ) (s : Finset ι) (d : ι → ℕ) : ℕ :=
  Nat.lcm base (pairwiseCollisionCore s d)

/-- Common denominator for the distinguished base and the finite
denominator family. -/
def endpointDenominatorLcm
    {ι : Type*} [DecidableEq ι]
    (base : ℕ) (s : Finset ι) (d : ι → ℕ) : ℕ :=
  Nat.lcm base (s.lcm d)

/-- Numerator of the reciprocal tail after placing every denominator over
the common endpoint lcm. -/
def endpointTailNumerator
    {ι : Type*} [DecidableEq ι]
    (base : ℕ) (s : Finset ι) (d : ι → ℕ) : ℕ :=
  s.sum fun i => endpointDenominatorLcm base s d / d i

/-- Positive base contribution to the displayed endpoint numerator over
the full common denominator. -/
def endpointBaseNumerator
    {ι : Type*} [DecidableEq ι]
    (K base : ℕ) (s : Finset ι) (d : ι → ℕ) : ℕ :=
  K * (endpointDenominatorLcm base s d / base)

/-- Displayed natural endpoint numerator.  The intended endpoint
application supplies the inequality making this truncated subtraction an
ordinary positive difference. -/
def endpointNumerator
    {ι : Type*} [DecidableEq ι]
    (K base : ℕ) (s : Finset ι) (d : ι → ℕ) : ℕ :=
  endpointBaseNumerator K base s d -
    endpointTailNumerator base s d































































/-! ## Private quotients and weighted CRT numerators -/



/-- Private quotient owned by one denominator after deleting all support
visible in the collision core. -/
def privateQuotient
    {ι : Type*} [DecidableEq ι]
    (base : ℕ) (s : Finset ι) (d : ι → ℕ) (i : ι) : ℕ :=
  d i / Nat.gcd (d i) (collisionCore base s d)



/-- Product of all finite-family private quotients. -/
def privateModulus
    {ι : Type*} [DecidableEq ι]
    (base : ℕ) (s : Finset ι) (d : ι → ℕ) : ℕ :=
  s.prod (privateQuotient base s d)











/-- Weighted leave-one-out CRT numerator for a finite modulus family.  The
term owned by `i` omits exactly the modulus `r i`. -/
def weightedPrivateNumerator
    {ι : Type*} [DecidableEq ι]
    (s : Finset ι) (r a : ι → ℕ) : ℕ :=
  s.sum fun i => a i * (s.erase i).prod r





/-- Canonical weight paired with one private quotient. -/
def privateWeight
    {ι : Type*} [DecidableEq ι]
    (base : ℕ) (s : Finset ι) (d : ι → ℕ) (i : ι) : ℕ :=
  collisionCore base s d /
    Nat.gcd (d i) (collisionCore base s d)

/-- Canonical weighted numerator attached to the finite collision core. -/
def collisionWeightedPrivateNumerator
    {ι : Type*} [DecidableEq ι]
    (base : ℕ) (s : Finset ι) (d : ι → ℕ) : ℕ :=
  weightedPrivateNumerator s
    (privateQuotient base s d)
    (privateWeight base s d)







































/-! ## Endpoint residues and finite projection bounds -/

/-- Canonical projection of a weighted support numerator modulo `Q`. -/
def projectedResidue (T Q : ℕ) : ℕ :=
  T % Q

/-- Canonical projection of the additive inverse of a natural numerator.
The outer remainder sends the zero residue to zero rather than to `Q`. -/
def complementaryProjectedResidue (T Q : ℕ) : ℕ :=
  projectedResidue (Q - projectedResidue T Q) Q



/-- Least nonnegative private-modulus residue of the displayed endpoint
numerator.  Under a nontrivial private modulus, coprimality makes it the
least positive residue. -/
def endpointPrivateResidue
    {ι : Type*} [DecidableEq ι]
    (K base : ℕ) (s : Finset ι) (d : ι → ℕ) : ℕ :=
  projectedResidue
    (endpointNumerator K base s d)
    (privateModulus base s d)



























































/-! ## The factorial-block endpoint window -/



/-- Reciprocal-denominator index block for the factorial endpoint:
`2, …, 2p-1`. -/
def factorialBlockIndices (p : ℕ) : Finset ℕ :=
  Finset.Icc 2 (2 * p - 1)

/-- Literal Erdős #68 reciprocal denominator. -/
def factorialGapDenominator (n : ℕ) : ℕ :=
  n.factorial - 1







/-- Distinguished predecessor-factorial denominator in the prime block. -/
def factorialBlockBase (p : ℕ) : ℕ :=
  (p - 1).factorial

/-- Actual strict-successor coefficient at the predecessor prefix, converted
to a natural number for the displayed positive endpoint numerator. -/
noncomputable def factorialBlockCoefficient (p : ℕ) : ℕ :=
  Int.toNat
    (strictFacTop
      ((factorialGapPrefix (p - 1) : ℚ) : ℝ)
      (p - 1))

/-- Full literal common denominator `L_p`. -/
def factorialBlockEndpointLcm (p : ℕ) : ℕ :=
  endpointDenominatorLcm
    (factorialBlockBase p)
    (factorialBlockIndices p)
    factorialGapDenominator







/-- Literal private modulus `R_p = L_p / C_p`. -/
def factorialBlockPrivateModulus (p : ℕ) : ℕ :=
  privateModulus
    (factorialBlockBase p)
    (factorialBlockIndices p)
    factorialGapDenominator

/-- Common-denominator reciprocal-tail numerator `T_p`. -/
def factorialBlockTailNumerator (p : ℕ) : ℕ :=
  endpointTailNumerator
    (factorialBlockBase p)
    (factorialBlockIndices p)
    factorialGapDenominator

/-- Positive predecessor contribution to the displayed block numerator. -/
noncomputable def factorialBlockBaseNumerator (p : ℕ) : ℕ :=
  endpointBaseNumerator
    (factorialBlockCoefficient p)
    (factorialBlockBase p)
    (factorialBlockIndices p)
    factorialGapDenominator

/-- Literal displayed endpoint numerator `Z_p`. -/
noncomputable def factorialBlockEndpointNumerator (p : ℕ) : ℕ :=
  endpointNumerator
    (factorialBlockCoefficient p)
    (factorialBlockBase p)
    (factorialBlockIndices p)
    factorialGapDenominator

/-- Literal least private-modulus residue `ρ_p`. -/
noncomputable def factorialBlockPrivateResidue (p : ℕ) : ℕ :=
  endpointPrivateResidue
    (factorialBlockCoefficient p)
    (factorialBlockBase p)
    (factorialBlockIndices p)
    factorialGapDenominator

















/-- Exact scale `2p²(2p-1)!` in the endpoint comparison. -/
def factorialBlockScale (p : ℕ) : ℕ :=
  2 * p ^ 2 * (2 * p - 1).factorial

/-- Exact budget numerator `2p+1` in the endpoint upper bound. -/
def factorialBlockBudget (p : ℕ) : ℕ :=
  2 * p + 1

/-- Literal rational endpoint gap
`K_{p-1}/(p-1)! - s_{2p-1}`. -/
noncomputable def factorialBlockEndpointGap (p : ℕ) : ℚ :=
  (factorialBlockCoefficient p : ℚ) / factorialBlockBase p -
    factorialGapPrefix (2 * p - 1)

/-- Literal Archimedean endpoint allowance
`(2p+1)/(2p²(2p-1)!)`. -/
def factorialBlockEndpointUpperBound (p : ℕ) : ℚ :=
  (factorialBlockBudget p : ℚ) / factorialBlockScale p





/-- The exact positive endpoint window targeted by a full prime block. -/
def factorialBlockEndpointWindow (p : ℕ) : Prop :=
  0 < factorialBlockEndpointGap p ∧
    factorialBlockEndpointGap p ≤
      factorialBlockEndpointUpperBound p









/-! ## Normalized collision arithmetic in a factorial block -/





































































/-! ## Leave-one-out and factor-pair projection bounds -/

































/-! ## Prime-power incidence and uniquely supported factors -/



















































/-! ## Endpoint-window exclusions and conditional irrationality criteria -/































































end ErdosProblems.Erdos68
