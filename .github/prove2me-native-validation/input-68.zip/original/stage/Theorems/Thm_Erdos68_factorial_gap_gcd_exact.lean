import Definitions.Def_ErdosProblems_Erdos68_ChannelBreakpointRigidity
import Definitions.Def_ErdosProblems_Erdos68_ChannelIntegralCongruence
import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Algebra.GCDMonoid.FinsetLemmas
import Mathlib.Algebra.Ring.GeomSum
import Mathlib.Analysis.Asymptotics.Defs
import Mathlib.Analysis.Complex.ExponentialBounds
import Mathlib.Analysis.Real.Pi.Bounds
import Mathlib.Analysis.SpecialFunctions.Stirling
import Mathlib.Data.Nat.Factorial.Basic
import Mathlib.Data.Nat.Factorial.BigOperators
import Mathlib.Data.Nat.ModEq
import Mathlib.Tactic.Ring

/-!
# Integral channel congruence for Erdős problem 68

This module compares a channel numerator with the corresponding factorial
moment modulo `d! - 1`.  The congruence holds for every support index, so
simultaneous cancellation of the channels `2, ..., D` makes their least common
multiple divide the factorial moment.

The second part estimates that least common multiple.  Consecutive numbers
`m! - 1` are compared through their pairwise gcds; this gives an explicit
finite lower bound after the gcd losses are counted.  Consequently, if a
positive integer `M` is divisible by the channel lcm and is smaller than
`(R+1)! - 1`, then `R` must grow at least cubically along `D = 2t^2`.  A later
estimate improves the explicit constant to `R+1 > (3/2)t^3` for `t >= 2^32`.

All conclusions after the congruence theorem retain these stated hypotheses.
In particular, this file does not construct `M` or `R` from the series in
Erdős problem 68, prove that its channels vanish, or decide the rationality of
that series.
-/
















/-! ## Product versus lcm with explicit gcd loss -/











/-! ## Factorial-gap collision bounds -/







/-! ## Consecutive factorial-gap segments -/
























































































/-! Additive exact paper correspondence, source commit c129ac97dcbc6a8218ba5f736aeb525c1652f8a5. -/

open Erdos68

theorem Erdos68.factorial_gap_gcd_exact
    {m n : ℕ} (hm : 2 ≤ m) (hmn : m < n) :
    let g := Nat.gcd (m.factorial - 1) (n.factorial - 1)
    let Q := n.descFactorial (n - m)
    g ∣ Q - 1 ∧ g ≤ Q - 1 ∧ Q - 1 < n ^ (n - m) := by sorry
