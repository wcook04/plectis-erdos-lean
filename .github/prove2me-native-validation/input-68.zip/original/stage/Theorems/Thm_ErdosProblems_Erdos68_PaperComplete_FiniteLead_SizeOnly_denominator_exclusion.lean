import Definitions.Def_ErdosProblems_Erdos68_ChannelBreakpointRigidity
import Definitions.Def_ErdosProblems_Erdos68_ChannelIntegralCongruence
import Definitions.Def_ErdosProblems_Erdos68_PrimeUnitTranslator
import Definitions.Def_ErdosProblems_Erdos68_PaperCompleteKernelFloorAlgorithm
import Definitions.Def_ErdosProblems_Erdos68_FiniteLeadBlocks_Size000
import Definitions.Def_ErdosProblems_Erdos68_FiniteLeadBlocks_Size001
import Definitions.Def_ErdosProblems_Erdos68_PaperCompleteDyadicEnclosure
import Definitions.Def_ErdosProblems_Erdos68_PaperCompleteFiniteLeadArithmetic
import Definitions.Def_ErdosProblems_Erdos68_PaperCompleteFiniteSizeData
import Init
import Mathlib.Algebra.BigOperators.Fin
import Mathlib.Algebra.BigOperators.Group.Finset.Basic
import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Algebra.GCDMonoid.FinsetLemmas
import Mathlib.Algebra.Order.BigOperators.Group.Finset
import Mathlib.Algebra.Order.Field.Basic
import Mathlib.Algebra.Order.Round
import Mathlib.Algebra.Ring.GeomSum
import Mathlib.Analysis.Asymptotics.Defs
import Mathlib.Analysis.Complex.ExponentialBounds
import Mathlib.Analysis.Real.Pi.Bounds
import Mathlib.Analysis.SpecialFunctions.Stirling
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Data.Fin.VecNotation
import Mathlib.Data.Nat.Factorial.Basic
import Mathlib.Data.Nat.Factorial.BigOperators
import Mathlib.Data.Nat.ModEq
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.LinearAlgebra.Matrix.Adjugate
import Mathlib.LinearAlgebra.Vandermonde
import Mathlib.Order.Interval.Finset.Nat
import Mathlib.Tactic
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.FinCases
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.InfiniteSum.Basic
import Mathlib.Topology.Algebra.InfiniteSum.Ring

namespace ErdosProblems.Erdos68.PaperComplete.FiniteLead.SizeOnly
end ErdosProblems.Erdos68.PaperComplete.FiniteLead.SizeOnly

/-!
# Size-only finite denominator certificate

This branch preserves the returned 80000-bit interval and Farey witnesses,
without importing the 300005-term grid computation. The two floor-block
leaves and each finite comparison below must elaborate before any numerical
exclusion is established. No certificate predicate is assumed by the final
theorem. These source candidates have not yet been kernel checked.
-/

set_option maxRecDepth 1000000
set_option maxHeartbeats 0

open ErdosProblems.Erdos68.PaperComplete.FiniteLead.SizeOnly

theorem ErdosProblems.Erdos68.PaperComplete.FiniteLead.SizeOnly.denominator_exclusion
    (a : ℤ) (q : ℕ) (hq : 0 < q)
    (hS : _root_.Erdos68.factorialGapSeries = (a : ℝ) / q) :
    (2 : ℕ) ^ 39990 ≤ q ∧
      sizeFarey.leftDen + sizeFarey.rightDen ≤ q ∧ (10 : ℕ) ^ 12040 < q := by sorry
