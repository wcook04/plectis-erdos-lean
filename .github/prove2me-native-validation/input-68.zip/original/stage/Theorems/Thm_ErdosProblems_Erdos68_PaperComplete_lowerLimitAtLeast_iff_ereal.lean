import Definitions.Def_ErdosProblems_Erdos68_ChannelBreakpointRigidity
import Definitions.Def_ErdosProblems_Erdos68_ChannelIntegralCongruence
import Definitions.Def_ErdosProblems_Erdos68_PaperCompleteAsymptotics
import Definitions.Def_ErdosProblems_Erdos68_PaperCompleteRadiusLimit
import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Algebra.GCDMonoid.FinsetLemmas
import Mathlib.Algebra.Ring.GeomSum
import Mathlib.Analysis.Asymptotics.Defs
import Mathlib.Analysis.Complex.ExponentialBounds
import Mathlib.Analysis.Real.Pi.Bounds
import Mathlib.Analysis.SpecialFunctions.Log.Basic
import Mathlib.Analysis.SpecialFunctions.Pow.Real
import Mathlib.Analysis.SpecialFunctions.Sqrt
import Mathlib.Analysis.SpecialFunctions.Stirling
import Mathlib.Data.EReal.Basic
import Mathlib.Data.Nat.Factorial.Basic
import Mathlib.Data.Nat.Factorial.BigOperators
import Mathlib.Data.Nat.ModEq
import Mathlib.Order.LiminfLimsup
import Mathlib.Tactic
import Mathlib.Tactic.Ring
import Mathlib.Topology.Order.Basic

/-!
# Literal liminf statements, without silently assuming finite liminf values

The displayed asymptotic theorems allow the value +infinity. The wrappers use
EReal for the liminf and prove equivalence with the epsilon/eventual assertions
in the main proof files. Thus no unproved upper-boundedness assumption is
introduced merely to fit a real-valued liminf API.

-/

open Filter
open scoped Topology

open ErdosProblems.Erdos68.PaperComplete

theorem ErdosProblems.Erdos68.PaperComplete.lowerLimitAtLeast_iff_ereal (f : ℕ → ℝ) (c : ℝ) :
    LowerLimitAtLeast f c ↔
      (c : EReal) ≤ Filter.liminf (fun n : ℕ => (f n : EReal)) atTop := by sorry
