import Definitions.Def_ErdosProblems_Erdos68_ChannelBreakpointRigidity
import Definitions.Def_ErdosProblems_Erdos68_ChannelIntegralCongruence
import Definitions.Def_ErdosProblems_Erdos68_PrimeUnitTranslator
import Definitions.Def_ErdosProblems_Erdos68_PaperCompleteDyadicEnclosure
import Mathlib.Algebra.BigOperators.Fin
import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Algebra.GCDMonoid.FinsetLemmas
import Mathlib.Algebra.Order.BigOperators.Group.Finset
import Mathlib.Algebra.Order.Field.Basic
import Mathlib.Algebra.Order.Round
import Mathlib.Algebra.Ring.GeomSum
import Mathlib.Analysis.Asymptotics.Defs
import Mathlib.Analysis.Complex.ExponentialBounds
import Mathlib.Analysis.Real.Pi.Bounds
import Mathlib.Analysis.SpecialFunctions.Stirling
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Data.Fin.VecNotation
import Mathlib.Data.Nat.Factorial.Basic
import Mathlib.Data.Nat.Factorial.BigOperators
import Mathlib.Data.Nat.ModEq
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.LinearAlgebra.Matrix.Adjugate
import Mathlib.LinearAlgebra.Vandermonde
import Mathlib.Tactic
import Mathlib.Tactic.FinCases
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.InfiniteSum.Basic
import Mathlib.Topology.Algebra.InfiniteSum.Ring

/-!
# Round 8: finite dyadic enclosure interface for the actual factorial-gap series

No numerical target is assumed to be true in this file. `DyadicData.Valid` is a
finite integer predicate: a floor-sum equality and an explicit upper endpoint.
The analytic soundness proof uses the inherited positive tail and the bound
`factorialGapTail N < 1/N!`. This deliberately gives the slightly wider 80000-bit
interval of width 7056, rather than the historical interval of width 7053.
The returned Farey certificate is checked against the wider interval.

Status: proof text, not elaborated in the return environment.
Mathlib source pin: 5e932f97dd25535344f80f9dd8da3aab83df0fe6.
-/


open scoped BigOperators

open ErdosProblems.Erdos68.PaperComplete.FiniteLead

theorem ErdosProblems.Erdos68.PaperComplete.FiniteLead.DyadicData.sound {c : DyadicData} (hc : c.Valid) :
    (c.lower : ℝ) / ((2 ^ c.bits : ℕ) : ℝ) < _root_.Erdos68.factorialGapSeries ∧
    _root_.Erdos68.factorialGapSeries < (c.upper : ℝ) / ((2 ^ c.bits : ℕ) : ℝ) := by sorry
