import Definitions.Def_ErdosProblems_Erdos68_ChannelBreakpointRigidity
import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Data.Nat.Factorial.Basic

/-!
# Channel breakpoint rigidity for Erdős problem 68

For a finite coefficient family whose indices all lie in one quotient band
`[k d, (k + 1) d)`, every factorial coefficient is the same fixed multiple
`(d!)^k` of its `d`-channel coefficient.  Hence cancellation of that channel
forces cancellation of the factorial moment.  In the first band, a nonzero
factorial moment together with channel cancellation requires at least one
support index to reach the breakpoint `2d`.

The namespace `Erdos68` is the finite-family presentation; it is distinct
from the Finsupp presentation in `ErdosProblems.Erdos68`.  No declaration
constructs a cancelling coefficient family, treats several channels
simultaneously, estimates a residual, or decides rationality of the #68
series.
-/

open Erdos68

theorem Erdos68.channel_coefficient_band
    {d i k : ℕ} (hlo : k * d ≤ i) (hhi : i < (k + 1) * d) :
    d.factorial ^ k * (i.factorial / d.factorial ^ (i / d)) = i.factorial := by sorry
