import Definitions.Def_ErdosProblems_Erdos68_ChannelBreakpointRigidity
import Definitions.Def_ErdosProblems_Erdos68_ChannelIntegralCongruence
import Definitions.Def_ErdosProblems_Erdos68_PrimeUnitTranslator
import Definitions.Def_ErdosProblems_Erdos68_PaperCompleteKernelFloorAlgorithm
import Definitions.Def_ErdosProblems_Erdos68_FiniteLeadBlocks_Size000
import Definitions.Def_ErdosProblems_Erdos68_FiniteLeadBlocks_Size001
import Definitions.Def_ErdosProblems_Erdos68_PaperCompleteDyadicEnclosure
import Definitions.Def_ErdosProblems_Erdos68_PaperCompleteFiniteLeadArithmetic
import Definitions.Def_ErdosProblems_Erdos68_PaperCompleteFiniteSizeData
import Init
import Mathlib.Algebra.BigOperators.Fin
import Mathlib.Algebra.BigOperators.Group.Finset.Basic
import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Algebra.GCDMonoid.FinsetLemmas
import Mathlib.Algebra.Order.BigOperators.Group.Finset
import Mathlib.Algebra.Order.Field.Basic
import Mathlib.Algebra.Order.Round
import Mathlib.Algebra.Ring.GeomSum
import Mathlib.Analysis.Asymptotics.Defs
import Mathlib.Analysis.Complex.ExponentialBounds
import Mathlib.Analysis.Real.Pi.Bounds
import Mathlib.Analysis.SpecialFunctions.Stirling
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Data.Fin.VecNotation
import Mathlib.Data.Nat.Factorial.Basic
import Mathlib.Data.Nat.Factorial.BigOperators
import Mathlib.Data.Nat.ModEq
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.LinearAlgebra.Matrix.Adjugate
import Mathlib.LinearAlgebra.Vandermonde
import Mathlib.Order.Interval.Finset.Nat
import Mathlib.Tactic
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.FinCases
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.Ring
import Mathlib.Topology.Algebra.InfiniteSum.Basic
import Mathlib.Topology.Algebra.InfiniteSum.Ring

/-! Compose proved adjacent blocks and check the final addition of their witnesses.
There is no trusted certificate hypothesis in this theorem. Compilation has not
been performed in the return environment.
-/
set_option maxRecDepth 1000000
set_option maxHeartbeats 0

open ErdosProblems.Erdos68.PaperComplete.FiniteLead

theorem ErdosProblems.Erdos68.PaperComplete.FiniteLead.size_floorPrefix_checked :
    floorPrefix (2 ^ 80000) 7053 = sizeLower := by sorry
