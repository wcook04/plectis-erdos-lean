import Definitions.Def_ErdosProblems_Erdos68_ChannelBreakpointRigidity
import Definitions.Def_ErdosProblems_Erdos68_ChannelIntegralCongruence
import Definitions.Def_ErdosProblems_Erdos68_PaperCompleteAsymptotics
import Definitions.Def_ErdosProblems_Erdos68_PaperCompleteRadiusLimit
import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Algebra.GCDMonoid.FinsetLemmas
import Mathlib.Algebra.Ring.GeomSum
import Mathlib.Analysis.Asymptotics.Defs
import Mathlib.Analysis.Complex.ExponentialBounds
import Mathlib.Analysis.Real.Pi.Bounds
import Mathlib.Analysis.SpecialFunctions.Log.Basic
import Mathlib.Analysis.SpecialFunctions.Sqrt
import Mathlib.Analysis.SpecialFunctions.Stirling
import Mathlib.Data.Nat.Factorial.Basic
import Mathlib.Data.Nat.Factorial.BigOperators
import Mathlib.Data.Nat.ModEq
import Mathlib.Tactic
import Mathlib.Tactic.Ring
import Mathlib.Topology.Order.Basic

/-!
# The sharp 16/9 radius constant

Long-record label res:radius-constant. Hypotheses are eventual, exactly as on
paper. The proof uses the actual optimised factorial segment, proves its
square-subsequence limiting scale, and rules out every subcritical radius.
It does not replace 16/9 by the already compiled finite 3/2 bound.

STATUS: compiled end-to-end proof candidate; no new axioms or placeholders.
-/

open Filter
open scoped Topology

open ErdosProblems.Erdos68.PaperComplete

theorem ErdosProblems.Erdos68.PaperComplete.asymptotic_radius_constant (M R : ℕ → ℕ)
    (hH : ∀ᶠ t : ℕ in atTop,
      0 < M t ∧ _root_.Erdos68.channelLCM (2 * t ^ 2) ∣ M t ∧
      M t < (R t + 1).factorial - 1) :
    LowerLimitAtLeast (fun t : ℕ => ((R t + 1 : ℕ) : ℝ) / (t : ℝ) ^ 3)
      ((16 : ℝ) / 9) := by sorry
