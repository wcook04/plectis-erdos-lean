import Definitions.Def_ErdosProblems_Erdos68_PaperCompleteKernelFloorAlgorithm
import Definitions.Def_ErdosProblems_Erdos68_FiniteLeadBlocks_Size001
import Init

/-! Generated untrusted witness, followed by an ordinary kernel computation.
The result below is NOT imported from C++ or from a Boolean log entry.
Lean v4.29.1 src/Lean/Elab/Tactic/Decide.lean implements `decide +kernel`
by adding and kernel-checking the complete decidable proof, without native trust.
This source was generated but could not be compiled in the return environment.
-/
set_option maxRecDepth 1000000
set_option maxHeartbeats 0

open ErdosProblems.Erdos68.PaperComplete.FiniteLead.KernelBlocks.Size001

theorem ErdosProblems.Erdos68.PaperComplete.FiniteLead.KernelBlocks.Size001.checked : kernelFloorBlock (2 ^ 80000) 4098 2956 = value := by sorry
