"""Pinned Lake environment and bounded Lean execution shared by packet runners."""
from __future__ import annotations
import hashlib
import json
import math
import os
from pathlib import Path
import signal
import subprocess
import sys
import time


class RuntimeError(ValueError):
    pass


def library_roots(cache: Path, binary: Path) -> tuple[list[Path], dict]:
    """Ask this toolchain's Lake for transitive roots; never guess package names."""
    cache, binary = cache.resolve(), binary.resolve()
    lake = binary.with_name('lake')
    if not lake.is_file() or not os.access(lake, os.X_OK):
        raise RuntimeError('pinned Lake executable is missing')
    env = {k: v for k, v in os.environ.items() if k not in ('LEAN_PATH', 'LEAN_SRC_PATH')}
    command = [str(lake), 'env', sys.executable, '-c',
               'import json,os; print(json.dumps(os.environ.get("LEAN_PATH", "")))']
    result = subprocess.run(command, cwd=cache, env=env, capture_output=True, text=True, timeout=60)
    if result.returncode:
        raise RuntimeError('Lake environment resolution failed: ' + result.stderr[-4000:])
    try:
        raw = json.loads(result.stdout)
    except ValueError as exc:
        raise RuntimeError('Lake environment output is not valid JSON') from exc
    if not isinstance(raw, str) or not raw or any(not part for part in raw.split(os.pathsep)):
        raise RuntimeError('Lake returned an empty or ambiguous LEAN_PATH')
    roots = []
    toolchain_root = binary.parent.parent / 'lib/lean'
    for part in raw.split(os.pathsep):
        path = Path(part)
        path = (cache / path).resolve() if not path.is_absolute() else path.resolve()
        if not path.is_relative_to(cache) and path != toolchain_root:
            raise RuntimeError('Lake library root escapes pinned checkout/toolchain: ' + str(path))
        if not path.is_dir():
            raise RuntimeError('Lake library root is missing: ' + str(path))
        if path not in roots:
            roots.append(path)
    digest = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
    return roots, {'resolver': 'pinned_lake_env', 'lake_sha256': digest(lake),
                   'manifest_sha256': digest(cache / 'lake-manifest.json'),
                   'toolchain_sha256': digest(cache / 'lean-toolchain'),
                   'library_roots': [str(p) for p in roots]}


def stop_group(process):
    try: os.killpg(process.pid, signal.SIGTERM)
    except ProcessLookupError: pass
    try: process.wait(timeout=1)
    except subprocess.TimeoutExpired: pass
    # Descendants may survive after the direct child exits.
    try: os.killpg(process.pid, signal.SIGKILL)
    except ProcessLookupError: pass
    process.wait(timeout=5)


def run_logged(command: list[str], *, cwd: Path, env: dict, stdout: Path,
               stderr: Path, timeout: float) -> dict:
    if not math.isfinite(timeout) or timeout <= 0:
        raise RuntimeError('execution budget must be finite and positive')
    deadline = env.get('P2M_DEADLINE_EPOCH')
    if deadline is not None:
        if not math.isfinite(float(deadline)):
            raise RuntimeError('shared deadline must be finite')
        timeout = min(timeout, float(deadline) - time.time())
    if timeout <= 0:
        raise RuntimeError('shared execution deadline exhausted before launch')
    started = time.monotonic()
    timed_out = False
    with stdout.open('xb') as out, stderr.open('xb') as err:
        process = subprocess.Popen(command, cwd=cwd, env=env, stdout=out, stderr=err,
                                   start_new_session=True)
        try:
            process.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            timed_out = True
            stop_group(process)
        except BaseException:
            stop_group(process)
            raise
    return {'exit_code': process.returncode, 'timed_out': timed_out,
            'timeout_seconds': timeout, 'elapsed_seconds': round(time.monotonic()-started, 3)}
