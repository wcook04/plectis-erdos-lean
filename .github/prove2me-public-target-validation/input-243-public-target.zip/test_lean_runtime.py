import json
import os
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch
from lean_runtime import RuntimeError, library_roots, run_logged


class LeanRuntimeTests(unittest.TestCase):
    def environment(self, root, values):
        cache = root / 'cache'; cache.mkdir()
        (cache/'lake-manifest.json').write_text('{}')
        (cache/'lean-toolchain').write_text('leanprover/lean4:v4.30.0')
        binary = root/'toolchain/bin/lean'; binary.parent.mkdir(parents=True)
        binary.write_text('placeholder')
        lake = binary.with_name('lake')
        lake.write_text('#!'+sys.executable+'\nimport json,os\nassert "LEAN_PATH" not in os.environ\nprint(json.dumps('+repr(os.pathsep.join(values))+'))\n')
        lake.chmod(0o755)
        return cache,binary

    def test_complete_transitive_environment_preserves_order_and_ignores_ambient(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp).resolve()
            values=['.lake/packages/mathlib/.lake/build/lib/lean','.lake/packages/batteries/.lake/build/lib/lean','.lake/build/lib/lean']
            cache,binary=self.environment(root,values)
            for v in values: (cache/v).mkdir(parents=True)
            with patch.dict(os.environ,{'LEAN_PATH':'/untrusted'}):
                roots,receipt=library_roots(cache,binary)
            self.assertEqual(roots,[cache/v for v in values])
            self.assertEqual(receipt['resolver'],'pinned_lake_env')

    def test_empty_and_escaping_roots_fail_closed(self):
        for values in [[''],['../escape']]:
            with self.subTest(values=values),tempfile.TemporaryDirectory() as tmp:
                root=Path(tmp).resolve(); (root/'escape').mkdir()
                cache,binary=self.environment(root,values)
                with self.assertRaises(RuntimeError):library_roots(cache,binary)

    def test_timeout_preserves_partial_output(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp)
            result=run_logged([sys.executable,'-c','import time; print("before timeout",flush=True); time.sleep(10)'],cwd=root,env=dict(os.environ),stdout=root/'out',stderr=root/'err',timeout=1)
            self.assertTrue(result['timed_out'])
            self.assertIn('before timeout',(root/'out').read_text())

    def test_exhausted_shared_deadline_prevents_launch(self):
        with tempfile.TemporaryDirectory() as tmp, patch('lean_runtime.subprocess.Popen') as process:
            root=Path(tmp)
            with self.assertRaisesRegex(RuntimeError,'deadline exhausted'):
                run_logged(['no-launch'],cwd=root,env={'P2M_DEADLINE_EPOCH':'1'},stdout=root/'out',stderr=root/'err',timeout=1)
            process.assert_not_called()

    def test_unbuilt_optional_package_root_is_preserved_and_reported(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp).resolve()
            values = ['.lake/packages/Cli/.lake/build/lib/lean',
                      '.lake/packages/batteries/.lake/build/lib/lean',
                      '.lake/build/lib/lean']
            cache, binary = self.environment(root, values)
            (cache / values[1]).mkdir(parents=True)
            roots, receipt = library_roots(cache, binary)
            self.assertEqual(roots, [cache / v for v in values])
            self.assertEqual(receipt['absent_search_roots'],
                             [str(cache / values[i]) for i in (0, 2)])
            self.assertEqual(receipt['import_validation'], 'pending_compiler_probe')
            self.assertFalse((cache / values[0]).exists())

    def test_file_or_escaping_symlink_in_search_path_fails_closed(self):
        for symlink in (False, True):
            with self.subTest(symlink=symlink), tempfile.TemporaryDirectory() as tmp:
                root = Path(tmp).resolve()
                cache, binary = self.environment(root, ['bad'])
                if symlink:
                    (root / 'external').mkdir()
                    (cache / 'bad').symlink_to(root / 'external', target_is_directory=True)
                else:
                    (cache / 'bad').write_text('not a directory')
                with self.assertRaises(RuntimeError): library_roots(cache, binary)


@unittest.skipUnless(os.environ.get('P2M_TEST_LEAN_BINARY'), 'explicit pinned toolchain conformance lane')
class RealLakeConformanceTests(unittest.TestCase):
    def test_real_lake_advertises_unbuilt_roots_but_only_required_imports_fail(self):
        import subprocess
        binary = Path(os.environ['P2M_TEST_LEAN_BINARY']).resolve()
        lake = binary.with_name('lake')
        with tempfile.TemporaryDirectory() as tmp:
            cache = Path(tmp).resolve()
            (cache / 'lean-toolchain').write_text('leanprover/lean4:v4.30.0\n')
            (cache / 'lakefile.toml').write_text('name = "runtime_fixture"\n[[require]]\nname = "Cli"\npath = "packages/Cli"\n')
            dependency = cache / 'packages/Cli'; dependency.mkdir(parents=True)
            (dependency / 'lakefile.toml').write_text('name = "Cli"\n[[lean_lib]]\nname = "Cli"\n')
            result = subprocess.run([str(lake), 'update'], cwd=cache, capture_output=True, text=True, timeout=30)
            self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
            roots, receipt = library_roots(cache, binary)
            self.assertIn(str(dependency / '.lake/build/lib/lean'), receipt['absent_search_roots'])
            env = dict(os.environ, LEAN_PATH=os.pathsep.join(map(str, roots)))
            for module, succeeds in [('Lean', True), ('Cli', False)]:
                source = cache / (module + 'Probe.lean'); source.write_text('import ' + module + '\n')
                result = run_logged([str(binary), source.name], cwd=cache, env=env,
                    stdout=cache / (module + '.stdout'), stderr=cache / (module + '.stderr'), timeout=30)
                self.assertEqual(result['exit_code'] == 0, succeeds)
                if not succeeds:
                    self.assertIn('Cli', (cache / (module + '.stdout')).read_text())
