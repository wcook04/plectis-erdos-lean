#!/usr/bin/env python3
"""Independently elaborate three fresh #243 proofs in their public contexts.

Run only in a pinned Lean/Mathlib checkout. This never calls Prove2Me and does
not substitute for production validation of the full aliased native graph.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import signal
from pathlib import Path


HERE = Path(__file__).resolve().parent
if not (HERE / 'lean_runtime.py').is_file():
    sys.path.insert(0, str(HERE.parents[2] / 'native/remote_validation'))
from lean_runtime import library_roots, run_logged

ALLOWED_AXIOMS = {"propext", "Classical.choice", "Quot.sound"}
PREFIX = "P2M_PUBLIC_TARGET "
PINNED_SOURCE = "fbf41fb8b571d217b1648070dcc39d5eda5394ad"
IDENT = re.compile(r"[A-Za-z_][A-Za-z0-9_]*(?:\.[A-Za-z_][A-Za-z0-9_]*)*\Z")
UNIVERSE = re.compile(r"(?<![\w.])u_[0-9]+\b")


class ValidationError(ValueError):
    pass


class LeanActionError(ValidationError):
    def __init__(self, message, row):
        super().__init__(message)
        self.row = row


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def canonical_type(value: str) -> str:
    names: dict[str, str] = {}
    return UNIVERSE.sub(lambda match: names.setdefault(match.group(), f"u_{len(names)}"), value)


def checked_json(path: Path) -> dict:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValidationError(f"expected JSON object: {path}")
    return value


def check_packet() -> dict:
    requirements = checked_json(HERE / "target_validation_requirements.json")
    offline = checked_json(HERE / "public_context_packet_check.json")
    if (requirements.get("schema") != "prove2me243_existing_id_target_validation_requirements_v1"
            or offline.get("schema") != "prove2me243_public_context_packet_check_v1"
            or offline.get("status") != "offline_exact_bytes_passed_no_lean_execution"
            or requirements.get("source_commit") != PINNED_SOURCE
            or set(requirements.get("targets", {})) != set(offline.get("targets", {}))):
        raise ValidationError("public target packet identity changed")
    if sha((HERE / "public_target_readback.json").read_bytes()) != requirements.get("public_target_readback_sha256"):
        raise ValidationError("authenticated public target readback changed")
    targets = requirements["targets"]
    if len(targets) != 3 or len(set(t["theorem_id"] for t in targets.values())) != 3:
        raise ValidationError("expected exactly three distinct public theorem IDs")
    for name, row in targets.items():
        if not IDENT.fullmatch(name):
            raise ValidationError("invalid target constant")
        for key, hash_key in (("public_target_file", "public_target_file_sha256"),
                              ("public_context_solution_file", "public_context_solution_sha256")):
            relative = row[key]
            path = (HERE / relative).resolve()
            if not path.is_relative_to((HERE / "public_target_context").resolve()) or not path.is_file():
                raise ValidationError("public context path escaped or vanished")
            if sha(path.read_bytes()) != row[hash_key]:
                raise ValidationError(f"public context file changed: {relative}")
        if offline["targets"].get(name, {}).get("exact_solution_body_sha256") != row["exact_solution_body_sha256"]:
            raise ValidationError("fresh proof body binding changed")
    for filename, expected in offline["historical_public_definition_sha256"].items():
        path = HERE / "public_target_context" / "Definitions" / filename
        if path.name != filename or sha(path.read_bytes()) != expected:
            raise ValidationError("historical public Definition changed")
    return requirements


def query_text(module: str, constant: str, role: str) -> bytes:
    if not IDENT.fullmatch(module) or not IDENT.fullmatch(constant):
        raise ValidationError("invalid Lean query identifier")
    return (f"import Lean\nimport {module}\nopen Lean\n"
            "set_option pp.universes true\nset_option pp.fullNames true\n"
            "set_option pp.notation false\nset_option pp.explicit true\n"
            "run_meta do\n"
            f"  let name := `{constant}\n"
            "  let ci ← getConstInfo name\n"
            "  let typeFmt ← Lean.Meta.ppExpr ci.type\n"
            "  let axioms ← collectAxioms name\n"
            "  let record := Json.mkObj [(\"type\", Json.str typeFmt.pretty), "
            "(\"axioms\", toJson (axioms.toList.map (fun n => n.toString)))]\n"
            f"  IO.println (\"{PREFIX}{role} \" ++ record.compress)\n").encode()


def run_lean(binary: Path, stage: Path, roots: list[Path], out: Path,
             relative: str, label: str, timeout: int, olean: bool) -> dict:
    env = os.environ.copy()
    env["LEAN_PATH"] = os.pathsep.join([str(out / "oleans"), *(str(r) for r in roots)])
    output = out / "oleans" / Path(relative).with_suffix(".olean")
    if olean:
        output.parent.mkdir(parents=True, exist_ok=True)
    command = [str(binary)] + (["-o", str(output)] if olean else []) + [relative]
    stdout, stderr = out / f"{label}.stdout", out / f"{label}.stderr"
    result = run_logged(command, cwd=stage, env=env, stdout=stdout,
                        stderr=stderr, timeout=timeout)
    row = {"label": label, "source": relative, "source_sha256": sha((stage / relative).read_bytes()),
           **result, "stdout_sha256": sha(stdout.read_bytes()),
           "stderr_sha256": sha(stderr.read_bytes()), "command": command}
    if result['exit_code'] != 0 or result['timed_out']:
        detail = (stdout.read_bytes()[-4096:] + stderr.read_bytes()[-4096:]).decode('utf-8', errors='replace')
        raise LeanActionError(f"Lean failed at {label}; timed_out={result['timed_out']}: {detail}", row)
    if olean:
        row["olean_sha256"] = sha(output.read_bytes())
    return row


def parse_query(output: bytes, role: str) -> dict:
    lines = [line for line in output.decode("utf-8").splitlines()
             if line.startswith(f"{PREFIX}{role} ")]
    if len(lines) != 1:
        raise ValidationError("Lean did not emit exactly one type/axiom record")
    row = json.loads(lines[0][len(f"{PREFIX}{role} "):])
    if (not isinstance(row.get("type"), str) or not row["type"]
            or not isinstance(row.get("axioms"), list)
            or any(not isinstance(a, str) for a in row["axioms"])):
        raise ValidationError("malformed Lean type/axiom record")
    return row


def validate(source: Path, cache: Path, binary: Path, roots: list[Path], out: Path, timeout: int) -> dict:
    if out.exists():
        raise ValidationError("output must be fresh")
    out.mkdir(parents=True)
    rows = []
    receipt = {'schema': 'prove2me_existing_theorem_public_context_build_v1',
               'status': 'running', 'actions': rows, 'target_results': {},
               'hosted_post_allowed': False}
    try:
        packet = check_packet()
        for checkout in (source, cache):
            if subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=checkout, text=True).strip() != PINNED_SOURCE:
                raise ValidationError("source or cache checkout differs from pinned commit")
            if subprocess.check_output(["git", "status", "--porcelain", "--untracked-files=no"],
                                       cwd=checkout):
                raise ValidationError("source or cache checkout has tracked modifications")
        toolchain = (source / "lean-toolchain").read_text().strip()
        match = re.fullmatch(r"leanprover/lean4:v(\d+\.\d+\.\d+)", toolchain)
        version = subprocess.check_output([str(binary), "--version"], text=True).strip()
        if not match or not re.search(r"\bversion " + re.escape(match.group(1)) + r"\b", version):
            raise ValidationError("Lean binary differs from pinned source toolchain")
        resolved_roots, environment = library_roots(cache, binary)
        if any(root.resolve() not in resolved_roots for root in roots):
            raise ValidationError("explicit library root is outside Lake's pinned environment")
        roots = resolved_roots
        (out / "oleans").mkdir()
        stage = out / "stage"
        shutil.copytree(HERE / "public_target_context", stage)
        receipt.update({"schema": "prove2me_existing_theorem_public_context_build_v1",
                   "status": "running", "source_commit": PINNED_SOURCE,
                   "requirements_sha256": sha((HERE / "target_validation_requirements.json").read_bytes()),
                   "offline_packet_sha256": sha((HERE / "public_context_packet_check.json").read_bytes()),
                   "runner_sha256": sha(Path(__file__).read_bytes()),
                   "lean_binary_sha256": sha(binary.read_bytes()), "lean_version": version,
                   "cache_commit": PINNED_SOURCE,
                   "library_roots": [str(root) for root in roots], "actions": rows,
                   "target_results": {}, "hosted_post_allowed": False, "environment": environment})
        smoke = stage / 'runtime_import_check.lean'
        smoke.write_text('import Mathlib\n')
        rows.append(run_lean(binary, stage, roots, out, smoke.name,
                             'runtime_import_check', min(timeout, 120), False))
        for filename in ("Def_ErdosProblems_Erdos243_PaperCompleteR7_RealTail.lean",
                         "Def_ErdosProblems_Erdos243_PaperCompleteR7_CanonicalState.lean"):
            rows.append(run_lean(binary, stage, roots, out, f"Definitions/{filename}",
                                 filename.removesuffix(".lean"), timeout, True))
        for index, (name, target) in enumerate(sorted(packet["targets"].items())):
            for role, relative in (("target", target["public_target_file"]),
                                   ("solution", target["public_context_solution_file"])):
                rows.append(run_lean(binary, stage, roots, out, relative.removeprefix("public_target_context/"),
                                     f"{index}_{role}", timeout, True))
                module = relative.removeprefix("public_target_context/").removesuffix(".lean").replace("/", ".")
                constant = name if role == "target" else "solution"
                query = f"audit_{index}_{role}.lean"
                (stage / query).write_bytes(query_text(module, constant, role))
                try:
                    rows.append(run_lean(binary, stage, roots, out, query,
                                         f"{index}_{role}_audit", timeout, False))
                    parsed = parse_query((out / f"{index}_{role}_audit.stdout").read_bytes(), role)
                finally:
                    (stage / query).unlink(missing_ok=True)
                receipt["target_results"].setdefault(name, {})[role] = parsed
            evidence = receipt["target_results"][name]
            if (canonical_type(evidence["target"]["type"]) != canonical_type(evidence["solution"]["type"])
                    or not set(evidence["solution"]["axioms"]) <= ALLOWED_AXIOMS
                    or "sorryAx" not in evidence["target"]["axioms"]):
                raise ValidationError(f"public theorem proof type or axiom mismatch: {name}")
            evidence["theorem_id"] = target["theorem_id"]
            evidence["public_context_solution_sha256"] = target["public_context_solution_sha256"]
            evidence["exact_solution_body_sha256"] = target["exact_solution_body_sha256"]
        receipt["status"] = "passed_public_context_only"
    except BaseException as exc:
        if isinstance(exc, LeanActionError):
            rows.append(exc.row)
        receipt["status"] = "failed"
        receipt["error"] = str(exc)
        message = str(exc)[-8192:].replace('%', '%25').replace('\r', '%0D').replace('\n', '%0A')
        print('::error title=Public target validation::' + message, flush=True)
        raise
    finally:
        temporary = out / '.receipt.tmp'
        temporary.write_text(json.dumps(receipt, indent=2, sort_keys=True) + "\n")
        temporary.replace(out / 'public_context_build_receipt.json')
    return receipt


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--check-packet", action="store_true")
    parser.add_argument("--source", type=Path)
    parser.add_argument("--cache", type=Path)
    parser.add_argument("--lean-binary", type=Path)
    parser.add_argument("--library-root", type=Path, action="append", default=[])
    parser.add_argument("--out", type=Path)
    parser.add_argument("--timeout-seconds", type=int, default=1800)
    args = parser.parse_args()
    if args.check_packet:
        packet = check_packet()
        print(json.dumps({'status': 'passed_offline_packet', 'targets': sorted(packet['targets']),
                          'hosted_post_allowed': False}))
        return
    if any(value is None for value in (args.source, args.cache, args.lean_binary, args.out)):
        parser.error('validation requires --source, --cache, --lean-binary and --out')
    signal.signal(signal.SIGTERM, lambda *_: (_ for _ in ()).throw(KeyboardInterrupt('terminated')))
    validate(args.source.resolve(), args.cache.resolve(), args.lean_binary.resolve(),
             [root.resolve() for root in args.library_root], args.out.resolve(), args.timeout_seconds)


if __name__ == "__main__":
    main()
